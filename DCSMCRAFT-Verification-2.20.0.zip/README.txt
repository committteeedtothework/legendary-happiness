DCSMCRAFT 2.20.0 verification
978 passing unit checks; 2 End browser checks; 8 Overworld/Titan browser regressions; packaged Linux Electron offline save/relaunch/import/export and Titan entry. Windows payloads verified; native Windows execution unverified.

Screenshots are staged in-game checkpoints, not a complete manual playthrough. See END.md and VALIDATION.md for limitations.
