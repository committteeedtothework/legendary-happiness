import {
  TITAN_CYLOOP,
  makeTitanCyloop,
  titanCyloopPosition,
} from "./titan-cyloop.js";
import {
  TITAN_DAMAGE,
  TITAN_ACTIONS,
  titanDamageConfig,
} from "./titan-combat.js";
import {
  point,
  distance,
  nearestTitanSurface,
  sweptTitanContact,
  constrainTitanBody,
  titanArmPath,
  titanAttackSide,
  closestSegment,
  titanBodyRegions,
} from "./titan-contact.js";
// Fixed-step arena simulation. No renderer, DOM, inventory or world mutation.
export const TITAN_DEFAULTS = Object.freeze({
  enabled: true,
  spawnChance: 0.32,
  cooldown: 900,
  particles: true,
  lighting: true,
  audio: true,
  music: true,
  difficulty: "normal",
  rings: 400,
  drain: 1,
  checkpoints: true,
  cinematics: true,
  strictParry: false,
  damage: TITAN_DAMAGE,
  healthMultiplier: 1,
  shadowQuality: "auto",
  postProcessing: true,
});
export function titanConfig(raw = {}) {
  const n = (k, a, b) =>
    Math.max(
      a,
      Math.min(b, Number.isFinite(+raw[k]) ? +raw[k] : TITAN_DEFAULTS[k]),
    );
  return {
    ...TITAN_DEFAULTS,
    ...Object.fromEntries(
      [
        "enabled",
        "particles",
        "lighting",
        "audio",
        "music",
        "checkpoints",
        "cinematics",
        "strictParry",
        "postProcessing",
      ].map((k) => [
        k,
        typeof raw[k] === "boolean" ? raw[k] : TITAN_DEFAULTS[k],
      ]),
    ),
    damage: titanDamageConfig(raw.damage),
    healthMultiplier: n("healthMultiplier", 0.5, 2),
    shadowQuality: ["auto", "off", "low", "high"].includes(raw.shadowQuality)
      ? raw.shadowQuality
      : "auto",
    spawnChance: n("spawnChance", 0, 1),
    cooldown: n("cooldown", 10, 7200),
    rings: Math.round(n("rings", 100, 999)),
    drain: n("drain", 0, 3),
    difficulty: ["easy", "normal", "hard"].includes(raw.difficulty)
      ? raw.difficulty
      : "normal",
  };
}
export const TITAN_ROUTE = [
  [0, 0, 78],
  [0, 5, 59],
  [12, 12, 43],
  [26, 20, 27],
  [32, 28, 9],
  [30, 36, -9],
  [22, 44, -25],
  [4, 52, -33],
  [-18, 60, -25],
  [-28, 68, -2],
  [-18, 76, 19],
  [-4, 84, 18],
  [0, 92, 0],
].map(([x, y, z]) => ({ x, y, z, w: 14 }));
export const TITAN_MOVES = Object.freeze({
  swat: {
    label: "SWATTING HAND · DODGE OR PARRY",
    tell: 1.25,
    strike: 0.55,
    recover: 3.2,
  },
  swing: {
    label: "LEFT ARM SWING",
    tell: 1.5,
    strike: 0.65,
    recover: 3.1,
    side: -1,
  },
  slap: {
    label: "RIGHT ARM SLAP",
    tell: 1.2,
    strike: 0.55,
    recover: 2.9,
    side: 1,
  },
  beam: {
    label: "MOUTH BEAM · STRUGGLE",
    tell: 1.8,
    strike: 4.5,
    recover: 3.8,
    qte: true,
  },
  crunch: {
    label: "GRAB AND CRUNCH",
    tell: 1.75,
    strike: 4.2,
    recover: 3.6,
    qte: true,
  },
});
const clamp = (v, a, b) => Math.max(a, Math.min(b, v)),
  dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z),
  lerp = (a, b, t) => a + (b - a) * t;
export const TITAN_CHEST = { x: 0, y: 57, z: 17 },
  TITAN_EMERALD = { x: 0, y: 95, z: 0 };

// Golden ring clusters are authored on the flat playable floor. Every cluster
// has a stable save ID, five visible rings, and a single atomic 10-ring award.
export const TITAN_RING_TRAILS = Array.from({ length: 36 }, (_, i) => {
  const row = Math.floor(i / 12),
    angle = ((i % 12) / 12) * Math.PI * 2 + row * 0.12;
  const radius = 35 + row * 28;
  return {
    id: i,
    x: Math.sin(angle) * radius,
    y: 1.25,
    z: Math.cos(angle) * radius,
    value: 10,
  };
});
export function collectTitanRings(s) {
  if (s.stage !== "traversal" || s.rings >= s.config.rings) return 0;
  s.ringPickups ||= [];
  let count = 0;
  for (const ring of TITAN_RING_TRAILS) {
    if (s.ringPickups.includes(ring.id)) continue;
    if (
      Math.hypot(
        s.avatar.x - ring.x,
        s.avatar.y + 1 - ring.y,
        s.avatar.z - ring.z,
      ) < 3.8
    ) {
      s.ringPickups.push(ring.id);
      s.rings = Math.min(s.config.rings, s.rings + ring.value);
      count += ring.value;
      emit(s, "ring", { count: ring.value, x: ring.x, y: ring.y, z: ring.z });
      if (s.rings >= s.config.rings) break;
    }
  }
  return count;
}

export function titanSession(config = {}, portalId = "trial") {
  const c = titanConfig(config),
    hp =
      { easy: 8000, normal: 12000, hard: 16000 }[c.difficulty] *
      c.healthMultiplier;
  return {
    schema: 1,
    id: portalId,
    stage: c.cinematics ? "intro" : "traversal",
    stageTime: 0,
    battleMusic: null,
    time: 0,
    config: c,
    avatar: {
      x: 0,
      y: 0.1,
      z: 78,
      vx: 0,
      vy: 0,
      vz: 0,
      yaw: 0,
      pitch: 0.1,
      onGround: true,
    },
    route: 0,
    emerald: false,
    checkpoint: "traversal",
    phase: 1,
    hp,
    maxHp: hp,
    rings: Math.min(80, c.rings),
    ringPickups: [],
    preparedRings: 0,
    balance: 3,
    strike: null,
    knockback: null,
    boosting: false,
    strikeSerial: 0,
    comboStep: 0,
    phantomRest: 0,
    staggerRest: 0,
    perfectCounter: false,
    attackAim: null,
    cinematicFrom: null,
    hitFeedback: null,
    energy: 100,
    combo: 0,
    comboTime: 0,
    phantom: 0,
    attack: "idle",
    attackTime: 0,
    sequence: 0,
    idle: 2.5,
    stagger: 0,
    iframes: 0,
    dodge: 0,
    action: "idle",
    actionTime: 0,
    parryAge: 0,
    parryHeld: false,
    qte: null,
    hitDone: false,
    cooldowns: { hit: 0, boom: 0, rush: 0, loop: 0, dodge: 0 },
    events: [],
    collected: [],
    counter: 0,
    pulseCooldown: 0,
    lock: true,
    won: false,
  };
}
const emit = (s, type, data = {}) => s.events.push({ type, ...data });
function change(s, stage) {
  s.stage = stage;
  s.stageTime = 0;
  if (["transform", "phase", "finale"].includes(stage))
    s.avatar.vx = s.avatar.vy = s.avatar.vz = 0;
  emit(s, "stage", { stage });
}
export function retryTitan(s) {
  const checkpoint = s.config.checkpoints ? s.checkpoint : "traversal",
    c = s.config,
    id = s.id,
    original = s.original,
    preparedRings = s.preparedRings;
  Object.assign(s, titanSession(c, id));
  s.original = original;
  s.checkpoint = checkpoint;
  if (checkpoint !== "traversal") {
    s.emerald = true;
    s.route = TITAN_ROUTE.length - 1;
    s.phase = checkpoint === "phase2" ? 2 : 1;
    s.hp = s.phase === 2 ? s.maxHp * 0.5 : s.maxHp;
    s.rings = Math.max(
      Math.min(180, s.config.rings),
      Math.min(s.config.rings, preparedRings || 0),
    );
    s.preparedRings = s.rings;
    startCombat(s);
  } else {
    s.stage = "traversal";
  }
  emit(s, "retry");
}
function startCombat(s) {
  change(s, "combat");
  const end = { x: 0, y: 68, z: 38 };
  // End the transformation at its continuous flight endpoint. Checkpoint
  // retries deliberately spawn at that same safe position.
  Object.assign(s.avatar, end, { vx: 0, vy: 0, vz: 0, onGround: false });
  s.strike = null;
  s.action = "idle";
  s.actionTime = 0;
  s.cinematicFrom = null;
  s.attack = "idle";
  s.attackTime = 0;
  s.idle = 2.5;
  s.iframes = 1;
  s.preparedRings = Math.max(s.preparedRings || 0, s.rings);
  s.energy = 100;
}
export function skipTitanCinematic(s) {
  if (["intro", "transform", "phase", "finale"].includes(s.stage)) {
    s.strike = null;
    s.qte = null;
    s.action = "idle";
    s.actionTime = 0;
  }
  if (s.stage === "intro") change(s, "traversal");
  else if (s.stage === "transform") startCombat(s);
  else if (s.stage === "phase") {
    change(s, "combat");
    s.attack = "idle";
    s.idle = 2.5;
    s.strike = null;
    s.action = "idle";
    s.actionTime = 0;
    s.iframes = 1;
  } else if (s.stage === "finale") {
    s.won = true;
    change(s, "victory");
  }
}
function hurt(s, swat = false) {
  if (s.iframes > 0 || s.stage !== "combat") return false;
  s.iframes = 1.25;
  const radius = Math.hypot(s.avatar.x, s.avatar.z) || 1;
  s.avatar.vx += (s.avatar.x / radius) * 16;
  s.avatar.vz += (s.avatar.z / radius) * 16;
  s.rings = Math.max(
    0,
    s.rings - { easy: 9, normal: 14, hard: 20 }[s.config.difficulty],
  );
  s.strike = null;
  s.hitFeedback = { until: s.time + 0.45, kind: "hurt" };
  s.avatar.vy += 5;
  s.combo = 0;
  s.comboStep = 0;
  s.action = "hurt";
  s.actionTime = 0.5;
  s.idle = Math.max(s.idle, 2.2);
  if (swat) {
    const rx = s.avatar.x,
      rz = s.avatar.z + 7.5,
      r = Math.hypot(rx, rz) || 1;
    s.knockback = {
      x: (rx / r) * 54,
      y: 14,
      z: (rz / r) * 54,
      left: 0.65,
      duration: 0.65,
    };
    s.avatar.vx = s.knockback.x;
    s.avatar.vy = 14;
    s.avatar.vz = s.knockback.z;
  }
  emit(s, "impact", {
    swat,
    point: point(s.avatar.x, s.avatar.y + 1.8, s.avatar.z),
    normal: point(s.avatar.x / radius, 0.2, s.avatar.z / radius),
  });
  return true;
}
function bossDamage(
  s,
  amount,
  contact = nearestTitanSurface(s, s.avatar),
  kind = "struggle",
) {
  if (
    s.stage !== "combat" ||
    (s.attack === "beam" && s.qte) ||
    (s.attack === "crunch" && s.qte)
  )
    return false;
  const damage = amount * (s.phantom > 0 ? 1.2 : 1);
  s.hp = Math.max(0, s.hp - damage);
  s.combo++;
  s.comboTime = 3;
  if (s.combo >= 12 && s.phantom <= 0 && s.phantomRest <= 0) {
    s.phantomRest = 16;
    s.phantom = 8;
    emit(s, "phantom");
  }
  s.hitFeedback = { until: s.time + 0.3, amount: damage, kind };
  emit(s, "hit", {
    amount: damage,
    kind,
    point: contact.point,
    normal: contact.normal,
    region: contact.id,
    serial: s.strike?.serial,
  });
  if (s.phase === 1 && s.hp <= s.maxHp * 0.5) {
    s.hp = s.maxHp * 0.5;
    s.phase = 2;
    s.checkpoint = "phase2";
    s.qte = null;
    s.strike = null;
    s.action = "idle";
    s.actionTime = 0;
    s.attack = "idle";
    change(s, "phase");
    if (!s.config.cinematics) skipTitanCinematic(s);
  } else if (s.hp <= 0) {
    s.qte = null;
    s.strike = null;
    s.cinematicFrom = { ...s.avatar };
    s.attack = "idle";
    change(s, "finale");
    if (!s.config.cinematics) skipTitanCinematic(s);
  }
  return true;
}
export function titanInput(s, action) {
  if (action === "skip") {
    skipTitanCinematic(s);
    return true;
  }
  if (action === "retry" && s.stage === "defeat") {
    retryTitan(s);
    return true;
  }
  if (s.qte && (action === "jump" || action === "hit")) {
    if (s.time - (s.qte.lastTap ?? -10) > 0.055) {
      s.qte.lastTap = s.time;
      s.qte.hits++;
      emit(s, "struggle");
    }
    return true;
  }
  if (s.stage === "traversal" && action === "jump" && s.avatar.onGround) {
    s.avatar.vy = 24;
    s.avatar.onGround = false;
    s.action = "jump";
    s.actionTime = 0.45;
    emit(s, "jump");
    return true;
  }
  if (s.stage !== "combat") return false;
  if (action === "target") {
    s.lock = !s.lock;
    return true;
  }
  if (action === "dodge" && s.cooldowns.dodge <= 0 && !s.qte) {
    if (s.strike?.move === "loop") {
      const speed = Math.hypot(s.avatar.vx, s.avatar.vy, s.avatar.vz);
      if (speed > 54)
        for (const k of ["vx", "vy", "vz"]) s.avatar[k] *= 54 / speed;
    }
    s.knockback = null;
    s.dodge = 0.42;
    s.iframes = 0.48;
    s.cooldowns.dodge = 0.85;
    s.strike = null;
    s.action = "dodge";
    s.actionTime = 0.42;
    emit(s, "dodge");
    return true;
  }
  if (action === "jump" && s.avatar.onGround) {
    s.avatar.vy = 18;
    s.avatar.onGround = false;
    return true;
  }
  if (s.qte || s.strike || s.action === "hurt" || s.dodge > 0) return false;
  if (action === "hit" && s.counter > 0) {
    if (nearestTitanSurface(s, s.avatar).distance > 32) return false;
    s.counter = 0;
    return beginStrike(
      s,
      "counter",
      s.perfectCounter ? "perfectCounter" : "counter",
    );
  }
  if (action === "hit" && s.cooldowns.hit <= 0) {
    const kind = ["basic", "combo", "heavy", "finisher"][s.comboStep % 4];
    return beginStrike(s, kind === "basic" ? "punch" : kind, kind);
  }
  if (["boom", "rush", "loop"].includes(action) && s.cooldowns[action] <= 0)
    return beginStrike(s, action, action);

  return false;
}
function beginStrike(s, move, damageKind) {
  const m = TITAN_ACTIONS[move];
  if (move === "loop" && nearestTitanSurface(s, s.avatar).distance > 13)
    return false;
  if (s.energy < m.cost) return false;
  s.energy -= m.cost;
  s.cooldowns[
    ["punch", "combo", "heavy", "finisher"].includes(move) ? "hit" : move
  ] = m.cooldown;
  s.action = ["punch", "combo", "heavy", "finisher"].includes(move)
    ? "punch"
    : move;
  s.actionTime = m.duration;
  const target = nearestTitanSurface(s, s.avatar);
  const dx = s.lock ? target.point.x - s.avatar.x : -Math.sin(s.avatar.yaw),
    dy = s.lock ? target.point.y - (s.avatar.y + 1.8) : 0,
    dz = s.lock ? target.point.z - s.avatar.z : -Math.cos(s.avatar.yaw),
    l = Math.hypot(dx, dy, dz) || 1;
  s.strike = {
    move,
    kind: damageKind,
    elapsed: 0,
    duration: m.duration,
    next: 0,
    serial: ++s.strikeSerial,
    direction: point(dx / l, dy / l, dz / l),
  };
  if (move === "loop") s.strike.orbit = makeTitanCyloop(s.avatar);
  if (move === "rush") s.iframes = Math.max(s.iframes, 0.28);
  emit(s, "attack-start", { kind: damageKind });
  if (["boom", "rush", "loop", "counter"].includes(move)) emit(s, move);
  return true;
}
function advanceStrike(s, from, dt, oldClock) {
  const a = s.strike;
  if (!a) return;
  const m = TITAN_ACTIONS[a.move];
  a.elapsed += dt;
  while (a.next < m.contacts.length && a.elapsed >= m.contacts[a.next]) {
    a.next++;
    const source = point(s.avatar.x, s.avatar.y + 1.8, s.avatar.z),
      previous = point(from.x, from.y + 1.8, from.z);
    const c =
      a.move === "loop" && a.orbit
        ? nearestTitanSurface(s, { ...a.orbit.from, y: a.orbit.from.y + 1.8 })
        : sweptTitanContact(s, previous, source, m.reach, oldClock);
    let facing = true;
    if (c && !s.lock && a.move !== "loop") {
      const dx = c.point.x - source.x,
        dz = c.point.z - source.z,
        l = Math.hypot(dx, dz);
      facing =
        l < 1 ||
        (-Math.sin(s.avatar.yaw) * dx - Math.cos(s.avatar.yaw) * dz) / l >
          -0.15;
    }
    if (c && facing) {
      if (bossDamage(s, s.config.damage[a.kind], c, a.kind)) {
        if (["punch", "combo", "heavy", "finisher"].includes(a.move))
          s.comboStep = (s.comboStep + 1) % 4;
        if (a.move === "loop" && s.staggerRest <= 0 && s.stage === "combat") {
          s.stagger = 1.8;
          s.staggerRest = 12;
          s.attack = "idle";
          s.attackTime = 0;
          s.idle = 2.2;
          emit(s, "stagger");
        }
      }
    } else {
      s.comboStep = 0;
      emit(s, "miss", { kind: a.kind });
    }
  }
  if (a.elapsed >= a.duration && s.strike === a) {
    if (a.move === "loop") s.avatar.vx = s.avatar.vy = s.avatar.vz = 0;
    s.strike = null;
  }
}
function parried(s) {
  s.attack = "idle";
  s.attackTime = 0;
  s.idle = 2.8;
  s.stagger = 1.8;
  s.strike = null;
  s.perfectCounter = s.parryAge < 0.22;
  s.energy = Math.min(100, s.energy + (s.perfectCounter ? 12 : 0));
  s.counter = 2.4;
  s.action = "parry";
  s.actionTime = 0.7;
  emit(s, "parry", { perfect: s.perfectCounter });
}
function canParry(s) {
  return s.parryHeld && (!s.config.strictParry || s.parryAge < 0.3);
}
function beamHazards(s, dt) {
  if (s.phase < 2 || s.iframes > 0) return;
  const p = s.avatar,
    angle = Math.atan2(p.x, p.z),
    radius = Math.hypot(p.x, p.z);
  if (p.z < 0 && radius < 47 && radius > 16 && p.y > 18 && p.y < 90) {
    for (let n = 0; n < 6; n++) {
      const beam = -Math.PI + ((n + 0.5) / 6) * Math.PI;
      let d = Math.atan2(Math.sin(angle - beam), Math.cos(angle - beam));
      if (Math.abs(d) < 0.055 && Math.sin(s.time * 0.8) > 0) {
        hurt(s);
        break;
      }
    }
  }
}
export function stepTitan(s, input = {}, dt = 1 / 60) {
  if (!Number.isFinite(dt) || dt <= 0) return;
  dt = Math.min(dt, 1 / 30);
  s.events = [];
  s.boosting = false;
  if (s.knockback) {
    s.knockback.left = Math.max(0, s.knockback.left - dt);
    if (!s.knockback.left) s.knockback = null;
  }
  s.time += dt;
  s.stageTime += dt;
  for (const k of Object.keys(s.cooldowns))
    s.cooldowns[k] = Math.max(0, s.cooldowns[k] - dt);
  for (const k of [
    "iframes",
    "dodge",
    "stagger",
    "counter",
    "actionTime",
    "comboTime",
    "phantom",
    "pulseCooldown",
    "phantomRest",
    "staggerRest",
  ])
    s[k] = Math.max(0, s[k] - dt);
  if (s.comboTime === 0) {
    s.combo = 0;
    s.comboStep = 0;
  }
  if (s.actionTime === 0 && !s.strike) s.action = "idle";
  s.energy = Math.min(100, s.energy + dt * 12);
  if (input.parry) {
    s.parryAge = s.parryHeld ? s.parryAge + dt : 0;
    s.parryHeld = true;
  } else {
    s.parryHeld = false;
    s.parryAge = 0;
  }
  if (s.stage === "intro") {
    if (s.stageTime >= 4.5) change(s, "traversal");
    return;
  }
  if (s.stage === "transform") {
    s.cinematicFrom ||= { ...s.avatar };
    const from = s.cinematicFrom,
      u = clamp((s.stageTime - 3.7) / 2.3, 0, 1),
      e = u * u * (3 - 2 * u);
    const lift = clamp(u / 0.25, 0, 1),
      travel = clamp((u - 0.25) / 0.4, 0, 1),
      fall = clamp((u - 0.65) / 0.35, 0, 1),
      ease = (v) => v * v * (3 - 2 * v);
    s.avatar.x = lerp(from.x, 0, ease(travel));
    s.avatar.y = lerp(lerp(from.y, 104, ease(lift)), 68, ease(fall));
    s.avatar.z = lerp(from.z, 38, ease(travel));
    if (s.stageTime >= 6) startCombat(s);
    return;
  }
  if (s.stage === "phase") {
    if (s.stageTime >= 4) skipTitanCinematic(s);
    return;
  }
  if (s.stage === "finale") {
    if (s.stageTime >= 7) {
      s.won = true;
      change(s, "victory");
    }
    return;
  }
  if (!["traversal", "combat"].includes(s.stage)) return;
  const p = s.avatar,
    from = { ...p },
    oldClock = s.attackTime;
  if (s.stage === "combat" && s.attack !== "idle" && !s.qte) s.attackTime += dt;
  let x = +!!input.right - +!!input.left,
    z = +!!input.forward - +!!input.back,
    length = Math.hypot(x, z);
  if (length) {
    x /= length;
    z /= length;
  }
  const yaw = p.yaw,
    boost = !!input.boost && s.energy > 1,
    speed = boost
      ? s.stage === "combat"
        ? 36
        : 30
      : s.stage === "combat"
        ? 17
        : 13,
    dx = x * Math.cos(yaw) - z * Math.sin(yaw),
    dz = -x * Math.sin(yaw) - z * Math.cos(yaw),
    acc = 1 - Math.exp(-dt * (s.stage === "combat" ? 7 : p.onGround ? 14 : 6));
  s.boosting = !!(
    boost &&
    (length > 0 || (s.stage === "combat" && (input.up || input.down))) &&
    !s.qte &&
    !s.knockback &&
    s.strike?.move !== "loop"
  );
  if (s.boosting) s.energy = Math.max(0, s.energy - dt * 20);
  p.vx = lerp(p.vx, dx * speed, acc);
  p.vz = lerp(p.vz, dz * speed, acc);
  if (s.dodge > 0) {
    const side = x || (!length ? 1 : 0),
      fwd = z;
    p.vx += (side * Math.cos(yaw) - fwd * Math.sin(yaw)) * dt * 180;
    p.vz += (-side * Math.sin(yaw) - fwd * Math.cos(yaw)) * dt * 180;
  }
  if (s.stage === "traversal") {
    collectTitanRings(s);
    const pulsePhase = s.time % 6;
    if (
      p.z < -12 &&
      p.y > 30 &&
      p.y < 75 &&
      pulsePhase > 4 &&
      pulsePhase < 4.5 &&
      (s.pulseCooldown || 0) <= 0
    ) {
      const radius = Math.max(1, Math.hypot(p.x, p.z));
      p.vx += (p.x / radius) * 14;
      p.vz += (p.z / radius) * 14;
      p.vy = Math.max(p.vy, 4);
      s.pulseCooldown = 2;
      emit(s, "pulse");
    }
    const oldY = p.y;
    p.vy -= 26 * dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.z += p.vz * dt;
    p.onGround = false;
    const surfaces = [{ x: 0, y: 0, z: 0, w: 360 }, ...TITAN_ROUTE.slice(1)];
    for (const q of surfaces)
      if (
        p.vy <= 0 &&
        oldY >= q.y - 0.01 &&
        p.y <= q.y &&
        Math.abs(p.x - q.x) < q.w / 2 + 0.3 &&
        Math.abs(p.z - q.z) < q.w / 2 + 0.3
      ) {
        p.y = q.y;
        p.vy = 0;
        p.onGround = true;
      }
    const next = TITAN_ROUTE[s.route + 1];
    if (
      next &&
      p.onGround &&
      Math.abs(p.y - next.y) < 0.2 &&
      dist(p, next) < 8
    ) {
      s.route++;
      emit(s, "checkpoint");
      if (!s.collected.includes(s.route)) {
        s.collected.push(s.route);
        s.rings = Math.min(s.config.rings, s.rings + 5);
        emit(s, "ring", { count: 5 });
      }
    }
    if (
      s.route >= TITAN_ROUTE.length - 1 &&
      dist({ ...p, y: p.y + 1 }, TITAN_EMERALD) < 5
    ) {
      s.emerald = true;
      s.checkpoint = "combat";
      change(s, "transform");
      emit(s, "emerald");
      if (!s.config.cinematics) startCombat(s);
    }
    const bodyRadius = Math.hypot(p.x, p.z);
    if (p.y < 88 && bodyRadius < 18) {
      const a = Math.atan2(p.x, p.z);
      p.x = Math.sin(a) * 18;
      p.z = Math.cos(a) * 18;
    }
    const safePad = TITAN_ROUTE[s.route];
    const missedPad =
      s.route > 0 &&
      ((p.onGround && p.y < safePad.y - 0.25) || p.y < safePad.y - 12);
    if (p.y < -0.2 || Math.hypot(p.x, p.z) > 175 || missedPad) {
      const q = TITAN_ROUTE[s.route];
      Object.assign(p, { x: q.x, y: q.y + 0.1, z: q.z, vx: 0, vy: 0, vz: 0 });
      emit(s, "return-pad");
    }
    return;
  }
  if (s.qte) {
    s.qte.left -= dt;
    p.vx = p.vy = p.vz = 0;
    if (s.qte.hits >= s.qte.need) {
      s.qte = null;
      s.attack = "idle";
      s.stagger = 3;
      s.idle = 3.5;
      s.attackTime = 0;
      bossDamage(s, s.config.damage.struggle);
      emit(s, "qte-win");
    } else if (s.qte.left <= 0) {
      s.qte = null;
      s.attack = "idle";
      s.idle = 3.5;
      s.attackTime = 0;
      s.rings = Math.max(
        0,
        s.rings - { easy: 10, normal: 20, hard: 30 }[s.config.difficulty],
      );
      s.iframes = 2;
      s.action = "hurt";
      s.actionTime = 1;
      emit(s, "qte-miss");
    }
    return;
  }
  s.rings = Math.max(
    0,
    s.rings -
      dt *
        s.config.drain *
        { easy: 0.65, normal: 1, hard: 1.3 }[s.config.difficulty],
  );
  if (s.rings <= 0) {
    change(s, "defeat");
    emit(s, "defeat");
    return;
  }
  p.vy = lerp(p.vy, (+!!input.up - +!!input.down) * speed, acc);
  if (["rush", "counter"].includes(s.strike?.move) && s.strike.elapsed < 0.44) {
    const n = s.strike.direction;
    // Explicit Wild Rush flight adds velocity; it never assigns a destination.
    p.vx += n.x * dt * 180;
    p.vy += n.y * dt * 180;
    p.vz += n.z * dt * 180;
  }
  if (s.strike?.move === "loop" && s.strike.orbit) {
    const elapsed = s.strike.elapsed + dt,
      q = titanCyloopPosition(s.strike.orbit, elapsed);
    p.vx = (q.x - p.x) / dt;
    p.vy = (q.y - p.y) / dt;
    p.vz = (q.z - p.z) / dt;
    p.x = q.x;
    p.y = q.y;
    p.z = q.z;
    p.onGround = false;
    if (elapsed >= TITAN_CYLOOP.approach && elapsed <= TITAN_CYLOOP.contact)
      s.iframes = Math.max(s.iframes, 0.1);
  } else {
    if (s.knockback) {
      const k = s.knockback,
        w = k.left / k.duration;
      p.vx = dx * speed * (1 - w * 0.65) + k.x * w;
      p.vz = dz * speed * (1 - w * 0.65) + k.z * w;
      p.vy = (+!!input.up - +!!input.down) * speed * (1 - w * 0.65) + k.y * w;
    }
    p.x += p.vx * dt;
    p.y = clamp(p.y + p.vy * dt, 0.05, 130);
    p.z += p.vz * dt;
    p.onGround = p.y <= 0.051;
  }
  constrainTitanBody(p);
  const r = Math.hypot(p.x, p.z);
  if (r > 145) {
    p.x *= 145 / r;
    p.z *= 145 / r;
  }
  advanceStrike(s, from, dt, oldClock);
  if (s.stage !== "combat") return;
  beamHazards(s, dt);
  if (input.hit) titanInput(s, "hit");
  if (s.attack === "idle") {
    s.idle -= dt;
    if (s.idle <= 0) {
      const moves =
        s.phase === 1
          ? ["swing", "slap", "swing", "slap"]
          : ["beam", "swing", "crunch", "slap"];
      const sequence = s.sequence++,
        move = moves[sequence % moves.length],
        side = p.x >= 0 ? "L" : "R",
        sign = side === "L" ? 1 : -1;
      s.swatSide = side;
      s.attack =
        ["swing", "slap"].includes(move) &&
        sequence % 4 === 1 &&
        nearestTitanSurface(s, p).distance < 18 &&
        distance(point(sign * 18, 74, -8.5), point(p.x, p.y + 1.8, p.z)) < 47
          ? "swat"
          : move;
      s.attackTime = 0;
      s.hitDone = false;
      s.attackAim = point(p.x, p.y, p.z);
      emit(s, "telegraph", { move: s.attack });
    }
    return;
  }
  const m = TITAN_MOVES[s.attack],
    scale = { easy: 1.25, normal: 1, hard: 0.85 }[s.config.difficulty],
    tell = m.tell * scale;
  if (!s.hitDone && s.attackTime >= tell && oldClock <= tell + m.strike) {
    const aim = s.attackAim || point(p.x, p.y, p.z);
    if (s.attack === "beam") {
      s.hitDone = true;
      const mouth = point(0, 85, 18),
        end = point(aim.x, aim.y + 1.8, aim.z);
      const gap = distance(
        point(p.x, p.y + 1.8, p.z),
        closestSegment(point(p.x, p.y + 1.8, p.z), mouth, end),
      );
      if (gap < 6 && distance(p, mouth) < 110 && s.iframes <= 0) {
        s.qte = {
          kind: "beam",
          left: 4.5,
          need: { easy: 8, normal: 12, hard: 16 }[s.config.difficulty],
          hits: 0,
        };
        emit(s, "beam");
      } else emit(s, "beam-miss", { point: end });
    } else if (s.attack === "crunch") {
      s.hitDone = true;
      if (distance(p, aim) < 10 && distance(p, TITAN_CHEST) < 70) {
        if (canParry(s)) parried(s);
        else if (s.iframes <= 0) {
          s.qte = {
            kind: "crunch",
            left: 4.2,
            need: { easy: 8, normal: 11, hard: 14 }[s.config.difficulty],
            hits: 0,
          };
          emit(s, "grab");
        }
      }
    } else {
      const side = titanAttackSide(s),
        before = titanBodyRegions(s, Math.max(oldClock, tell)).find(
          (q) => q.id === side + " forearm",
        ),
        after = titanBodyRegions(s).find((q) => q.id === side + " forearm");
      let contact = false;
      for (let sample = 0; sample <= 4; sample++) {
        const t = sample / 4,
          a = point(
            lerp(before.a.x, after.a.x, t),
            lerp(before.a.y, after.a.y, t),
            lerp(before.a.z, after.a.z, t),
          ),
          b = point(
            lerp(before.b.x, after.b.x, t),
            lerp(before.b.y, after.b.y, t),
            lerp(before.b.z, after.b.z, t),
          ),
          body = point(
            lerp(from.x, p.x, t),
            lerp(from.y, p.y, t) + 1.8,
            lerp(from.z, p.z, t),
          );
        if (distance(body, closestSegment(body, a, b)) < 9) contact = true;
      }
      if (contact) {
        s.hitDone = true;
        if (canParry(s)) parried(s);
        else hurt(s, s.attack === "swat");
      }
    }
  }
  if (s.attack !== "idle" && s.attackTime >= tell + m.strike) {
    s.attack = "idle";
    s.attackTime = 0;
    s.idle = m.recover;
  }
}
export function restoreTitanSession(raw) {
  if (
    !raw ||
    raw.schema !== 1 ||
    typeof raw.id !== "string" ||
    raw.id.length > 150 ||
    !raw.original ||
    ![
      "intro",
      "traversal",
      "transform",
      "combat",
      "phase",
      "finale",
      "victory",
      "defeat",
    ].includes(raw.stage)
  )
    return null;
  const s = titanSession(raw.config, raw.id);
  s.original = raw.original;
  for (const k of ["stage", "checkpoint"])
    if (raw[k] !== undefined) s[k] = raw[k];
  for (const k of ["emerald", "won", "lock"])
    if (typeof raw[k] === "boolean") s[k] = raw[k];
  for (const [k, a, b] of [
    ["route", 0, 12],
    ["stageTime", 0, 1e7],
    ["time", 0, 1e7],
    ["phase", 1, 2],
    ["maxHp", 100, 100000],
    ["hp", 0, 100000],
    ["preparedRings", 0, 999],
    ["rings", 0, 999],
    ["energy", 0, 100],
    ["sequence", 0, 1e7],
  ])
    if (Number.isFinite(raw[k])) s[k] = clamp(raw[k], a, b);
  s.ringPickups = Array.isArray(raw.ringPickups)
    ? [
        ...new Set(
          raw.ringPickups.filter(
            (n) =>
              Number.isInteger(n) && n >= 0 && n < TITAN_RING_TRAILS.length,
          ),
        ),
      ]
    : [];
  // Upgrade an in-progress legacy encounter by preserving its health fraction.
  if (raw.balance !== 2 && raw.balance !== 3) {
    const ratio = s.maxHp > 0 ? s.hp / s.maxHp : 1;
    s.maxHp = { easy: 8000, normal: 12000, hard: 16000 }[s.config.difficulty];
    s.hp = Math.max(0, s.maxHp * ratio);
  }
  s.balance = 3;
  const music = raw.battleMusic;
  if (
    music &&
    ["phaseOne", "phaseTwo", "transition", "finale"].includes(music.section) &&
    Number.isFinite(music.offset) &&
    music.offset >= 0 &&
    music.offset <= 264.96
  )
    s.battleMusic = { section: music.section, offset: music.offset };
  if (raw.cinematicFrom && ["transform", "finale"].includes(s.stage)) {
    s.cinematicFrom = Object.fromEntries(
      ["x", "y", "z"].map((k) => [
        k,
        Number.isFinite(raw.cinematicFrom[k])
          ? clamp(raw.cinematicFrom[k], -180, 180)
          : s.avatar[k],
      ]),
    );
  }
  s.route = Math.floor(s.route);
  s.phase = Math.floor(s.phase);
  s.hp = Math.min(s.hp, s.maxHp);
  s.collected = Array.isArray(raw.collected)
    ? [
        ...new Set(
          raw.collected.filter((n) => Number.isInteger(n) && n > 0 && n <= 12),
        ),
      ]
    : [];
  for (const k of ["x", "y", "z", "yaw", "pitch"])
    if (Number.isFinite(raw.avatar?.[k]))
      s.avatar[k] = clamp(
        raw.avatar[k],
        k === "y" ? -1 : -180,
        k === "y" ? 131 : 180,
      );
  if (s.stage === "combat") {
    s.attack = "idle";
    s.idle = 3;
    s.iframes = 2;
    s.qte = null;
  }
  if (!["traversal", "combat", "phase2"].includes(s.checkpoint))
    s.checkpoint = "traversal";
  return s;
}
