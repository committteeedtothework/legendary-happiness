import { TITAN_CYLOOP } from "./titan-cyloop.js";
// Independently configurable damage. Rush's value is per contact, three maximum.
export const TITAN_DAMAGE = Object.freeze({
  basic: 34,
  combo: 42,
  heavy: 62,
  finisher: 120,
  boom: 145,
  rush: 95,
  loop: 185,
  counter: 300,
  perfectCounter: 460,
  struggle: 300,
});
export const TITAN_ACTIONS = Object.freeze({
  punch: {
    duration: 0.32,
    contacts: [0.13],
    reach: 6.5,
    cost: 0,
    cooldown: 0.32,
  },
  combo: {
    duration: 0.35,
    contacts: [0.15],
    reach: 6.5,
    cost: 0,
    cooldown: 0.35,
  },
  heavy: { duration: 0.4, contacts: [0.18], reach: 7, cost: 0, cooldown: 0.4 },
  finisher: {
    duration: 0.55,
    contacts: [0.25],
    reach: 7.5,
    cost: 0,
    cooldown: 0.55,
  },
  boom: { duration: 0.65, contacts: [0.3], reach: 43, cost: 18, cooldown: 1.8 },
  rush: {
    duration: 0.8,
    contacts: [0.22, 0.4, 0.61],
    reach: 8,
    cost: 28,
    cooldown: 4.5,
  },
  loop: {
    duration: TITAN_CYLOOP.duration,
    contacts: [TITAN_CYLOOP.contact],
    reach: 13,
    cost: 45,
    cooldown: 12,
  },
  counter: {
    duration: 1.2,
    contacts: [0.48],
    reach: 16,
    cost: 0,
    cooldown: 1.2,
  },
});
export function titanDamageConfig(raw = {}) {
  return Object.fromEntries(
    Object.entries(TITAN_DAMAGE).map(([k, v]) => [
      k,
      Math.max(1, Math.min(v * 3, Number.isFinite(+raw?.[k]) ? +raw[k] : v)),
    ]),
  );
}
export function titanActionDuration(s) {
  return (
    s.strike?.duration ||
    {
      punch: 0.32,
      counter: 1.2,
      boom: 0.65,
      rush: 0.8,
      loop: TITAN_CYLOOP.duration,
      dodge: 0.42,
      hurt: 0.5,
    }[s.action] ||
    1
  );
}
