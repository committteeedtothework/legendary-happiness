// An explicit E ability: continuous approach, exactly one revolution, return.
// The physical avatar and rendered rig share this path; Q can cancel anywhere.
export const TITAN_CYLOOP = Object.freeze({
  approach: 0.35,
  orbit: 2.4,
  return: 0.35,
  radius: 48,
  centerZ: -7.5,
  duration: 3.1,
  contact: 2.75,
});
const clamp = (x) => Math.max(0, Math.min(1, x));
const ease = (x) => {
  x = clamp(x);
  return x * x * (3 - 2 * x);
};
const mix = (a, b, t) => a + (b - a) * t;
export function makeTitanCyloop(p) {
  return {
    from: { x: p.x, y: p.y, z: p.z },
    angle: Math.atan2(p.x, p.z - TITAN_CYLOOP.centerZ),
    height: Math.max(24, Math.min(100, p.y)),
  };
}
export function titanCyloopPosition(orbit, time) {
  const c = TITAN_CYLOOP,
    progress = clamp((time - c.approach) / c.orbit),
    angle = orbit.angle + progress * Math.PI * 2,
    edge = {
      x: Math.sin(orbit.angle) * c.radius,
      y: orbit.height,
      z: c.centerZ + Math.cos(orbit.angle) * c.radius,
    };
  if (time < c.approach) {
    const t = ease(time / c.approach);
    return {
      x: mix(orbit.from.x, edge.x, t),
      y: mix(orbit.from.y, edge.y, t),
      z: mix(orbit.from.z, edge.z, t),
      progress: 0,
    };
  }
  if (time > c.contact) {
    const t = ease((time - c.contact) / c.return);
    return {
      x: mix(edge.x, orbit.from.x, t),
      y: mix(edge.y, orbit.from.y, t),
      z: mix(edge.z, orbit.from.z, t),
      progress: 1,
    };
  }
  return {
    x: Math.sin(angle) * c.radius,
    y: orbit.height,
    z: c.centerZ + Math.cos(angle) * c.radius,
    progress,
  };
}
