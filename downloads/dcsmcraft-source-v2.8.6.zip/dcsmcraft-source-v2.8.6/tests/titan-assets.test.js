import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import * as T from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { auditTitanGlb } from "../scripts/audit-titan-glb.mjs";
import {
  importedRig,
  updateImportedSonic,
  updateImportedGiganto,
  disposeImportedRig,
} from "../src/titan-imports.js";
import { disposeTitanObject } from "../src/giganto-models.js";
import { titanSession } from "../src/giganto-simulation.js";
globalThis.self ||= globalThis;
globalThis.ProgressEvent ||= class ProgressEvent {
  constructor(type, init = {}) {
    this.type = type;
    Object.assign(this, init);
  }
};
const cache = {};
async function asset(role) {
  if (cache[role]) return cache[role];
  const b = fs.readFileSync(
      new URL(`../public/models/titan/${role}.glb`, import.meta.url),
    ),
    len = b.readUInt32LE(12),
    g = JSON.parse(b.subarray(20, 20 + len)),
    bin = b.subarray(28 + len);
  // Unit tests load the real geometry/skins/clips, omitting image decode only.
  // Browser tests parse the exact complete file, including all actual textures.
  const metadata = g.extras.dcsmRig,
    superIndex = g.extras.dcsmSuperMaterial;
  g.extensionsRequired = [];
  g.extensionsUsed = [];
  g.images = [];
  g.textures = [];
  for (const mat of g.materials) {
    for (const key of Object.keys(mat))
      if (key.endsWith("Texture")) delete mat[key];
    for (const key of Object.keys(mat.pbrMetallicRoughness || {}))
      if (key.endsWith("Texture")) delete mat.pbrMetallicRoughness[key];
  }
  for (const mesh of g.meshes)
    for (const pr of mesh.primitives) delete pr.extensions;
  g.buffers = [
    {
      byteLength: bin.length,
      uri: "data:application/octet-stream;base64," + bin.toString("base64"),
    },
  ];
  const gltf = await new GLTFLoader().parseAsync(JSON.stringify(g), "");
  const a = {
    role,
    gltf,
    metadata,
    superMaterial:
      role === "sonic"
        ? await gltf.parser.getDependency("material", superIndex)
        : undefined,
  };
  cache[role] = a;
  return a;
}
test("both finished GLBs pass real container, embedded image, skin, clip-name, socket and triangle-budget checks", () => {
  for (const role of ["sonic", "giganto"]) {
    const b = fs.readFileSync(
        new URL(`../public/models/titan/${role}.glb`, import.meta.url),
      ),
      r = auditTitanGlb(b, role);
    assert.equal(r.valid, true, JSON.stringify(r.errors));
    assert.ok(r.animationNames.length >= 20);
    assert.ok(r.images.every((i) => i.embedded));
    assert.ok(r.triangles < 60000);
  }
});
test("every real imported clip targets existing skinned joints with finite bounded deformation, including raised Super quills", async () => {
  for (const role of ["sonic", "giganto"]) {
    const a = await asset(role),
      r = importedRig(a),
      u = r.userData;
    let skinned = 0;
    r.traverse((o) => {
      if (o.isSkinnedMesh) {
        skinned++;
        const j = o.geometry.attributes.skinIndex,
          w = o.geometry.attributes.skinWeight;
        for (let i = 0; i < j.count; i++) {
          let sum = 0;
          for (let k = 0; k < 4; k++) {
            const n = j.array[i * 4 + k],
              v = w.array[i * 4 + k];
            assert.ok(n < o.skeleton.bones.length);
            assert.ok(v >= 0 && Number.isFinite(v));
            sum += v;
          }
          assert.ok(Math.abs(sum - 1) < 0.002);
        }
      }
    });
    assert.ok(skinned > 0);
    for (const clip of a.gltf.animations) {
      u.mixer.stopAllAction();
      const action = u.mixer.clipAction(clip);
      action.reset().play();
      for (const t of [0, clip.duration * 0.5, clip.duration * 0.97]) {
        u.mixer.setTime(t);
        r.updateMatrixWorld(true);
        const box = new T.Box3();
        r.traverse((o) => {
          if (o.isSkinnedMesh) {
            o.skeleton.update();
            o.computeBoundingBox();
            box.union(o.boundingBox.clone().applyMatrix4(o.matrixWorld));
          }
        });
        assert.ok(
          [...box.min.toArray(), ...box.max.toArray()].every(Number.isFinite),
          role + " " + clip.name,
        );
        const size = box.getSize(new T.Vector3());
        assert.ok(
          size.length() < (role === "sonic" ? 9 : 190),
          role + " " + clip.name + " " + size.toArray(),
        );
      }
    }
    disposeImportedRig(r);
  }
});
test("Sonic changes animation and blue/gold materials without moving the simulated avatar, and restores the base pose after held parry", async () => {
  const r = importedRig(await asset("sonic")),
    s = titanSession({ drain: 0 });
  const before = JSON.stringify(s);
  updateImportedSonic(r, s, 1 / 60);
  assert.equal(JSON.stringify(s), before);
  assert.equal(r.userData.currentClip, "idle");
  s.stage = "transform";
  s.emerald = true;
  updateImportedSonic(r, s, 1 / 60);
  assert.equal(r.userData.super, true);
  assert.equal(r.userData.currentClip, "transform");
  s.stage = "combat";
  s.parryHeld = true;
  updateImportedSonic(r, s, 1 / 60);
  assert.equal(r.userData.currentClip, "parry");
  s.parryHeld = false;
  s.action = "punch";
  s.actionTime = 0.2;
  updateImportedSonic(r, s, 1 / 60);
  assert.match(r.userData.currentClip, /attack_/);
  s.stage = "traversal";
  s.emerald = false;
  s.action = "idle";
  updateImportedSonic(r, s, 1 / 60);
  assert.equal(r.userData.super, false);
  disposeImportedRig(r);
});
test("Giganto arm windup/strike and beam/grab poses follow the existing attack clock and animated sockets remain attached", async () => {
  const r = importedRig(await asset("giganto")),
    s = titanSession({ drain: 0 });
  s.stage = "combat";
  s.emerald = true;
  for (const [attack, time, clip] of [
    ["swing", 0.5, "arm_swing_windup"],
    ["swing", 1.6, "arm_swing"],
    ["slap", 0.4, "arm_slap_windup"],
    ["slap", 1.3, "arm_slap"],
    ["crunch", 0.5, "grab_windup"],
    ["crunch", 2, "grab"],
    ["beam", 0.5, "beam_charge"],
  ]) {
    s.attack = attack;
    s.attackTime = time;
    updateImportedGiganto(r, s, 1 / 60);
    assert.equal(r.userData.currentClip, clip);
  }
  s.qte = { kind: "beam", left: 3 };
  updateImportedGiganto(r, s, 1 / 60);
  assert.equal(r.userData.currentClip, "beam_fire");
  r.updateMatrixWorld(true);
  assert.ok(
    r.userData.jawSocket
      .getWorldPosition(new T.Vector3())
      .toArray()
      .every(Number.isFinite),
  );
  assert.equal(r.userData.laserSockets.filter(Boolean).length, 10);
  const original = JSON.stringify(s);
  s.phase = 2;
  s.stage = "phase";
  updateImportedGiganto(r, s, 1 / 60);
  assert.equal(r.userData.currentClip, "phase_transition");
  s.stage = "finale";
  updateImportedGiganto(r, s, 1 / 60);
  assert.equal(r.userData.currentClip, "defeat");
  disposeImportedRig(r);
});
test("forked encounters own independent skeletons, mixers and materials while sharing bounded cached mesh resources", async () => {
  const a = await asset("sonic"),
    r = importedRig(a),
    q = importedRig(a);
  assert.notEqual(r.userData.bones.head, q.userData.bones.head);
  assert.notEqual(r.userData.materials[0], q.userData.materials[0]);
  const s = titanSession({ drain: 0 });
  s.emerald = true;
  s.stage = "combat";
  s.action = "punch";
  s.actionTime = 0.12;
  for (let n = 0; n < 30; n++) updateImportedSonic(r, s, 1 / 60);
  assert.equal(q.userData.super, false);
  let materialDisposals = 0;
  for (const material of r.userData.materials)
    material.addEventListener("dispose", () => materialDisposals++);
  disposeImportedRig(r);
  disposeTitanObject(r);
  assert.equal(materialDisposals, r.userData.materials.length);
  disposeImportedRig(q);
  disposeTitanObject(q);
});
