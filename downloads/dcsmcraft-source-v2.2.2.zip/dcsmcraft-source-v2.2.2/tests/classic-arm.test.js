import test from "node:test";
import assert from "node:assert/strict";
import * as THREE from "three";
import { ITEMS } from "../src/data.js";
import { actionPose } from "../src/animation.js";
import { mockCanvas } from "./helpers/mock-canvas.js";
import {
  createHandRig,
  createHeldModel,
  fitHandGrip,
  updateHandRig,
} from "../src/first-person.js";

test("classic first-person arms have square contiguous sections without finger geometry or overlapping gloves", () => {
  for (const gloved of [false, true]) {
    const r = createHandRig();
    r.glove.visible = gloved;
    updateHandRig(r);
    const visible = [];
    r.root.traverseVisible((o) => {
      if (o.isMesh) visible.push(o);
    });
    assert.deepEqual(
      visible.map((o) => o.name).sort(),
      [gloved ? "block-glove" : "block-hand", "block-sleeve"].sort(),
    );
    for (const part of visible) {
      assert.equal(part.geometry.parameters.width, 0.16);
      assert.equal(part.geometry.parameters.depth, 0.16);
    }
    const skinEnd = r.forearm.localToWorld(new THREE.Vector3(0, 0.5, 0));
    const sleeveStart = r.cuff.localToWorld(new THREE.Vector3(0, -0.5, 0));
    assert.ok(skinEnd.distanceTo(sleeveStart) < 1e-12);
    assert.deepEqual(
      r.forearm.quaternion.toArray(),
      r.cuff.quaternion.toArray(),
    );
    assert.deepEqual(r.glove.position.toArray(), r.forearm.position.toArray());
    assert.deepEqual(r.glove.scale.toArray(), r.forearm.scale.toArray());
  }
});

test("both full arms and all held families remain connected and clear of the camera throughout action cycles", () => {
  const restore = mockCanvas();
  try {
    const atlas = { texture: new THREE.Texture(), pack: "renewed" };
    for (const id of [
      null,
      "diamond_sword",
      "devin_sword",
      "diamond_spear",
      "iron_axe",
      "iron_pickaxe",
      "iron_shovel",
      "iron_hoe",
      "stone",
      "oak_door",
      "flint_and_steel",
      "apple",
      "saint_corpse_part",
      "matthew_dual_pistols",
    ]) {
      for (const left of [false, true]) {
        const r = createHandRig(),
          model = createHeldModel(id, atlas);
        r.root.scale.x = left ? -1 : 1;
        if (model) r.grip.add(model);
        fitHandGrip(r, id, model);
        const socket = r.grip.position.toArray();
        for (const kind of ["attack", "mine", "place", "use", "eat", "fire"])
          for (const direction of [-1, 1])
            for (let n = 0; n <= 40; n++) {
              const p = actionPose(kind, n / 40, ITEMS[id]?.tool, direction);
              r.root.position.set(
                (left ? -1 : 1) * (0.37 + p.x),
                -0.27 + p.y,
                -0.72 + p.z,
              );
              r.root.rotation.set(p.rx, p.ry, p.rz);
              updateHandRig(r);
              r.root.updateMatrixWorld(true);
              const bounds = new THREE.Box3().setFromObject(r.root);
              assert.ok(
                bounds.max.z < -0.04,
                `${id}/${kind}/${n} camera intersection`,
              );
              const hand = r.wrist.localToWorld(
                new THREE.Vector3(0, -0.04, 0.025),
              );
              const tip = r.forearm.localToWorld(new THREE.Vector3(0, -0.5, 0));
              assert.ok(
                tip.distanceTo(hand) < 1e-12,
                `${id}/${kind} detached arm`,
              );
              assert.deepEqual(r.grip.position.toArray(), socket);
              if (model) assert.equal(model.parent, r.grip);
            }
      }
    }
  } finally {
    restore();
  }
});
