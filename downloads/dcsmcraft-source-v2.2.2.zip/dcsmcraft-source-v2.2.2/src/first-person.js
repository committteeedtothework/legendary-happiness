import { createCorpseModel } from "./stand-models.js";
import { createWeaponModel } from "./weapon-models.js";
import { createPistolModel } from "./pistol-model.js";
import * as THREE from "three";
import { BLOCKS, ITEMS } from "./data.js";
import { itemIconCanvas } from "./textures.js";
import { isFlatItem } from "./item-shapes.js";
import { blockArtUV } from "./block-art.js";

function box(parent, size, position, material) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  mesh.position.set(...position);
  parent.add(mesh);
  return mesh;
}
export function createHandRig() {
  const root = new THREE.Group(),
    wrist = new THREE.Group(),
    grip = new THREE.Group();
  root.add(wrist);
  root.position.set(0.37, -0.27, -0.72);
  wrist.rotation.set(-0.12, -0.12, -0.13);
  const skin = new THREE.MeshLambertMaterial({ color: "#bb8b64" });
  const sleeve = new THREE.MeshLambertMaterial({ color: "#355b6b" });
  // A classic rectangular arm: its skin and sleeve share one straight axis.
  // There are no separate palms, finger bars or knuckles to poke through items.
  const forearm = box(root, [0.16, 1, 0.16], [0, 0, 0], skin);
  const cuff = box(root, [0.16, 1, 0.16], [0, 0, 0], sleeve);
  forearm.name = "block-hand";
  cuff.name = "block-sleeve";
  grip.position.set(0, 0, -0.055);
  wrist.add(grip);
  const glove = box(
    root,
    [0.16, 1, 0.16],
    [0, 0, 0],
    new THREE.MeshLambertMaterial({ color: "#292833" }),
  );
  glove.name = "block-glove";
  glove.visible = false;
  const rig = {
    root,
    wrist,
    grip,
    sleeve,
    skin,
    glove,
    forearm,
    cuff,
    viewBounds: new THREE.Box3(),
    localViewBounds: null,
    arm: {
      anchor: new THREE.Vector3(),
      hand: new THREE.Vector3(),
      direction: new THREE.Vector3(),
      inverse: new THREE.Matrix4(),
    },
  };
  updateHandRig(rig);
  return rig;
}

const armAxis = new THREE.Vector3(0, 1, 0);
export function updateHandRig(rig) {
  const { root, wrist, forearm, cuff, glove, arm } = rig;
  // Coordinates belong to the view-model camera, not the moving wrist. Mirrored
  // left-hand rigs use the same solve; held items keep their rigid sockets.
  // Keep all held geometry in front of the view camera near plane, even at
  // the extreme of eating, recoil and long-weapon follow-through animations.
  if (!rig.localViewBounds) cacheHandBounds(rig);
  root.updateWorldMatrix(true, false);
  wrist.updateWorldMatrix(false, false);
  rig.viewBounds.copy(rig.localViewBounds).applyMatrix4(wrist.matrixWorld);
  if (rig.viewBounds.max.z > -0.11) {
    const shift = rig.viewBounds.max.z + 0.11;
    root.position.z -= shift;
    rig.viewBounds.min.z -= shift;
    rig.viewBounds.max.z -= shift;
  }
  root.updateMatrix();
  wrist.updateMatrix();
  arm.inverse.copy(root.matrix).invert();
  arm.anchor
    .set(root.scale.x < 0 ? -0.48 : 0.48, -1.1, -0.4)
    .applyMatrix4(arm.inverse);
  arm.hand.set(0, -0.04, 0.025).applyMatrix4(wrist.matrix);
  arm.direction.subVectors(arm.anchor, arm.hand);
  const length = arm.direction.length();
  arm.direction.normalize();
  forearm.quaternion.setFromUnitVectors(armAxis, arm.direction);
  cuff.quaternion.copy(forearm.quaternion);
  // Equal square sections meet exactly: no floating wrist, sleeve lip or
  // coplanar side surfaces that flicker as the arm moves.
  forearm.position.copy(arm.hand).addScaledVector(arm.direction, length * 0.16);
  forearm.scale.y = length * 0.32;
  // Gloved skins replace the entire skin section, without overlapping surfaces.
  forearm.visible = !glove.visible;
  glove.position.copy(forearm.position);
  glove.quaternion.copy(forearm.quaternion);
  glove.scale.copy(forearm.scale);
  cuff.position.copy(arm.hand).addScaledVector(arm.direction, length * 0.66);
  cuff.scale.y = length * 0.68;
}
// Cache rigid held geometry at equip. Include the square hand cap even when
// empty-handed; the long sleeve is solved separately to an off-screen anchor.
export function cacheHandBounds(rig) {
  rig.root.updateMatrixWorld(true);
  const inverse = new THREE.Matrix4().copy(rig.wrist.matrixWorld).invert(),
    local = new THREE.Box3(
      new THREE.Vector3(-0.12, -0.14, -0.12),
      new THREE.Vector3(0.12, 0.12, 0.12),
    ),
    part = new THREE.Box3(),
    matrix = new THREE.Matrix4();
  rig.wrist.traverse((mesh) => {
    if (!mesh.geometry) return;
    mesh.geometry.computeBoundingBox();
    matrix.multiplyMatrices(inverse, mesh.matrixWorld);
    part.copy(mesh.geometry.boundingBox).applyMatrix4(matrix);
    local.union(part);
  });
  // Rigid content is cached once at equip; leave slack for slide recoil/glints.
  rig.localViewBounds = local.expandByScalar(0.075);
}
export function fitHandGrip(rig, id, model) {
  const pistol = id === "matthew_dual_pistols",
    flat = isFlatItem(id),
    block = ITEMS[id]?.block !== undefined && !flat;
  // The item emerges from the front of a solid square fist. Pistols sit higher
  // so the receiver clears its top instead of needing an enlarged finger cage.
  rig.grip.position.set(0, pistol ? 0.025 : 0, pistol ? -0.045 : -0.055);
  if (model) {
    model.position.z = flat ? -0.035 : 0;
    model.position.y = block ? 0.036 : 0;
  }
  rig.root.userData.gripStyle = pistol
    ? "pistol"
    : flat
      ? "flat"
      : block
        ? "support"
        : "handle";
  cacheHandBounds(rig);
}
export function createHeldModel(id, atlas) {
  const item = ITEMS[id];
  if (!item) return null;
  if (id === "saint_corpse_part") return createCorpseModel();
  if (id === "matthew_dual_pistols") return createPistolModel();
  const weapon = createWeaponModel(id);
  if (weapon) return weapon;
  if (isFlatItem(id)) return createFlatTool(id);
  const g = new THREE.Group();
  g.userData.kind = item.block !== undefined ? "block" : item.tool || "item";
  if (item.block !== undefined) {
    const door = BLOCKS[item.block].door;
    const geometry = new THREE.BoxGeometry(
      door ? 0.15 : 0.235,
      door ? 0.32 : 0.235,
      door ? 0.035 : 0.235,
    );
    const uv = geometry.attributes.uv;
    for (let face = 0; face < 6; face++) {
      for (let i = face * 4; i < face * 4 + 4; i++) {
        const [u, v] = blockArtUV(
          item.block,
          face,
          uv.getX(i),
          uv.getY(i),
          atlas.pack,
        );
        uv.setXY(i, u, v);
      }
    }
    const cube = new THREE.Mesh(
      geometry,
      new THREE.MeshLambertMaterial({ map: atlas.texture, alphaTest: 0.5 }),
    );
    cube.material.userData.sharedMap = true;
    cube.position.set(-0.025, 0.11, door ? -0.055 : -0.18);
    cube.rotation.y = -0.35;
    g.add(cube);
  }
  return g;
}

function createFlatTool(id) {
  const root = new THREE.Group();
  const map = new THREE.CanvasTexture(itemIconCanvas(id));
  map.magFilter = map.minFilter = THREE.NearestFilter;
  map.colorSpace = THREE.SRGBColorSpace;
  const mesh = new THREE.Mesh(
    new THREE.PlaneGeometry(0.24, 0.24),
    new THREE.MeshLambertMaterial({
      map,
      alphaTest: 0.5,
      side: THREE.DoubleSide,
    }),
  );
  mesh.position.set(0, 0.075, -0.025);
  root.add(mesh);
  root.userData = { kind: "item", flatCutout: true, item: id };
  return root;
}
export function createDroppedModel(id, atlas) {
  const item = ITEMS[id];
  if (!item) return new THREE.Group();
  const model = createHeldModel(id, atlas);
  const bounds = new THREE.Box3().setFromObject(model),
    size = bounds.getSize(new THREE.Vector3()),
    center = bounds.getCenter(new THREE.Vector3());
  // Root offset preserves rigid tool grips while normalising dropped silhouettes.
  const root = new THREE.Group(),
    scale = 0.38 / Math.max(size.x, size.y, size.z, 0.01);
  model.position.sub(center);
  root.add(model);
  root.scale.setScalar(scale);
  root.userData.droppedItem = id;
  root.userData.flatCutout = !!model.userData.flatCutout;
  return root;
}
