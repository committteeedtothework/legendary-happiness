Actual game captures. Open index.html.
Standalone SHA-256: 3bfa97bb5fb574c1880415274da5c24d30c78f2025df4af62384485b3f45080e
