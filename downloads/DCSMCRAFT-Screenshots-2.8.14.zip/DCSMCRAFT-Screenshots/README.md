# DCSMCRAFT 2.8.14 — in-game screenshots

Open index.html for the gallery. These captures come from the actual standalone game in Chromium, using controlled view positions for presentation review. The full playable portal-to-return encounter is verified separately. Main final views use High quality at 1280×720; compact.png is 640×480. The settings image shows working arena-only options. before-* images show the previous 2.8.13 build.

Final standalone HTML SHA-256: f2233a49a9516aa1b5ffa3e49b600c0036ee8b21f136ef5e45e5f483ee7145cf
