import { TITAN_ACTIONS } from "./titan-combat.js";
import { nearestTitanSurface } from "./titan-contact.js";
const icons = {
  ring: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="5"/>',
  star: '<path d="m12 2 2.7 6.8L22 12l-7.3 3.2L12 22l-2.7-6.8L2 12l7.3-3.2Z"/>',
  shield: '<path d="M4 3h16v9c0 5-8 9-8 9s-8-4-8-9Z"/>',
  sword: '<path d="m7 15 11-12 3 1-1 3L9 18M4 13l7 7M3 21l4-4"/>',
  speed: '<path d="m4 4 8 4-2 5 10 4-1 4H3l-1-5 6-7M13 3h8M16 7h6"/>',
  bolt: '<path d="m14 2-9 12h6l-1 8 9-13h-6Z"/>',
  gem: '<path d="m7 3 10 0 5 7-10 12L2 10Z M2 10h20M7 3l5 19 5-19"/>',
};
const icon = (name) =>
  `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round">${icons[name]}</svg>`;
export function titanHudTemplate() {
  return `
 <div class="titan-compass" aria-label="Camera heading"><div class="titan-compass-ticks"></div><b id="titan-bearing">N 000°</b><i></i></div>
 <div class="titan-top"><strong class="titan-title">GIGANTO</strong><div class="titan-health" role="progressbar" aria-label="Giganto health"><em></em><i></i></div><span id="titan-phase"></span></div>
 <div class="titan-resources"><div class="titan-ring-total">${icon("ring")}<b id="titan-rings"></b></div><div class="titan-mini" title="Rings gathered">${icon("star")}<span id="titan-gathered">0</span></div><div class="titan-mini" title="Chaos Emeralds">${icon("gem")}<span id="titan-emeralds">6</span></div><div class="titan-mini" title="Energy">${icon("bolt")}<span id="titan-energy"></span></div></div>
 <div class="titan-objective"><b id="titan-objective"></b><span id="titan-detail"></span></div>
 <div class="titan-combo"><strong id="titan-combo">0</strong><small>COMBO</small><div><i id="titan-rush-meter"></i></div><span id="titan-rush-label"></span></div>
 <div class="titan-stats" aria-label="Sonic battle stats"><i class="titan-stats-diamond"></i><div class="titan-stat stat-n">${icon("speed")}<b id="titan-stat-speed">0</b><small>SPEED</small></div><div class="titan-stat stat-w">${icon("sword")}<b id="titan-stat-power">34</b><small>POWER</small></div><div class="titan-stat stat-e">${icon("shield")}<b id="titan-stat-guard">READY</b><small>GUARD</small></div><div class="titan-stat stat-s">${icon("ring")}<b id="titan-stat-capacity">400</b><small>CAPACITY</small></div></div>
 <div class="titan-speedometer"><svg viewBox="0 0 160 140" aria-label="Speed and boost"><path class="dial-track" d="M22 112A65 65 0 1 1 138 112" pathLength="100"/><path id="titan-speed-arc" d="M22 112A65 65 0 1 1 138 112" pathLength="100"/><path class="dial-ticks" d="M19 96l8-2m-9-18h9m-5-23 8 4m3-25 7 6m12-24 4 9m23-12v9m24-6-4 9m25 1-7 7m23 10-8 5m17 17-9 2m11 21h-9m6 21-8-3"/></svg><div class="titan-speed-number"><b id="titan-speed">0</b><small>m/s</small></div><div class="titan-boost"><span>${icon("bolt")}</span><b id="titan-boost">100</b></div><div class="titan-energy-track"><i id="titan-boost-fill"></i></div></div>
 <div class="titan-abilities" aria-label="Combat abilities">${[
   ["homing", "X", "HOMING"],
   ["boom", "R", "SONIC BOOM"],
   ["rush", "F", "WILD RUSH"],
   ["loop", "E", "CYLOOP"],
   ["cross", "C", "CROSS SLASH"],
   ["shot", "V", "HOMING SHOT"],
 ]
   .map(
     ([key, button, label]) =>
       `<div data-ability="${key}"><kbd>${button}</kbd><span>${label}</span><b></b><i></i></div>`,
   )
   .join("")}</div>
 <div class="titan-target-state" id="titan-target-state"></div><div class="titan-phase-banner" id="titan-phase-banner" role="status"></div><div class="titan-damage-number" id="titan-damage-number"></div>
 <div class="titan-tell" id="titan-tell"></div><div class="titan-qte" id="titan-qte" hidden><b></b><progress max="1"></progress><div></div></div><div class="titan-controls" id="titan-controls"></div><div id="titan-reticle" aria-label="Locked target" hidden><svg viewBox="0 0 30 28" fill="none" stroke="currentColor" stroke-width="2"><path d="m15 2 12 23H3Z"/></svg></div>`;
}
export function updateTitanHudExtras(hud, s, view) {
  const q = (id) => hud.querySelector(id),
    speed = Math.hypot(s.avatar.vx, s.avatar.vy, s.avatar.vz),
    heading = view?.heading || 0,
    dirs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  q("#titan-bearing").textContent =
    `${dirs[Math.round(heading / 45) % 8]} ${Math.round(heading).toString().padStart(3, "0")}°`;
  hud.style.setProperty("--titan-bearing", `${-(heading % 15) * 2}px`);
  q("#titan-gathered").textContent =
    (s.ringPickups?.length || 0) * 10 + s.collected.length * 5;
  q("#titan-emeralds").textContent = s.emerald ? "7" : "6";
  q("#titan-combo").textContent = s.combo;
  q("#titan-rush-meter").style.width =
    `${s.phantom > 0 ? 100 : Math.min(100, (s.combo / 12) * 100)}%`;
  q("#titan-rush-label").textContent = s.phantom > 0 ? "PHANTOM RUSH" : "";
  q("#titan-speed").textContent = Math.round(speed);
  q("#titan-stat-speed").textContent = Math.round(speed);
  q("#titan-stat-capacity").textContent = s.config.rings;
  q("#titan-stat-power").textContent = Math.round(
    s.config.damage.basic * (s.phantom > 0 ? 1.2 : 1),
  );
  const contact = nearestTitanSurface(s, { ...s.avatar, y: s.avatar.y + 1.8 });
  q("#titan-target-state").textContent =
    s.stage === "combat" ? `${s.lock ? "TARGET LOCKED" : "FREE CAMERA"}` : "";
  q("#titan-target-state").classList.toggle("in-range", contact.distance < 7);
  const hit = s.hitFeedback?.until > s.time ? s.hitFeedback : null;
  q("#titan-damage-number").textContent = hit?.amount
    ? `${Math.round(hit.amount)}${hit.kind === "perfectCounter" ? " · PERFECT" : ""}`
    : "";
  const damage = q("#titan-damage-number"),
    screen = view?.damageScreen;
  damage.style.left = `${(screen?.x ?? 0.53) * 100}%`;
  damage.style.top = `${(screen?.y ?? 0.43) * 100}%`;
  damage.style.opacity = screen?.visible === false ? "0" : "1";
  hud.classList.toggle("has-combo", s.combo > 0);
  hud.classList.toggle("damage-taken", hit?.kind === "hurt");
  hud.classList.toggle("hit-confirm", !!hit?.amount);
  hud.classList.toggle(
    "critical-rings",
    s.emerald && s.rings < Math.min(60, s.config.rings * 0.25),
  );
  q("#titan-phase-banner").textContent =
    s.stage === "phase"
      ? "PHASE II"
      : s.stage === "transform"
        ? "SUPER SONIC"
        : "";
  hud.dataset.stage = s.stage;
  hud.classList.toggle("counter-cinematic", !!s.counterScene);
  hud.style.setProperty("--titan-health", `${(s.hp / s.maxHp) * 100}%`);
  for (const key of ["homing", "boom", "rush", "loop", "cross", "shot"]) {
    const node = q(`[data-ability="${key}"]`),
      m = TITAN_ACTIONS[key],
      cd = s.cooldowns[key] || 0;
    node.querySelector("b").textContent =
      cd > 0.05
        ? cd.toFixed(1)
        : s.energy < m.cost
          ? `${m.cost} ENERGY`
          : "READY";
    node.querySelector("i").style.width =
      `${(1 - Math.min(1, cd / m.cooldown)) * 100}%`;
    node.classList.toggle(
      "unavailable",
      cd > 0.05 || s.energy < m.cost || !!s.strike,
    );
  }
  q("#titan-stat-guard").textContent = s.parryHeld
    ? "PARRY"
    : s.counter > 0
      ? "COUNTER"
      : "READY";
  q("#titan-boost").textContent = Math.round(s.energy);
  q("#titan-boost-fill").style.width = `${s.energy}%`;
  q("#titan-speed-arc").style.strokeDashoffset =
    100 - Math.min(100, (speed / 36) * 100);
  hud.classList.toggle("combat", s.emerald);
  hud.classList.toggle("phantom", s.phantom > 0);
}
