Actual captures from the verified standalone. Open index.html.
Standalone SHA-256: 4cfcf4bc6d3fd3b6062ad7933f9693c0751aa51672f9db399c967bcc7becaa61
