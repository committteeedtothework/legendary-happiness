@echo off
call "%~dp0server\HOST-PUBLIC.cmd"
