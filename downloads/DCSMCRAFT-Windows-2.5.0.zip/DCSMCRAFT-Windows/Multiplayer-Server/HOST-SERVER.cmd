@echo off
call "%~dp0server\HOST-SERVER.cmd"
