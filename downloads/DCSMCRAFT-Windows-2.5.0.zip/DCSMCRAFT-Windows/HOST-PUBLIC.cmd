@echo off
call "%~dp0Multiplayer-Server\HOST-PUBLIC.cmd"
