Actual captures from the verified standalone. Open index.html.
Standalone SHA-256: bdeea19e0901d00dc6d164975597b444f8b24acbc31167ec2a9d9558a83d6d3c
