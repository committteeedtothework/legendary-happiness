Actual game captures. Open index.html.
Standalone SHA-256: a01d88e0eb995bb11dbcbae8081ad1a829cc9d7ba6bd36e81fc1cb62fb1f2ee4
