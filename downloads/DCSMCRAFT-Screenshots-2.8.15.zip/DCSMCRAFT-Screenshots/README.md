# DCSMCRAFT 2.8.15 in-game captures

Open index.html. Actual Chromium captures from the tested standalone; the soundtrack panel shows a test custom cue map, not the shipped defaults. Fight shots come from the automated playable encounter and cinematic checks.

HTML SHA-256: 8d298697d6c1974e7d7bc656b2ada87d0a4f0120b7ed4f90d7782d4b0750e345
