Actual captures from the verified standalone. Open index.html.
Standalone SHA-256: 89c52d3377376b8afc54c53dc08c80c8f488df627004f1a63e824925a4aa7f19
