import * as T from "three";
// One shared, smooth but irregular canopy mesh. Instancing keeps the draw budget fixed.
export function titanCanopy(width = 16, height = 10) {
  const g = new T.SphereGeometry(1, width, height),
    p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i),
      y = p.getY(i),
      z = p.getZ(i),
      r =
        1 +
        0.1 * Math.sin(x * 7 + z * 3) * Math.sin(y * 6 + z * 5) +
        0.07 * Math.cos(z * 9 - x * 4) * Math.cos(y * 7);
    p.setXYZ(i, x * r, y * (r + 0.08 * Math.sin(x * 4 + z * 4)), z * r);
  }
  g.computeVertexNormals();
  return g;
}
