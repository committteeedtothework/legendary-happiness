export const CONTROLLER_PRESETS = Object.freeze([
  ["auto", "Automatic"],
  ["xbox", "Xbox"],
  ["playstation", "PlayStation"],
  ["switch", "Switch Pro"],
  ["generic", "Generic standard"],
  ["custom", "Custom"],
]);
export const PAD_DEFAULTS = Object.freeze({
  enabled: true,
  preset: "auto",
  deadzone: 0.18,
  lookSensitivity: 2.6,
  invertY: false,
  vibration: true,
  moveX: 0,
  moveY: 1,
  lookX: 2,
  lookY: 3,
  leftTriggerAxis: -1,
  rightTriggerAxis: -1,
  bindings: {},
});
export const PAD_BUTTONS = Object.freeze({
  jump: 0,
  crouch: 1,
  attack: 2,
  inventory: 3,
  leftShoulder: 4,
  rightShoulder: 5,
  use: 6,
  mine: 7,
  view: 8,
  pause: 9,
  sprint: 10,
  target: 11,
  up: 12,
  down: 13,
  left: 14,
  right: 15,
});
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
export function controllerConfig(raw = {}) {
  raw = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
  const n = (k, a, b) =>
    Number.isFinite(raw[k]) ? clamp(raw[k], a, b) : PAD_DEFAULTS[k];
  return {
    enabled: raw.enabled !== false,
    preset: CONTROLLER_PRESETS.some(([k]) => k === raw.preset)
      ? raw.preset
      : "auto",
    deadzone: n("deadzone", 0.05, 0.45),
    lookSensitivity: n("lookSensitivity", 0.5, 6),
    invertY: raw.invertY === true,
    vibration: raw.vibration !== false,
    ...Object.fromEntries(
      [
        "moveX",
        "moveY",
        "lookX",
        "lookY",
        "leftTriggerAxis",
        "rightTriggerAxis",
      ].map((k) => [k, Math.round(n(k, -1, 15))]),
    ),
    bindings: Object.fromEntries(
      Object.entries(PAD_BUTTONS).map(([k, v]) => [
        k,
        Number.isInteger(raw.bindings?.[k])
          ? clamp(raw.bindings[k], -1, 63)
          : v,
      ]),
    ),
  };
}
export function controllerFamily(id = "", preset = "auto") {
  if (preset !== "auto")
    return ["xbox", "playstation", "switch"].includes(preset)
      ? preset
      : "generic";
  if (/playstation|dualshock|dualsense|sony|054c/i.test(id))
    return "playstation";
  if (/nintendo|switch|057e/i.test(id)) return "switch";
  if (/xbox|xinput|microsoft|045e/i.test(id)) return "xbox";
  return "generic";
}
export function radialDeadzone(x, y, zone = 0.18) {
  x = Number.isFinite(x) ? clamp(x, -1, 1) : 0;
  y = Number.isFinite(y) ? clamp(y, -1, 1) : 0;
  const r = Math.hypot(x, y);
  if (r <= zone) return { x: 0, y: 0 };
  const m = clamp((r - zone) / (1 - zone), 0, 1) / r;
  return { x: x * m, y: y * m };
}
export function readController(pad, raw = {}) {
  const c = controllerConfig(raw),
    axis = (i) =>
      i >= 0 && Number.isFinite(pad?.axes?.[i]) ? clamp(pad.axes[i], -1, 1) : 0;
  const move = radialDeadzone(axis(c.moveX), axis(c.moveY), c.deadzone),
    look = radialDeadzone(axis(c.lookX), axis(c.lookY), c.deadzone);
  const values = Array.from(
    { length: Math.min(64, pad?.buttons?.length || 0) },
    (_, i) => {
      const b = pad.buttons[i];
      return b?.pressed
        ? 1
        : Number.isFinite(b?.value)
          ? clamp(b.value, 0, 1)
          : 0;
    },
  );
  const buttons = Object.fromEntries(
    Object.entries(PAD_BUTTONS).map(([k, v]) => [
      k,
      values[c.preset === "custom" ? c.bindings[k] : v] >= 0.55,
    ]),
  );
  if (c.leftTriggerAxis >= 0)
    buttons.use = (axis(c.leftTriggerAxis) + 1) / 2 > 0.55;
  if (c.rightTriggerAxis >= 0)
    buttons.mine = (axis(c.rightTriggerAxis) + 1) / 2 > 0.55;
  return {
    move,
    look: {
      x: Math.sign(look.x) * Math.abs(look.x) ** 1.5,
      y: Math.sign(look.y) * Math.abs(look.y) ** 1.5 * (c.invertY ? -1 : 1),
    },
    buttons,
    values,
    family: controllerFamily(pad?.id, c.preset),
    standard: pad?.mapping === "standard",
  };
}
const faces = {
  xbox: ["A", "B", "X", "Y"],
  playstation: ["×", "○", "□", "△"],
  switch: ["B", "A", "Y", "X"],
  generic: ["1", "2", "3", "4"],
};
export function padGlyph(family, action) {
  const face = faces[family] || faces.generic;
  const n = PAD_BUTTONS[action];
  if (n >= 0 && n <= 3) return face[n];
  const labels =
    family === "playstation"
      ? {
          leftShoulder: "L1",
          rightShoulder: "R1",
          use: "L2",
          mine: "R2",
          view: "Create",
          pause: "Options",
          sprint: "L3",
          target: "R3",
        }
      : family === "switch"
        ? {
            leftShoulder: "L",
            rightShoulder: "R",
            use: "ZL",
            mine: "ZR",
            view: "−",
            pause: "+",
            sprint: "L Stick",
            target: "R Stick",
          }
        : {
            leftShoulder: "LB",
            rightShoulder: "RB",
            use: "LT",
            mine: "RT",
            view: "View",
            pause: "Menu",
            sprint: "L Stick",
            target: "R Stick",
          };
  return (
    labels[action] ||
    { up: "↑", down: "↓", left: "←", right: "→" }[action] ||
    action
  );
}
export function arenaPadGlyph(family, move) {
  const a = padGlyph(family, "leftShoulder");
  return (
    {
      homing: padGlyph(family, "inventory"),
      boom: "↑",
      rush: "↓",
      loop: "←",
      cross: "→",
      shot: a + " + ↑",
      stomp: a + " + ↓",
      spin: a + " + →",
      cyclone: a + " + ←",
    }[move] || move
  );
}
export function menuButtonNames(family) {
  return {
    confirm: family === "switch" ? "crouch" : "jump",
    cancel: family === "switch" ? "jump" : "crouch",
  };
}
