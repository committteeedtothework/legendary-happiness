# Validation record — DCSMCRAFT 1.6.1

Reference remains Minecraft Java Edition 1.20.4, with the existing partial/missing mechanics listed in FEATURES.md. This patch changes the planted temple sword's Guardian gate; generator 11 and existing terrain are retained.

## Core checks

**332 core tests pass**, including seven new Guardian-gate cases. Zero, one and two defeated Guardians cannot begin extraction in Survival/Creative and Normal/Peaceful combinations. The third real Guardian death opens the inner seal and permits the existing 30-second, unique sword claim. Duplicate/invalid role entries, living Guardians with stale completed records, and death reports for living/foreign/invalid Guardians cannot unlock the sword. Changing modes/difficulty and saving/reloading after two defeats preserves the final Guardian requirement.

Existing crafting, movement, fluids, inventory, saving/recovery, Cinderworld, pistol and Mad Titan checks remain passing. Already claimed swords remain claimed, and pre-temple worlds retain their original relic behavior. Creative catalogs and owner commands remain Creative/cheat tools; the new restriction is for the planted temple relic.

## Browser checks

The dedicated standalone scenario uses the exact built HTML with external requests blocked. It checks live Guardians blocking collection in Creative and Peaceful, real charged melee defeats of two Guardians, a saved/reloaded final Guardian still blocking extraction, the final real defeat, normal Sigil attunement through the arch, actual held-mouse extraction for 30 seconds, and a unique sword surviving reload. The retained Cinderworld/vault/Sigil/Guardian progression scenario is also selected for regression testing. **Both selected browser scenarios pass**, with no page or checked WebGL errors. Final results are also recorded in the versioned validation JSON.

Combat fixtures control positions, equipment and charged attacks for reproducibility. They exercise production damage, persistent defeat recording and extraction; they are not an unaided full Survival playthrough or exhaustive proof of no bugs.

## Build and compatibility

Runtime/build inputs are frozen before browser checks. Production web assets, standalone HTML and Windows x64 launcher build successfully; extraction of the launcher's embedded HTML matches byte-for-byte. Native Windows execution remains unverified on this Linux host. Direct file:// navigation is restricted by the managed browser; the identical standalone HTML is tested over a local HTTP origin with external requests blocked.

Sixty sampled chunks in both dimensions across generators 2–11 are byte-identical to published 1.6.0. This is representative compatibility evidence, not an exhaustive comparison across all seeds/chunks. Frozen input hashes, ZIP CRCs and artifact SHA-256 checksums are verified during packaging and public download verification.

The broader feature checklist and multiplayer limits remain in FEATURES.md and MULTIPLAYER.md. This focused patch does not repeat all nine browser regression scenarios previously passed for 1.6.0; its two selected scenarios target the changed acquisition gate and existing connected progression.
