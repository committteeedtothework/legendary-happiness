import * as THREE from "three";
import { relicSite } from "./relic.js";

// One reusable draw call for runes, orbiting motes and combat sparks.
export class ArcaneEffects {
  constructor(scene) {
    this.capacity = 256;
    this.cursor = 0;
    this.particles = [];
    this.positions = new Float32Array(this.capacity * 3).fill(-10000);
    this.colors = new Float32Array(this.capacity * 3);
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute(
      "position",
      new THREE.BufferAttribute(this.positions, 3).setUsage(
        THREE.DynamicDrawUsage,
      ),
    );
    geometry.setAttribute(
      "color",
      new THREE.BufferAttribute(this.colors, 3).setUsage(
        THREE.DynamicDrawUsage,
      ),
    );
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = 16;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "white";
    ctx.fillRect(7, 1, 2, 14);
    ctx.fillRect(1, 7, 14, 2);
    ctx.fillRect(5, 5, 6, 6);
    const map = new THREE.CanvasTexture(canvas);
    map.magFilter = map.minFilter = THREE.NearestFilter;
    this.points = new THREE.Points(
      geometry,
      new THREE.PointsMaterial({
        map,
        size: 0.13,
        vertexColors: true,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        alphaTest: 0.1,
      }),
    );
    this.points.frustumCulled = false;
    scene.add(this.points);
  }
  clear() {
    this.particles = [];
    this.positions.fill(-10000);
    this.points.geometry.attributes.position.needsUpdate = true;
  }
  emit(x, y, z, vx, vy, vz, life = 0.8, tint = [0.35, 0.95, 1]) {
    const i = this.cursor++ % this.capacity;
    this.particles[i] = { x, y, z, vx, vy, vz, life, max: life, tint };
  }
  burst(p, count = 28) {
    for (let i = 0; i < count; i++) {
      const a = i * 2.399,
        r = 1 + Math.random() * 2;
      this.emit(
        p.x,
        p.y + 1,
        p.z,
        Math.cos(a) * r,
        (Math.random() - 0.2) * 3,
        Math.sin(a) * r,
        0.5 + Math.random() * 0.5,
        i % 4 === 0 ? [0.9, 0.65, 1] : [0.3, 0.9, 1],
      );
    }
  }
  update(world, p, held, time, dt, playing, particles) {
    this.points.visible = playing && particles !== "minimal";
    if (dt > 0 && this.points.visible && time >= (this.nextMote || 0)) {
      this.nextMote = time + 0.07;
      const site = relicSite(world);
      if (
        site &&
        !world.relicClaimed &&
        Math.hypot(p.x - site.x, p.z - site.z) < 35
      ) {
        const a = time * 1.8;
        this.emit(
          site.x + 0.5 + Math.cos(a) * 0.75,
          site.y + 0.6 + Math.sin(a * 0.6) * 0.3,
          site.z + 0.5 + Math.sin(a) * 0.75,
          0,
          0.6,
          0,
          1.2,
        );
      }
      if (held === "devin_sword") {
        const x = p.x - Math.sin(p.yaw) * 0.7 + Math.cos(p.yaw) * 0.3,
          z = p.z - Math.cos(p.yaw) * 0.7 - Math.sin(p.yaw) * 0.3;
        this.emit(x, p.y + 1.1, z, 0, 0.2, 0, 0.4, [0.4, 0.65, 1]);
      }
    }
    for (let i = 0; i < this.capacity; i++) {
      const q = this.particles[i];
      if (!q || q.life <= 0) {
        this.positions[i * 3 + 1] = -10000;
        continue;
      }
      q.life -= dt;
      q.x += q.vx * dt;
      q.y += q.vy * dt;
      q.z += q.vz * dt;
      this.positions.set([q.x, q.y, q.z], i * 3);
      this.colors.set(
        q.tint.map((v) => v * Math.max(0, q.life / q.max)),
        i * 3,
      );
    }
    this.points.geometry.attributes.position.needsUpdate = true;
    this.points.geometry.attributes.color.needsUpdate = true;
  }
}
export function animateMagic(root, time) {
  root?.traverse((o) => {
    if (o.userData.magicOrbit !== undefined) {
      const a = time * 1.4 + o.userData.magicOrbit;
      o.position.x = Math.cos(a) * 0.105;
      o.position.z = Math.sin(a) * 0.105;
      o.rotation.y = a;
    }
  });
}
