import { createPistolBank } from "./pistol-audio.js";
import { isWater, isLava } from "./block-dynamics.js";
import { MusicEngine } from "./music.js";
import { weatherAt } from "./weather.js";
import { createVoiceBank } from "./voices.js";
import { B } from "./data.js";
import { Soundscape } from "./soundscape.js";
import { createFoleyBank, surfaceFamily } from "./foley.js";
// Original procedural Foley: filtered noise, short resonant impacts, and
// harmonic envelopes. No downloaded recordings or external audio files.
export class AudioEngine {
  constructor(settings) {
    this.settings = settings;
    this.context = null;
    this.played = 0;
    this.active = 0;
  }
  unlock() {
    try {
      const Context = window.AudioContext || window.webkitAudioContext;
      if (!Context) return;
      if (!this.context) {
        this.context = new Context();
        this.master = this.context.createGain();
        this.compressor = this.context.createDynamicsCompressor();
        this.compressor.threshold.value = -16;
        this.compressor.ratio.value = 4;
        this.compressor.attack.value = 0.005;
        this.compressor.release.value = 0.15;
        this.master.connect(this.compressor);
        this.compressor.connect(this.context.destination);
        this.bank = {
          ...createFoleyBank(this.context),
          ...createPistolBank(this.context),
        };
        this.voices = createVoiceBank(this.context);
        this.soundscape = new Soundscape(this.context, this.master);
        this.music = new MusicEngine(this.context, this.master);

        this.noise = this.context.createBuffer(
          1,
          this.context.sampleRate * 3,
          this.context.sampleRate,
        );
        const data = this.noise.getChannelData(0);
        for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
      }
      this.updateVolume();
      this.context.resume()?.catch(() => {});
    } catch {
      /* Audio availability must never prevent a menu or world from opening. */
    }
  }
  updateVolume() {
    if (this.master)
      this.master.gain.setTargetAtTime(
        this.settings.volume,
        this.context.currentTime,
        0.025,
      );
  }
  note(
    frequency,
    duration,
    gain = 0.15,
    type = "sine",
    delay = 0,
    end = frequency,
  ) {
    if (!this.context || this.active > 36) return;
    const c = this.context,
      t = c.currentTime + delay,
      osc = c.createOscillator(),
      env = c.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(frequency, t);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, end), t + duration);
    env.gain.setValueAtTime(0.0001, t);
    env.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), t + 0.008);
    env.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    osc.connect(env);
    let spatial;
    if (this.voicePan) {
      spatial = c.createStereoPanner();
      spatial.pan.value = this.voicePan;
      env.connect(spatial);
      spatial.connect(this.master);
    } else env.connect(this.master);
    osc.start(t);
    osc.stop(t + duration);
    this.active++;
    osc.onended = () => {
      this.active--;
      osc.disconnect();
      env.disconnect();
      spatial?.disconnect();
    };
  }
  hiss(duration, frequency = 900, gain = 0.16, delay = 0, type = "lowpass") {
    if (!this.context || this.active > 36) return;
    const c = this.context,
      t = c.currentTime + delay,
      source = c.createBufferSource(),
      filter = c.createBiquadFilter(),
      env = c.createGain();
    source.buffer = this.noise;
    filter.type = type;
    filter.frequency.setValueAtTime(frequency, t);
    filter.frequency.exponentialRampToValueAtTime(
      Math.max(80, frequency * 0.4),
      t + duration,
    );
    filter.Q.value = 0.7;
    env.gain.setValueAtTime(0.0001, t);
    env.gain.linearRampToValueAtTime(gain, t + 0.006);
    env.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    source.connect(filter);
    filter.connect(env);
    let spatial;
    if (this.voicePan) {
      spatial = c.createStereoPanner();
      spatial.pan.value = this.voicePan;
      env.connect(spatial);
      spatial.connect(this.master);
    } else env.connect(this.master);
    source.start(t, Math.random() * 0.4, Math.min(duration, 2.5));
    this.active++;
    source.onended = () => {
      this.active--;
      source.disconnect();
      filter.disconnect();
      env.disconnect();
      spatial?.disconnect();
    };
  }
  tone(type, surface = "grass") {
    if (!this.context || !this.settings.volume) return;
    this.updateVolume();
    this.played++;
    const stone = /stone|ore|cobble|obsidian|basalt|furnace|brick/.test(
        surface,
      ),
      wood = /log|plank|chest|table|bed/.test(surface),
      pitch = 0.93 + Math.random() * 0.14;
    if (type === "pistol") {
      const finish =
        surface === "black" || surface === "silver"
          ? surface
          : (this.pistolShots = (this.pistolShots || 0) + 1) % 2
            ? "silver"
            : "black";
      this.sample(
        `pistol_${finish}`,
        0.34,
        0.992 + Math.random() * 0.016,
        0,
        finish === "black" ? -0.12 : 0.12,
      );
    } else if (type === "trickster") {
      this.hiss(0.2, 1700, 0.06);
      this.note(420, 0.22, 0.035, "sine", 0, 960);
    } else if (type === "incursion") {
      this.hiss(1.8, 230, 0.14);
      this.note(42, 1.7, 0.12, "sine", 0, 84);
      this.note(126, 1.3, 0.035, "triangle", 0.2, 47);
    } else if (type === "ui") {
      // A rounded, quiet wooden key: smooth envelopes avoid sharp click transients.
      this.note(620 * pitch, 0.065, 0.045, "sine", 0, 410 * pitch);
      this.note(940 * pitch, 0.045, 0.012, "sine", 0.004, 730 * pitch);
      this.hiss(0.045, 1100, 0.018);
    } else if (type === "arrow") {
      this.hiss(0.12, 3800, 0.08);
      this.note(280, 0.07, 0.025, "triangle", 0, 130);
    } else if (type === "fuse") {
      this.hiss(0.28, 3300, 0.12, 0, "highpass");
    } else if (type === "explosion" || type === "guardian-impact") {
      this.hiss(0.65, 420, 0.23);
      this.note(95, 0.45, 0.16, "sine", 0, 25);
    } else if (type === "guardian-charge" || type === "rune") {
      this.note(145, 0.7, 0.055, "sine", 0, 580);
      this.note(218, 0.8, 0.025, "sine", 0.06, 870);
    } else if (type === "seeker") {
      this.note(330, 0.28, 0.07, "sine", 0, 990);
      this.note(660, 0.4, 0.025, "sine", 0.025, 1320);
      this.hiss(0.18, 2200, 0.025);
    } else if (["step", "land", "break", "place", "mine"].includes(type)) {
      const family = surfaceFamily(surface),
        volume =
          type === "mine"
            ? 0.3
            : type === "step"
              ? 0.38
              : type === "land"
                ? 0.9
                : type === "place"
                  ? 0.62
                  : 1;
      this.sample(
        family,
        volume,
        type === "step"
          ? 1.12
          : type === "land"
            ? 0.76
            : 0.9 + Math.random() * 0.16,
      );
      if (type === "break") {
        this.sample(family, 0.32, 1.32, 0.04);
        if (family === "stone") this.hiss(0.14, 2200, 0.045, 0.03);
      }
    } else if (type === "hit") {
      this.sample("cloth", 1, 0.8);
      this.sample("stone", 0.22, 0.65);
      this.hiss(0.12, 1300, 0.12);
    } else if (type === "swing") {
      this.hiss(0.16, 3500, 0.1, 0, "bandpass");
    } else if (type === "craft" || type === "pickup" || type === "smelt") {
      const f = type === "pickup" ? 880 : type === "smelt" ? 550 : 440;
      for (let i = 0; i < 3; i++)
        this.note(f * [1, 1.25, 1.5][i], 0.22, 0.06, "sine", i * 0.06);
    } else if (type === "eat") {
      for (let i = 0; i < 3; i++)
        this.hiss(0.055, 1700 + i * 600, 0.14, i * 0.1);
    } else if (type === "open") {
      this.note(220, 0.16, 0.09, "triangle", 0, 110);
      this.hiss(0.12, 950, 0.07);
    } else if (type === "door-open" || type === "door-close") {
      this.sample("wood", 0.55, type === "door-open" ? 0.75 : 0.95);
      this.note(
        type === "door-open" ? 155 : 210,
        0.18,
        0.045,
        "triangle",
        0.02,
        type === "door-open" ? 240 : 100,
      );
      this.sample("wood", 0.25, 1.6, 0.12);
    } else if (type === "bucket" || type === "fizz") {
      this.hiss(
        type === "bucket" ? 0.25 : 0.55,
        type === "bucket" ? 750 : 3800,
        0.085,
      );
      if (type === "bucket") this.note(210, 0.16, 0.04, "sine", 0, 420);
    } else if (type === "ignite") {
      this.hiss(0.45, 4100, 0.2);
      this.note(580, 0.08, 0.07, "triangle", 0, 180);
    } else if (type === "portal") {
      for (let i = 0; i < 8; i++) {
        this.note(110 * Math.pow(2, i / 12), 1.4, 0.045, "sine", i * 0.08, 55);
        this.note(
          220 * Math.pow(2, i / 12),
          0.8,
          0.025,
          "triangle",
          i * 0.08,
          110,
        );
      }
      this.hiss(0.6, 650, 0.13, 0.15);
    } else if (type === "trade") {
      this.mob("villager", 0);
      this.note(740, 0.12, 0.04, "sine", 0.1, 960);
      this.note(1100, 0.16, 0.04, "sine", 0.18, 1200);
    } else if (type === "enchant" || type === "relic") {
      for (let i = 0; i < 5; i++)
        this.note(
          330 * [1, 1.25, 1.5, 2, 2.5][i],
          type === "relic" ? 1.2 : 0.5,
          0.045,
          "sine",
          i * 0.08,
        );
      this.hiss(0.35, 4200, 0.04);
    } else if (type === "pulse") {
      this.note(110, 0.5, 0.16, "sine", 0, 35);
      this.hiss(0.35, 2300, 0.12);
      this.note(660, 0.5, 0.05, "triangle", 0.04, 220);
    } else if (type === "equip") {
      this.sample("cloth", 0.5, 1.2);
      this.note(280, 0.05, 0.04, "triangle", 0, 180);
    } else if (type === "growl") {
      this.note(63 * pitch, 0.6, 0.11, "sawtooth", 0, 37);
      this.note(78 * pitch, 0.45, 0.05, "triangle", 0.06, 49);
      this.hiss(0.4, 550, 0.06);
    } else if (type === "dawn") {
      for (let i = 0; i < 4; i++)
        this.note(
          1200 + (i % 2) * 550,
          0.12,
          0.035,
          "sine",
          i * 0.16,
          1700 + i * 100,
        );
    } else if (type === "dusk") {
      this.note(196, 1.3, 0.04, "sine");
      this.note(246.94, 1.4, 0.025, "sine", 0.15, 164.81);
      this.hiss(0.5, 1100, 0.035);
    } else if (type === "swim") {
      this.hiss(0.3, 1100, 0.13);
      this.note(190, 0.16, 0.04, "sine", 0, 75);
    } else {
      this.note(140, 0.08, 0.06, "triangle", 0, 90);
    }
  }
  sample(family, gain = 0.5, rate = 1, delay = 0, pan = 0) {
    if (!this.context || this.active > 44) return;
    const choices = this.bank?.[family] || this.voices?.[family];
    if (!choices) return;
    const c = this.context,
      source = c.createBufferSource(),
      volume = c.createGain(),
      stereo = c.createStereoPanner();
    source.buffer = choices[Math.floor(Math.random() * choices.length)];
    source.playbackRate.value = rate;
    volume.gain.value = gain;
    stereo.pan.value = Math.max(-1, Math.min(1, pan));
    source.connect(volume);
    volume.connect(stereo);
    stereo.connect(this.master);
    source.start(c.currentTime + delay);
    this.active++;
    source.onended = () => {
      this.active--;
      source.disconnect();
      volume.disconnect();
      stereo.disconnect();
    };
  }
  voice(game, entity, kind = "idle") {
    const dx = entity.x - game.player.x,
      dz = entity.z - game.player.z,
      d = Math.hypot(dx, dz, entity.y - game.player.y);
    const pan =
      d > 0.01
        ? (dx * Math.cos(game.player.yaw) - dz * Math.sin(game.player.yaw)) / d
        : 0;
    this.mob(entity.type, d, kind, pan);
  }
  mob(type, distance = 0, kind = "idle", pan = 0) {
    if (
      !this.context ||
      !this.settings.volume ||
      this.settings.mobSounds === false ||
      (this.settings.mobVolume ?? 0.75) <= 0 ||
      distance > 32
    )
      return;
    const gain =
        Math.max(0, 1 - distance / 32) ** 2 *
        (this.settings.mobVolume ?? 0.75) *
        (kind === "idle" ? 0.35 : 0.5),
      pitch =
        (0.96 + Math.random() * 0.08) *
        (kind === "death"
          ? 0.72
          : kind === "hurt"
            ? 1.25
            : kind === "attack"
              ? 0.87
              : 1);
    this.played++;
    this.sample(type, gain, pitch, 0, pan);
  }
  silenceAmbient() {
    this.soundscape?.silence();
  }
  ambient(game) {
    if (!this.context) return;
    this.music?.update(game, this.settings);
    this.soundscape?.pump();
    if (
      !game.active ||
      !game.running ||
      this.settings.ambientSounds === false ||
      !this.settings.volume
    ) {
      this.silenceAmbient();
      return;
    }
    if (this.context.currentTime < (this.nextAmbienceMix || 0)) return;
    this.nextAmbienceMix = this.context.currentTime + 0.5;
    const p = game.player,
      t = game.world.terrain(p.x, p.z),
      cinder = game.dimension === "cinderwild",
      cave = p.y < t.h - 4,
      night = game.time % 24000 >= 13000 && game.time % 24000 < 23000,
      v = this.settings.ambientVolume ?? 0.55;
    if (v <= 0) {
      this.silenceAmbient();
      return;
    }
    const weather = weatherAt(game.world, p);
    let water = 0,
      fire = 0;
    if (!cave && !cinder && p.y < t.h + 15)
      for (const [dx, dz] of [
        [0, 0],
        [3, 0],
        [-3, 0],
        [0, 3],
        [0, -3],
        [7, 0],
        [-7, 0],
        [0, 7],
        [0, -7],
      ]) {
        const x = Math.floor(p.x + dx),
          z = Math.floor(p.z + dz),
          ground = game.world.terrain(x, z).h;
        if (
          Math.abs(p.y - 62) < 12 &&
          ground < 62 &&
          isWater(game.world.get(x, 61, z))
        )
          water = Math.max(water, 1 - Math.hypot(dx, dz) / 12);
        if (
          isLava(game.world.get(x, Math.floor(p.y), z)) ||
          game.world.get(x, Math.floor(p.y), z) === B.fire
        )
          fire = Math.max(fire, 1 - Math.hypot(dx, dz) / 12);
      }
    for (const [pos, container] of Object.entries(game.world.containers))
      if (container.burn > 0) {
        const [x, y, z] = pos.split(",").map(Number);
        fire = Math.max(
          fire,
          Math.max(0, 1 - Math.hypot(p.x - x, p.y - y, p.z - z) / 9),
        );
      }
    const wooded = [
        "woodland",
        "birch_woodland",
        "pine_forest",
        "snowy_taiga",
        "marsh",
        "jungle",
      ].includes(t.biome),
      dry = ["desert", "badlands", "savanna"].includes(t.biome),
      high = ["alpine", "stony_peaks"].includes(t.biome),
      hush = weather.exposed ? 1 : 0.18;
    this.soundscape?.mix(
      {
        wind:
          v *
          (weather.funnel
            ? 0.7
            : cinder
              ? 0.1
              : cave
                ? 0.05
                : high
                  ? 0.55
                  : dry
                    ? 0.32
                    : 0.22),
        leaves:
          v *
          (wooded && !cave && !cinder
            ? ["pine_forest", "snowy_taiga"].includes(t.biome)
              ? 0.09
              : 0.18
            : 0),
        water: v * (p.inWater ? 0.5 : water * 0.42),
        night:
          v *
          (night && !cave && !cinder
            ? t.biome === "marsh"
              ? 0.4
              : dry
                ? 0.11
                : 0.25
            : 0),
        rumble: v * (weather.funnel ? 0.65 : cinder ? 0.45 : cave ? 0.13 : 0),
        fire: v * (cinder ? 0.15 : fire * 0.25),
        rain: v * weather.rain * hush * 0.75,
        hail: v * (weather.hail || 0) * hush * 0.5,
        insectBase: t.biome === "marsh" ? 650 : 3500,
        insectSpread: t.biome === "marsh" ? 650 : 2800,
      },
      p.underwater,
    );
    if (
      weather.strike &&
      weather.strike.tick !== this.lastThunderTick &&
      game.world.tick - weather.strike.tick < 20
    ) {
      this.lastThunderTick = weather.strike.tick;
      const d = Math.hypot(weather.strike.x - p.x, weather.strike.z - p.z),
        delay = d / 340;
      this.hiss(1.7, 650, 0.32 * v * hush, delay);
      this.note(38, 2.4, 0.07 * v * hush, "sine", delay, 24);
      this.hiss(0.9, 220, 0.25 * v * hush, delay + 0.3);
    }
    if (
      game.elapsed >= (this.nextBird || 0) &&
      !night &&
      !cave &&
      !cinder &&
      !p.underwater
    ) {
      this.nextBird = game.elapsed + 7 + Math.random() * (dry ? 28 : 18);
      if (!weather.storm && weather.rain < 0.5) {
        const base = wooded ? 1700 : dry ? 1200 : 1450,
          count = 1 + Math.floor(Math.random() * 4);
        for (let i = 0; i < count; i++) {
          const f = base * (0.8 + Math.random() * 0.65);
          this.note(
            f,
            0.07 + Math.random() * 0.12,
            0.015 * v * (weather.exposed ? 1 : 0.25),
            "sine",
            i * 0.16,
            f * (0.8 + Math.random() * 0.7),
          );
        }
      }
    }
  }
}
