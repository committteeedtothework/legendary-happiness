const smooth = (a, b, v) => {
  const x = Math.max(0, Math.min(1, (v - a) / (b - a)));
  return x * x * (3 - 2 * x);
};
// Continuous across midnight and tick boundaries. World time remains authoritative.
export function daylightAt(time) {
  const phase = ((((time % 24000) + 24000) % 24000) / 24000) * Math.PI * 2;
  const altitude = Math.sin(phase),
    daylight = smooth(-0.24, 0.24, altitude);
  const warmth = Math.exp(-Math.pow(altitude / 0.24, 2));
  return {
    phase,
    altitude,
    daylight,
    warmth,
    sun: Math.max(0, altitude) * 1.15,
    moon: 0.12 * Math.max(0, -altitude),
    stars: 1 - smooth(-0.38, 0.04, altitude),
  };
}
