import { createPistolModel } from "./pistol-model.js";
import * as THREE from "three";
import { BLOCKS, ITEMS } from "./data.js";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { COLS, ROWS, iconURL, itemIconCanvas } from "./textures.js";

function box(parent, size, position, material) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  mesh.position.set(...position);
  parent.add(mesh);
  return mesh;
}
export function createHandRig() {
  const root = new THREE.Group(),
    wrist = new THREE.Group(),
    grip = new THREE.Group();
  root.add(wrist);
  root.position.set(0.37, -0.27, -0.72);
  wrist.rotation.set(-0.12, -0.12, -0.13);
  const skin = new THREE.MeshLambertMaterial({ color: "#bb8b64" });
  const sleeve = new THREE.MeshLambertMaterial({ color: "#355b6b" });
  box(wrist, [0.115, 0.24, 0.11], [0, -0.245, 0.07], sleeve).rotation.x = -0.3;
  box(wrist, [0.1, 0.16, 0.095], [0, -0.105, 0.025], skin);
  box(wrist, [0.108, 0.12, 0.08], [0, 0, 0.02], skin);
  // The handle fits between the palm and fingers; the head is above the fist.
  for (let i = 0; i < 3; i++)
    box(wrist, [0.1, 0.028, 0.028], [0, -0.03 + i * 0.032, -0.065], skin);
  box(wrist, [0.033, 0.065, 0.065], [-0.065, 0.015, -0.025], skin).rotation.z =
    -0.3;
  grip.position.set(0, 0, -0.042);
  wrist.add(grip);
  const glove = new THREE.Group();
  const leather = new THREE.MeshLambertMaterial({ color: "#292833" });
  box(glove, [0.111, 0.075, 0.085], [0, 0.02, 0.023], leather);
  box(glove, [0.104, 0.047, 0.1], [0, -0.075, 0.025], leather);
  glove.visible = false;
  wrist.add(glove);
  return { root, wrist, grip, sleeve, skin, glove };
}
export function createHeldModel(id, atlas) {
  const item = ITEMS[id];
  if (!item) return null;
  if (id === "matthew_dual_pistols") return createPistolModel();
  const g = new THREE.Group();
  g.userData.kind = item.block !== undefined ? "block" : item.tool || "item";
  if (item.tool && item.block === undefined) {
    const handle = new THREE.MeshLambertMaterial({ color: "#8d653d" });
    const edge = new THREE.MeshLambertMaterial({ color: item.color });
    const highlight = new THREE.MeshLambertMaterial({ color: "#e6eed5" });
    if (id.startsWith("hellfire_")) {
      handle.color.set("#3f3441");
      edge.emissive.set("#582216");
      highlight.color.set("#ffc97e");
    }
    box(
      g,
      [0.038, item.tool === "sword" ? 0.21 : 0.35, 0.038],
      [0, item.tool === "sword" ? 0 : 0.09, 0],
      handle,
    );
    if (item.legendary) {
      edge.color.set("#64dff4");
      edge.emissive.set("#164c79");
      const gold = new THREE.MeshLambertMaterial({
          color: "#d6b475",
          emissive: "#3a251c",
        }),
        rune = new THREE.MeshBasicMaterial({ color: "#b4faff" }),
        midnight = new THREE.MeshLambertMaterial({
          color: "#334766",
          emissive: "#101d39",
        });
      const blade = new THREE.Shape();
      blade.moveTo(-0.052, 0.14);
      blade.lineTo(-0.067, 0.42);
      blade.lineTo(-0.035, 0.54);
      blade.lineTo(0, 0.68);
      blade.lineTo(0.035, 0.54);
      blade.lineTo(0.067, 0.42);
      blade.lineTo(0.052, 0.14);
      blade.closePath();
      const mesh = new THREE.Mesh(
        new THREE.ExtrudeGeometry(blade, {
          depth: 0.035,
          bevelEnabled: true,
          bevelThickness: 0.007,
          bevelSize: 0.008,
          bevelSegments: 1,
          steps: 1,
        }),
        edge,
      );
      mesh.position.z = -0.018;
      g.add(mesh);
      box(g, [0.022, 0.36, 0.047], [0, 0.34, 0], midnight);
      for (let i = 0; i < 5; i++) {
        box(
          g,
          [0.023, 0.018, 0.052],
          [0, 0.22 + i * 0.058, 0],
          rune,
        ).rotation.z = i % 2 ? 0.6 : -0.6;
      }
      for (const side of [-1, 1]) {
        box(g, [0.16, 0.04, 0.07], [side * 0.095, 0.13, 0], gold).rotation.z =
          side * 0.45;
        box(
          g,
          [0.045, 0.11, 0.065],
          [side * 0.16, 0.19, 0],
          midnight,
        ).rotation.z = side * -0.3;
      }
      box(g, [0.065, 0.12, 0.068], [0, 0.12, 0], gold);
      const gem = new THREE.Mesh(new THREE.IcosahedronGeometry(0.046, 0), rune);
      gem.position.set(0, 0.15, -0.05);
      g.add(gem);
      for (let i = 0; i < 3; i++) {
        const shard = new THREE.Mesh(
          new THREE.OctahedronGeometry(0.018, 0),
          rune,
        );
        shard.position.y = 0.27 + i * 0.055;
        shard.userData.magicOrbit = (i * Math.PI * 2) / 3;
        g.add(shard);
      }
      box(g, [0.07, 0.07, 0.07], [0, -0.105, 0], midnight);
    } else if (item.tool === "spear") {
      box(g, [0.034, 0.53, 0.034], [0, 0.07, 0], handle);
      box(g, [0.075, 0.18, 0.045], [0, 0.41, 0], edge);
      box(g, [0.04, 0.07, 0.04], [0, 0.535, 0], edge);
      box(g, [0.095, 0.025, 0.055], [0, 0.325, 0], edge);
      box(g, [0.013, 0.15, 0.05], [-0.02, 0.42, 0], highlight);
    } else if (item.tool === "sword") {
      box(g, [0.15, 0.035, 0.055], [0, 0.12, 0], edge);
      box(g, [0.067, 0.34, 0.032], [0, 0.3, 0], edge);
      box(g, [0.038, 0.055, 0.032], [0, 0.497, 0], edge);
      box(g, [0.012, 0.3, 0.006], [-0.022, 0.31, -0.02], highlight);
      box(g, [0.055, 0.045, 0.055], [0, -0.103, 0], edge);
    } else if (item.tool === "pickaxe") {
      box(g, [0.31, 0.055, 0.06], [0, 0.28, 0], edge);
      for (const side of [-1, 1])
        box(g, [0.045, 0.1, 0.05], [side * 0.144, 0.24, 0], edge).rotation.z =
          side * -0.25;
    } else if (item.tool === "axe") {
      box(g, [0.13, 0.17, 0.055], [-0.075, 0.25, 0], edge);
      box(g, [0.045, 0.11, 0.065], [-0.155, 0.25, 0], edge);
    } else if (item.tool === "hoe") {
      box(g, [0.24, 0.045, 0.055], [-0.065, 0.28, 0], edge);
      box(g, [0.045, 0.1, 0.055], [-0.165, 0.24, 0], edge);
    } else {
      box(g, [0.12, 0.16, 0.04], [0, 0.29, 0], edge);
      box(g, [0.075, 0.04, 0.04], [0, 0.39, 0], edge);
    }
  } else if (item.block !== undefined) {
    const door = BLOCKS[item.block].door;
    const geometry = new THREE.BoxGeometry(
      door ? 0.15 : 0.235,
      door ? 0.32 : 0.235,
      door ? 0.035 : 0.235,
    );
    const uv = geometry.attributes.uv;
    for (let face = 0; face < 6; face++) {
      const tile = item.block * 3 + [1, 1, 0, 2, 1, 1][face];
      for (let i = face * 4; i < face * 4 + 4; i++)
        uv.setXY(
          i,
          ((tile % COLS) + 0.015 + uv.getX(i) * 0.97) / COLS,
          1 - (Math.floor(tile / COLS) + 0.985 - uv.getY(i) * 0.97) / ROWS,
        );
    }
    const cube = new THREE.Mesh(
      geometry,
      new THREE.MeshLambertMaterial({ map: atlas.texture, alphaTest: 0.5 }),
    );
    cube.material.userData.sharedMap = true;
    cube.position.set(-0.025, 0.11, door ? -0.055 : -0.18);
    cube.rotation.y = -0.35;
    g.add(cube);
  } else {
    const map = new THREE.TextureLoader().load(iconURL(id));
    map.magFilter = map.minFilter = THREE.NearestFilter;
    map.colorSpace = THREE.SRGBColorSpace;
    const sprite = new THREE.Mesh(
      new THREE.BoxGeometry(0.2, 0.23, 0.025),
      new THREE.MeshLambertMaterial({ map, alphaTest: 0.5, transparent: true }),
    );
    sprite.position.set(0, 0.08, -0.025);
    g.add(sprite);
  }
  return g;
}

export function createDroppedModel(id, atlas) {
  const item = ITEMS[id];
  if (!item) return new THREE.Group();
  let model;
  if (item.tool || item.block !== undefined) model = createHeldModel(id, atlas);
  else {
    // Solid pixel silhouettes have lit front/back faces and coloured side walls.
    // Merge horizontal runs into one vertex-coloured mesh per dropped item.
    const canvas = itemIconCanvas(id),
      data = canvas.getContext("2d").getImageData(0, 0, 32, 32).data,
      parts = [];
    for (let y = 0; y < 32; y++)
      for (let x = 0; x < 32; ) {
        const i = (y * 32 + x) * 4;
        if (data[i + 3] < 100) {
          x++;
          continue;
        }
        let end = x + 1;
        while (
          end < 32 &&
          [0, 1, 2, 3].every(
            (ch) => data[(y * 32 + end) * 4 + ch] === data[i + ch],
          )
        )
          end++;
        const geo = new THREE.BoxGeometry((end - x) / 32, 1 / 32, 0.12);
        geo.translate((x + end) / 64 - 0.5, 0.5 - (y + 0.5) / 32, 0);
        const color = new THREE.Color().setRGB(
          data[i] / 255,
          data[i + 1] / 255,
          data[i + 2] / 255,
          THREE.SRGBColorSpace,
        );
        const colors = new Float32Array(geo.attributes.position.count * 3);
        for (let j = 0; j < colors.length; j += 3)
          colors.set([color.r, color.g, color.b], j);
        geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
        parts.push(geo);
        x = end;
      }
    model = new THREE.Group();
    if (parts.length) {
      const geometry = mergeGeometries(parts);
      parts.forEach((g) => g.dispose());
      model.add(
        new THREE.Mesh(
          geometry,
          new THREE.MeshLambertMaterial({ vertexColors: true }),
        ),
      );
    }
  }
  const bounds = new THREE.Box3().setFromObject(model),
    size = bounds.getSize(new THREE.Vector3()),
    center = bounds.getCenter(new THREE.Vector3());
  // Root offset preserves rigid tool grips while normalising dropped silhouettes.
  const root = new THREE.Group(),
    scale = 0.38 / Math.max(size.x, size.y, size.z, 0.01);
  model.position.sub(center);
  root.add(model);
  root.scale.setScalar(scale);
  root.userData.droppedItem = id;
  return root;
}
