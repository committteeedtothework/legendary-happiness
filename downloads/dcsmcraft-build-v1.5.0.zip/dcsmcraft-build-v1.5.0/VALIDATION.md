# Validation record — DCSMCRAFT 1.5.0

Mechanics reference remains **Minecraft Java Edition 1.20.4**, with the partial and missing features listed in FEATURES.md. Infernal Kingdoms adds generator 11 and retains generators 2–10.

## Core checks

**310 core tests pass**, including 11 new infernal-release cases. They cover deterministic six-region terrain and negative chunk borders, all three huge structures, functioning enchanted gear, six non-clipping persistent defenders, guarded chest protection and permanent defeats, empty-container saves/regeneration, Peaceful dormancy, actual pistol hits rejected by Guardians, melee vulnerability, the Sigil-consuming approach/inner-Guardian gate/unique sword claim, Vergil preview and animated/network-valid skin, safe portal platforms above lava, and re-attuning an arch after a Peaceful visit. Prior recipes, fluids, collisions, equipment, unique weapons, storage, chat and relay tests remain.

A separate comparison imports the published 1.4.1 source and compares **54 chunks** across **both dimensions and every generator 2–10**: voxel data is byte-for-byte identical, including sampled negative boundaries. This is representative compatibility evidence, not an exhaustive comparison of every possible seed/chunk. Saved realms keep their generator. Existing Guardian health is preserved; fresh Guardians use 140 health, while bullet immunity and stronger damage apply to both.

A separate generator-11 resource probe of 49 chunks found **1,606 Hellfire ore blocks and 2,690 Brimstone ore blocks**. Existing mining-tier and alloy/equipment recipe tests remain passing.

## Browser playtests

**Six selected browser scenarios pass** on the frozen build (three new standalone scenarios, one HTTPS/WSS regression and two Survival co-op regressions). No page or checked WebGL errors were observed in the new standalone scenarios.

New scenarios use the exact built standalone HTML with external resources blocked, so the game, textures, models, fonts and worker function without internet. They cover:

- Selecting and persisting Vergil through the wardrobe, visible F5 coat rig, world creation, and flint-and-steel ignition of a real obsidian portal into a generator-11 Cinderworld.
- Rendering the Citadel, Cathedral and Crucible with their actual chests and all three new monster types; checking WebGL errors, the expedition guide and original creature models. Screenshots were visually inspected.
- Survival chest opening and mining blocked before victory; real production melee clears six defenders; the chest yields its Sigil; the Sigil is consumed once to open the temple; real pistol fire does zero Guardian damage while melee works; all three Guardians are defeated; actual held-mouse extraction waits 30 seconds and awards exactly one sword; reload preserves the sword, attunement and cleared Cinderworld encounter.

Combat tests use controlled setup, teleport positioning and advanced cooldown clocks between melee strikes, while retaining production targeting, damage, durability and defeat rules. Extraction uses real elapsed time and input. These are deterministic scenarios, not an unaided end-to-end Survival playthrough or a guarantee of zero possible bugs.

Retained regressions cover actual native HTTPS/WSS probes and two-client chat/inventory/world sharing; the full Survival co-op wood/crafting/mining/building/chest/furnace/combat/death/respawn/save/rejoin loop; and two guests racing a chest stack with owner-command permission enforcement. TLS tests use isolated test certificates; shipping certificate validation is unchanged.

## Builds and delivery

`npm test`, `npm run build`, `npm run build:standalone` and `npm run build:desktop` succeed. **107 runtime/build inputs** are frozen by SHA-256 and checked before packaging. The Windows x64 executable's extracted HTML is byte-identical to the standalone payload. ZIP CRCs and contents are verified; previous versioned release files are preserved. Published downloads are checked through independent HTTPS GETs and compared to the original byte sizes and SHA-256 hashes.

The Windows launcher is unsigned and opens installed Edge/Chrome with the existing stable desktop profile. **Actual Windows 10/11 execution remains unverified on this Linux host.** Managed browser policy prevents testing direct file:// navigation; the standalone bytes are exercised over an intercepted HTTP page with all other requests blocked.

## Remaining limits

A new world is required for the Sigil-gated temple. Previously unvisited Cinderworld realms get the new terrain; previously visited realms preserve their old generator and buildings. No destructive realm reset/migration is performed. Infernal upper towers are hollow and have no ladder system or furnished upper floors. Mob movement uses local steering, not complete dungeon navigation. Creative and Peaceful bypass encounter protection. Cinderworld travel remains unavailable during co-op; this update does not add dimension multiplayer, a dedicated simulation server or always-on hosting.

Live Cloudflare tunnel creation and native Windows hosting were not tested in this update. HTTPS/WSS regressions use a real local TLS relay. YouTube retains its external provider and file-origin limitations. The full current checklist is in FEATURES.md.

## Reproduce

```sh
npm ci
npm test
npm run build
npm run build:standalone
npm run build:desktop
npx playwright test tests/browser/infernal-release.spec.js tests/browser/https-relay.spec.js tests/browser/survival-coop.spec.js
```

Build before browser checks and keep runtime source frozen during them. TLS tests require OpenSSL only for temporary test certificates. Runtime hosting does not require OpenSSL. No source/assets from Minecraft or DMC were extracted or bundled.
