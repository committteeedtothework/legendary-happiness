Actual game renders, not generated illustrations. Open index.html.
Standalone SHA-256: 7dc01d8edda9a00b591a93b2b4a629e8bc46c85fb76cc8eca7bdc2c514cf298e
