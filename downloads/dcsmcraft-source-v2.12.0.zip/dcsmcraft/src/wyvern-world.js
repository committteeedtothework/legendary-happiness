import { wyvernGround, runwayPoint, TOWER } from "./wyvern-space.js";
import { wyvernRouteDistance } from "./wyvern-route.js";
import { wyvernFlightFrame } from "./wyvern-choreography.js";
export const WYVERN_LIMITS = Object.freeze({groundRadius:340,flightRadius:1500,minY:-600,maxY:800,mapSize:6400});
export function wyvernWorldPoint(s,p) {
  const f=wyvernFlightFrame(s),c=Math.cos(f.yaw),a=Math.sin(f.yaw);
  return {x:f.x+p.x*c+p.z*a,y:f.y+p.y,z:f.z+p.z*c-p.x*a};
}
export function wyvernFloor(s,p) {
  const q=wyvernWorldPoint(s,p),f=wyvernFlightFrame(s);
  return wyvernGround(q.x,q.z)-f.y;
}
// Scenery never occupies the playable field, elevated chase ribbon or the
// giant's swept flight corridor. These are placements, not invisible walls.
export function wyvernScenerySafe(x,z,radius=70) {
  if (Math.hypot(x,z)<420+radius) return false;
  if (wyvernRouteDistance(x,z)<340+radius) return false;
  for(let t=0;t<=2400;t+=16) {
    const p=runwayPoint(t);
    if(Math.hypot(x-p.x,z-p.z)<radius+35)return false;
  }
  return true;
}
export function clearWyvernTerrainCamera(s,camera,focus) {
  const q={...camera};
  // Lift the complete boom, including its interpolated path, above the same
  // terrain function used to build both LOD meshes.
  for(let i=1;i<=24;i++) {
    const u=i/24,p={x:focus.x+(q.x-focus.x)*u,y:focus.y+(q.y-focus.y)*u,z:focus.z+(q.z-focus.z)*u};
    const floor=wyvernFloor(s,p)+1.3;
    if(p.y<floor)q.y+=(floor-p.y)/u;
  }
  if (!s.emerald) {
    let safe={...focus};
    for(let i=1;i<=48;i++) {
      const u=i/48,p={x:focus.x+(q.x-focus.x)*u,y:focus.y+(q.y-focus.y)*u,z:focus.z+(q.z-focus.z)*u};
      const radius=13-4*Math.max(0,Math.min(1,p.y/80))+0.8;
      if(p.y<80&&Math.hypot(p.x-TOWER.x,p.z-TOWER.z)<radius)return safe;
      safe=p;
    }
  }
  return q;
}

export function wyvernLocalPoint(frame,p) {
 const x=p.x-frame.x,z=p.z-frame.z,c=Math.cos(frame.yaw),a=Math.sin(frame.yaw);
 return {x:x*c-z*a,y:p.y-frame.y,z:z*c+x*a};
}
export function advectWyvernAvatar(p,oldFrame,newFrame) {
 const c=Math.cos(oldFrame.yaw),a=Math.sin(oldFrame.yaw),world={x:oldFrame.x+p.x*c+p.z*a,y:oldFrame.y+p.y,z:oldFrame.z+p.z*c-p.x*a};
 const q=wyvernLocalPoint(newFrame,world),turn=oldFrame.yaw-newFrame.yaw;
 const vx=p.vx*Math.cos(turn)+p.vz*Math.sin(turn),vz=p.vz*Math.cos(turn)-p.vx*Math.sin(turn);
 Object.assign(p,q,{vx,vz});
}
