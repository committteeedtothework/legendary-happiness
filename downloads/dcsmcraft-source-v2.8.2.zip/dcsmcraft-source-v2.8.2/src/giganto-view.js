import {
  prepareTitanModels,
  importedRig,
  updateImportedSonic,
  updateImportedGiganto,
  disposeImportedRig,
} from "./titan-imports.js";
import * as T from "three";
import {
  makeSonic,
  makeGiganto,
  poseSonic,
  poseGiganto,
  makeTitanArena,
  makeEmerald,
  disposeTitanObject,
} from "./giganto-models.js";
import {
  TITAN_ROUTE,
  TITAN_EMERALD,
  TITAN_CHEST,
} from "./giganto-simulation.js";
// Conservative mantle clearance. The wider new shoulders need more room than
// the old cylindrical torso, both before and after camera smoothing.
export function titanCameraClearance(y) {
  return y >= 60 && y < 88 ? 38 : y >= 40 && y < 60 ? 30 : 21;
}
export class TitanView {
  constructor(game) {
    this.game = game;
    this.scene = new T.Scene();
    this.scene.background = new T.Color("#86afc2");
    this.scene.fog = new T.FogExp2("#98b6b4", 0.0024);
    this.camera = new T.PerspectiveCamera(65, 1, 0.15, 700);
    this.scene.add(new T.HemisphereLight("#d1ecf1", "#383641", 2.3));
    this.light = new T.DirectionalLight("#fff4d6", 3);
    this.light.position.set(50, 130, 60);
    this.light.castShadow = !!game.settings.shadows;
    this.light.shadow.mapSize.set(1024, 1024);
    Object.assign(this.light.shadow.camera, {
      left: -100,
      right: 100,
      top: 110,
      bottom: -100,
      near: 1,
      far: 350,
    });
    this.scene.add(this.light);
    this.arena = makeTitanArena(TITAN_ROUTE);
    this.scene.add(this.arena);
    this.sonic = makeSonic();
    this.boss = makeGiganto();
    this.emerald = makeEmerald();
    this.emerald.position.set(
      TITAN_EMERALD.x,
      TITAN_EMERALD.y,
      TITAN_EMERALD.z,
    );
    this.scene.add(this.sonic, this.boss, this.emerald);
    // Layered additive glow and a bounded, animated corona replace the opaque
    // wire sphere. Original shader; no postprocessing/fullscreen bloom required.
    const glowMat = new T.ShaderMaterial({
      uniforms: { intensity: { value: 0.8 } },
      vertexShader: `varying vec3 normalW; varying vec3 viewW;
        void main(){vec4 p=modelMatrix*vec4(position,1.); normalW=normalize(mat3(modelMatrix)*normal);viewW=cameraPosition-p.xyz;gl_Position=projectionMatrix*viewMatrix*p;}`,
      fragmentShader: `varying vec3 normalW; varying vec3 viewW;uniform float intensity;
        void main(){float edge=pow(1.-abs(dot(normalize(normalW),normalize(viewW))),2.);gl_FragColor=vec4(1.,.79,.12,edge*.38*intensity);}`,
      transparent: true,
      depthWrite: false,
      blending: T.AdditiveBlending,
      side: T.DoubleSide,
    });
    this.aura = new T.Mesh(new T.SphereGeometry(1, 24, 16), glowMat);
    this.aura.scale.set(1.25, 2.3, 1.25);
    this.scene.add(this.aura);
    this.corona = new T.InstancedMesh(
      new T.CylinderGeometry(0.016, 0.026, 1.3, 4),
      new T.MeshBasicMaterial({
        color: "#ffe86d",
        transparent: true,
        opacity: 0.65,
        blending: T.AdditiveBlending,
        depthWrite: false,
      }),
      48,
    );
    this.corona.instanceMatrix.setUsage(T.DynamicDrawUsage);
    this.corona.frustumCulled = false;
    this.scene.add(this.corona);
    this.superLight = new T.PointLight("#ffdd57", 0, 18, 2);
    this.scene.add(this.superLight);
    this.sky = new T.Mesh(
      new T.SphereGeometry(580, 32, 20),
      new T.ShaderMaterial({
        uniforms: { storm: { value: 0 } },
        side: T.BackSide,
        depthWrite: false,
        vertexShader: `varying vec3 dir;void main(){dir=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
        fragmentShader: `varying vec3 dir;uniform float storm;
        float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
        float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
        void main(){vec3 d=normalize(dir);float h=smoothstep(-.08,.8,d.y);vec3 c=mix(vec3(.74,.85,.9),vec3(.16,.43,.73),h);vec2 uv=d.xz/max(.09,d.y)*2.;float n=noise(uv)*.55+noise(uv*2.1)*.28+noise(uv*4.2)*.17;float clouds=smoothstep(.57,.76,n)*smoothstep(.04,.23,d.y);c=mix(c,vec3(.94,.97,1.),clouds*.75);c=mix(c,c*vec3(.52,.58,.72),storm*.5);gl_FragColor=vec4(c,1.);}`,
      }),
    );
    this.sky.renderOrder = -10;
    this.scene.add(this.sky);
    this.beam = new T.Mesh(
      new T.CylinderGeometry(2.6, 2.6, 1, 10),
      new T.MeshBasicMaterial({
        color: "#ff687b",
        transparent: true,
        opacity: 0.8,
      }),
    );
    this.scene.add(this.beam);
    this.climbPulse = new T.Mesh(
      new T.TorusGeometry(1, 0.035, 4, 36),
      new T.MeshBasicMaterial({
        color: "#f18082",
        transparent: true,
        opacity: 0.5,
      }),
    );
    this.scene.add(this.climbPulse);
    // Three beams per dorsal emitter; the whole 30-ray fan is one draw call.
    this.backFan = new T.InstancedMesh(
      new T.CylinderGeometry(0.18, 0.18, 1, 5),
      new T.MeshBasicMaterial({
        color: "#ff3865",
        toneMapped: false,
        transparent: true,
        opacity: 0.82,
        blending: T.AdditiveBlending,
        depthWrite: false,
      }),
      30,
    );
    this.backFan.instanceMatrix.setUsage(T.DynamicDrawUsage);
    this.backFan.frustumCulled = false;
    this.scene.add(this.backFan);
    this.rayDummy = new T.Object3D();
    this.up = new T.Vector3(0, 1, 0);
    this.emitterStart = new T.Vector3();
    this.emitterEnd = new T.Vector3();
    this.rayDelta = new T.Vector3();
    this.fx = new T.InstancedMesh(
      new T.OctahedronGeometry(0.14),
      new T.MeshBasicMaterial({ color: "#fff1ad" }),
      96,
    );
    this.fx.instanceMatrix.setUsage(T.DynamicDrawUsage);
    this.fx.frustumCulled = false;
    this.scene.add(this.fx);
    this.fxData = [];
    this.dummy = new T.Object3D();
    this.look = new T.Vector3();
    this.camReady = false;
    this.lastAction = "";
    this.assetsReady = typeof document === "undefined";
    this.ready = this.assetsReady
      ? Promise.resolve(true)
      : prepareTitanModels()
          .then((assets) => {
            if (this.disposed) return false;
            disposeTitanObject(this.sonic);
            disposeTitanObject(this.boss);
            this.sonic = importedRig(assets[0]);
            this.boss = importedRig(assets[1]);
            this.scene.add(this.sonic, this.boss);
            this.assetsReady = true;
            return true;
          })
          .catch((error) => {
            this.assetError = error.message;
            return false;
          });
  }
  event(e, s) {
    if (
      [
        "hit",
        "parry",
        "counter",
        "boom",
        "rush",
        "loop",
        "emerald",
        "qte-win",
      ].includes(e.type)
    )
      for (let n = 0; n < (e.type === "hit" ? 5 : 18); n++) {
        if (this.fxData.length >= 96) this.fxData.shift();
        const p = e.type === "emerald" ? TITAN_EMERALD : s.avatar;
        this.fxData.push({
          x: p.x,
          y: p.y + 1.5,
          z: p.z,
          vx: Math.sin(n * 2.4) * 8,
          vy: 3 + (n % 5),
          vz: Math.cos(n * 2.4) * 8,
          life: 0.7,
        });
      }
  }
  line(mesh, a, b, r = 1) {
    const d = new T.Vector3().subVectors(b, a);
    mesh.position.copy(a).add(b).multiplyScalar(0.5);
    mesh.quaternion.setFromUnitVectors(
      new T.Vector3(0, 1, 0),
      d.clone().normalize(),
    );
    mesh.scale.set(r, d.length(), r);
  }
  draw(s, dt) {
    const g = this.game,
      c = this.camera,
      p = s.avatar,
      t = s.time,
      superForm = s.emerald;
    if (!this.assetsReady) return;
    if (this.sonic.userData.imported) updateImportedSonic(this.sonic, s, dt);
    else poseSonic(this.sonic, s, dt);
    if (this.boss.userData.imported) updateImportedGiganto(this.boss, s, dt);
    else poseGiganto(this.boss, s, dt);
    this.boss.updateMatrixWorld(true);
    this.boss.visible = s.stage !== "victory";
    const dissolve =
      s.stage === "finale"
        ? Math.max(0, Math.min(1, (s.stageTime - 4) / 2.5))
        : 0;
    for (const m of this.boss.userData.materials) {
      m.transparent = dissolve > 0;
      m.opacity = 1 - dissolve;
    }
    if (s.stage === "finale" && s.stageTime > 3.8 && !this.exploded) {
      this.exploded = true;
      for (let n = 0; n < 64; n++) {
        const a = n * 2.4;
        this.fxData.push({
          x: Math.sin(a) * 8,
          y: 48 + (n % 20),
          z: Math.cos(a) * 8,
          vx: Math.sin(a) * 22,
          vy: 8 + (n % 11),
          vz: Math.cos(a) * 22,
          life: 2,
          size: 9,
        });
      }
      this.fxData = this.fxData.slice(-96);
    }
    this.emerald.visible = !s.emerald;
    this.emerald.rotation.y = t;
    this.emerald.position.y = 95 + Math.sin(t * 2) * 0.25;
    this.aura.visible = superForm;
    this.aura.position.set(p.x, p.y + 1.8, p.z);
    this.aura.rotation.y = t * 0.3;
    this.aura.material.uniforms.intensity.value =
      s.stage === "transform" ? 1.2 + Math.sin(s.stageTime * 10) * 0.4 : 0.85;
    this.aura.scale.set(1.3, 2.25, 1.3);
    this.superLight.position.copy(this.aura.position);
    this.superLight.intensity = superForm && s.config.lighting ? 5 : 0;
    this.corona.visible = superForm && s.config.particles;
    const ca = this.sonic.rotation.y;
    for (let n = 0; n < 48; n++) {
      const a = n * 2.399963 + t * (n % 2 ? 0.7 : -0.5),
        y = ((n % 12) / 12) * 4.4 - 2,
        radius = 1.1 + Math.sin(t * 7 + n * 3) * 0.14;
      this.dummy.position.set(
        p.x + Math.sin(a) * radius,
        p.y + 2 + y,
        p.z + Math.cos(a) * radius,
      );
      this.dummy.rotation.set(Math.sin(a) * 0.6, ca, Math.cos(a) * 0.6);
      this.dummy.scale.set(
        0.8,
        0.35 + (0.5 + 0.5 * Math.sin(t * 8 + n)) * 1.1,
        0.6,
      );
      this.dummy.updateMatrix();
      this.corona.setMatrixAt(n, this.dummy.matrix);
    }
    this.corona.instanceMatrix.needsUpdate = true;
    this.light.intensity = s.config.lighting
      ? 3 + (s.stage === "transform" ? Math.sin(s.stageTime * 3) * 1.1 : 0)
      : 1.7;
    const climbing = ["intro", "traversal", "transform"].includes(s.stage);
    this.arena.userData.platforms.visible = climbing;
    this.arena.userData.rings.forEach((m, n) => {
      m.visible = climbing;
      m.material.color.set(n <= s.route ? "#e4c773" : "#42ddd6");
      m.scale.setScalar(n === s.route + 1 ? 1 + Math.sin(t * 3) * 0.08 : 1);
    });
    const pulsePhase = s.time % 6;
    this.climbPulse.visible =
      s.stage === "traversal" && pulsePhase > 3 && pulsePhase < 5;
    this.climbPulse.position.set(0, 55, -12);
    this.climbPulse.scale.setScalar(10 + Math.max(0, pulsePhase - 3) * 22);
    this.climbPulse.material.opacity =
      pulsePhase < 4 ? 0.25 : 0.65 * (5 - pulsePhase);
    this.beam.visible = s.attack === "beam" && !!s.qte;
    if (this.beam.visible)
      this.line(
        this.beam,
        this.boss.userData.jawSocket
          ? this.boss.userData.jawSocket.getWorldPosition(new T.Vector3())
          : new T.Vector3(0, -0.2, 3.5).applyMatrix4(
              this.boss.userData.bones.jaw.matrixWorld,
            ),
        new T.Vector3(p.x, p.y + 1, p.z),
      );
    this.backFan.visible =
      s.phase === 2 && !["victory", "finale"].includes(s.stage);
    for (let n = 0; n < 30; n++) {
      const rod = this.boss.userData.rods[Math.floor(n / 3)],
        lane = n % 3;
      const socket = this.boss.userData.laserSockets?.[Math.floor(n / 3)];
      if (socket) socket.getWorldPosition(this.emitterStart);
      else this.emitterStart.set(0, 11.8, 0).applyMatrix4(rod.matrixWorld);
      // Behind the Titan: spectacular fan matches the existing dorsal hazard.
      // Every beam originates on an animated emitter, never floats in midair.
      const a =
        -Math.PI / 2 + (Math.floor(n / 3) / 9) * Math.PI + (lane - 1) * 0.18;
      this.emitterEnd.set(
        Math.sin(a) * (100 + lane * 25),
        132 + lane * 35,
        -65 - Math.cos(a) * 85,
      );
      this.rayDelta.subVectors(this.emitterEnd, this.emitterStart);
      this.rayDummy.position
        .copy(this.emitterStart)
        .add(this.emitterEnd)
        .multiplyScalar(0.5);
      this.rayDummy.quaternion.setFromUnitVectors(
        this.up,
        this.rayDelta.clone().normalize(),
      );
      this.rayDummy.scale.set(1, this.rayDelta.length(), 1);
      this.rayDummy.updateMatrix();
      this.backFan.setMatrixAt(n, this.rayDummy.matrix);
    }
    this.backFan.instanceMatrix.needsUpdate = true;
    if (
      superForm &&
      s.config.particles &&
      this.fxData.length < 80 &&
      Math.floor(t * 18) !== this.sparkTick
    ) {
      this.sparkTick = Math.floor(t * 18);
      this.fxData.push({
        x: p.x + Math.sin(t * 7) * 1.2,
        y: p.y + 0.5 + ((t * 3) % 3),
        z: p.z + Math.cos(t * 9) * 1.2,
        vx: 0,
        vy: 1.7,
        vz: 0,
        life: 0.7,
        size: 1.2,
      });
    }
    this.fxData = this.fxData.filter((f) => (f.life -= dt) > 0);
    for (let n = 0; n < 96; n++) {
      const f = s.config.particles ? this.fxData[n] : null;
      if (f) {
        f.x += f.vx * dt;
        f.y += f.vy * dt;
        f.z += f.vz * dt;
        this.dummy.position.set(f.x, f.y, f.z);
        this.dummy.scale.setScalar(f.life * (f.size || 1));
      } else this.dummy.scale.setScalar(0);
      this.dummy.updateMatrix();
      this.fx.setMatrixAt(n, this.dummy.matrix);
    }
    this.fx.instanceMatrix.needsUpdate = true;
    let target = new T.Vector3(p.x, p.y + 2, p.z),
      desired = new T.Vector3();
    if (s.stage === "intro") {
      target.set(0, 50, 0);
      desired.set(95, 57, 135);
    } else if (s.stage === "transform") {
      const a = s.stageTime * 0.8;
      desired.set(p.x + Math.sin(a) * 9, p.y + 4, p.z + Math.cos(a) * 9);
    } else if (s.stage === "phase") {
      target.set(0, 62, 0);
      desired.set(90, 88, 100);
    } else if (s.stage === "finale" || s.stage === "victory") {
      target.set(0, 60, 0);
      desired.set(55, 64, 102);
      if (s.stage === "finale") {
        this.sonic.position.set(
          0,
          57 + Math.min(1, s.stageTime / 4) * 26,
          33 - Math.min(1, s.stageTime / 5) * 30,
        );
        this.aura.position.copy(this.sonic.position);
      }
    } else if (s.qte) {
      target.set(0, 73, 16);
      desired.set(35, 73, 63);
    } else if (superForm && s.lock) {
      target.lerp(new T.Vector3(0, 66, 0), 0.42);
      const a = Math.atan2(p.x, p.z);
      desired.set(
        p.x + Math.sin(a) * 11 + Math.cos(a) * 2.8,
        p.y + 4.2,
        p.z + Math.cos(a) * 11 - Math.sin(a) * 2.8,
      );
    } else {
      const d = superForm ? 13 : 9,
        cp = Math.cos(p.pitch);
      desired.set(
        p.x + Math.sin(p.yaw) * d * cp,
        p.y + 3 + Math.sin(p.pitch) * d,
        p.z + Math.cos(p.yaw) * d * cp,
      );
    }
    desired.y = Math.max(2.5, desired.y);
    const r = Math.hypot(desired.x, desired.z);
    const desiredRadius = titanCameraClearance(desired.y);
    if (r < desiredRadius && desired.y < 93) {
      if (r < 0.001) desired.z = desiredRadius;
      else {
        desired.x *= desiredRadius / r;
        desired.z *= desiredRadius / r;
      }
    }
    if (this.camReady) {
      c.position.lerp(desired, 1 - Math.exp(-dt * 8));
      this.look.lerp(target, 1 - Math.exp(-dt * 9));
    } else {
      c.position.copy(desired);
      this.look.copy(target);
      this.camReady = true;
    }
    const cameraRadius = Math.hypot(c.position.x, c.position.z);
    const clearance = titanCameraClearance(c.position.y);
    if (c.position.y < 93 && cameraRadius < clearance) {
      if (cameraRadius < 0.001) c.position.z = clearance;
      else {
        c.position.x *= clearance / cameraRadius;
        c.position.z *= clearance / cameraRadius;
      }
    }
    c.position.y = Math.max(2.5, c.position.y);
    c.lookAt(this.look);
    c.aspect = innerWidth / innerHeight;
    c.updateProjectionMatrix();
    this.scene.background.set(s.phase === 2 ? "#617e96" : "#a8d6ed");
    this.sky.material.uniforms.storm.value = T.MathUtils.lerp(
      this.sky.material.uniforms.storm.value,
      s.phase === 2 ? 1 : 0,
      1 - Math.exp(-dt * 0.8),
    );
    const marker = new T.Vector3(
      TITAN_CHEST.x,
      TITAN_CHEST.y,
      TITAN_CHEST.z,
    ).project(c);
    this.targetScreen = {
      x: (marker.x + 1) * 0.5,
      y: (1 - marker.y) * 0.5,
      visible:
        marker.z > -1 &&
        marker.z < 1 &&
        Math.abs(marker.x) < 1 &&
        Math.abs(marker.y) < 1,
    };
    g.renderer.gl.info.reset();
    const gl = g.renderer.gl,
      oldMapping = gl.toneMapping,
      oldExposure = gl.toneMappingExposure;
    try {
      gl.toneMapping = T.ACESFilmicToneMapping;
      gl.toneMappingExposure = 1;
      gl.render(this.scene, c);
    } finally {
      gl.toneMapping = oldMapping;
      gl.toneMappingExposure = oldExposure;
    }
  }
  dispose() {
    this.disposed = true;
    disposeImportedRig(this.sonic);
    disposeImportedRig(this.boss);
    disposeTitanObject(this.scene);
    this.light.shadow.map?.dispose();
  }
}
export function titanPortal() {
  const group = new T.Group(),
    mat = new T.MeshBasicMaterial({ color: "#67e5dd" }),
    r = new T.Mesh(new T.TorusGeometry(1.65, 0.14, 6, 40), mat);
  r.position.y = 2;
  group.add(r);
  const inner = new T.Mesh(
    new T.CircleGeometry(1.5, 32),
    new T.MeshBasicMaterial({
      color: "#3347a5",
      side: T.DoubleSide,
      transparent: true,
      opacity: 0.66,
      depthWrite: false,
    }),
  );
  inner.position.y = 2;
  group.add(inner);
  const ring = new T.Mesh(
    new T.TorusGeometry(1.38, 0.035, 4, 32),
    new T.MeshBasicMaterial({ color: "#ffe69c" }),
  );
  ring.position.y = 2;
  group.add(ring);
  for (let n = 0; n < 7; n++) {
    const gem = new T.Mesh(
      new T.OctahedronGeometry(0.17),
      new T.MeshBasicMaterial({
        color: [
          "#ef6567",
          "#91e7d9",
          "#af91e3",
          "#f7d86b",
          "#84adf0",
          "#ece8d8",
          "#8be090",
        ][n],
      }),
    );
    const a = (n / 7) * Math.PI * 2;
    gem.position.set(Math.sin(a) * 1.8, 2 + Math.cos(a) * 1.8, 0.05);
    group.add(gem);
  }
  const light = new T.PointLight("#62e6d8", 5, 10, 2);
  light.position.y = 2;
  group.add(light);
  const sparks = new T.InstancedMesh(
    new T.OctahedronGeometry(0.06),
    new T.MeshBasicMaterial({ color: "#b9ffec" }),
    16,
  );
  sparks.position.y = 2;
  sparks.frustumCulled = false;
  group.add(sparks);
  group.userData = { ring, inner, light, sparks };
  return group;
}

const portalDummy = new T.Object3D();
export function animateTitanPortal(group, time, particles, lighting) {
  group.userData.ring.rotation.z = time * 0.4;
  group.userData.inner.rotation.z = -time * 0.25;
  group.userData.light.visible = lighting;
  group.userData.sparks.visible = particles;
  for (let n = 0; n < 16; n++) {
    const a = time * 0.65 + (n / 16) * Math.PI * 2;
    portalDummy.position.set(
      Math.sin(a) * 1.9,
      Math.cos(a) * 1.9 + Math.sin(time * 2 + n) * 0.12,
      0.15 * Math.sin(a * 3),
    );
    portalDummy.scale.setScalar(0.7 + 0.5 * Math.sin(time * 3 + n));
    portalDummy.updateMatrix();
    group.userData.sparks.setMatrixAt(n, portalDummy.matrix);
  }
  group.userData.sparks.instanceMatrix.needsUpdate = true;
}
