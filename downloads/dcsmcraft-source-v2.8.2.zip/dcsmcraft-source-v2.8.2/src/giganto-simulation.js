// Fixed-step arena simulation. No renderer, DOM, inventory or world mutation.
export const TITAN_DEFAULTS = Object.freeze({
  enabled: true,
  spawnChance: 0.32,
  cooldown: 900,
  particles: true,
  lighting: true,
  audio: true,
  music: true,
  difficulty: "normal",
  rings: 360,
  drain: 1,
  checkpoints: true,
  cinematics: true,
  strictParry: false,
});
export function titanConfig(raw = {}) {
  const n = (k, a, b) =>
    Math.max(
      a,
      Math.min(b, Number.isFinite(+raw[k]) ? +raw[k] : TITAN_DEFAULTS[k]),
    );
  return {
    ...TITAN_DEFAULTS,
    ...Object.fromEntries(
      [
        "enabled",
        "particles",
        "lighting",
        "audio",
        "music",
        "checkpoints",
        "cinematics",
        "strictParry",
      ].map((k) => [
        k,
        typeof raw[k] === "boolean" ? raw[k] : TITAN_DEFAULTS[k],
      ]),
    ),
    spawnChance: n("spawnChance", 0, 1),
    cooldown: n("cooldown", 10, 7200),
    rings: Math.round(n("rings", 100, 999)),
    drain: n("drain", 0, 3),
    difficulty: ["easy", "normal", "hard"].includes(raw.difficulty)
      ? raw.difficulty
      : "normal",
  };
}
export const TITAN_ROUTE = [
  [0, 0, 78],
  [0, 5, 59],
  [12, 12, 43],
  [26, 20, 27],
  [32, 28, 9],
  [30, 36, -9],
  [22, 44, -25],
  [4, 52, -33],
  [-18, 60, -25],
  [-28, 68, -2],
  [-18, 76, 19],
  [-4, 84, 18],
  [0, 92, 0],
].map(([x, y, z]) => ({ x, y, z, w: 14 }));
export const TITAN_MOVES = Object.freeze({
  swing: {
    label: "LEFT ARM SWING",
    tell: 1.5,
    strike: 0.42,
    recover: 3.1,
    side: -1,
  },
  slap: {
    label: "RIGHT ARM SLAP",
    tell: 1.2,
    strike: 0.32,
    recover: 2.9,
    side: 1,
  },
  beam: {
    label: "MOUTH BEAM · STRUGGLE",
    tell: 1.8,
    strike: 4.5,
    recover: 3.8,
    qte: true,
  },
  crunch: {
    label: "GRAB AND CRUNCH",
    tell: 1.75,
    strike: 4.2,
    recover: 3.6,
    qte: true,
  },
});
const clamp = (v, a, b) => Math.max(a, Math.min(b, v)),
  dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z),
  lerp = (a, b, t) => a + (b - a) * t;
export const TITAN_CHEST = { x: 0, y: 57, z: 17 },
  TITAN_EMERALD = { x: 0, y: 95, z: 0 };
export function titanSession(config = {}, portalId = "trial") {
  const c = titanConfig(config),
    hp = { easy: 1800, normal: 2600, hard: 3400 }[c.difficulty];
  return {
    schema: 1,
    id: portalId,
    stage: c.cinematics ? "intro" : "traversal",
    stageTime: 0,
    time: 0,
    config: c,
    avatar: {
      x: 0,
      y: 0.1,
      z: 78,
      vx: 0,
      vy: 0,
      vz: 0,
      yaw: 0,
      pitch: 0.1,
      onGround: true,
    },
    route: 0,
    emerald: false,
    checkpoint: "traversal",
    phase: 1,
    hp,
    maxHp: hp,
    rings: c.rings,
    energy: 100,
    combo: 0,
    comboTime: 0,
    phantom: 0,
    attack: "idle",
    attackTime: 0,
    sequence: 0,
    idle: 2.5,
    stagger: 0,
    iframes: 0,
    dodge: 0,
    action: "idle",
    actionTime: 0,
    parryAge: 0,
    parryHeld: false,
    qte: null,
    hitDone: false,
    cooldowns: { hit: 0, boom: 0, rush: 0, loop: 0, dodge: 0 },
    events: [],
    collected: [],
    counter: 0,
    pulseCooldown: 0,
    lock: true,
    won: false,
  };
}
const emit = (s, type, data = {}) => s.events.push({ type, ...data });
function change(s, stage) {
  s.stage = stage;
  s.stageTime = 0;
  emit(s, "stage", { stage });
}
export function retryTitan(s) {
  const checkpoint = s.config.checkpoints ? s.checkpoint : "traversal",
    c = s.config,
    id = s.id,
    original = s.original;
  Object.assign(s, titanSession(c, id));
  s.original = original;
  s.checkpoint = checkpoint;
  if (checkpoint !== "traversal") {
    s.emerald = true;
    s.route = TITAN_ROUTE.length - 1;
    s.phase = checkpoint === "phase2" ? 2 : 1;
    s.hp = s.phase === 2 ? s.maxHp * 0.5 : s.maxHp;
    startCombat(s);
  } else {
    s.stage = "traversal";
  }
  emit(s, "retry");
}
function startCombat(s) {
  change(s, "combat");
  s.avatar = {
    ...s.avatar,
    x: 0,
    y: 56,
    z: 48,
    vx: 0,
    vy: 0,
    vz: 0,
    onGround: false,
    yaw: 0,
    pitch: 0,
  };
  s.attack = "idle";
  s.attackTime = 0;
  s.idle = 2.5;
  s.iframes = 1;
  s.rings = s.config.rings;
  s.energy = 100;
}
export function skipTitanCinematic(s) {
  if (s.stage === "intro") change(s, "traversal");
  else if (s.stage === "transform") startCombat(s);
  else if (s.stage === "phase") {
    change(s, "combat");
    s.attack = "idle";
    s.idle = 2.5;
  } else if (s.stage === "finale") {
    s.won = true;
    change(s, "victory");
  }
}
function hurt(s) {
  if (s.iframes > 0 || s.stage !== "combat") return false;
  s.iframes = 1.25;
  s.avatar.vz += 18;
  s.avatar.vy += 5;
  s.combo = 0;
  s.action = "hurt";
  s.actionTime = 0.75;
  s.idle = Math.max(s.idle, 2.2);
  emit(s, "impact");
  return true;
}
function bossDamage(s, amount) {
  if (
    s.stage !== "combat" ||
    (s.attack === "beam" && s.qte) ||
    (s.attack === "crunch" && s.qte)
  )
    return false;
  if (s.attack !== "idle" && s.stagger <= 0 && s.attackTime < 1) return false;
  s.hp = Math.max(0, s.hp - amount * (s.phantom > 0 ? 1.2 : 1));
  s.combo++;
  s.comboTime = 3;
  if (s.combo >= 12 && s.phantom <= 0) {
    s.phantom = 8;
    emit(s, "phantom");
  }
  emit(s, "hit", { amount });
  if (s.phase === 1 && s.hp <= s.maxHp * 0.5) {
    s.hp = s.maxHp * 0.5;
    s.phase = 2;
    s.checkpoint = "phase2";
    s.qte = null;
    s.attack = "idle";
    change(s, "phase");
    if (!s.config.cinematics) skipTitanCinematic(s);
  } else if (s.hp <= 0) {
    s.qte = null;
    s.attack = "idle";
    change(s, "finale");
    if (!s.config.cinematics) skipTitanCinematic(s);
  }
  return true;
}
export function titanInput(s, action) {
  if (action === "skip") {
    skipTitanCinematic(s);
    return true;
  }
  if (action === "retry" && s.stage === "defeat") {
    retryTitan(s);
    return true;
  }
  if (s.qte && (action === "jump" || action === "hit")) {
    if (s.time - (s.qte.lastTap ?? -10) > 0.055) {
      s.qte.lastTap = s.time;
      s.qte.hits++;
      emit(s, "struggle");
    }
    return true;
  }
  if (s.stage === "traversal" && action === "jump" && s.avatar.onGround) {
    s.avatar.vy = 24;
    s.avatar.onGround = false;
    s.action = "jump";
    s.actionTime = 0.45;
    emit(s, "jump");
    return true;
  }
  if (s.stage !== "combat") return false;
  if (action === "target") {
    s.lock = !s.lock;
    return true;
  }
  if (action === "dodge" && s.cooldowns.dodge <= 0) {
    s.dodge = 0.5;
    s.iframes = 0.6;
    s.cooldowns.dodge = 0.95;
    s.action = "dodge";
    s.actionTime = 0.5;
    emit(s, "dodge");
    return true;
  }
  if (action === "hit" && s.counter > 0) {
    s.counter = 0;
    s.action = "counter";
    s.actionTime = 1.2;
    s.stagger = 3.2;
    bossDamage(s, 180);
    emit(s, "counter");
    return true;
  }
  if (action === "hit" && s.cooldowns.hit <= 0 && s.action !== "hurt") {
    s.cooldowns.hit = 0.28;
    s.action = "punch";
    s.actionTime = 0.28;
    const p = s.avatar,
      d = dist(p, TITAN_CHEST);
    if (d < 65) {
      if (d > 12) {
        const n = Math.min(0.42, (d - 10) / d);
        p.x = lerp(p.x, TITAN_CHEST.x, n);
        p.y = lerp(p.y, TITAN_CHEST.y, n);
        p.z = lerp(p.z, TITAN_CHEST.z, n);
      }
      if (d < 28) bossDamage(s, [23, 28, 37][s.combo % 3]);
    }
    return true;
  }
  if (action === "boom" && s.cooldowns.boom <= 0 && s.energy >= 18) {
    s.energy -= 18;
    s.cooldowns.boom = 1.1;
    s.action = "boom";
    s.actionTime = 0.65;
    if (dist(s.avatar, TITAN_CHEST) < 85) bossDamage(s, 65);
    emit(s, "boom");
    return true;
  }
  if (action === "rush" && s.cooldowns.rush <= 0 && s.energy >= 28) {
    s.energy -= 28;
    s.cooldowns.rush = 3.5;
    s.action = "rush";
    s.actionTime = 0.8;
    s.iframes = 0.5;
    if (dist(s.avatar, TITAN_CHEST) < 90) {
      s.avatar.x = 10;
      s.avatar.y = 58;
      s.avatar.z = 29;
      bossDamage(s, 105);
    }
    emit(s, "rush");
    return true;
  }
  if (action === "loop" && s.cooldowns.loop <= 0 && s.energy >= 45 && !s.qte) {
    s.energy -= 45;
    s.cooldowns.loop = 9;
    s.stagger = 5;
    s.attack = "idle";
    s.attackTime = 0;
    s.idle = 5;
    s.action = "loop";
    s.actionTime = 1.6;
    bossDamage(s, 75);
    emit(s, "loop");
    return true;
  }
  return false;
}
function parried(s) {
  s.attack = "idle";
  s.attackTime = 0;
  s.idle = 4;
  s.stagger = 4;
  s.counter = 2.4;
  s.action = "parry";
  s.actionTime = 0.7;
  emit(s, "parry");
}
function canParry(s) {
  return s.parryHeld && (!s.config.strictParry || s.parryAge < 0.3);
}
function beamHazards(s, dt) {
  if (s.phase < 2 || s.iframes > 0) return;
  const p = s.avatar,
    angle = Math.atan2(p.x, p.z),
    radius = Math.hypot(p.x, p.z);
  if (p.z < 0 && radius < 47 && radius > 16 && p.y > 18 && p.y < 90) {
    for (let n = 0; n < 6; n++) {
      const beam = -Math.PI + ((n + 0.5) / 6) * Math.PI;
      let d = Math.atan2(Math.sin(angle - beam), Math.cos(angle - beam));
      if (Math.abs(d) < 0.055 && Math.sin(s.time * 0.8) > 0) {
        hurt(s);
        break;
      }
    }
  }
}
export function stepTitan(s, input = {}, dt = 1 / 60) {
  if (!Number.isFinite(dt) || dt <= 0) return;
  dt = Math.min(dt, 1 / 30);
  s.events = [];
  s.time += dt;
  s.stageTime += dt;
  for (const k of Object.keys(s.cooldowns))
    s.cooldowns[k] = Math.max(0, s.cooldowns[k] - dt);
  for (const k of [
    "iframes",
    "dodge",
    "stagger",
    "counter",
    "actionTime",
    "comboTime",
    "phantom",
    "pulseCooldown",
  ])
    s[k] = Math.max(0, s[k] - dt);
  if (s.comboTime === 0) s.combo = 0;
  if (s.actionTime === 0) s.action = "idle";
  s.energy = Math.min(100, s.energy + dt * 12);
  if (input.parry) {
    s.parryAge = s.parryHeld ? s.parryAge + dt : 0;
    s.parryHeld = true;
  } else {
    s.parryHeld = false;
    s.parryAge = 0;
  }
  if (s.stage === "intro") {
    if (s.stageTime >= 4.5) change(s, "traversal");
    return;
  }
  if (s.stage === "transform") {
    if (s.stageTime >= 6) startCombat(s);
    return;
  }
  if (s.stage === "phase") {
    if (s.stageTime >= 4) skipTitanCinematic(s);
    return;
  }
  if (s.stage === "finale") {
    if (s.stageTime >= 7) {
      s.won = true;
      change(s, "victory");
    }
    return;
  }
  if (!["traversal", "combat"].includes(s.stage)) return;
  const p = s.avatar;
  let x = +!!input.right - +!!input.left,
    z = +!!input.forward - +!!input.back,
    length = Math.hypot(x, z);
  if (length) {
    x /= length;
    z /= length;
  }
  if (s.stage === "combat" && s.lock) p.yaw = Math.atan2(p.x, p.z);
  const yaw = p.yaw,
    boost = !!input.boost && s.energy > 1,
    speed = boost ? 30 : 13,
    dx = x * Math.cos(yaw) - z * Math.sin(yaw),
    dz = -x * Math.sin(yaw) - z * Math.cos(yaw),
    acc = 1 - Math.exp(-dt * (s.stage === "combat" ? 7 : p.onGround ? 14 : 6));
  if (boost && length) s.energy = Math.max(0, s.energy - dt * 20);
  p.vx = lerp(p.vx, dx * speed, acc);
  p.vz = lerp(p.vz, dz * speed, acc);
  if (s.dodge > 0) {
    p.vx += Math.cos(yaw) * dt * 95 * (x < 0 ? -1 : 1);
    p.vz -= Math.sin(yaw) * dt * 95 * (x < 0 ? -1 : 1);
  }
  if (s.stage === "traversal") {
    const pulsePhase = s.time % 6;
    if (
      p.z < -12 &&
      p.y > 30 &&
      p.y < 75 &&
      pulsePhase > 4 &&
      pulsePhase < 4.5 &&
      (s.pulseCooldown || 0) <= 0
    ) {
      const radius = Math.max(1, Math.hypot(p.x, p.z));
      p.vx += (p.x / radius) * 14;
      p.vz += (p.z / radius) * 14;
      p.vy = Math.max(p.vy, 4);
      s.pulseCooldown = 2;
      emit(s, "pulse");
    }
    const oldY = p.y;
    p.vy -= 26 * dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.z += p.vz * dt;
    p.onGround = false;
    const surfaces = [{ x: 0, y: 0, z: 0, w: 360 }, ...TITAN_ROUTE.slice(1)];
    for (const q of surfaces)
      if (
        p.vy <= 0 &&
        oldY >= q.y - 0.01 &&
        p.y <= q.y &&
        Math.abs(p.x - q.x) < q.w / 2 + 0.3 &&
        Math.abs(p.z - q.z) < q.w / 2 + 0.3
      ) {
        p.y = q.y;
        p.vy = 0;
        p.onGround = true;
      }
    const next = TITAN_ROUTE[s.route + 1];
    if (next && p.onGround && dist(p, next) < 8) {
      s.route++;
      emit(s, "checkpoint");
      if (!s.collected.includes(s.route)) {
        s.collected.push(s.route);
        emit(s, "ring");
      }
    }
    if (
      s.route >= TITAN_ROUTE.length - 1 &&
      dist({ ...p, y: p.y + 1 }, TITAN_EMERALD) < 5
    ) {
      s.emerald = true;
      s.checkpoint = "combat";
      change(s, "transform");
      emit(s, "emerald");
      if (!s.config.cinematics) startCombat(s);
    }
    const bodyRadius = Math.hypot(p.x, p.z);
    if (p.y < 88 && bodyRadius < 18) {
      const a = Math.atan2(p.x, p.z);
      p.x = Math.sin(a) * 18;
      p.z = Math.cos(a) * 18;
    }
    const safePad = TITAN_ROUTE[s.route];
    const missedPad =
      s.route > 0 &&
      ((p.onGround && p.y < safePad.y - 0.25) || p.y < safePad.y - 12);
    if (p.y < -0.2 || Math.hypot(p.x, p.z) > 175 || missedPad) {
      const q = TITAN_ROUTE[s.route];
      Object.assign(p, { x: q.x, y: q.y + 0.1, z: q.z, vx: 0, vy: 0, vz: 0 });
      emit(s, "return-pad");
    }
    return;
  }
  if (s.qte) {
    s.qte.left -= dt;
    p.vx = p.vy = p.vz = 0;
    if (s.qte.hits >= s.qte.need) {
      s.qte = null;
      s.attack = "idle";
      s.stagger = 3;
      s.idle = 3.5;
      s.attackTime = 0;
      bossDamage(s, 100);
      emit(s, "qte-win");
    } else if (s.qte.left <= 0) {
      s.qte = null;
      s.attack = "idle";
      s.idle = 3.5;
      s.attackTime = 0;
      s.rings = Math.max(
        0,
        s.rings - { easy: 10, normal: 20, hard: 30 }[s.config.difficulty],
      );
      s.iframes = 2;
      s.action = "hurt";
      s.actionTime = 1;
      emit(s, "qte-miss");
    }
    return;
  }
  s.rings = Math.max(
    0,
    s.rings -
      dt *
        s.config.drain *
        { easy: 0.65, normal: 1, hard: 1.3 }[s.config.difficulty],
  );
  if (s.rings <= 0) {
    change(s, "defeat");
    emit(s, "defeat");
    return;
  }
  p.vy = lerp(p.vy, (+!!input.up - +!!input.down) * speed, acc);
  p.x += p.vx * dt;
  p.y = clamp(p.y + p.vy * dt, 5, 115);
  p.z += p.vz * dt;
  const r = Math.hypot(p.x, p.z);
  if (r < 19 && p.y < 87) {
    const a = Math.atan2(p.x, p.z);
    p.x = Math.sin(a) * 19;
    p.z = Math.cos(a) * 19;
  }
  if (r > 130) {
    p.x *= 130 / r;
    p.z *= 130 / r;
  }
  beamHazards(s, dt);
  if (input.hit) titanInput(s, "hit");
  if (s.attack === "idle") {
    s.idle -= dt;
    if (s.idle <= 0) {
      const moves =
        s.phase === 1
          ? ["swing", "slap", "swing", "slap"]
          : ["beam", "swing", "crunch", "slap"];
      s.attack = moves[s.sequence++ % moves.length];
      s.attackTime = 0;
      s.hitDone = false;
      emit(s, "telegraph", { move: s.attack });
    }
    return;
  }
  s.attackTime += dt;
  const m = TITAN_MOVES[s.attack],
    scale = { easy: 1.25, normal: 1, hard: 0.85 }[s.config.difficulty],
    tell = m.tell * scale;
  if (!s.hitDone && s.attackTime >= tell) {
    s.hitDone = true;
    const d = dist(p, TITAN_CHEST);
    if (s.attack === "beam") {
      s.qte = {
        kind: "beam",
        left: 4.5,
        need: { easy: 8, normal: 12, hard: 16 }[s.config.difficulty],
        hits: 0,
      };
      emit(s, "beam");
    } else if (s.attack === "crunch") {
      if (d < 75 && canParry(s)) parried(s);
      else if (d < 75 && s.iframes <= 0) {
        s.qte = {
          kind: "crunch",
          left: 4.2,
          need: { easy: 8, normal: 11, hard: 14 }[s.config.difficulty],
          hits: 0,
        };
        emit(s, "grab");
      }
    } else if (
      d < 70 &&
      p.y > 28 &&
      p.y < 83 &&
      p.z > -20 &&
      p.z < 75 &&
      Math.abs(p.x) < 62
    ) {
      if (canParry(s)) parried(s);
      else hurt(s);
    }
  }
  if (s.attack !== "idle" && s.attackTime >= tell + m.strike) {
    s.attack = "idle";
    s.attackTime = 0;
    s.idle = m.recover;
  }
}
export function restoreTitanSession(raw) {
  if (
    !raw ||
    raw.schema !== 1 ||
    typeof raw.id !== "string" ||
    raw.id.length > 150 ||
    !raw.original ||
    ![
      "intro",
      "traversal",
      "transform",
      "combat",
      "phase",
      "finale",
      "victory",
      "defeat",
    ].includes(raw.stage)
  )
    return null;
  const s = titanSession(raw.config, raw.id);
  s.original = raw.original;
  for (const k of ["stage", "checkpoint"])
    if (raw[k] !== undefined) s[k] = raw[k];
  for (const k of ["emerald", "won", "lock"])
    if (typeof raw[k] === "boolean") s[k] = raw[k];
  for (const [k, a, b] of [
    ["route", 0, 12],
    ["stageTime", 0, 120],
    ["time", 0, 1e7],
    ["phase", 1, 2],
    ["maxHp", 100, 10000],
    ["hp", 0, 10000],
    ["rings", 0, 999],
    ["energy", 0, 100],
    ["sequence", 0, 1e7],
  ])
    if (Number.isFinite(raw[k])) s[k] = clamp(raw[k], a, b);
  s.route = Math.floor(s.route);
  s.phase = Math.floor(s.phase);
  s.hp = Math.min(s.hp, s.maxHp);
  s.collected = Array.isArray(raw.collected)
    ? [
        ...new Set(
          raw.collected.filter((n) => Number.isInteger(n) && n > 0 && n <= 12),
        ),
      ]
    : [];
  for (const k of ["x", "y", "z", "yaw", "pitch"])
    if (Number.isFinite(raw.avatar?.[k]))
      s.avatar[k] = clamp(
        raw.avatar[k],
        k === "y" ? -1 : -180,
        k === "y" ? 116 : 180,
      );
  if (s.stage === "combat") {
    s.attack = "idle";
    s.idle = 3;
    s.iframes = 2;
    s.qte = null;
  }
  if (!["traversal", "combat", "phase2"].includes(s.checkpoint))
    s.checkpoint = "traversal";
  return s;
}
