// Original synthesized score and effects; no Sonic recordings or sampled music.
export class TitanAudio {
  constructor(game) {
    this.game = game;
    this.notes = 0;
    this.beat = 0;
    this.next = 0;
  }
  tone(frequency, duration = 0.2, type = "sine", volume = 0.1, delay = 0) {
    const a = this.game.audio;
    if (!a.context || !a.master || !this.game.giganto?.record.config.audio)
      return;
    const ctx = a.context;
    if (!this.bus) {
      this.bus = ctx.createGain();
      this.bus.connect(a.master);
    }
    const o = ctx.createOscillator(),
      v = ctx.createGain(),
      t = ctx.currentTime + delay;
    o.type = type;
    o.frequency.setValueAtTime(frequency, t);
    o.frequency.exponentialRampToValueAtTime(
      Math.max(24, frequency * 0.72),
      t + duration,
    );
    v.gain.setValueAtTime(0.0001, t);
    v.gain.exponentialRampToValueAtTime(volume, t + 0.012);
    v.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    o.connect(v);
    v.connect(this.bus);
    this.notes++;
    o.start(t);
    o.stop(t + duration + 0.02);
    o.onended = () => {
      this.notes = Math.max(0, this.notes - 1);
      o.disconnect();
      v.disconnect();
    };
  }
  event(e) {
    const type = e.type;
    if (type === "pulse") this.tone(110, 0.5, "triangle", 0.065);
    if (type === "hit" || type === "impact") {
      this.tone(95, 0.17, "triangle", 0.17);
      this.tone(330, 0.12, "square", 0.025);
    } else if (type === "telegraph") {
      this.tone(75, 0.5, "sawtooth", 0.06);
      this.tone(155, 0.3, "triangle", 0.07, 0.2);
    } else if (["parry", "counter", "qte-win"].includes(type)) {
      [440, 660, 880].forEach((f, n) =>
        this.tone(f, 0.25, "triangle", 0.065, n * 0.06),
      );
    } else if (type === "emerald" || type === "ring") {
      [660, 880, 1320].forEach((f, n) =>
        this.tone(f, 0.3, "sine", 0.05, n * 0.08),
      );
    } else if (type === "beam") {
      this.tone(90, 0.8, "sawtooth", 0.08);
      this.tone(180, 0.65, "triangle", 0.05);
    } else if (["rush", "loop", "boom", "dodge", "jump"].includes(type)) {
      this.tone(type === "jump" ? 420 : 220, 0.22, "triangle", 0.065);
    } else if (type === "stage") {
      this.tone(110, 0.6, "triangle", 0.1);
      this.tone(165, 0.6, "sine", 0.06, 0.15);
    }
  }
  frame(s, playing) {
    const a = this.game.audio;
    a.updateVolume();
    if (this.bus)
      this.bus.gain.setTargetAtTime(
        playing && s.config.audio ? 0.65 : 0,
        a.context.currentTime,
        0.04,
      );
    if (
      !playing ||
      !s.config.audio ||
      !s.config.music ||
      this.game.settings.musicEnabled === false ||
      !a.context
    )
      return;
    const now = a.context.currentTime;
    if (now < this.next) return;
    this.next = now + 0.23;
    const roots = [82.41, 73.42, 98, 65.41],
      base = roots[Math.floor(this.beat / 16) % 4];
    this.tone(base * (this.beat % 4 === 3 ? 2 : 1), 0.21, "sawtooth", 0.026);
    if (this.beat % 2 === 0) this.tone(48, 0.12, "sine", 0.11);
    if (this.beat % 4 === 2) this.tone(180, 0.06, "triangle", 0.035);
    if (this.beat % 4 === 0) {
      const melody = [4, 3, 2, 3, 5, 4, 2, 1][Math.floor(this.beat / 4) % 8];
      this.tone(base * melody, 0.35, "triangle", 0.025);
    }
    this.beat++;
  }
  silence() {
    if (this.bus)
      this.bus.gain.setTargetAtTime(
        0,
        this.game.audio.context.currentTime,
        0.03,
      );
  }
  dispose() {
    this.silence();
    const bus = this.bus;
    this.bus = null;
    if (bus) setTimeout(() => bus.disconnect(), 500);
  }
}
