import { test, expect } from "@playwright/test";
import { readFileSync, mkdirSync, writeFileSync } from "node:fs";
import { createServer } from "node:http";
const html = readFileSync("dist/DCSMCRAFT-Standalone.html"),
  out = "/workspace/artifacts/giganto-285";
mkdirSync(out, { recursive: true });
let server, origin;
test.use({ trace: "off" });
test.beforeAll(async () => {
  server = createServer((q, r) => {
    r.setHeader("Content-Type", "text/html");
    r.end(html);
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  origin = `http://127.0.0.1:${server.address().port}`;
});
test.afterAll(async () => {
  server?.closeAllConnections();
  if (server) await new Promise((r) => server.close(r));
});
async function boot(page) {
  const errors = [],
    external = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (m) => {
    if (/Shader Error|GL_INVALID|WebGLProgram/.test(m.text()))
      errors.push(m.text());
  });
  await page.addInitScript(
    () =>
      localStorage.getItem("dcsmcraft-settings") ||
      localStorage.setItem(
        "dcsmcraft-settings",
        JSON.stringify({
          graphics: 1,
          renderDistance: 2,
          distantTerrain: false,
          volume: 0,
          musicEnabled: false,
          ambientSounds: false,
          frameLimit: 30,
          skin: "explorer",
        }),
      ),
  );
  await page.route("**/*", (r) =>
    r
      .request()
      .url()
      .startsWith(origin + "/")
      ? r.continue()
      : (external.push(r.request().url()), r.abort()),
  );
  await page.goto(origin + "/titan.html");
  await page.waitForFunction(() => dcsmcraft?.initialized);
  await page.locator("[data-action=create]").click();
  await page.locator("[name=seed]").fill("Wildflower");
  await page.locator("[name=mode][value=creative]").check();
  await page.locator("[name=difficulty]").selectOption("peaceful");
  await page.locator("[data-action=start-world]").click();
  await page.waitForFunction(
    () => dcsmcraft.running && dcsmcraft.ui.screen === "play",
  );
  await page.evaluate(() => {
    const g = dcsmcraft;
    g.pause();
    g.ui.play();
    g.entities = [];
    g.inventory.slots.fill(null);
    g.world.set(0, 199, 0, 3);
    g.inventory.selected = 0;
    Object.assign(g.player, {
      x: 0.5,
      y: 200,
      z: 0.5,
      yaw: 0,
      pitch: 0,
      vy: 0,
      onGround: true,
      health: 20,
    });
  });
  return { errors, external };
}

async function portal(page, full = false) {
  await page.evaluate((full) => {
    const g = dcsmcraft;
    if (full)
      g.inventory.slots = Array.from({ length: 36 }, () => ({
        id: "stone",
        count: 64,
      }));
    for (let x = 0; x <= 10; x++)
      for (let z = 0; z <= 10; z++) {
        g.world.set(x, 199, z, 3);
        for (let y = 200; y < 206; y++) g.world.set(x, y, z, 0);
      }
    Object.assign(g.player, {
      x: 4.5,
      y: 200,
      z: 7,
      yaw: 0,
      pitch: 0,
      onGround: true,
      health: 17,
      hunger: 12,
      saturation: 3,
    });
    g.inventory.slots[0] = {
      id: "diamond_sword",
      count: 1,
      durability: 500,
      enchantments: { sharpness: 2 },
    };
    g.giganto.record.config.spawnChance = 0;
    g.giganto.record.portal = {
      id: "browser-titan",
      cell: "0,0",
      x: 4,
      y: 200,
      z: 4,
    };
    g.giganto.overworld(0.01);
    g.running = true;
    g.pointerLockFallback = true;
  }, full);
  await page.keyboard.press("KeyE");
  await page.waitForFunction(
    () =>
      dcsmcraft.giganto.active &&
      !dcsmcraft.giganto.pending &&
      dcsmcraft.giganto.view?.assetsReady,
  );
}
async function bot(page) {
  await page.evaluate(() => {
    window.titanBot = setInterval(() => {
      const g = dcsmcraft,
        e = g.giganto,
        s = e.session;
      if (!e.active || !s || !g.running) return;
      const k = e.controls,
        p = s.avatar;
      if (s.stage === "traversal") {
        const route = [
            [0, 0, 78],
            [0, 5, 59],
            [12, 12, 43],
            [26, 20, 27],
            [32, 28, 9],
            [30, 36, -9],
            [22, 44, -25],
            [4, 52, -33],
            [-18, 60, -25],
            [-28, 68, -2],
            [-18, 76, 19],
            [-4, 84, 18],
            [0, 92, 0],
          ],
          gathering = s.route === 0 && s.rings < Math.min(360, s.config.rings),
          candidates = Array.from({ length: 36 }, (_, i) => {
            const row = Math.floor(i / 12),
              a = ((i % 12) / 12) * Math.PI * 2 + row * 0.12,
              r = 35 + row * 28;
            return { id: i, x: Math.sin(a) * r, z: Math.cos(a) * r };
          }).filter((r) => !s.ringPickups.includes(r.id)),
          ring = gathering
            ? candidates.sort(
                (a, b) =>
                  Math.hypot(a.x - p.x, a.z - p.z) -
                  Math.hypot(b.x - p.x, b.z - p.z),
              )[0]
            : null,
          q = ring ? [ring.x, 0, ring.z] : route[s.route + 1];
        if (!q) return;
        const dx = q[0] - p.x,
          dz = q[2] - p.z,
          d = Math.hypot(dx, dz);
        if (d > 1) p.yaw = Math.atan2(-dx, -dz);
        if (d > 1.3) k.add("KeyW");
        else k.delete("KeyW");
        if (d > 4) k.add("ShiftLeft");
        else k.delete("ShiftLeft");
        if (p.onGround && !ring) {
          dispatchEvent(
            new KeyboardEvent("keydown", { code: "Space", bubbles: true }),
          );
          dispatchEvent(
            new KeyboardEvent("keyup", { code: "Space", bubbles: true }),
          );
        }
      } else if (s.stage === "combat") {
        k.delete("ShiftLeft");
        k.add("Mouse0");
        k.add("Mouse2");
        if (s.qte) {
          dispatchEvent(
            new KeyboardEvent("keydown", { code: "Space", bubbles: true }),
          );
          dispatchEvent(
            new KeyboardEvent("keyup", { code: "Space", bubbles: true }),
          );
          return;
        }
        const dx = -p.x,
          dz = 5 - p.z,
          d = Math.hypot(dx, dz);
        if (d > 1) p.yaw = Math.atan2(-dx, -dz);
        if (d > 2) k.add("KeyW");
        else k.delete("KeyW");
        if (p.y < 56) k.add("Space");
        else k.delete("Space");
        if (p.y > 58) k.add("ControlLeft");
        else k.delete("ControlLeft");
        for (const code of ["KeyR", "KeyF", "KeyE"]) {
          dispatchEvent(new KeyboardEvent("keydown", { code, bubbles: true }));
          dispatchEvent(new KeyboardEvent("keyup", { code, bubbles: true }));
        }
      }
    }, 70);
  });
}
test("playable portal → Sonic traversal → final Emerald → Super Sonic → both combat phases → victory → exactly-once reward and original-world return", async ({
  page,
}) => {
  test.setTimeout(650000);
  const evidence = await boot(page);
  const original = await page.evaluate(() => ({
    dimension: dcsmcraft.dimension,
    time: dcsmcraft.time,
    seed: dcsmcraft.world.seed,
  }));
  await portal(page);
  const entryTime = await page.evaluate(() => {
    dcsmcraft.settings.musicEnabled = true;
    dcsmcraft.settings.musicVolume = 0.45;
    dcsmcraft.settings.volume = 0.03;
    return dcsmcraft.time;
  });
  await expect(page.locator("#titan-hud")).toBeVisible();
  expect(
    await page.evaluate(() => [
      dcsmcraft.giganto.view.sonic.userData.imported,
      dcsmcraft.giganto.view.boss.userData.imported,
    ]),
  ).toEqual([true, true]);
  expect(
    await page.locator("#hud").evaluate((n) => getComputedStyle(n).visibility),
  ).toBe("hidden");
  await page.screenshot({ path: out + "/intro.png" });
  await page.keyboard.press("Enter");
  await bot(page);
  await page.waitForFunction(() => dcsmcraft.giganto.session.emerald, null, {
    timeout: 210000,
  });
  await page.screenshot({ path: out + "/transformation.png" });
  await page.waitForFunction(
    () => dcsmcraft.giganto.audio.score?.state === "playing",
  );
  const openingMusic = await page.evaluate(() => ({
    section: dcsmcraft.giganto.audio.score.current.section,
    duration: dcsmcraft.giganto.audio.score.buffer.duration,
    channels: dcsmcraft.giganto.audio.score.buffer.numberOfChannels,
  }));
  expect(openingMusic.section).toBe("phaseOne");
  expect(openingMusic.duration).toBeGreaterThan(264);
  expect(openingMusic.channels).toBe(2);

  await page.waitForFunction(
    () => dcsmcraft.giganto.session.phase === 2,
    null,
    {
      timeout: 240000,
    },
  );
  await page.screenshot({ path: out + "/phase-two.png" });
  await page.waitForFunction(
    () =>
      dcsmcraft.giganto.session.stage === "combat" &&
      dcsmcraft.giganto.session.phase === 2,
  );
  await page.screenshot({ path: out + "/combat-camera.png" });
  await page.waitForFunction(
    () => dcsmcraft.giganto.session.stage === "victory",
    null,
    { timeout: 300000 },
  );
  await expect(page.locator("[data-titan=exit]")).toBeVisible();
  await page.screenshot({ path: out + "/victory.png" });
  await page.evaluate(() => clearInterval(window.titanBot));
  const before = await page.evaluate(() => {
    const g = dcsmcraft;
    return {
      hp: g.player.health,
      time: g.time,
      rings: g.giganto.session.rings,
      route: g.giganto.session.route,
      pickups: g.giganto.session.ringPickups.length,
      battleSeconds: g.giganto.session.time,
      hpMaximum: g.giganto.session.maxHp,
      geometry: g.renderer.gl.info.render.calls,
      music: {
        starts: g.giganto.audio.score?.starts,
        state: g.giganto.audio.score?.state,
        stopped: g.giganto.audio.score?.current === null,
      },
    };
  });
  expect(before.hp).toBe(17);
  expect(before.time).toBe(entryTime);
  expect(before.route).toBe(12);
  expect(before.pickups).toBeGreaterThanOrEqual(28);
  expect(before.hpMaximum).toBe(12000);
  expect(before.battleSeconds).toBeGreaterThan(90);
  expect(before.geometry).toBeLessThan(380);
  expect(before.music.starts).toBeGreaterThanOrEqual(3);
  expect(before.music.starts).toBeLessThanOrEqual(4);
  expect(before.music.stopped).toBe(true);
  await page.locator("[data-titan=exit]").click();
  await page.waitForFunction(
    () => !dcsmcraft.giganto.active && !dcsmcraft.giganto.closing,
  );
  const restored = await page.evaluate(async () => {
    const g = dcsmcraft;
    g.pause();
    await g.save();
    return {
      id: g.id,
      health: g.player.health,
      dimension: g.dimension,
      seed: g.world.seed,
      ledger: g.giganto.record.ledger,
      inventory: g.inventory.export(),
      duplicateExit: await g.giganto.exit(),
      cooldown: g.giganto.record.cooldownUntil - g.tickCount,
    };
  });
  expect(restored.health).toBe(17);
  expect(restored.dimension).toBe(original.dimension);
  expect(restored.seed).toBe(original.seed);
  expect(restored.ledger).toEqual(["browser-titan"]);
  expect(restored.duplicateExit).toBe(false);
  expect(restored.inventory.slots[0].enchantments.sharpness).toBe(2);
  expect(
    restored.inventory.slots
      .filter((q) => q?.id === "diamond")
      .reduce((n, q) => n + q.count, 0),
  ).toBe(6);
  expect(
    restored.inventory.slots
      .filter((q) => q?.id === "hellfire_ingot")
      .reduce((n, q) => n + q.count, 0),
  ).toBe(8);
  await page.evaluate(async (id) => {
    await dcsmcraft.loadWorld(id);
    dcsmcraft.pause();
  }, restored.id);
  expect(
    await page.evaluate(() => dcsmcraft.giganto.record.ledger.length),
  ).toBe(1);
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
  writeFileSync(
    out + "/victory-report.json",
    JSON.stringify({ before, restored }, null, 2),
  );
});
test("arena saves resume fairly, pause freezes resources, and forfeit restores equipment without rewards", async ({
  page,
}) => {
  test.setTimeout(150000);
  const evidence = await boot(page);
  await portal(page);
  await page.keyboard.press("Enter");
  await page.evaluate(async () => {
    const g = dcsmcraft;
    g.pause();
    await g.save();
    window.arenaSaveId = g.id;
  });
  await page.evaluate(async () => {
    await dcsmcraft.loadWorld(window.arenaSaveId);
    dcsmcraft.pause();
  });
  expect(
    await page.evaluate(
      () =>
        dcsmcraft.giganto.active &&
        dcsmcraft.giganto.session.stage === "traversal",
    ),
  ).toBe(true);
  const paused = await page.evaluate(() => ({
    time: dcsmcraft.giganto.session.time,
    rings: dcsmcraft.giganto.session.rings,
  }));
  await page.waitForTimeout(200);
  expect(
    await page.evaluate(() => ({
      time: dcsmcraft.giganto.session.time,
      rings: dcsmcraft.giganto.session.rings,
    })),
  ).toEqual(paused);
  await page.locator("[data-titan=exit]").click();
  await page.waitForFunction(() => !dcsmcraft.giganto.active);
  expect(await page.evaluate(() => dcsmcraft.player.health)).toBe(17);
  expect(
    await page.evaluate(() => dcsmcraft.giganto.record.ledger.length),
  ).toBe(0);
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
});

test("defeat retries the saved phase checkpoint; failed victory saves roll back rewards, and full inventories receive exactly one persistent overflow drop per reward", async ({
  page,
}) => {
  test.setTimeout(150000);
  const evidence = await boot(page);
  await portal(page, true);
  await page.evaluate(() => {
    const e = dcsmcraft.giganto,
      s = e.session;
    s.stage = "combat";
    s.emerald = true;
    s.phase = 2;
    s.checkpoint = "phase2";
    s.hp = s.maxHp / 2;
    s.rings = 0.0001;
    s.config.drain = 3;
  });
  await page.waitForFunction(
    () =>
      dcsmcraft.ui.screen === "titan-result" &&
      dcsmcraft.giganto.session.stage === "defeat",
  );
  await page.locator("[data-titan=retry]").click();
  expect(
    await page.evaluate(() => [
      dcsmcraft.giganto.session.phase,
      dcsmcraft.giganto.session.stage,
    ]),
  ).toEqual([2, "combat"]);
  await page.evaluate(() => {
    const g = dcsmcraft;
    g.giganto.session.stage = "victory";
    g.giganto.session.won = true;
    g.giganto.renderResultIfNeeded();
    window.realSave = g.store.save.bind(g.store);
    g.store.save = async () => {
      throw Error("simulated interrupted save");
    };
  });
  await page.locator("[data-titan=exit]").click();
  await page.waitForFunction(() => !dcsmcraft.giganto.closing);
  expect(
    await page.evaluate(() => ({
      active: dcsmcraft.giganto.active,
      ledger: dcsmcraft.giganto.record.ledger.length,
      drops: dcsmcraft.drops.filter((d) => d.uid?.startsWith("titan:")).length,
    })),
  ).toEqual({ active: true, ledger: 0, drops: 0 });
  await page.evaluate(() => (dcsmcraft.store.save = window.realSave));
  await page.locator("[data-titan=exit]").click();
  await page.waitForFunction(
    () => !dcsmcraft.giganto.active && !dcsmcraft.giganto.closing,
  );
  const result = await page.evaluate(async () => {
    const g = dcsmcraft;
    g.pause();
    await g.save();
    const id = g.id;
    await g.loadWorld(id);
    g.pause();
    return {
      ledger: g.giganto.record.ledger.length,
      items: g.drops
        .filter((d) => d.uid?.startsWith("titan:"))
        .map((d) => ({ id: d.id, count: d.count, uid: d.uid })),
      again: await g.giganto.exit(),
      health: g.player.health,
    };
  });
  expect(result.ledger).toBe(1);
  expect(result.items.map((q) => [q.id, q.count]).sort()).toEqual([
    ["diamond", 6],
    ["hellfire_ingot", 8],
  ]);
  expect(new Set(result.items.map((q) => q.uid)).size).toBe(2);
  expect(result.again).toBe(false);
  expect(result.health).toBe(17);
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
  writeFileSync(out + "/recovery-report.json", JSON.stringify(result, null, 2));
});

test("portal settings and seeded natural placement validate every occupied cell, enforce single encounter/cooldown and reject co-op activation", async ({
  page,
}) => {
  test.setTimeout(120000);
  const evidence = await boot(page);
  const result = await page.evaluate(async () => {
    const g = dcsmcraft,
      e = g.giganto;
    g.dimension = "overworld";
    const originalTerrain = g.world.terrain.bind(g.world);
    g.world.terrain = (x, z) => ({ ...originalTerrain(x, z), h: 199 });
    for (let x = -40; x <= 100; x++)
      for (let z = -40; z <= 100; z++) {
        g.world.set(x, 199, z, 3);
        for (let y = 200; y < 205; y++) g.world.set(x, y, z, 0);
      }
    e.record.config.spawnChance = 1;
    const found = e.findPortal(true),
      p = e.record.portal;
    const duplicate = e.findPortal(true);
    g.player.x = p.x + 0.5;
    g.player.y = p.y;
    g.player.z = p.z + 2;
    g.player.onGround = true;
    g.running = true;
    e.overworld(0.01);
    g.world.set(p.x + 1, p.y + 2, p.z, 3);
    const blocked = await e.enter();
    g.world.set(p.x + 1, p.y + 2, p.z, 0);
    g.multiplayer.connected = true;
    const coop = await e.enter();
    g.multiplayer.connected = false;
    e.record.cooldownUntil = g.tickCount + 100;
    const cooldown = await e.enter();
    g.world.terrain = originalTerrain;
    return { found, duplicate, blocked, coop, cooldown, active: e.active };
  });
  expect(result).toEqual({
    found: true,
    duplicate: false,
    blocked: false,
    coop: false,
    cooldown: false,
    active: false,
  });
  await page.evaluate(() => dcsmcraft.pause());
  await page.locator("[data-action=titan-menu]").click();
  await expect(page.locator("[data-titan-config=drain]")).toBeVisible();
  await page.locator("[data-titan-config=drain]").fill("0");
  await page.locator("[data-titan-config=drain]").dispatchEvent("change");
  expect(await page.evaluate(() => dcsmcraft.giganto.record.config.drain)).toBe(
    0,
  );
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
});

test("reference-image visual fixture keeps Super Sonic readable in the foreground, fans lasers from animated emitters and restores the shared renderer", async ({
  page,
}) => {
  test.setTimeout(240000);
  const evidence = await boot(page);
  await portal(page);
  const report = await page.evaluate(() => {
    const g = dcsmcraft,
      e = g.giganto,
      s = e.session,
      r = g.renderer;
    // Art inspection fixture, separate from the physical traversal playthrough.
    g.running = false;
    s.stage = "combat";
    s.phase = 2;
    s.emerald = true;
    s.stageTime = 2;
    s.attack = "idle";
    Object.assign(s.avatar, {
      x: -12,
      y: 64,
      z: 45,
      vx: 0,
      vy: 0,
      vz: 0,
      yaw: 0,
      pitch: 0,
    });
    s.config.shadowQuality = "high";
    g.settings.graphics = 3;
    g.settings.maxPixelRatio = 1;
    r.applyGraphics();
    const mapping = r.gl.toneMapping,
      exposure = r.gl.toneMappingExposure;
    const frameTimes = [];
    for (let n = 0; n < 70; n++) {
      const start = performance.now();
      s.time += 1 / 60;
      e.view.draw(s, 1 / 60);
      r.gl.getContext().finish();
      if (n > 4) frameTimes.push(performance.now() - start);
    }
    frameTimes.sort((a, b) => a - b);
    return {
      renderer: r.gl.getContext().getParameter(r.gl.getContext().RENDERER),
      renderSize: [r.gl.domElement.width, r.gl.domElement.height],
      medianFrameMs: frameTimes[Math.floor(frameTimes.length * 0.5)],
      p95FrameMs: frameTimes[Math.floor(frameTimes.length * 0.95)],
      image: r.gl.domElement.toDataURL("image/png"),
      mappingRestored: r.gl.toneMapping === mapping,
      exposureRestored: r.gl.toneMappingExposure === exposure,
      lasers: e.view.backFan.count,
      corona: e.view.corona.count,
      padsVisible: e.view.arena.userData.platforms.visible,
      camera: e.view.camera.position.toArray(),
      drawCalls: r.gl.info.render.calls,
    };
  });
  writeFileSync(
    out + "/reference-composition.png",
    Buffer.from(report.image.split(",")[1], "base64"),
  );
  delete report.image;
  await page.screenshot({ path: out + "/reference-hud.png" });
  await page.setViewportSize({ width: 854, height: 480 });
  await page.screenshot({ path: out + "/compact-hud.png" });
  await page.setViewportSize({ width: 1280, height: 800 });
  expect(report.mappingRestored).toBe(true);
  expect(report.exposureRestored).toBe(true);
  expect(report.padsVisible).toBe(false);
  expect(report.lasers).toBe(30);
  expect(report.corona).toBe(48);
  expect(report.drawCalls).toBeLessThan(200);
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
  writeFileSync(out + "/visual-report.json", JSON.stringify(report, null, 2));
});

test("every imported animation renders with embedded textures, finite rig transforms and bounded geometry; model contact sheets and software-render timing", async ({
  page,
}) => {
  test.setTimeout(180000);
  const evidence = await boot(page);
  await portal(page);
  const report = await page.evaluate(async () => {
    const g = dcsmcraft,
      v = g.giganto.view,
      gl = g.renderer.gl;
    g.running = false;
    const originalSize = { w: gl.domElement.width, h: gl.domElement.height },
      oldPixel = gl.getPixelRatio(),
      oldShadows = gl.shadowMap.enabled;
    gl.shadowMap.enabled = false;
    gl.setPixelRatio(1);
    gl.setSize(320, 320, false);
    const scene = new v.scene.constructor();
    scene.background = v.scene.background.clone();
    scene.add(v.light.clone());
    const hemi = v.scene.children.find((o) => o.isHemisphereLight);
    scene.add(hemi.clone());
    const results = {};
    for (const role of ["sonic", "giganto"]) {
      const root = role === "sonic" ? v.sonic : v.boss,
        u = root.userData,
        parent = root.parent;
      scene.add(root);
      root.position.set(0, 0, 0);
      root.rotation.set(0, 0, 0);
      const height = u.metadata.height,
        camera = v.camera.clone();
      camera.aspect = 1;
      camera.position.set(height * 0.32, height * 0.54, height * 1.7);
      camera.lookAt(0, height * 0.48, 0);
      camera.updateProjectionMatrix();
      const names = [...u.actions.keys()],
        canvas = document.createElement("canvas");
      canvas.width = 6 * 320;
      canvas.height = Math.ceil(names.length / 6) * 352;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#151f2d";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      const clips = [],
        timings = [];
      const images = [];
      root.traverse((o) => {
        if (o.isMesh) {
          for (const m of Array.isArray(o.material) ? o.material : [o.material])
            for (const k of ["map", "normalMap", "emissiveMap"])
              if (m[k])
                images.push({
                  material: m.name,
                  kind: k,
                  width: m[k].image.width,
                  height: m[k].image.height,
                });
        }
      });
      for (let i = 0; i < names.length; i++) {
        const name = names[i],
          action = u.actions.get(name),
          clip = action.getClip();
        u.mixer.stopAllAction();
        action.reset().play().setEffectiveWeight(1).setEffectiveTimeScale(1);
        const gold =
          role === "sonic" &&
          [
            "transform",
            "fly",
            "parry",
            "super_quills",
            "counter",
            "sonic_boom",
          ].includes(name);
        if (role === "sonic") {
          for (const [m, blue] of u.blueMaterials)
            m.material = gold ? u.superMaterial : blue;
          if (gold && name !== "super_quills")
            u.actions.get("super_quills").reset().play();
        }
        const samples = [];
        for (const fraction of [0.05, 0.5, 0.95]) {
          u.mixer.setTime(clip.duration * fraction);
          root.updateMatrixWorld(true);
          let finite = true,
            skins = 0;
          root.traverse((o) => {
            if (o.isSkinnedMesh) {
              o.skeleton.update();
              skins++;
              finite &&= o.skeleton.boneMatrices.every(Number.isFinite);
            }
          });
          gl.info.reset();
          const start = performance.now();
          gl.render(scene, camera);
          gl.getContext().finish();
          timings.push(performance.now() - start);
          samples.push({
            fraction,
            finite,
            skins,
            triangles: gl.info.render.triangles,
            calls: gl.info.render.calls,
          });
          if (fraction === 0.5) {
            ctx.drawImage(
              gl.domElement,
              (i % 6) * 320,
              Math.floor(i / 6) * 352,
              320,
              320,
            );
            ctx.fillStyle = "#ffffff";
            ctx.font = "16px monospace";
            ctx.fillText(
              name,
              (i % 6) * 320 + 8,
              Math.floor(i / 6) * 352 + 340,
            );
          }
        }
        clips.push({ name, duration: clip.duration, samples });
      }
      parent.add(root);
      u.mixer.stopAllAction();
      timings.sort((a, b) => a - b);
      results[role] = {
        clips,
        images,
        medianRenderMs: timings[Math.floor(timings.length * 0.5)],
        p95RenderMs: timings[Math.floor(timings.length * 0.95)],
        contactSheet: canvas.toDataURL("image/png"),
      };
    }
    gl.shadowMap.enabled = oldShadows;
    gl.setPixelRatio(oldPixel);
    gl.setSize(originalSize.w / oldPixel, originalSize.h / oldPixel, false);
    return results;
  });
  for (const role of ["sonic", "giganto"]) {
    const r = report[role];
    writeFileSync(
      out + "/" + role + "-all-clips.png",
      Buffer.from(r.contactSheet.split(",")[1], "base64"),
    );
    delete r.contactSheet;
    expect(r.images.length).toBeGreaterThan(0);
    expect(r.images.every((i) => i.width > 0 && i.height > 0)).toBe(true);
    expect(r.clips.length).toBe(role === "sonic" ? 22 : 24);
    for (const clip of r.clips)
      for (const sample of clip.samples) {
        expect(sample.finite, role + " " + clip.name).toBe(true);
        expect(sample.skins).toBeGreaterThan(0);
        expect(sample.triangles).toBeLessThan(role === "sonic" ? 30000 : 60000);
        expect(sample.calls).toBeLessThan(40);
      }
  }
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
  writeFileSync(
    out + "/all-clips-report.json",
    JSON.stringify(report, null, 2),
  );
});

test("real supplied MP3 decodes locally, emits non-silent stereo, follows phase cues and pause, restores a long checkpoint and releases on exit", async ({
  page,
}) => {
  test.setTimeout(150000);
  const evidence = await boot(page);
  await portal(page);
  await page.evaluate(() => {
    const g = dcsmcraft,
      e = g.giganto;
    g.settings.volume = 0.05;
    g.settings.musicEnabled = true;
    g.settings.musicVolume = 0.45;
    g.audio.unlock();
    // Controlled audio fixture: hold simulation still and drive the real audio
    // module with actual session states. The first case is the natural fight.
    e.realFrame = e.frame;
    e.frame = () => {};
    e.session.stage = "combat";
    e.session.stageTime = 1;
    e.session.emerald = true;
    e.audio.frame(e.session, true);
  });
  await page.waitForFunction(() => !!dcsmcraft.giganto.audio.score?.buffer);
  await page.evaluate(() =>
    dcsmcraft.giganto.audio.frame(dcsmcraft.giganto.session, true),
  );
  const decoded = await page.evaluate(() => {
    const e = dcsmcraft.giganto,
      a = e.audio.score,
      c = dcsmcraft.audio.context;
    const analyser = c.createAnalyser();
    analyser.fftSize = 2048;
    a.current.gain.connect(analyser);
    window.scoreAnalyser = analyser;
    return {
      duration: a.buffer.duration,
      sampleRate: a.buffer.sampleRate,
      channels: a.buffer.numberOfChannels,
      bytes: a.buffer.length * a.buffer.numberOfChannels * 4,
      section: a.current.section,
      offset: a.current.offset,
      starts: a.starts,
    };
  });
  expect(decoded.section).toBe("phaseOne");
  expect(decoded.offset).toBeGreaterThanOrEqual(1);
  expect(decoded.offset).toBeLessThan(20);
  expect(decoded.channels).toBe(2);
  await page.waitForFunction(() => {
    const data = new Float32Array(2048);
    scoreAnalyser.getFloatTimeDomainData(data);
    return data.some((x) => Math.abs(x) > 0.0001);
  });
  const levels = await page.evaluate(() => {
    const d = new Float32Array(2048);
    scoreAnalyser.getFloatTimeDomainData(d);
    scoreAnalyser.disconnect();
    return Math.sqrt(d.reduce((a, x) => a + x * x, 0) / d.length);
  });
  expect(levels).toBeGreaterThan(0.0001);
  const cues = await page.evaluate(() => {
    const e = dcsmcraft.giganto,
      s = e.session,
      a = e.audio.score;
    a.update(s, false, dcsmcraft.settings);
    const paused = a.current === null;
    const pausedOffset = s.battleMusic.offset;
    a.update(s, true, dcsmcraft.settings);
    const resumed = a.current.offset;
    s.phase = 2;
    s.stage = "phase";
    s.stageTime = 0;
    a.update(s, true, dcsmcraft.settings);
    const pickup = a.current.offset;
    s.stage = "combat";
    s.stageTime = 0;
    a.update(s, true, dcsmcraft.settings);
    const chorus = a.current.offset;
    s.stage = "finale";
    s.stageTime = 0;
    a.update(s, true, dcsmcraft.settings);
    const finale = a.current.offset;
    dcsmcraft.settings.musicEnabled = false;
    a.update(s, true, dcsmcraft.settings);
    const muted = a.current === null;
    dcsmcraft.settings.musicEnabled = true;
    s.stage = "combat";
    s.stageTime = 450.4;
    s.phase = 2;
    s.emerald = true;
    s.checkpoint = "phase2";
    return { paused, pausedOffset, resumed, pickup, chorus, finale, muted };
  });
  expect(cues.paused).toBe(true);
  expect(cues.resumed).toBe(cues.pausedOffset);
  expect(cues.resumed).toBeGreaterThanOrEqual(1);
  expect(cues.pickup).toBe(175.14);
  expect(cues.chorus).toBe(179.14);
  expect(cues.finale).toBe(221.14);
  expect(cues.muted).toBe(true);
  const id = await page.evaluate(async () => {
    const g = dcsmcraft;
    g.pause();
    await g.save();
    g.giganto.frame = g.giganto.realFrame;
    return g.id;
  });
  await page.evaluate(async (id) => {
    await dcsmcraft.loadWorld(id);
    dcsmcraft.pause();
  }, id);
  await page.waitForFunction(() => dcsmcraft.giganto.view?.assetsReady);
  expect(await page.evaluate(() => dcsmcraft.giganto.session.stageTime)).toBe(
    450.4,
  );
  await page.evaluate(() => {
    const e = dcsmcraft.giganto;
    e.audio.frame(e.session, true);
  });
  await page.waitForFunction(() => !!dcsmcraft.giganto.audio.score?.buffer);
  const restored = await page.evaluate(async () => {
    const g = dcsmcraft,
      e = g.giganto;
    e.audio.frame(e.session, true);
    const score = e.audio.score;
    const offset = score.current.offset;
    await e.exit(false);
    g.pause();
    return {
      offset,
      disposed: score.disposed,
      bufferReleased: score.buffer === null,
      voices: score.voices.size,
      active: e.active,
      ledger: e.record.ledger.length,
    };
  });
  expect(restored.offset).toBeGreaterThanOrEqual(160.54);
  expect(restored.offset).toBeLessThan(198.94);
  expect(restored.disposed).toBe(true);
  expect(restored.bufferReleased).toBe(true);
  expect(restored.voices).toBe(0);
  expect(restored.active).toBe(false);
  expect(restored.ledger).toBe(0);
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
  writeFileSync(
    out + "/music-report.json",
    JSON.stringify({ decoded, rms: levels, cues, restored }, null, 2),
  );
});

test("pre-fight recording plays during physical ring collection, collected rings survive reload and the original HUD returns after the trial", async ({
  page,
}) => {
  test.setTimeout(150000);
  const evidence = await boot(page);
  await portal(page);
  await page.evaluate(() => {
    const g = dcsmcraft,
      e = g.giganto;
    g.settings.volume = 0.04;
    g.settings.musicEnabled = true;
    g.settings.musicVolume = 0.45;
    g.audio.unlock();
    e.session.stage = "traversal";
    Object.assign(e.session.avatar, {
      x: 0,
      y: 0.1,
      z: 41,
      yaw: 0,
      pitch: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      onGround: true,
    });
  });
  await page.keyboard.press("KeyA");
  await page.waitForFunction(
    () => dcsmcraft.giganto.audio.prelude?.player.state === "playing",
  );
  const pre = await page.evaluate(() => {
    const p = dcsmcraft.giganto.audio.prelude.player;
    return {
      duration: p.media.duration,
      time: p.media.currentTime,
      loop: p.media.loop,
      title: p.currentTrack.title,
    };
  });
  expect(pre.duration).toBeGreaterThan(245);
  expect(pre.title).toBe("Titan: GIGANTO");
  expect(pre.loop).toBe(true);
  await page.keyboard.down("KeyW");
  await page.waitForFunction(() =>
    dcsmcraft.giganto.session.ringPickups.includes(0),
  );
  await page.keyboard.up("KeyW");
  await page.screenshot({ path: out + "/ring-preparation-hud.png" });
  const id = await page.evaluate(async () => {
    const g = dcsmcraft;
    g.pause();
    await g.save();
    return g.id;
  });
  await page.evaluate(async (id) => {
    await dcsmcraft.loadWorld(id);
    dcsmcraft.pause();
  }, id);
  await page.waitForFunction(() => dcsmcraft.giganto.view?.assetsReady);
  const saved = await page.evaluate(() => ({
    rings: dcsmcraft.giganto.session.rings,
    pickups: dcsmcraft.giganto.session.ringPickups,
    route: dcsmcraft.giganto.session.route,
  }));
  expect(saved.rings).toBe(90);
  expect(saved.pickups).toEqual([0]);
  expect(saved.route).toBe(0);
  await page.evaluate(() => {
    const g = dcsmcraft,
      s = g.giganto.session;
    s.stage = "transform";
    s.emerald = true;
    s.rings = 125;
    g.giganto.input("skip");
    g.resume();
  });
  await page.waitForFunction(
    () => dcsmcraft.giganto.audio.score?.state === "playing",
  );
  const fight = await page.evaluate(() => ({
    rings: dcsmcraft.giganto.session.rings,
    preReleased: !dcsmcraft.giganto.audio.prelude?.player.media,
    phase: dcsmcraft.giganto.audio.score.current.section,
  }));
  expect(fight.rings).toBeLessThanOrEqual(125);
  expect(fight.rings).toBeGreaterThan(120);
  expect(fight.preReleased).toBe(true);
  expect(fight.phase).toBe("phaseOne");
  await page.evaluate(async () => {
    await dcsmcraft.giganto.exit(false);
    dcsmcraft.pause();
  });
  const restored = await page.evaluate(() => ({
    active: dcsmcraft.giganto.active,
    skin: dcsmcraft.settings.skin,
    health: dcsmcraft.player.health,
    hud: getComputedStyle(document.querySelector("#hud")).visibility,
    scope: document.querySelector("#app").classList.contains("titan-active"),
    scoreGone: !dcsmcraft.giganto.audio.score,
    preGone: !dcsmcraft.giganto.audio.prelude,
  }));
  expect(restored.active).toBe(false);
  expect(restored.health).toBe(17);
  expect(restored.hud).toBe("visible");
  expect(restored.scope).toBe(false);
  expect(restored.scoreGone).toBe(true);
  expect(restored.preGone).toBe(true);
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
  writeFileSync(
    out + "/prelude-rings-report.json",
    JSON.stringify({ pre, saved, fight, restored }, null, 2),
  );
});

test("arena-only cyan HUD, live damage tuning, dynamic shadows, controllable attacks and cutscene skips restore the original renderer and player", async ({
  page,
}) => {
  test.setTimeout(240000);
  const evidence = await boot(page);
  await portal(page);
  const initial = await page.evaluate(() => {
    const g = dcsmcraft,
      e = g.giganto,
      s = e.session;
    g.running = false;
    s.stage = "combat";
    s.emerald = true;
    s.idle = 999;
    s.config.drain = 0;
    Object.assign(s.avatar, {
      x: 0,
      y: 57,
      z: 5,
      vx: 0,
      vy: 0,
      vz: 0,
      yaw: 0.4,
    });
    const hp = s.hp;
    e.input("hit");
    return { hp, after: s.hp, pending: !!s.strike };
  });
  expect(initial.after).toBe(initial.hp);
  expect(initial.pending).toBe(true);
  const moved = await page.evaluate(() => {
    const e = dcsmcraft.giganto,
      s = e.session,
      p = { ...s.avatar };
    e.controls.add("KeyD");
    e.controls.add("Space");
    for (let i = 0; i < 8; i++) {
      dcsmcraft.running = true;
      e.frame(1 / 60);
    }
    dcsmcraft.running = false;
    e.controls.clear();
    return {
      x: s.avatar.x - p.x,
      y: s.avatar.y - p.y,
      yaw: s.avatar.yaw,
      hp: s.hp,
    };
  });
  expect(moved.x).toBeGreaterThan(0.2);
  expect(moved.y).toBeGreaterThan(0.2);
  expect(moved.yaw).toBe(0.4);
  expect(moved.hp).toBeLessThan(initial.hp);
  await page.evaluate(() => {
    dcsmcraft.giganto.pauseMenu();
  });
  await page.locator("[data-titan=menu]").click();
  await page.locator(".titan-tuning summary").click();
  await page.locator("[data-titan-damage=basic]").fill("49");
  await page.locator("[data-titan-damage=basic]").dispatchEvent("change");
  await page.locator("[data-titan-config=shadowQuality]").selectOption("high");
  expect(
    await page.evaluate(() => dcsmcraft.giganto.session.config.damage.basic),
  ).toBe(49);
  const render = await page.evaluate(() => {
    const g = dcsmcraft,
      e = g.giganto,
      s = e.session,
      r = g.renderer.gl;
    const old = {
      enabled: r.shadowMap.enabled,
      type: r.shadowMap.type,
      mapping: r.toneMapping,
      exposure: r.toneMappingExposure,
    };
    g.settings.graphics = 3;
    g.settings.maxPixelRatio = 1;
    g.renderer.applyGraphics();
    s.stage = "combat";
    s.emerald = true;
    s.rings = 35;
    s.phase = 2;
    s.attack = "swing";
    s.attackTime = 0.9;
    s.avatar.x = -18;
    s.avatar.y = 61;
    s.avatar.z = 36;
    for (let i = 0; i < 8; i++) {
      s.time += 1 / 60;
      e.view.draw(s, 1 / 60);
    }
    e.updateHUD();
    r.getContext().finish();
    const result = {
      mapSize: e.view.light.shadow.map?.width,
      projection: e.view.light.shadow.camera.projectionMatrix.elements.every(
        Number.isFinite,
      ),
      shadowRestored:
        r.shadowMap.enabled === old.enabled && r.shadowMap.type === old.type,
      mappingRestored:
        r.toneMapping === old.mapping && r.toneMappingExposure === old.exposure,
      shadowCasting: 0,
      calls: r.info.render.calls,
      warning: e.view.warning.visible,
      critical: e.hud.classList.contains("critical-rings"),
    };
    e.view.boss.traverse((o) => {
      if (o.isMesh && o.castShadow) result.shadowCasting++;
    });
    s.config.shadowQuality = "off";
    s.config.postProcessing = false;
    g.settings.graphics = 1;
    e.view.draw(s, 1 / 60);
    result.off =
      !e.view.light.castShadow && r.shadowMap.enabled === old.enabled;
    return result;
  });
  expect(render.mapSize).toBe(2048);
  expect(render.shadowCasting).toBeGreaterThan(0);
  expect(render.projection).toBe(true);
  expect(render.shadowRestored).toBe(true);
  expect(render.mappingRestored).toBe(true);
  expect(render.off).toBe(true);
  expect(render.warning).toBe(true);
  expect(render.critical).toBe(true);
  expect(render.calls).toBeLessThan(230);
  await page.locator("[data-titan=back]").click();
  await page.evaluate(() => {
    dcsmcraft.ui.play();
    dcsmcraft.running = false;
  });
  await page.screenshot({ path: out + "/cyan-combat-hud.png" });
  await page.setViewportSize({ width: 640, height: 480 });
  await page.screenshot({ path: out + "/cyan-compact-hud.png" });
  const skip = await page.evaluate(() => {
    const g = dcsmcraft,
      e = g.giganto,
      s = e.session;
    g.running = false;
    const stages = [];
    for (const stage of ["intro", "transform", "phase"]) {
      s.stage = stage;
      s.stageTime = 1;
      e.input("skip");
      stages.push({
        from: stage,
        to: s.stage,
        qte: s.qte,
        action: s.action,
        pending: !!s.strike,
      });
      e.view.draw(s, 1 / 60);
    }
    return stages;
  });
  expect(skip.map((x) => x.to)).toEqual(["traversal", "combat", "combat"]);
  expect(skip.every((x) => x.qte === null && !x.pending)).toBe(true);
  await page.evaluate(async () => {
    await dcsmcraft.giganto.exit(false);
  });
  expect(
    await page.locator("#hud").evaluate((n) => getComputedStyle(n).visibility),
  ).toBe("visible");
  expect(await page.evaluate(() => dcsmcraft.player.health)).toBe(17);
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
  writeFileSync(
    out + "/polish-report.json",
    JSON.stringify({ initial, moved, render, skip }, null, 2),
  );
});
