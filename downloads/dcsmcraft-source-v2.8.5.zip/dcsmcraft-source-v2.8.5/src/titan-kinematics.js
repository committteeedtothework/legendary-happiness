import { nearestTitanSurface, titanArmPath } from "./titan-contact.js";
import { titanActionDuration } from "./titan-combat.js";
import * as T from "three";
const up = new T.Vector3(0, 1, 0);
function rotateWorld(bone, from, to, weight) {
  if (from.lengthSq() < 1e-8 || to.lengthSq() < 1e-8) return;
  const delta = new T.Quaternion().setFromUnitVectors(
      from.normalize(),
      to.normalize(),
    ),
    q = bone.getWorldQuaternion(new T.Quaternion()).premultiply(delta),
    parent =
      bone.parent?.getWorldQuaternion(new T.Quaternion()) || new T.Quaternion();
  q.premultiply(parent.invert());
  bone.quaternion.slerp(q, weight).normalize();
}
export function solveTitanArm(
  root,
  upper,
  elbow,
  hand,
  target,
  pole,
  weight = 1,
) {
  if (!upper || !elbow || !hand || weight <= 0) return;
  root.updateMatrixWorld(true);
  const a = upper.getWorldPosition(new T.Vector3()),
    b = elbow.getWorldPosition(new T.Vector3()),
    c = hand.getWorldPosition(new T.Vector3()),
    l1 = a.distanceTo(b),
    l2 = b.distanceTo(c),
    direction = target.clone().sub(a);
  if (l1 < 1e-4 || l2 < 1e-4 || direction.lengthSq() < 1e-8) return;
  const distance = T.MathUtils.clamp(
    direction.length(),
    Math.abs(l1 - l2) + 0.001,
    l1 + l2 - 0.001,
  );
  direction.normalize();
  const side = pole
    .clone()
    .sub(a)
    .addScaledVector(direction, -pole.clone().sub(a).dot(direction));
  if (side.lengthSq() < 1e-8) side.crossVectors(direction, up);
  if (side.lengthSq() < 1e-8) side.set(1, 0, 0);
  side.normalize();
  const along = (l1 * l1 - l2 * l2 + distance * distance) / (2 * distance),
    height = Math.sqrt(Math.max(0, l1 * l1 - along * along));
  const bend = a
    .clone()
    .addScaledVector(direction, along)
    .addScaledVector(side, height);
  rotateWorld(upper, b.clone().sub(a), bend.clone().sub(a), weight);
  root.updateMatrixWorld(true);
  const now = elbow.getWorldPosition(new T.Vector3()),
    end = hand.getWorldPosition(new T.Vector3());
  rotateWorld(elbow, end.sub(now), target.clone().sub(now), weight);
  root.updateMatrixWorld(true);
}
export function performTitanSonic(root, s) {
  const b = root.userData.bones;
  // Keep the mesh attached to the controlled avatar. Cyloop draws an energy
  // path around the opponent instead of orbiting the player without consent.
  const speed = Math.hypot(s.avatar.vx, s.avatar.vz);
  if (s.stage === "combat" && s.action === "idle") {
    root.rotation.z = T.MathUtils.clamp(-s.avatar.vx * 0.007, -0.18, 0.18);
    root.rotation.x = T.MathUtils.clamp(s.avatar.vy * 0.006, -0.15, 0.15);
    root.position.y +=
      Math.sin(s.time * 2.6) * 0.06 * (1 - Math.min(1, speed / 20));
  }

  if (s.stage === "combat" && ["punch", "counter", "rush"].includes(s.action)) {
    const u = T.MathUtils.clamp(
        1 - s.actionTime / titanActionDuration(s),
        0,
        1,
      ),
      strike = Math.sin(Math.PI * T.MathUtils.clamp(u / 0.82, 0, 1)) ** 1.6,
      left =
        s.strike?.move === "rush"
          ? Math.floor(u * 3) % 2 !== 0
          : s.comboStep % 2 !== 0;
    const contact = nearestTitanSurface(s, {
        x: s.avatar.x,
        y: s.avatar.y + 1.8,
        z: s.avatar.z,
      }),
      direction = new T.Vector3(
        contact.point.x - s.avatar.x,
        contact.point.y - s.avatar.y - 1.8,
        contact.point.z - s.avatar.z,
      ),
      distance = direction.length();
    if (distance > 2 && distance < 9)
      root.position.addScaledVector(
        direction.normalize(),
        Math.min(3, distance - 2) * strike,
      );
    root.updateMatrixWorld(true);
    const localTarget = root.localToWorld(
        new T.Vector3(left ? 0.38 : -0.38, 2.25, 0.35 + strike * 1.45),
      ),
      target = localTarget.lerp(
        new T.Vector3(contact.point.x, contact.point.y, contact.point.z),
        strike * 0.65,
      ),
      pole = root.localToWorld(new T.Vector3(left ? 1.5 : -1.5, 1.5, 0.1));
    solveTitanArm(
      root,
      b[left ? "armL" : "armR"],
      b[left ? "elbowL" : "elbowR"],
      b[left ? "handL" : "handR"],
      target,
      pole,
      0.85,
    );
  }
  if (
    s.stage === "combat" &&
    s.parryHeld &&
    !["punch", "counter"].includes(s.action)
  ) {
    for (const side of ["L", "R"]) {
      const sign = side === "L" ? 1 : -1,
        target = root.localToWorld(new T.Vector3(sign * 0.3, 2.45, 0.78)),
        pole = root.localToWorld(new T.Vector3(sign * 1.4, 1.7, 0));
      solveTitanArm(
        root,
        b["arm" + side],
        b["elbow" + side],
        b["hand" + side],
        target,
        pole,
        0.72,
      );
    }
  }
}
export function performTitanBoss(root, s) {
  const head = root.userData.bones.head;
  if (head && ["intro", "traversal", "combat"].includes(s.stage)) {
    root.updateMatrixWorld(true);
    const origin = head.getWorldPosition(new T.Vector3()),
      forward = new T.Vector3(1, 0, 0).applyQuaternion(
        head.getWorldQuaternion(new T.Quaternion()),
      ),
      target = new T.Vector3(s.avatar.x, s.avatar.y + 2, s.avatar.z).sub(
        origin,
      );
    rotateWorld(head, forward, target, 0.38);
  }

  if (s.stage !== "combat" || s.attack === "idle") return;
  const b = root.userData.bones;
  for (const side of ["L", "R"]) {
    if (s.attack !== "crunch" && side !== (s.attack === "swing" ? "L" : "R"))
      continue;
    const q = titanArmPath(s, side),
      sign = side === "L" ? 1 : -1;
    solveTitanArm(
      root,
      b["arm" + side],
      b["elbow" + side],
      b["hand" + side],
      new T.Vector3(q.x, q.y, q.z),
      new T.Vector3(sign * 58, 49, 1),
      1,
    );
  }
}
