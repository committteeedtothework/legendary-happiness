// Shared analytic rig/contact geometry, in arena metres. Rendering and the
// fixed-step simulation use the same arm paths; no renderer state drives hits.
const mix = (a, b, t) => a + (b - a) * t;
const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
export const point = (x, y, z) => ({ x, y, z });
export const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
export function closestSegment(p, a, b) {
  const dx = b.x - a.x,
    dy = b.y - a.y,
    dz = b.z - a.z;
  const t = clamp(
    ((p.x - a.x) * dx + (p.y - a.y) * dy + (p.z - a.z) * dz) /
      (dx * dx + dy * dy + dz * dz || 1),
  );
  return point(a.x + dx * t, a.y + dy * t, a.z + dz * t);
}
export function titanArmPath(s, side, clock = s.attackTime) {
  const sign = side === "L" ? 1 : -1,
    neutral = point(sign * 18, 25, -10.5);
  if (!["swing", "slap", "crunch"].includes(s.attack) || s.stage !== "combat")
    return neutral;
  const tell =
    { swing: 1.5, slap: 1.2, crunch: 1.75 }[s.attack] *
    { easy: 1.25, normal: 1, hard: 0.85 }[s.config.difficulty];
  if (s.attack === "crunch") {
    const target = s.attackAim || point(0, 57, 30),
      t = clamp(clock / tell),
      e = t * t * (3 - 2 * t);
    return point(
      mix(neutral.x, target.x + sign * 3, e),
      mix(neutral.y, target.y + 2, e),
      mix(neutral.z, target.z, e),
    );
  }
  if (side !== (s.attack === "swing" ? "L" : "R")) return neutral;
  const strike = s.attack === "swing" ? 0.65 : 0.55;
  const raised = point(sign * 50, 62, 15);
  if (clock < tell) {
    const t = clamp(clock / tell);
    return point(
      mix(neutral.x, raised.x, t),
      mix(neutral.y, raised.y, t),
      mix(neutral.z, raised.z, t),
    );
  }
  const u = clamp((clock - tell) / strike),
    e = u * u * (3 - 2 * u);
  return point(
    sign * (50 - 75 * e),
    62 - 9 * Math.sin(u * Math.PI),
    15 + 21 * Math.sin(u * Math.PI),
  );
}
export function titanBodyRegions(s, clock = s.attackTime) {
  const regions = [
    { id: "torso", center: point(0, 63, -7.5), axes: point(16, 20, 8.5) },
    { id: "hips", center: point(0, 53, -7.5), axes: point(10, 10, 7) },
    { id: "head", center: point(0, 85, 7), axes: point(11, 11, 11) },
  ];
  for (const side of ["L", "R"]) {
    const sign = side === "L" ? 1 : -1,
      shoulder = point(sign * 20, 73, -8.5),
      hand = titanArmPath(s, side, clock);
    const elbow = point(
      mix(shoulder.x, hand.x, 0.54) + sign * 3,
      mix(shoulder.y, hand.y, 0.54),
      mix(shoulder.z, hand.z, 0.54),
    );
    regions.push(
      {
        id: side + " shoulder",
        a: point(sign * 13, 74, -7),
        b: shoulder,
        r: 12,
      },
      { id: side + " upper arm", a: shoulder, b: elbow, r: 7 },
      { id: side + " forearm", a: elbow, b: hand, r: 5.5 },
      { id: side + " hand", a: hand, b: hand, r: 5 },
      {
        id: side + " thigh",
        a: point(sign * 5, 51, -6),
        b: point(sign * 5, 27, -6),
        r: 7,
      },
      {
        id: side + " shin",
        a: point(sign * 5, 27, -6),
        b: point(sign * 5, 4, -3),
        r: 5,
      },
    );
  }
  return regions;
}
function regionContact(region, p) {
  if (region.axes) {
    const keys = ["x", "y", "z"],
      q = keys.map((k) => p[k] - region.center[k]),
      rr = keys.map((k) => region.axes[k] ** 2),
      unit = Math.sqrt(q.reduce((sum, v, i) => sum + (v * v) / rr[i], 0));
    let v;
    if (unit <= 1) {
      v = unit > 1e-8 ? q.map((x) => x / unit) : [0, 0, region.axes.z];
    } else {
      let lo = 0,
        hi = Math.sqrt(q.reduce((sum, v, i) => sum + v * v * rr[i], 0));
      for (let i = 0; i < 22; i++) {
        const mid = (lo + hi) / 2,
          f = q.reduce(
            (sum, v, j) => sum + (rr[j] * v * v) / (mid + rr[j]) ** 2,
            0,
          );
        if (f > 1) lo = mid;
        else hi = mid;
      }
      v = q.map((x, i) => (rr[i] * x) / ((lo + hi) / 2 + rr[i]));
    }
    const c = point(
        v[0] + region.center.x,
        v[1] + region.center.y,
        v[2] + region.center.z,
      ),
      n = v.map((x, i) => x / rr[i]),
      l = Math.hypot(...n) || 1;
    return {
      id: region.id,
      point: c,
      normal: point(n[0] / l, n[1] / l, n[2] / l),
      inside: unit < 1,
      distance: unit < 1 ? 0 : distance(p, c),
    };
  }
  const c = closestSegment(p, region.a, region.b),
    d = distance(p, c),
    n =
      d > 1e-6
        ? point((p.x - c.x) / d, (p.y - c.y) / d, (p.z - c.z) / d)
        : point(0, 0, 1);
  return {
    id: region.id,
    point: point(
      c.x + n.x * region.r,
      c.y + n.y * region.r,
      c.z + n.z * region.r,
    ),
    normal: n,
    inside: d < region.r,
    distance: Math.max(0, d - region.r),
  };
}
export function nearestTitanSurface(s, p, clock = s.attackTime) {
  let best = null;
  for (const region of titanBodyRegions(s, clock)) {
    const c = regionContact(region, p);
    if (!best || c.distance < best.distance) best = c;
  }
  return best;
}
export function sweptTitanContact(s, from, to, reach, oldClock = s.attackTime) {
  const old = titanBodyRegions(s, oldClock),
    now = titanBodyRegions(s),
    travel = distance(from, to);
  const samples = Math.min(24, Math.max(4, Math.ceil(travel / 1.5)));
  let best = null;
  for (let i = 0; i <= samples; i++) {
    const t = i / samples,
      p = point(
        mix(from.x, to.x, t),
        mix(from.y, to.y, t),
        mix(from.z, to.z, t),
      );
    for (let j = 0; j < now.length; j++) {
      const r = now[j].axes
        ? now[j]
        : {
            ...now[j],
            a: point(
              mix(old[j].a.x, now[j].a.x, t),
              mix(old[j].a.y, now[j].a.y, t),
              mix(old[j].a.z, now[j].a.z, t),
            ),
            b: point(
              mix(old[j].b.x, now[j].b.x, t),
              mix(old[j].b.y, now[j].b.y, t),
              mix(old[j].b.z, now[j].b.z, t),
            ),
          };
      const c = regionContact(r, p);
      if (c.distance <= reach && (!best || c.distance < best.distance))
        best = c;
    }
  }
  return best;
}
export function constrainTitanBody(p) {
  const solid = titanBodyRegions({
    stage: "traversal",
    attack: "idle",
    config: {},
  }).filter((r) =>
    [
      "torso",
      "hips",
      "head",
      "L thigh",
      "R thigh",
      "L shin",
      "R shin",
    ].includes(r.id),
  );
  const q = point(p.x, p.y + 1.8, p.z);
  for (const region of solid) {
    const c = regionContact(region, q);
    if (c.inside || c.distance < 1.2) {
      q.x = c.point.x + c.normal.x * 1.2;
      q.y = c.point.y + c.normal.y * 1.2;
      q.z = c.point.z + c.normal.z * 1.2;
      if (q.y < 1.85) {
        // The floor wins over a downward foot normal. Slide around the foot
        // horizontally instead of repeatedly pushing the avatar underground.
        const origin = region.a
            ? closestSegment(point(p.x, p.y + 1.8, p.z), region.a, region.b)
            : region.center,
          dx = p.x - origin.x,
          dz = p.z - origin.z,
          l = Math.hypot(dx, dz);
        q.x = origin.x + (l > 1e-6 ? dx / l : 0) * (region.r + 1.3);
        q.z = origin.z + (l > 1e-6 ? dz / l : 1) * (region.r + 1.3);
        q.y = 1.85;
      }
    }
  }
  p.x = q.x;
  p.y = Math.max(0.05, q.y - 1.8);
  p.z = q.z;
}

export function titanFinalePosition(from, time) {
  const u = clamp(time / 3.8),
    ease = (t) => {
      t = clamp(t);
      return t * t * (3 - 2 * t);
    },
    a = Math.atan2(from.x, from.z),
    angle = a * (1 - ease((u - 0.2) / 0.55)),
    radius = mix(
      mix(Math.hypot(from.x, from.z), 52, ease(u / 0.32)),
      28,
      ease((u - 0.7) / 0.3),
    );
  return point(
    Math.sin(angle) * radius,
    mix(from.y, 82, ease(u)) + Math.sin(u * Math.PI) * 8,
    Math.cos(angle) * radius,
  );
}
