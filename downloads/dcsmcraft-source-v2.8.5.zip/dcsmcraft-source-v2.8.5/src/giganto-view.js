import {
  nearestTitanSurface,
  titanArmPath,
  titanFinalePosition,
} from "./titan-contact.js";
import {
  makeTitanLandscape,
  updateTitanLandscape,
  disposeTitanLandscape,
} from "./titan-landscape.js";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
import {
  prepareTitanModels,
  importedRig,
  updateImportedSonic,
  updateImportedGiganto,
  disposeImportedRig,
} from "./titan-imports.js";
import * as T from "three";
import {
  makeSonic,
  makeGiganto,
  poseSonic,
  poseGiganto,
  makeTitanArena,
  makeEmerald,
  disposeTitanObject,
} from "./giganto-models.js";
import {
  TITAN_ROUTE,
  TITAN_EMERALD,
  TITAN_CHEST,
} from "./giganto-simulation.js";
// Conservative mantle clearance. The wider new shoulders need more room than
// the old cylindrical torso, both before and after camera smoothing.
export function titanCameraClearance(y) {
  return y >= 60 && y < 88 ? 38 : y >= 40 && y < 60 ? 30 : 21;
}
const distanceSquared = (a, b) => a.distanceToSquared(b);
const movingTrail = (s) =>
  ["dodge", "rush", "punch", "counter"].includes(s.action);
export class TitanView {
  constructor(game) {
    this.game = game;
    this.scene = new T.Scene();
    this.scene.background = new T.Color("#86afc2");
    this.scene.fog = new T.FogExp2("#9aadb1", 0.0018);
    this.camera = new T.PerspectiveCamera(67, 1, 0.15, 1600);
    this.hemi = new T.HemisphereLight("#b9d9ee", "#343e24", 1.25);
    this.scene.add(this.hemi);
    this.light = new T.DirectionalLight("#fff0d1", 4.1);
    const rim = new T.DirectionalLight("#a5cee9", 2.1);
    rim.position.set(-85, 100, -70);
    this.scene.add(rim);
    this.light.position.set(75, 165, 90);
    this.light.target.position.set(0, 44, -5);
    this.scene.add(this.light.target);
    this.light.castShadow = !!game.settings.shadows;
    this.light.shadow.mapSize.set(1024, 1024);
    Object.assign(this.light.shadow.camera, {
      left: -155,
      right: 155,
      top: 155,
      bottom: -155,
      near: 1,
      far: 350,
    });
    this.light.shadow.camera.updateProjectionMatrix();
    this.light.shadow.bias = -0.00012;
    this.light.shadow.normalBias = 0.18;
    this.light.shadow.radius = 2;
    this.scene.add(this.light);
    this.arena = makeTitanLandscape(TITAN_ROUTE, game.settings.graphics || 2);
    this.scene.add(this.arena);
    this.sonic = makeSonic();
    this.boss = makeGiganto();
    this.emerald = makeEmerald();
    this.emerald.position.set(
      TITAN_EMERALD.x,
      TITAN_EMERALD.y,
      TITAN_EMERALD.z,
    );
    this.scene.add(this.sonic, this.boss, this.emerald);
    // Layered additive glow and a bounded, animated corona replace the opaque
    // wire sphere. Original shader; no postprocessing/fullscreen bloom required.
    const glowMat = new T.ShaderMaterial({
      uniforms: { intensity: { value: 0.8 } },
      vertexShader: `varying vec3 normalW; varying vec3 viewW;
        void main(){vec4 p=modelViewMatrix*vec4(position,1.); normalW=normalize(normalMatrix*normal);viewW=-p.xyz;gl_Position=projectionMatrix*p;}`,
      fragmentShader: `varying vec3 normalW; varying vec3 viewW;uniform float intensity;
        void main(){float edge=pow(1.-abs(dot(normalize(normalW),normalize(viewW))),2.);gl_FragColor=vec4(1.,.79,.12,edge*.22*intensity);}`,
      transparent: true,
      depthWrite: false,
      blending: T.AdditiveBlending,
      side: T.DoubleSide,
    });
    this.aura = new T.Mesh(new T.SphereGeometry(1, 24, 16), glowMat);
    this.aura.scale.set(1.25, 2.3, 1.25);
    this.scene.add(this.aura);
    this.corona = new T.InstancedMesh(
      new T.CylinderGeometry(0.012, 0.022, 0.8, 5),
      new T.MeshBasicMaterial({
        color: "#ffe86d",
        transparent: true,
        opacity: 0.28,
        blending: T.AdditiveBlending,
        depthWrite: false,
      }),
      48,
    );
    this.corona.instanceMatrix.setUsage(T.DynamicDrawUsage);
    this.corona.frustumCulled = false;
    this.scene.add(this.corona);
    this.superLight = new T.PointLight("#ffdd57", 0, 18, 2);
    this.scene.add(this.superLight);
    this.sky = new T.Mesh(
      new T.SphereGeometry(1250, 64, 32),
      new T.ShaderMaterial({
        uniforms: { storm: { value: 0 } },
        side: T.BackSide,
        depthWrite: false,
        vertexShader: `varying vec3 dir;void main(){dir=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
        fragmentShader: `varying vec3 dir;uniform float storm;
        float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
        float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
        void main(){vec3 d=normalize(dir);float h=smoothstep(-.08,.8,d.y);vec3 c=mix(vec3(.74,.85,.9),vec3(.16,.43,.73),h);vec2 uv=d.xz/max(.09,d.y)*2.;float n=noise(uv)*.55+noise(uv*2.1)*.28+noise(uv*4.2)*.17;float clouds=smoothstep(.57,.76,n)*smoothstep(.04,.23,d.y);c=mix(c,vec3(.94,.97,1.),clouds*.75);float sun=pow(max(0.,dot(d,normalize(vec3(-.4,.75,.45)))),128.);c+=vec3(1.,.8,.47)*sun*1.3;
        c=mix(c,c*vec3(.38,.55,.73),storm*.66);gl_FragColor=vec4(c,1.);}`,
      }),
    );
    this.sky.renderOrder = -10;
    this.scene.add(this.sky);
    this.beam = new T.Mesh(
      new T.CylinderGeometry(2.6, 2.6, 1, 10),
      new T.MeshBasicMaterial({
        color: "#ff687b",
        transparent: true,
        opacity: 0.8,
      }),
    );
    this.scene.add(this.beam);
    this.climbPulse = new T.Mesh(
      new T.TorusGeometry(1, 0.035, 4, 36),
      new T.MeshBasicMaterial({
        color: "#f18082",
        transparent: true,
        opacity: 0.5,
      }),
    );
    this.scene.add(this.climbPulse);
    // Three beams per dorsal emitter; the whole 30-ray fan is one draw call.
    this.backFan = new T.InstancedMesh(
      new T.CylinderGeometry(0.18, 0.18, 1, 5),
      new T.MeshBasicMaterial({
        color: "#ff3865",
        toneMapped: false,
        transparent: true,
        opacity: 0.82,
        blending: T.AdditiveBlending,
        depthWrite: false,
      }),
      30,
    );
    this.backFan.instanceMatrix.setUsage(T.DynamicDrawUsage);
    this.backFan.frustumCulled = false;
    this.scene.add(this.backFan);
    this.rayDummy = new T.Object3D();
    this.up = new T.Vector3(0, 1, 0);
    this.emitterStart = new T.Vector3();
    this.emitterEnd = new T.Vector3();
    this.rayDelta = new T.Vector3();
    this.fx = new T.InstancedMesh(
      new T.PlaneGeometry(0.7, 0.7),
      new T.MeshBasicMaterial({
        color: new T.Color(1.8, 1.8, 1.8),
        map: this.makeParticleTexture(),
        transparent: true,
        depthWrite: false,
        blending: T.AdditiveBlending,
        toneMapped: false,
      }),
      96,
    );
    this.fx.instanceMatrix.setUsage(T.DynamicDrawUsage);
    this.fx.frustumCulled = false;
    this.scene.add(this.fx);
    this.fxData = [];
    for (let i = 0; i < 96; i++) this.fx.setColorAt(i, new T.Color("#fff1ad"));
    this.ripples = new T.InstancedMesh(
      new T.TorusGeometry(1, 0.018, 5, 64),
      new T.MeshBasicMaterial({
        color: "#bceeff",
        transparent: true,
        opacity: 0.65,
        blending: T.AdditiveBlending,
        depthWrite: false,
      }),
      12,
    );
    this.ripples.frustumCulled = false;
    this.scene.add(this.ripples);
    this.rippleData = [];
    this.dummy = new T.Object3D();
    this.look = new T.Vector3();
    this.camReady = false;
    this.lastAction = "";
    this.cyloop = new T.Mesh(
      new T.TorusGeometry(27, 0.15, 6, 96),
      new T.MeshBasicMaterial({
        color: "#43e3ff",
        transparent: true,
        opacity: 0.7,
        depthWrite: false,
        blending: T.AdditiveBlending,
      }),
    );
    this.cyloop.rotation.x = -Math.PI / 2;
    this.cyloop.position.set(0, 57, -7.5);
    this.scene.add(this.cyloop);
    this.trailData = [];
    this.trails = new T.InstancedMesh(
      new T.CylinderGeometry(0.05, 0.12, 1, 5),
      new T.MeshBasicMaterial({
        color: "#7feaff",
        transparent: true,
        opacity: 0.35,
        depthWrite: false,
        blending: T.AdditiveBlending,
      }),
      48,
    );
    this.trails.frustumCulled = false;
    this.scene.add(this.trails);
    this.warning = new T.Mesh(
      new T.SphereGeometry(1, 12, 8),
      new T.MeshBasicMaterial({
        color: "#ffbd66",
        transparent: true,
        opacity: 0.22,
        wireframe: true,
        depthWrite: false,
      }),
    );
    this.scene.add(this.warning);
    this.contactShadow = new T.Mesh(
      new T.CircleGeometry(1.5, 32),
      new T.MeshBasicMaterial({
        map: this.particleTexture,
        color: "#081326",
        transparent: true,
        opacity: 0.35,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -1,
      }),
    );
    this.contactShadow.rotation.x = -Math.PI / 2;
    this.scene.add(this.contactShadow);

    this.assetsReady = typeof document === "undefined";
    this.ready = this.assetsReady
      ? Promise.resolve(true)
      : prepareTitanModels()
          .then((assets) => {
            if (this.disposed) return false;
            disposeTitanObject(this.sonic);
            disposeTitanObject(this.boss);
            this.sonic = importedRig(assets[0]);
            this.boss = importedRig(assets[1]);
            this.scene.add(this.sonic, this.boss);
            this.assetsReady = true;
            return true;
          })
          .catch((error) => {
            this.assetError = error.message;
            return false;
          });
  }
  makeParticleTexture() {
    const data = new Uint8Array(32 * 32 * 4);
    for (let y = 0; y < 32; y++)
      for (let x = 0; x < 32; x++) {
        const dx = (x - 15.5) / 15.5,
          dy = (y - 15.5) / 15.5,
          r = Math.hypot(dx, dy),
          i = (x + y * 32) * 4;
        data.set(
          [255, 255, 255, Math.max(0, Math.exp(-r * r * 7) * (1 - r) * 255)],
          i,
        );
      }
    const tex = new T.DataTexture(data, 32, 32);
    tex.magFilter = tex.minFilter = T.LinearFilter;
    tex.needsUpdate = true;
    this.particleTexture = tex;
    return tex;
  }
  event(e, s) {
    this.ripple(e, s);
    if (e.type === "hit") {
      this.hitStop = Math.min(0.055, 0.025 + (e.amount || 0) / 16000);
      this.reactionUntil = s.time + 0.18;
    }
    if (
      ["hit", "impact", "parry", "counter", "beam", "stage"].includes(e.type)
    ) {
      this.shake = Math.min(
        0.75,
        (this.shake || 0) +
          ({
            hit: Math.min(0.3, 0.06 + (e.amount || 0) / 1800),
            impact: 0.4,
            parry: 0.28,
            counter: 0.6,
            beam: 0.3,
            stage: 0.45,
          }[e.type] || 0),
      );
      this.impactTime = 0.22;
    }
    if (
      [
        "hit",
        "parry",
        "counter",
        "boom",
        "rush",
        "loop",
        "emerald",
        "qte-win",
        "ring",
        "stage",
        "impact",
      ].includes(e.type)
    )
      for (
        let n = 0;
        n <
        (e.type === "hit"
          ? Math.min(15, 4 + Math.floor((e.amount || 0) / 40))
          : 14);
        n++
      ) {
        if (this.fxData.length >= 96) this.fxData.shift();
        const p =
          e.point ||
          (e.type === "emerald"
            ? TITAN_EMERALD
            : e.type === "ring"
              ? {
                  x: e.x ?? s.avatar.x,
                  y: e.y ?? s.avatar.y,
                  z: e.z ?? s.avatar.z,
                }
              : ["hit", "counter", "boom"].includes(e.type)
                ? TITAN_CHEST
                : s.avatar);
        this.fxData.push({
          x: p.x,
          y: e.point ? p.y : p.y + 1.5,
          z: p.z,
          vx: Math.sin(n * 2.4) * 5 + (e.normal?.x || 0) * 9,
          vy: 2 + (n % 5) + (e.normal?.y || 0) * 7,
          vz: Math.cos(n * 2.4) * 5 + (e.normal?.z || 0) * 9,
          color: ["parry", "counter", "rush", "loop", "qte-win"].includes(
            e.type,
          )
            ? "#a7e9ff"
            : e.type === "hit"
              ? "#fff3dd"
              : "#ffe294",
          life: 0.7,
        });
      }
  }
  ripple(e, s) {
    const max = {
      hit: Math.min(8, 2 + (e.amount || 0) / 70),
      counter: 16,
      parry: 8,
      boom: 7,
      loop: 16,
      stage: 24,
      emerald: 12,
    }[e.type];
    if (max)
      this.rippleData.push({
        normal: e.normal,
        x:
          e.point?.x ??
          (e.type === "hit" || e.type === "counter"
            ? TITAN_CHEST.x
            : s.avatar.x),
        y:
          e.point?.y ??
          (e.type === "hit" || e.type === "counter"
            ? TITAN_CHEST.y
            : s.avatar.y + 1.5),
        z:
          e.point?.z ??
          (e.type === "hit" || e.type === "counter"
            ? TITAN_CHEST.z
            : s.avatar.z),
        life: 0.65,
        max,
      });
    this.rippleData = this.rippleData.slice(-12);
  }
  line(mesh, a, b, r = 1) {
    const d = new T.Vector3().subVectors(b, a);
    mesh.position.copy(a).add(b).multiplyScalar(0.5);
    mesh.quaternion.setFromUnitVectors(
      new T.Vector3(0, 1, 0),
      d.clone().normalize(),
    );
    mesh.scale.set(r, d.length(), r);
  }
  draw(s, dt) {
    const g = this.game,
      c = this.camera,
      p = s.avatar,
      t = s.time,
      superForm = s.emerald;
    if (!this.assetsReady) return;
    const freeze = (this.hitStop || 0) > 0 && s.stage === "combat";
    this.hitStop = Math.max(0, (this.hitStop || 0) - dt);
    if (!freeze) {
      if (this.sonic.userData.imported) updateImportedSonic(this.sonic, s, dt);
      else poseSonic(this.sonic, s, dt);
      if (this.boss.userData.imported) updateImportedGiganto(this.boss, s, dt);
      else poseGiganto(this.boss, s, dt);
    } else this.sonic.position.set(p.x, p.y + 0.12, p.z);
    if (s.stage === "finale") {
      const q = titanFinalePosition(s.cinematicFrom || p, s.stageTime);
      this.sonic.position.set(q.x, q.y, q.z);
    }
    for (const m of this.boss.userData.materials) {
      if (m.emissive) {
        m.userData.titanBaseEmissive ||= m.emissive.clone();
        m.emissive.copy(m.userData.titanBaseEmissive);
        if (this.reactionUntil > s.time)
          m.emissive.lerp(
            new T.Color("#58bed2"),
            (0.22 * (this.reactionUntil - s.time)) / 0.18,
          );
      }
    }
    this.boss.updateMatrixWorld(true);
    this.boss.visible = s.stage !== "victory";
    const dissolve =
      s.stage === "finale"
        ? Math.max(0, Math.min(1, (s.stageTime - 4) / 2.5))
        : 0;
    for (const m of this.boss.userData.materials) {
      m.transparent = dissolve > 0;
      m.opacity = 1 - dissolve;
    }
    if (s.stage === "finale" && s.stageTime > 3.8 && !this.exploded) {
      this.exploded = true;
      for (let n = 0; n < 64; n++) {
        const a = n * 2.4;
        this.fxData.push({
          x: Math.sin(a) * 8,
          y: 48 + (n % 20),
          z: Math.cos(a) * 8,
          vx: Math.sin(a) * 22,
          vy: 8 + (n % 11),
          vz: Math.cos(a) * 22,
          life: 2,
          size: 3,
        });
      }
      this.fxData = this.fxData.slice(-96);
    }
    updateTitanLandscape(this.arena, s, dt);
    this.emerald.visible = !s.emerald;
    this.emerald.rotation.y = t;
    this.emerald.position.y = 95 + Math.sin(t * 2) * 0.25;
    this.aura.visible = superForm;
    this.aura.position.copy(this.sonic.position);
    this.aura.position.y += 1.8;
    this.aura.rotation.y = t * 0.3;
    this.aura.material.uniforms.intensity.value =
      s.stage === "transform" ? 1.2 + Math.sin(s.stageTime * 10) * 0.4 : 0.85;
    this.aura.scale.set(1.3, 2.25, 1.3);
    this.superLight.position.copy(this.aura.position);
    this.superLight.intensity = superForm && s.config.lighting ? 5 : 0;
    this.corona.visible = superForm && s.config.particles;
    const ca = this.sonic.rotation.y;
    for (let n = 0; n < 48; n++) {
      const a = n * 2.399963 + t * (n % 2 ? 0.7 : -0.5),
        y = ((n % 12) / 12) * 4.4 - 2,
        radius = 1.1 + Math.sin(t * 7 + n * 3) * 0.14;
      this.dummy.position.set(
        this.sonic.position.x + Math.sin(a) * radius,
        this.sonic.position.y + 2 + y,
        this.sonic.position.z + Math.cos(a) * radius,
      );
      this.dummy.rotation.set(Math.sin(a) * 0.6, ca, Math.cos(a) * 0.6);
      this.dummy.scale.set(
        0.8,
        0.35 + (0.5 + 0.5 * Math.sin(t * 8 + n)) * 1.1,
        0.6,
      );
      this.dummy.updateMatrix();
      this.corona.setMatrixAt(n, this.dummy.matrix);
    }
    this.corona.instanceMatrix.needsUpdate = true;
    this.light.intensity = s.config.lighting
      ? (s.phase === 2 ? 1.55 : 4.1) +
        (s.stage === "transform" ? Math.sin(s.stageTime * 3) * 1.1 : 0)
      : 1.7;
    this.hemi.intensity = s.phase === 2 ? 1.12 : 1.25;
    this.light.color.set(s.phase === 2 ? "#bad8f2" : "#fff0d1");
    this.scene.fog.color.lerp(
      new T.Color(s.phase === 2 ? "#3a596e" : "#9aadb1"),
      1 - Math.exp(-dt * 1.4),
    );
    const climbing = ["intro", "traversal", "transform"].includes(s.stage);
    this.arena.userData.platforms.visible = climbing;
    this.arena.userData.rings.forEach((m, n) => {
      m.visible = climbing;
      m.material.color.set(n <= s.route ? "#d8c58b" : "#a7cecf");
      m.scale.setScalar(n === s.route + 1 ? 1 + Math.sin(t * 3) * 0.08 : 1);
    });
    const pulsePhase = s.time % 6;
    this.climbPulse.visible =
      s.stage === "traversal" && pulsePhase > 3 && pulsePhase < 5;
    this.climbPulse.position.set(0, 55, -12);
    this.climbPulse.scale.setScalar(10 + Math.max(0, pulsePhase - 3) * 22);
    this.climbPulse.material.opacity =
      pulsePhase < 4 ? 0.25 : 0.65 * (5 - pulsePhase);
    this.beam.visible =
      s.attack === "beam" &&
      (s.qte ||
        s.attackTime >=
          1.8 * { easy: 1.25, normal: 1, hard: 0.85 }[s.config.difficulty]);
    if (this.beam.visible)
      this.line(
        this.beam,
        this.boss.userData.jawSocket
          ? this.boss.userData.jawSocket.getWorldPosition(new T.Vector3())
          : new T.Vector3(0, -0.2, 3.5).applyMatrix4(
              this.boss.userData.bones.jaw.matrixWorld,
            ),
        new T.Vector3(
          s.qte ? p.x : (s.attackAim?.x ?? p.x),
          (s.qte ? p.y : (s.attackAim?.y ?? p.y)) + 1,
          s.qte ? p.z : (s.attackAim?.z ?? p.z),
        ),
      );
    this.backFan.visible =
      s.phase === 2 && !["victory", "finale"].includes(s.stage);
    for (let n = 0; n < 30; n++) {
      const rod = this.boss.userData.rods[Math.floor(n / 3)],
        lane = n % 3;
      const socket = this.boss.userData.laserSockets?.[Math.floor(n / 3)];
      if (socket) socket.getWorldPosition(this.emitterStart);
      else this.emitterStart.set(0, 11.8, 0).applyMatrix4(rod.matrixWorld);
      // Behind the Titan: spectacular fan matches the existing dorsal hazard.
      // Every beam originates on an animated emitter, never floats in midair.
      const a =
        -Math.PI / 2 + (Math.floor(n / 3) / 9) * Math.PI + (lane - 1) * 0.18;
      this.emitterEnd.set(
        Math.sin(a) * (100 + lane * 25),
        132 + lane * 35,
        -65 - Math.cos(a) * 85,
      );
      this.rayDelta.subVectors(this.emitterEnd, this.emitterStart);
      this.rayDummy.position
        .copy(this.emitterStart)
        .add(this.emitterEnd)
        .multiplyScalar(0.5);
      this.rayDummy.quaternion.setFromUnitVectors(
        this.up,
        this.rayDelta.clone().normalize(),
      );
      this.rayDummy.scale.set(1, this.rayDelta.length(), 1);
      this.rayDummy.updateMatrix();
      this.backFan.setMatrixAt(n, this.rayDummy.matrix);
    }
    this.backFan.instanceMatrix.needsUpdate = true;
    if (
      superForm &&
      s.config.particles &&
      this.fxData.length < 80 &&
      Math.floor(t * 18) !== this.sparkTick
    ) {
      this.sparkTick = Math.floor(t * 18);
      this.fxData.push({
        x: this.sonic.position.x + Math.sin(t * 7) * 1.2,
        y: this.sonic.position.y + 0.5 + ((t * 3) % 3),
        z: this.sonic.position.z + Math.cos(t * 9) * 1.2,
        vx: 0,
        vy: 1.7,
        vz: 0,
        life: 0.7,
        size: 1.2,
      });
    }
    this.fxData = this.fxData.filter((f) => (f.life -= dt) > 0);
    for (let n = 0; n < 96; n++) {
      const f = s.config.particles ? this.fxData[n] : null;
      if (f) {
        f.x += f.vx * dt;
        f.y += f.vy * dt;
        f.z += f.vz * dt;
        this.dummy.position.set(f.x, f.y, f.z);
        this.dummy.scale.setScalar(f.life * (f.size || 1));
      } else this.dummy.scale.setScalar(0);
      this.dummy.quaternion.copy(c.quaternion);
      this.dummy.updateMatrix();
      this.fx.setMatrixAt(n, this.dummy.matrix);
      this.fx.setColorAt(n, new T.Color(f?.color || "#ffe294"));
    }
    this.fx.instanceMatrix.needsUpdate = true;
    this.fx.instanceColor.needsUpdate = true;
    this.rippleData = this.rippleData.filter((r) => (r.life -= dt) > 0);
    for (let i = 0; i < 12; i++) {
      const r = s.config.particles ? this.rippleData[i] : null;
      if (r) {
        this.dummy.position.set(r.x, r.y, r.z);
        if (r.normal)
          this.dummy.quaternion.setFromUnitVectors(
            new T.Vector3(0, 0, 1),
            new T.Vector3(r.normal.x, r.normal.y, r.normal.z),
          );
        else this.dummy.quaternion.copy(c.quaternion);
        this.dummy.scale.setScalar((1 - r.life / 0.65) * r.max + 0.2);
      } else this.dummy.scale.setScalar(0);
      this.dummy.updateMatrix();
      this.ripples.setMatrixAt(i, this.dummy.matrix);
    }
    this.ripples.instanceMatrix.needsUpdate = true;
    this.cyloop.visible =
      s.stage === "combat" &&
      s.action === "loop" &&
      s.config.particles &&
      nearestTitanSurface(s, p).distance < 22;
    this.cyloop.geometry.setDrawRange(
      0,
      Math.floor(
        (Math.max(0, 1 - s.actionTime / 1.6) *
          this.cyloop.geometry.index.count) /
          3,
      ) * 3,
    );
    this.cyloop.rotation.z = t * 0.25;
    this.arena.userData.quality = g.settings.graphics || 2;
    this.contactShadow.visible = p.y < 10;
    this.contactShadow.position.set(p.x, 0.025, p.z);
    this.contactShadow.scale.setScalar(1 + p.y * 0.08);
    this.contactShadow.material.opacity = 0.36 * Math.max(0, 1 - p.y / 10);
    if (
      dt > 0 &&
      s.config.particles &&
      this.previousSonic &&
      distanceSquared(this.previousSonic, this.sonic.position) > 0.02 &&
      (movingTrail(s) || Math.hypot(p.vx, p.vz) > 22)
    ) {
      this.trailData.push({
        a: this.previousSonic.clone(),
        b: this.sonic.position.clone(),
        life: 0.23,
      });
    }
    this.previousSonic = this.sonic.position.clone();
    this.trailData = this.trailData
      .filter((q) => (q.life -= dt) > 0)
      .slice(-48);
    for (let i = 0; i < 48; i++) {
      const q = s.config.particles ? this.trailData[i] : null;
      if (q) {
        const d = q.b.clone().sub(q.a);
        this.dummy.position.copy(q.a).add(q.b).multiplyScalar(0.5);
        this.dummy.position.y += 1.4;
        this.dummy.quaternion.setFromUnitVectors(
          this.up,
          d.clone().normalize(),
        );
        this.dummy.scale.set(q.life / 0.23, d.length(), q.life / 0.23);
      } else this.dummy.scale.setScalar(0);
      this.dummy.updateMatrix();
      this.trails.setMatrixAt(i, this.dummy.matrix);
    }
    this.trails.instanceMatrix.needsUpdate = true;
    this.warning.visible =
      s.stage === "combat" && ["swing", "slap", "crunch"].includes(s.attack);
    if (this.warning.visible) {
      const q = titanArmPath(s, s.attack === "slap" ? "R" : "L");
      this.warning.position.set(q.x, q.y, q.z);
      this.warning.scale.setScalar(8);
      this.warning.material.opacity = 0.12 + Math.sin(t * 8) * 0.04;
    }
    let target = new T.Vector3(p.x, p.y + 2, p.z),
      desired = new T.Vector3();
    if (s.stage === "intro") {
      target.set(0, 50, 0);
      const orbit = -0.22 + s.stageTime * 0.07;
      desired.set(
        Math.sin(orbit) * 160,
        25 + s.stageTime * 5,
        Math.cos(orbit) * 160,
      );
    } else if (s.stage === "transform") {
      const a = s.stageTime * 0.8;
      desired.set(p.x + Math.sin(a) * 9, p.y + 4, p.z + Math.cos(a) * 9);
    } else if (s.stage === "phase") {
      const a =
        Math.atan2(p.x, p.z) + 0.22 * Math.sin((s.stageTime * Math.PI) / 4);
      target.set(p.x * 0.32, 69, p.z * 0.32);
      desired.set(
        Math.sin(a) * 108,
        80 + Math.sin(s.stageTime * 0.8) * 7,
        Math.cos(a) * 108,
      );
    } else if (s.stage === "finale" || s.stage === "victory") {
      target.set(0, 60, 0);
      desired.set(55, 64, 102);
    } else if (s.qte) {
      target.set(0, 73, 16);
      desired.set(35, 73, 63);
    } else if (superForm && s.lock) {
      const surface = nearestTitanSurface(s, {
        x: p.x,
        y: p.y + 1.8,
        z: p.z,
      }).point;
      target.lerp(new T.Vector3(surface.x, surface.y, surface.z), 0.23);
      const cp = Math.cos(p.pitch);
      desired.set(
        p.x + Math.sin(p.yaw) * 19 * cp,
        p.y + 5 + Math.sin(p.pitch) * 19,
        p.z + Math.cos(p.yaw) * 19 * cp,
      );
    } else {
      const d = superForm ? 19 : 13,
        cp = Math.cos(p.pitch);
      desired.set(
        p.x + Math.sin(p.yaw) * d * cp,
        p.y + 3 + Math.sin(p.pitch) * d,
        p.z + Math.cos(p.yaw) * d * cp,
      );
    }
    desired.y = Math.max(2.5, desired.y);
    const r = Math.hypot(desired.x, desired.z);
    const desiredRadius = titanCameraClearance(desired.y);
    if (r < desiredRadius && desired.y < 93) {
      if (r < 0.001) desired.z = desiredRadius;
      else {
        desired.x *= desiredRadius / r;
        desired.z *= desiredRadius / r;
      }
    }
    if (this.camReady) {
      c.position.lerp(desired, 1 - Math.exp(-dt * 8));
      this.look.lerp(target, 1 - Math.exp(-dt * 9));
    } else {
      c.position.copy(desired);
      this.look.copy(target);
      this.camReady = true;
    }
    const cameraRadius = Math.hypot(c.position.x, c.position.z);
    const clearance = titanCameraClearance(c.position.y);
    if (c.position.y < 93 && cameraRadius < clearance) {
      if (cameraRadius < 0.001) c.position.z = clearance;
      else {
        c.position.x *= clearance / cameraRadius;
        c.position.z *= clearance / cameraRadius;
      }
    }
    c.position.y = Math.max(2.5, c.position.y);
    this.shake = Math.max(0, (this.shake || 0) - dt * 2.8);
    if (this.shake > 0 && dt > 0) {
      c.position.x += Math.sin(t * 69) * this.shake;
      c.position.y += Math.cos(t * 87) * this.shake * 0.5;
    }
    const movingBoost = Math.hypot(p.vx, p.vz) > 22;
    c.fov = T.MathUtils.lerp(
      c.fov,
      movingBoost ? 76 : 67,
      1 - Math.exp(-dt * 5),
    );
    const safeRadius = titanCameraClearance(c.position.y),
      actualRadius = Math.hypot(c.position.x, c.position.z);
    if (c.position.y < 93 && actualRadius < safeRadius) {
      c.position.x *= safeRadius / Math.max(0.001, actualRadius);
      c.position.z *= safeRadius / Math.max(0.001, actualRadius);
    }
    c.lookAt(this.look);
    this.heading =
      (T.MathUtils.radToDeg(
        Math.atan2(c.position.x - this.look.x, c.position.z - this.look.z),
      ) +
        360) %
      360;
    c.aspect = innerWidth / innerHeight;
    c.updateProjectionMatrix();
    this.scene.background.set(s.phase === 2 ? "#617e96" : "#a8d6ed");
    this.sky.material.uniforms.storm.value = T.MathUtils.lerp(
      this.sky.material.uniforms.storm.value,
      s.phase === 2 ? 1 : 0,
      1 - Math.exp(-dt * 0.8),
    );
    const surface = nearestTitanSurface(s, {
      x: p.x,
      y: p.y + 1.8,
      z: p.z,
    }).point;
    const marker = new T.Vector3(surface.x, surface.y, surface.z).project(c);
    this.targetScreen = {
      x: (marker.x + 1) * 0.5,
      y: (1 - marker.y) * 0.5,
      visible:
        marker.z > -1 &&
        marker.z < 1 &&
        Math.abs(marker.x) < 1 &&
        Math.abs(marker.y) < 1,
    };
    g.renderer.gl.info.reset();
    const gl = g.renderer.gl,
      oldMapping = gl.toneMapping,
      oldExposure = gl.toneMappingExposure,
      oldShadow = gl.shadowMap
        ? { enabled: gl.shadowMap.enabled, type: gl.shadowMap.type }
        : null;
    const shadows =
        s.config.shadowQuality !== "off" &&
        (s.config.shadowQuality !== "auto" || g.settings.shadows === true),
      resolution = s.config.shadowQuality === "high" ? 2048 : 1024;
    this.light.castShadow = shadows;
    if (this.light.shadow.mapSize.x !== resolution) {
      this.light.shadow.map?.dispose();
      this.light.shadow.map = null;
      this.light.shadow.mapSize.set(resolution, resolution);
    }
    if (gl.shadowMap) {
      gl.shadowMap.enabled = shadows;
      gl.shadowMap.type = T.PCFSoftShadowMap;
    }

    try {
      gl.toneMapping = T.ACESFilmicToneMapping;
      gl.toneMappingExposure = 1;
      if (
        gl.isWebGLRenderer &&
        g.settings.graphics >= 2 &&
        s.config.postProcessing
      ) {
        if (!this.composer) {
          const environment = new T.Scene();
          environment.add(this.sky.clone(false));
          const pmrem = new T.PMREMGenerator(gl);
          this.environmentTarget = pmrem.fromScene(environment, 0, 0.1, 1800);
          this.scene.environment = this.environmentTarget.texture;
          this.scene.environmentIntensity = 0.32;
          pmrem.dispose();
          this.composer = new EffectComposer(gl);
          this.composer.addPass(new RenderPass(this.scene, c));
          this.bloom = new UnrealBloomPass(
            new T.Vector2(1, 1),
            0.3,
            0.35,
            1.05,
          );
          this.composer.addPass(this.bloom);
          this.composer.addPass(new OutputPass());
        }
        const size = gl.getSize(new T.Vector2()),
          ratio = gl.getPixelRatio(),
          key = [size.x, size.y, ratio].join(",");
        if (this.postSize !== key) {
          this.composer.setPixelRatio(ratio);
          this.composer.setSize(size.x, size.y);
          this.postSize = key;
        }
        this.bloom.strength = s.config.particles ? 0.34 : 0.16;
        this.composer.render(dt);
      } else gl.render(this.scene, c);
    } finally {
      gl.toneMapping = oldMapping;
      gl.toneMappingExposure = oldExposure;
      if (oldShadow) {
        gl.shadowMap.enabled = oldShadow.enabled;
        gl.shadowMap.type = oldShadow.type;
      }
    }
  }
  dispose() {
    this.disposed = true;
    disposeImportedRig(this.sonic);
    disposeImportedRig(this.boss);
    this.environmentTarget?.dispose();
    this.particleTexture?.dispose();
    disposeTitanLandscape(this.arena);
    if (this.composer) {
      for (const pass of this.composer.passes) pass.dispose?.();
      this.composer.dispose();
    }
    disposeTitanObject(this.scene);
    this.light.shadow.map?.dispose();
  }
}
export function titanPortal() {
  const group = new T.Group(),
    mat = new T.MeshBasicMaterial({ color: "#67e5dd" }),
    r = new T.Mesh(new T.TorusGeometry(1.65, 0.14, 6, 40), mat);
  r.position.y = 2;
  group.add(r);
  const inner = new T.Mesh(
    new T.CircleGeometry(1.5, 32),
    new T.MeshBasicMaterial({
      color: "#3347a5",
      side: T.DoubleSide,
      transparent: true,
      opacity: 0.66,
      depthWrite: false,
    }),
  );
  inner.position.y = 2;
  group.add(inner);
  const ring = new T.Mesh(
    new T.TorusGeometry(1.38, 0.035, 4, 32),
    new T.MeshBasicMaterial({ color: "#ffe69c" }),
  );
  ring.position.y = 2;
  group.add(ring);
  for (let n = 0; n < 7; n++) {
    const gem = new T.Mesh(
      new T.OctahedronGeometry(0.17),
      new T.MeshBasicMaterial({
        color: [
          "#ef6567",
          "#91e7d9",
          "#af91e3",
          "#f7d86b",
          "#84adf0",
          "#ece8d8",
          "#8be090",
        ][n],
      }),
    );
    const a = (n / 7) * Math.PI * 2;
    gem.position.set(Math.sin(a) * 1.8, 2 + Math.cos(a) * 1.8, 0.05);
    group.add(gem);
  }
  const light = new T.PointLight("#62e6d8", 5, 10, 2);
  light.position.y = 2;
  group.add(light);
  const sparks = new T.InstancedMesh(
    new T.OctahedronGeometry(0.06),
    new T.MeshBasicMaterial({ color: "#b9ffec" }),
    16,
  );
  sparks.position.y = 2;
  sparks.frustumCulled = false;
  group.add(sparks);
  group.userData = { ring, inner, light, sparks };
  return group;
}

const portalDummy = new T.Object3D();
export function animateTitanPortal(group, time, particles, lighting) {
  group.userData.ring.rotation.z = time * 0.4;
  group.userData.inner.rotation.z = -time * 0.25;
  group.userData.light.visible = lighting;
  group.userData.sparks.visible = particles;
  for (let n = 0; n < 16; n++) {
    const a = time * 0.65 + (n / 16) * Math.PI * 2;
    portalDummy.position.set(
      Math.sin(a) * 1.9,
      Math.cos(a) * 1.9 + Math.sin(time * 2 + n) * 0.12,
      0.15 * Math.sin(a * 3),
    );
    portalDummy.scale.setScalar(0.7 + 0.5 * Math.sin(time * 3 + n));
    portalDummy.updateMatrix();
    group.userData.sparks.setMatrixAt(n, portalDummy.matrix);
  }
  group.userData.sparks.instanceMatrix.needsUpdate = true;
}
