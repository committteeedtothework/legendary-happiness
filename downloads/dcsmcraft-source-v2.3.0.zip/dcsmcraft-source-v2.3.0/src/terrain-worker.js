import { meshHorizon } from "./horizon.js";
import { World } from "./world.js";
import { meshChunk } from "./mesher.js";
let world, signature;
self.onmessage = ({ data: job }) => {
  try {
    const next = [
      job.seed,
      job.dimension,
      job.generationVersion,
      job.surfaceOnly,
    ].join(":");
    if (next !== signature) {
      world = new World(job.seed, {}, job.dimension, job.generationVersion);
      world.surfaceOnly = job.surfaceOnly;
      signature = next;
    }
    // Only nearby chunks are retained in the worker; transfer buffers never detach game state.
    world.chunks.clear();
    world.fluidQueue.clear();
    world.fluidBuckets.forEach((b) => (b.length = 0));
    world.dirty.clear();
    world.skyCache.clear();
    world.containers = {};
    world.cropTicks = {};
    world.generatedLights.clear();
    world.caneRoots.clear();
    world.edits = new Map(Object.entries(job.edits));
    world.editChunks.clear();
    for (const [pos, id] of world.edits) {
      const [x, y, z] = pos.split(",").map(Number),
        key = `${Math.floor(x / 16)},${Math.floor(z / 16)}`;
      if (!world.editChunks.has(key)) world.editChunks.set(key, []);
      world.editChunks.get(key).push([x, y, z, id]);
    }
    world.palm = job.palm || null;
    world.portals = job.portals || {};
    world.relicClaimed = !!job.relicClaimed;
    const groups = job.horizon
      ? meshHorizon(world, job.cx, job.cz, {
          span: job.span || 1,
          step: job.span > 1 ? 4 : 2,
          biomeColors: job.biomeColors,
          texturePack: job.texturePack,
        })
      : meshChunk(world, world.ensure(job.cx, job.cz), {
          surfaceOnly: job.surfaceOnly,
          ambientOcclusion: job.ambientOcclusion,
          biomeColors: job.biomeColors,
          biomeBlend: job.biomeBlend,
          texturePack: job.texturePack,
        });
    const buffers = groups
      .filter(Boolean)
      .flatMap((g) => Object.values(g).map((a) => a.buffer));
    self.postMessage({ ticket: job.ticket, groups }, buffers);
  } catch (error) {
    self.postMessage({ ticket: job.ticket, error: error.message });
  }
};
