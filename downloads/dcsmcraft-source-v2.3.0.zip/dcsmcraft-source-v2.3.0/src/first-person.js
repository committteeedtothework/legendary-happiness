import { createCorpseModel } from "./stand-models.js";
import { createWeaponModel } from "./weapon-models.js";
import { createPistolModel } from "./pistol-model.js";
import * as THREE from "three";
import { BLOCKS, ITEMS } from "./data.js";
import { itemIconCanvas } from "./textures.js";
import { isFlatItem } from "./item-shapes.js";
import { blockArtUV } from "./block-art.js";
import { armAppearanceFor } from "./skins.js";

const HAND_SOCKET = new THREE.Vector3(0, -0.04, 0.025);
const HAND_UNITS = 0.16 / 0.18;
export const HAND_REST_Y = -0.22;

function box(parent, size, position, material) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  mesh.position.set(...position);
  parent.add(mesh);
  return mesh;
}
export function createHandRig() {
  const root = new THREE.Group(),
    wrist = new THREE.Group(),
    grip = new THREE.Group();
  root.add(wrist);
  root.position.set(0.37, HAND_REST_Y, -0.72);
  wrist.rotation.set(-0.12, -0.12, -0.13);
  const appearance = armAppearanceFor("explorer");
  const skin = new THREE.MeshLambertMaterial({ color: appearance.skin });
  const sleeve = new THREE.MeshLambertMaterial({ color: appearance.sleeve });
  // A classic rectangular arm: its skin and sleeve share one straight axis.
  // There are no separate palms, finger bars or knuckles to poke through items.
  const forearm = box(root, [0.16, 1, 0.16], [0, 0, 0], skin);
  const cuff = box(root, [0.16, 1, 0.16], [0, 0, 0], sleeve);
  forearm.name = "block-hand";
  cuff.name = "block-sleeve";
  grip.position.copy(HAND_SOCKET);
  wrist.add(grip);
  const glove = box(
    root,
    [0.167, 1, 0.167],
    [0, 0, 0],
    new THREE.MeshLambertMaterial({ color: "#292833" }),
  );
  glove.name = "block-glove";
  glove.visible = false;
  const shoulder = box(
    root,
    [0.187, 1, 0.223],
    [0, 0, 0],
    new THREE.MeshLambertMaterial(),
  );
  shoulder.name = "armor-shoulder";
  shoulder.visible = false;
  const rig = {
    root,
    wrist,
    grip,
    sleeve,
    skin,
    glove,
    shoulder,
    appearance,
    forearm,
    cuff,
    viewBounds: new THREE.Box3(),
    localViewBounds: null,
    arm: {
      anchor: new THREE.Vector3(),
      hand: new THREE.Vector3(),
      direction: new THREE.Vector3(),
      inverse: new THREE.Matrix4(),
    },
  };
  updateHandRig(rig);
  return rig;
}

export function applyHandAppearance(rig, appearance, armorColor) {
  rig.appearance = appearance;
  rig.skin.color.set(appearance.skin);
  rig.sleeve.color.set(appearance.sleeve);
  rig.glove.visible = !!appearance.glove;
  if (appearance.glove) rig.glove.material.color.set(appearance.glove.color);
  rig.shoulder.visible = !!armorColor;
  if (armorColor) rig.shoulder.material.color.set(armorColor);
}

const armAxis = new THREE.Vector3(0, 1, 0);
export function updateHandRig(rig) {
  const { root, wrist, forearm, cuff, glove, shoulder, arm } = rig;
  // Coordinates belong to the view-model camera, not the moving wrist. Mirrored
  // left-hand rigs use the same solve; held items keep their rigid sockets.
  // Keep all held geometry in front of the view camera near plane, even at
  // the extreme of eating, recoil and long-weapon follow-through animations.
  if (!rig.localViewBounds) cacheHandBounds(rig);
  root.updateWorldMatrix(true, false);
  wrist.updateWorldMatrix(false, false);
  rig.viewBounds.copy(rig.localViewBounds).applyMatrix4(wrist.matrixWorld);
  if (rig.viewBounds.max.z > -0.11) {
    const shift = rig.viewBounds.max.z + 0.11;
    root.position.z -= shift;
    rig.viewBounds.min.z -= shift;
    rig.viewBounds.max.z -= shift;
  }
  root.updateMatrix();
  wrist.updateMatrix();
  arm.inverse.copy(root.matrix).invert();
  arm.anchor
    .set(root.scale.x < 0 ? -0.48 : 0.48, -1.1, -0.4)
    .applyMatrix4(arm.inverse);
  arm.hand.copy(HAND_SOCKET).applyMatrix4(wrist.matrix);
  arm.direction.subVectors(arm.anchor, arm.hand);
  const length = arm.direction.length();
  arm.direction.normalize();
  forearm.quaternion.setFromUnitVectors(armAxis, arm.direction);
  cuff.quaternion.copy(forearm.quaternion);
  // Equal square sections meet exactly: no floating wrist, sleeve lip or
  // coplanar side surfaces that flicker as the arm moves.
  const handLength = Math.min(
    rig.appearance.handLength * HAND_UNITS,
    length * 0.5,
  );
  forearm.position
    .copy(arm.hand)
    .addScaledVector(arm.direction, handLength / 2);
  forearm.scale.y = handLength;
  // Fingerless gloves have the same exposed tip and wrist as the F5 costume.
  // Their outer faces sit clear of the skin, rather than flickering coplanarly.
  const gloveStyle = rig.appearance.glove;
  const gloveStart = Math.min(
    (gloveStyle?.start || 0) * HAND_UNITS,
    handLength,
  );
  const gloveEnd = Math.min((gloveStyle?.end || 0) * HAND_UNITS, handLength);
  glove.position
    .copy(arm.hand)
    .addScaledVector(arm.direction, (gloveStart + gloveEnd) / 2);
  glove.quaternion.copy(forearm.quaternion);
  glove.scale.y = Math.max(0.001, gloveEnd - gloveStart);
  cuff.position
    .copy(arm.hand)
    .addScaledVector(arm.direction, (length + handLength) / 2);
  cuff.scale.y = length - handLength;
  const shoulderLength = Math.min(0.2 * HAND_UNITS, length - handLength);
  shoulder.position
    .copy(arm.anchor)
    .addScaledVector(arm.direction, -shoulderLength / 2);
  shoulder.quaternion.copy(cuff.quaternion);
  shoulder.scale.y = shoulderLength;
}
// Cache rigid held geometry at equip. Include the square hand cap even when
// empty-handed; the long sleeve is solved separately to an off-screen anchor.
export function cacheHandBounds(rig) {
  rig.root.updateMatrixWorld(true);
  const inverse = new THREE.Matrix4().copy(rig.wrist.matrixWorld).invert(),
    local = new THREE.Box3(
      new THREE.Vector3(-0.12, -0.14, -0.12),
      new THREE.Vector3(0.12, 0.12, 0.12),
    ),
    part = new THREE.Box3(),
    matrix = new THREE.Matrix4();
  rig.wrist.traverseVisible((mesh) => {
    if (!mesh.geometry) return;
    mesh.geometry.computeBoundingBox();
    matrix.multiplyMatrices(inverse, mesh.matrixWorld);
    part.copy(mesh.geometry.boundingBox).applyMatrix4(matrix);
    local.union(part);
  });
  // Rigid content is cached once at equip; leave slack for slide recoil/glints.
  rig.localViewBounds = local.expandByScalar(0.075);
}
export function fitHandGrip(rig, id, model) {
  const pistol = id === "matthew_dual_pistols",
    flat = isFlatItem(id),
    block = ITEMS[id]?.block !== undefined && !flat;
  // Use the actual square hand tip as the socket, never the old finger cage.
  rig.grip.position.copy(HAND_SOCKET);
  if (model) {
    model.position.set(
      0,
      pistol ? 0.025 : 0,
      flat ? -0.055 : pistol ? -0.015 : 0,
    );
    if (block) {
      // Keep the hand tip inside the rotated block's lower rear portion.
      // Fitting only its camera bounds cannot establish physical contact.
      const cube = model.children[0];
      model.position.copy(cube.position).negate();
      model.position.y += 0.065;
      model.position.z -= 0.045;
    }
  }
  rig.root.userData.gripStyle = pistol
    ? "pistol"
    : flat
      ? "flat"
      : block
        ? "support"
        : "handle";
  cacheHandBounds(rig);
}
export function createHeldModel(id, atlas) {
  const item = ITEMS[id];
  if (!item) return null;
  if (id === "saint_corpse_part") return createCorpseModel();
  if (id === "matthew_dual_pistols") return createPistolModel();
  const weapon = createWeaponModel(id);
  if (weapon) return weapon;
  if (isFlatItem(id)) return createFlatTool(id);
  const g = new THREE.Group();
  g.userData.kind = item.block !== undefined ? "block" : item.tool || "item";
  if (item.block !== undefined) {
    const door = BLOCKS[item.block].door;
    const geometry = new THREE.BoxGeometry(
      door ? 0.15 : 0.235,
      door ? 0.32 : 0.235,
      door ? 0.035 : 0.235,
    );
    const uv = geometry.attributes.uv;
    for (let face = 0; face < 6; face++) {
      for (let i = face * 4; i < face * 4 + 4; i++) {
        const [u, v] = blockArtUV(
          item.block,
          face,
          uv.getX(i),
          uv.getY(i),
          atlas.pack,
        );
        uv.setXY(i, u, v);
      }
    }
    const cube = new THREE.Mesh(
      geometry,
      new THREE.MeshLambertMaterial({ map: atlas.texture, alphaTest: 0.5 }),
    );
    cube.material.userData.sharedMap = true;
    cube.position.set(-0.025, 0.11, door ? -0.055 : -0.18);
    cube.rotation.y = -0.35;
    g.add(cube);
  }
  return g;
}

function createFlatTool(id) {
  const root = new THREE.Group();
  const map = new THREE.CanvasTexture(itemIconCanvas(id));
  map.magFilter = map.minFilter = THREE.NearestFilter;
  map.colorSpace = THREE.SRGBColorSpace;
  const mesh = new THREE.Mesh(
    new THREE.PlaneGeometry(0.24, 0.24),
    new THREE.MeshLambertMaterial({
      map,
      alphaTest: 0.5,
      side: THREE.DoubleSide,
    }),
  );
  mesh.position.set(0, 0.075, -0.025);
  root.add(mesh);
  root.userData = { kind: "item", flatCutout: true, item: id };
  return root;
}
export function createDroppedModel(id, atlas) {
  const item = ITEMS[id];
  if (!item) return new THREE.Group();
  const model = createHeldModel(id, atlas);
  const bounds = new THREE.Box3().setFromObject(model),
    size = bounds.getSize(new THREE.Vector3()),
    center = bounds.getCenter(new THREE.Vector3());
  // Root offset preserves rigid tool grips while normalising dropped silhouettes.
  const root = new THREE.Group(),
    scale = 0.38 / Math.max(size.x, size.y, size.z, 0.01);
  model.position.sub(center);
  root.add(model);
  root.scale.setScalar(scale);
  root.userData.droppedItem = id;
  root.userData.flatCutout = !!model.userData.flatCutout;
  return root;
}
