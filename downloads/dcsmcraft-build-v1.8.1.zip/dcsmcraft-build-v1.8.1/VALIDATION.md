# DCSMCRAFT validation

## Supplied Assets — 1.8.1

**363 core tests and three browser scenarios pass.** The web build, standalone HTML and Windows x64 PE compile successfully. All 304 runtime/build/source-asset inputs are frozen before browser verification and rechecked before packaging. The executable's extracted HTML matches the standalone byte-for-byte.

The exact standalone HTML runs over local HTTP with every outside request blocked. Browser tests compare all **327 imported block-face tiles** and **87 item icons**, preserving transparency (allowing normal canvas rounding for translucent pixels). Real UI selection updates the atlas, hotbar, Creative catalog and held/dropped flint-and-steel cutout. Q creates a rendered dropped item. All four packs switch reversibly with identical original-pack atlas snapshots and no world edits. The supplied preference, an inventory stack and a block edit across a chunk boundary survive actual save/reload. The normal Vite web entry starts with a saved Supplied preference, creates a world and responds to W movement. Screenshots of the pack selector, terrain, held cutout and inventory were visually inspected.

The first browser run had a fixture error reading `drop.stack.id`; existing drop records use `drop.id`. Correcting the test required no game change. It was expanded to compare every imported icon, then all three scenarios passed against the same frozen runtime.

All selected source PNG hashes match the manifest. **66 sampled terrain chunks** across generators 2–12 and both dimensions, plus **22 accumulated container snapshots**, match published v1.8.0 byte-for-byte. All 24 non-version data exports are identical; the data source differs only in version/attribution comment. Of the prior JS modules, 76 are byte-identical; only data.js, graphics.js, textures.js and ui.js change. Simulation, physics, recipes, models, combat, audio, storage and networking are unchanged. The previous release's broader model/Survival/multiplayer validations are retained below as history; they were not all repeated for this texture-only update.

Limits: source animations use frame zero with existing fluid shimmer; custom blocks/items and unsupported modeled surfaces keep original art. This does not import new block/item gameplay or guarantee bug-free operation. Native Windows launch and direct file:// persistence cannot be verified on this Linux host; managed Chromium blocks direct file navigation. The exact self-contained payload is tested over HTTP with outside requests blocked. Existing documented foundation limitations remain.

Reference remains Minecraft Java Edition 1.20.4 with partial/missing mechanics in FEATURES.md. This release changes original models and cosmetic animation. Generator 12, item/block IDs, recipes, stats and authoritative movement/combat/progression code are retained. Existing worlds receive the update without regeneration.

## Core checks

**361 core tests pass**, including 11 new model/animation cases. New checks cover all 42 weapon/tool silhouettes, finite vertex colours and transforms, thin geometry, bounded merged batches, dropped-size normalization, actual gold-grip metadata/pixels, raised Devin ridges, three stationary blade glints and Minimal-particle suppression. Distinct staged action curves settle to rest and remain visual only.

Each weapon keeps its grip in the articulated palm through attack/mining/use poses with armor. Swimming checks cover prone strokes, continuous stationary treading, full submersion near the floor, wading/Creative-flight exclusions, smooth land exit, hip-centered rotation, pause, held-item phase continuity and first-person phase consistency across 30/60/144 Hz. Validated co-op appearance flags/visual velocity are tested separately from authoritative physics.

All eight Cinderworld designs have distinct geometry, finite animated special poses, preserved collision heights, glowing rest materials and bounded batches. Added jaw/claw/cloak subassemblies initially exceeded the old Titan draw budget; batching each rigid joint group corrected this without raising the existing budget. A water playtest found swimming stopping near the bottom: the visual pose now also accepts full submersion, without changing water physics. Hip-centered rotation and accumulated stroke phase prevent position drift and phase jumps.

Published v1.7 pistol geometry, first-person fire poses and F5 player poses have matching fingerprints. The pistol model, audio, abilities and effects source files are byte-identical. Working block/door models have matching fingerprints. World, physics, simulation, inventory, equipment, relic, cave and hostile-combat source files are byte-identical. The planted Devin display shares the new held model, stays inside its existing target cell, respects Minimal particles, hides after claim/removal and leaves the extraction blocks intact.

## Browser playtests

**Eight selected browser scenarios pass** on the frozen build:

1. Exact standalone: generate all 42 held models, render representative weapon/tool families, inspect flint/steel's actual transparent hole and flat geometry, ignite ordinary ground with durability loss, drop it using Q, preserve ordinary blocks/pistols, then save/reload an edited world.
2. Actual sword-click damage; F5 staged weapon poses, attached elbow/palm grips, Minimal-particle suppression, and a naturally generated temple's matching planted Devin model. Deterministic animation phase is frozen for action screenshots.
3. Actual W movement through real water with existing fluid/body physics, first-person paddling, F5 prone swimming, continuous stationary treading and smooth land recovery.
4. Eight redesigned Cinderworld foe/neutral rigs in the actual dimension, special-pose rendering and glowing material restoration after a damage flash.
5. Retained pistol palm sockets, independent recoil, F5, particle controls and item swaps.
6. Flint ignition and actual portal entry, linked Cinderworld return, realm saves and persistent reload.
7. All-Guardians sword requirement: Creative/Peaceful refusal, real defeats across reload, Sigil attunement, the actual 30-second held-mouse extraction and a unique persistent sword.
8. Actual HTTPS/WSS Survival relay, invitation, synchronized chat/inventory/world interactions and rendered co-op player appearances.

New model/cinder/swim screenshots are visually inspected. Creature positions, gear, target health, animation phases and portal/Guardian fixtures are controlled for reproducibility; this is not an unaided complete Survival playthrough or a guarantee of no bugs. The first visual pass exposed the bottom-of-pool pose gap and the new joint batching budget issue; both are fixed. One final test initially expected durability loss in Creative; its fixture was corrected to verify Creative keeps 64 uses and Survival ignition consumes one, without changing gameplay. The corrected scenario was rerun against the identical frozen build. Tests exercise production input, rendering, physics and inventory/save paths. Every historical browser scenario was not repeated.

## Compatibility and builds

Sixty-six sampled chunks across generators 2–12 and both dimensions are byte-identical to published v1.7.0, as are 22 accumulated container snapshots. Block/item definitions, recipes, mob stats, Creative catalogs and generation version compare equal. Thirteen relevant gameplay/pistol source files have identical SHA-256 values. These are representative terrain samples, not exhaustive proof across all seeds/chunks. The versioned compatibility report includes comparisons and fingerprints.

The production web build, self-contained HTML and Windows x64 executable build successfully. The companion extractor yields HTML identical to the standalone; the PE embeds the same bytes. Runtime/build inputs are frozen before browser tests and rechecked before packaging. ZIP CRCs and artifact SHA-256 values are verified; public download bytes are fetched and compared again before release publication.

Native Windows execution is unverified on this Linux host. Managed Chromium blocks direct file:// navigation before the game loads, so the identical standalone HTML is tested over local HTTP with outside requests blocked. The flint/portal and HTTPS cases rebuild the same frozen source into a temporary standalone copy; it is compared with the shipped HTML. Live Cloudflare tunneling and actual YouTube streaming remain unverified. Historical PERFORMANCE.json data is labelled by its original versions; no new hardware FPS claim is made.

## Intentional limits

These are original assets and cosmetic animations, not exact Minecraft skin UV/animation parity. The swimming model retains the authoritative upright collision body, so a horizontal visual limb can intersect nearby terrain. Animation wind-up does not delay existing click damage. Pistol models/recoil/F5 player rig/poses remain excluded; that retained stance is an intentional exception to the new non-pistol swimming rig. Co-op player movement/swimming appearances update, while complete remote attack animation synchronization remains partial. Enemy navigation/combat limits remain as previously documented.