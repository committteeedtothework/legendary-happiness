import * as T from "three";
import {
  makeSonic,
  makeGiganto,
  poseSonic,
  poseGiganto,
  makeTitanArena,
  makeEmerald,
  disposeTitanObject,
} from "./giganto-models.js";
import {
  TITAN_ROUTE,
  TITAN_EMERALD,
  TITAN_CHEST,
} from "./giganto-simulation.js";
export class TitanView {
  constructor(game) {
    this.game = game;
    this.scene = new T.Scene();
    this.scene.background = new T.Color("#86afc2");
    this.scene.fog = new T.FogExp2("#98b6b4", 0.0024);
    this.camera = new T.PerspectiveCamera(65, 1, 0.15, 700);
    this.scene.add(new T.HemisphereLight("#d1ecf1", "#383641", 2.3));
    this.light = new T.DirectionalLight("#fff4d6", 3);
    this.light.position.set(50, 130, 60);
    this.light.castShadow = !!game.settings.shadows;
    this.light.shadow.mapSize.set(1024, 1024);
    Object.assign(this.light.shadow.camera, {
      left: -100,
      right: 100,
      top: 110,
      bottom: -100,
      near: 1,
      far: 350,
    });
    this.scene.add(this.light);
    this.arena = makeTitanArena(TITAN_ROUTE);
    this.scene.add(this.arena);
    this.sonic = makeSonic();
    this.boss = makeGiganto();
    this.emerald = makeEmerald();
    this.emerald.position.set(
      TITAN_EMERALD.x,
      TITAN_EMERALD.y,
      TITAN_EMERALD.z,
    );
    this.scene.add(this.sonic, this.boss, this.emerald);
    this.aura = new T.Mesh(
      new T.SphereGeometry(1, 12, 8),
      new T.MeshBasicMaterial({
        color: "#ffe77b",
        transparent: true,
        opacity: 0.12,
        depthWrite: false,
        wireframe: true,
      }),
    );
    this.aura.scale.setScalar(3);
    this.scene.add(this.aura);
    this.beam = new T.Mesh(
      new T.CylinderGeometry(2.6, 2.6, 1, 10),
      new T.MeshBasicMaterial({
        color: "#ff687b",
        transparent: true,
        opacity: 0.8,
      }),
    );
    this.scene.add(this.beam);
    this.climbPulse = new T.Mesh(
      new T.TorusGeometry(1, 0.035, 4, 36),
      new T.MeshBasicMaterial({
        color: "#f18082",
        transparent: true,
        opacity: 0.5,
      }),
    );
    this.scene.add(this.climbPulse);
    this.backBeams = [];
    for (let n = 0; n < 6; n++) {
      const m = new T.Mesh(
        new T.CylinderGeometry(0.55, 0.55, 1, 6),
        new T.MeshBasicMaterial({
          color: "#ee5363",
          transparent: true,
          opacity: 0.5,
        }),
      );
      this.scene.add(m);
      this.backBeams.push(m);
    }
    this.fx = new T.InstancedMesh(
      new T.OctahedronGeometry(0.14),
      new T.MeshBasicMaterial({ color: "#fff1ad" }),
      96,
    );
    this.fx.instanceMatrix.setUsage(T.DynamicDrawUsage);
    this.fx.frustumCulled = false;
    this.scene.add(this.fx);
    this.fxData = [];
    this.dummy = new T.Object3D();
    this.look = new T.Vector3();
    this.camReady = false;
    this.lastAction = "";
  }
  event(e, s) {
    if (
      [
        "hit",
        "parry",
        "counter",
        "boom",
        "rush",
        "loop",
        "emerald",
        "qte-win",
      ].includes(e.type)
    )
      for (let n = 0; n < (e.type === "hit" ? 5 : 18); n++) {
        if (this.fxData.length >= 96) this.fxData.shift();
        const p = e.type === "emerald" ? TITAN_EMERALD : s.avatar;
        this.fxData.push({
          x: p.x,
          y: p.y + 1.5,
          z: p.z,
          vx: Math.sin(n * 2.4) * 8,
          vy: 3 + (n % 5),
          vz: Math.cos(n * 2.4) * 8,
          life: 0.7,
        });
      }
  }
  line(mesh, a, b, r = 1) {
    const d = new T.Vector3().subVectors(b, a);
    mesh.position.copy(a).add(b).multiplyScalar(0.5);
    mesh.quaternion.setFromUnitVectors(
      new T.Vector3(0, 1, 0),
      d.clone().normalize(),
    );
    mesh.scale.set(r, d.length(), r);
  }
  draw(s, dt) {
    const g = this.game,
      c = this.camera,
      p = s.avatar,
      t = s.time,
      superForm = s.emerald;
    poseSonic(this.sonic, s, dt);
    poseGiganto(this.boss, s, dt);
    this.boss.visible = s.stage !== "victory";
    const dissolve =
      s.stage === "finale"
        ? Math.max(0, Math.min(1, (s.stageTime - 4) / 2.5))
        : 0;
    for (const m of this.boss.userData.materials) {
      m.transparent = dissolve > 0;
      m.opacity = 1 - dissolve;
    }
    if (s.stage === "finale" && s.stageTime > 3.8 && !this.exploded) {
      this.exploded = true;
      for (let n = 0; n < 64; n++) {
        const a = n * 2.4;
        this.fxData.push({
          x: Math.sin(a) * 8,
          y: 48 + (n % 20),
          z: Math.cos(a) * 8,
          vx: Math.sin(a) * 22,
          vy: 8 + (n % 11),
          vz: Math.cos(a) * 22,
          life: 2,
          size: 9,
        });
      }
      this.fxData = this.fxData.slice(-96);
    }
    this.emerald.visible = !s.emerald;
    this.emerald.rotation.y = t;
    this.emerald.position.y = 95 + Math.sin(t * 2) * 0.25;
    this.aura.visible = superForm;
    this.aura.position.set(p.x, p.y + 1.8, p.z);
    this.aura.rotation.y = t * 1.7;
    this.aura.material.opacity =
      s.stage === "transform" ? 0.1 + Math.sin(s.stageTime * 12) * 0.07 : 0.1;
    this.light.intensity = s.config.lighting
      ? 3 + (s.stage === "transform" ? Math.sin(s.stageTime * 3) * 1.1 : 0)
      : 1.7;
    this.arena.userData.rings.forEach((m, n) => {
      m.material.color.set(n <= s.route ? "#e4c773" : "#42ddd6");
      m.scale.setScalar(n === s.route + 1 ? 1 + Math.sin(t * 3) * 0.08 : 1);
    });
    const pulsePhase = s.time % 6;
    this.climbPulse.visible =
      s.stage === "traversal" && pulsePhase > 3 && pulsePhase < 5;
    this.climbPulse.position.set(0, 55, -12);
    this.climbPulse.scale.setScalar(10 + Math.max(0, pulsePhase - 3) * 22);
    this.climbPulse.material.opacity =
      pulsePhase < 4 ? 0.25 : 0.65 * (5 - pulsePhase);
    this.beam.visible = s.attack === "beam" && !!s.qte;
    if (this.beam.visible)
      this.line(
        this.beam,
        new T.Vector3(0, 83, 8),
        new T.Vector3(p.x, p.y + 1, p.z),
      );
    this.backBeams.forEach((m, n) => {
      m.visible = s.phase === 2 && !["victory", "finale"].includes(s.stage);
      const a = -Math.PI + ((n + 0.5) / 6) * Math.PI;
      this.line(
        m,
        new T.Vector3((n - 2.5) * 4, 79, -9),
        new T.Vector3(Math.sin(a) * 75, 150, Math.cos(a) * 75),
      );
      m.material.opacity = 0.3 + Math.sin(t * 0.8) * 0.18;
    });
    if (s.action === "loop") {
      const a = t * 9;
      this.aura.position.set(Math.sin(a) * 25, 58, Math.cos(a) * 25);
      this.aura.scale.setScalar(5);
    } else this.aura.scale.setScalar(3);
    this.fxData = this.fxData.filter((f) => (f.life -= dt) > 0);
    for (let n = 0; n < 96; n++) {
      const f = s.config.particles ? this.fxData[n] : null;
      if (f) {
        f.x += f.vx * dt;
        f.y += f.vy * dt;
        f.z += f.vz * dt;
        this.dummy.position.set(f.x, f.y, f.z);
        this.dummy.scale.setScalar(f.life * (f.size || 1));
      } else this.dummy.scale.setScalar(0);
      this.dummy.updateMatrix();
      this.fx.setMatrixAt(n, this.dummy.matrix);
    }
    this.fx.instanceMatrix.needsUpdate = true;
    let target = new T.Vector3(p.x, p.y + 2, p.z),
      desired = new T.Vector3();
    if (s.stage === "intro") {
      target.set(0, 50, 0);
      desired.set(95, 57, 135);
    } else if (s.stage === "transform") {
      const a = s.stageTime * 0.8;
      desired.set(p.x + Math.sin(a) * 9, p.y + 4, p.z + Math.cos(a) * 9);
    } else if (s.stage === "phase") {
      target.set(0, 62, 0);
      desired.set(90, 88, 100);
    } else if (s.stage === "finale" || s.stage === "victory") {
      target.set(0, 60, 0);
      desired.set(55, 64, 102);
      if (s.stage === "finale") {
        this.sonic.position.set(
          0,
          57 + Math.min(1, s.stageTime / 4) * 26,
          33 - Math.min(1, s.stageTime / 5) * 30,
        );
        this.aura.position.copy(this.sonic.position);
      }
    } else if (s.qte) {
      target.set(0, 73, 16);
      desired.set(35, 73, 63);
    } else if (superForm && s.lock) {
      target.lerp(new T.Vector3(0, 65, 0), 0.3);
      const a = Math.atan2(p.x, p.z);
      desired.set(p.x + Math.sin(a) * 16, p.y + 7, p.z + Math.cos(a) * 16);
    } else {
      const d = superForm ? 13 : 9,
        cp = Math.cos(p.pitch);
      desired.set(
        p.x + Math.sin(p.yaw) * d * cp,
        p.y + 3 + Math.sin(p.pitch) * d,
        p.z + Math.cos(p.yaw) * d * cp,
      );
    }
    desired.y = Math.max(2.5, desired.y);
    const r = Math.hypot(desired.x, desired.z);
    if (r < 21 && desired.y < 93) {
      desired.x *= 21 / Math.max(0.1, r);
      desired.z *= 21 / Math.max(0.1, r);
    }
    if (this.camReady) {
      c.position.lerp(desired, 1 - Math.exp(-dt * 8));
      this.look.lerp(target, 1 - Math.exp(-dt * 9));
    } else {
      c.position.copy(desired);
      this.look.copy(target);
      this.camReady = true;
    }
    const cameraRadius = Math.hypot(c.position.x, c.position.z);
    if (c.position.y < 93 && cameraRadius < 21) {
      if (cameraRadius < 0.001) c.position.z = 21;
      else {
        c.position.x *= 21 / cameraRadius;
        c.position.z *= 21 / cameraRadius;
      }
    }
    c.position.y = Math.max(2.5, c.position.y);
    c.lookAt(this.look);
    c.aspect = innerWidth / innerHeight;
    c.updateProjectionMatrix();
    this.scene.background.set(s.phase === 2 ? "#586675" : "#86afc2");
    const marker = new T.Vector3(
      TITAN_CHEST.x,
      TITAN_CHEST.y,
      TITAN_CHEST.z,
    ).project(c);
    this.targetScreen = {
      x: (marker.x + 1) * 0.5,
      y: (1 - marker.y) * 0.5,
      visible:
        marker.z > -1 &&
        marker.z < 1 &&
        Math.abs(marker.x) < 1 &&
        Math.abs(marker.y) < 1,
    };
    g.renderer.gl.info.reset();
    g.renderer.gl.render(this.scene, c);
  }
  dispose() {
    disposeTitanObject(this.scene);
    this.light.shadow.map?.dispose();
  }
}
export function titanPortal() {
  const group = new T.Group(),
    mat = new T.MeshBasicMaterial({ color: "#67e5dd" }),
    r = new T.Mesh(new T.TorusGeometry(1.65, 0.14, 6, 40), mat);
  r.position.y = 2;
  group.add(r);
  const inner = new T.Mesh(
    new T.CircleGeometry(1.5, 32),
    new T.MeshBasicMaterial({
      color: "#3347a5",
      side: T.DoubleSide,
      transparent: true,
      opacity: 0.66,
      depthWrite: false,
    }),
  );
  inner.position.y = 2;
  group.add(inner);
  const ring = new T.Mesh(
    new T.TorusGeometry(1.38, 0.035, 4, 32),
    new T.MeshBasicMaterial({ color: "#ffe69c" }),
  );
  ring.position.y = 2;
  group.add(ring);
  for (let n = 0; n < 7; n++) {
    const gem = new T.Mesh(
      new T.OctahedronGeometry(0.17),
      new T.MeshBasicMaterial({
        color: [
          "#ef6567",
          "#91e7d9",
          "#af91e3",
          "#f7d86b",
          "#84adf0",
          "#ece8d8",
          "#8be090",
        ][n],
      }),
    );
    const a = (n / 7) * Math.PI * 2;
    gem.position.set(Math.sin(a) * 1.8, 2 + Math.cos(a) * 1.8, 0.05);
    group.add(gem);
  }
  const light = new T.PointLight("#62e6d8", 5, 10, 2);
  light.position.y = 2;
  group.add(light);
  const sparks = new T.InstancedMesh(
    new T.OctahedronGeometry(0.06),
    new T.MeshBasicMaterial({ color: "#b9ffec" }),
    16,
  );
  sparks.position.y = 2;
  sparks.frustumCulled = false;
  group.add(sparks);
  group.userData = { ring, inner, light, sparks };
  return group;
}

const portalDummy = new T.Object3D();
export function animateTitanPortal(group, time, particles, lighting) {
  group.userData.ring.rotation.z = time * 0.4;
  group.userData.inner.rotation.z = -time * 0.25;
  group.userData.light.visible = lighting;
  group.userData.sparks.visible = particles;
  for (let n = 0; n < 16; n++) {
    const a = time * 0.65 + (n / 16) * Math.PI * 2;
    portalDummy.position.set(
      Math.sin(a) * 1.9,
      Math.cos(a) * 1.9 + Math.sin(time * 2 + n) * 0.12,
      0.15 * Math.sin(a * 3),
    );
    portalDummy.scale.setScalar(0.7 + 0.5 * Math.sin(time * 3 + n));
    portalDummy.updateMatrix();
    group.userData.sparks.setMatrixAt(n, portalDummy.matrix);
  }
  group.userData.sparks.instanceMatrix.needsUpdate = true;
}
