import * as T from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
const texCache = new Map();
function pixelTexture(base, accent) {
  const key = base + accent;
  if (texCache.has(key)) return texCache.get(key);
  const data = new Uint8Array(16 * 16 * 4),
    a = new T.Color(base),
    b = new T.Color(accent);
  for (let y = 0; y < 16; y++)
    for (let x = 0; x < 16; x++) {
      const c = (x * 3 + y * 5) % 19 < 3 ? b : a;
      let n = (y * 16 + x) * 4;
      data.set(
        [
          Math.round(c.r * 255),
          Math.round(c.g * 255),
          Math.round(c.b * 255),
          255,
        ],
        n,
      );
    }
  const t = new T.DataTexture(data, 16, 16, T.RGBAFormat);
  t.magFilter = t.minFilter = T.NearestFilter;
  t.generateMipmaps = false;
  t.colorSpace = T.LinearSRGBColorSpace;
  t.needsUpdate = true;
  texCache.set(key, t);
  return t;
}
function material(color, accent = color, metal = 0, glow = 0) {
  return new T.MeshStandardMaterial({
    color: "#ffffff",
    map: pixelTexture(color, accent),
    metalness: metal,
    roughness: 0.65,
    flatShading: true,
    emissive: new T.Color(color),
    emissiveIntensity: glow,
  });
}
function mesh(parent, geo, mat, pos = [0, 0, 0], scale = [1, 1, 1]) {
  const m = new T.Mesh(geo, mat);
  m.position.set(...pos);
  m.scale.set(...scale);
  m.castShadow = m.receiveShadow = true;
  parent.add(m);
  return m;
}
const ball = (p, m, pos, scale) =>
    mesh(p, new T.SphereGeometry(1, 12, 8), m, pos, scale),
  box = (p, m, pos, size) => mesh(p, new T.BoxGeometry(...size), m, pos);
function joint(p, name, pos) {
  const b = new T.Bone();
  b.name = name;
  b.position.set(...pos);
  p.add(b);
  return b;
}
export function makeSonic() {
  const root = new T.Group(),
    blue = material("#1b55bd", "#2873df"),
    skin = material("#e0bd8b", "#f0d1a1"),
    white = material("#eeeedd", "#c9d7da"),
    red = material("#c83943", "#e65b57"),
    black = material("#202a3b"),
    green = material("#4ea66a"),
    gold = material("#e6b638", "#fff0a0", 0.15, 0.25),
    bones = {};
  const hip = (bones.hip = joint(root, "hip", [0, 1.15, 0]));
  ball(hip, blue, [0, 0.15, 0], [0.43, 0.63, 0.35]);
  ball(hip, skin, [0, 0.18, 0.29], [0.29, 0.4, 0.1]);
  const head = (bones.head = joint(hip, "head", [0, 0.92, 0]));
  ball(head, blue, [0, 0, 0], [0.64, 0.63, 0.54]);
  const quills = [];
  for (let n = 0; n < 6; n++) {
    const q = mesh(head, new T.ConeGeometry(0.33, 0.95, 7), blue, [
      Math.sin(n * 1.1) * 0.38,
      -0.05 - Math.floor(n / 2) * 0.15,
      -0.4 - Math.floor(n / 2) * 0.13,
    ]);
    q.rotation.x = -1.65 - Math.floor(n / 2) * 0.25;
    q.userData.baseX = q.rotation.x;
    quills.push(q);
    q.rotation.z = (n % 2 ? 1 : -1) * 0.65;
  }
  for (const side of [-1, 1]) {
    const ear = mesh(head, new T.ConeGeometry(0.24, 0.5, 3), blue, [
      side * 0.41,
      0.5,
      0,
    ]);
    ear.rotation.z = -side * 0.22;
    const inside = mesh(head, new T.ConeGeometry(0.13, 0.29, 3), skin, [
      side * 0.41,
      0.52,
      0.08,
    ]);
    inside.rotation.z = -side * 0.22;
    ball(head, white, [side * 0.21, 0.08, 0.44], [0.3, 0.34, 0.13]);
    ball(head, green, [side * 0.19, 0.05, 0.554], [0.085, 0.17, 0.035]);
    ball(head, black, [side * 0.18, 0.06, 0.581], [0.037, 0.13, 0.02]);
    ball(head, white, [side * 0.19, 0.14, 0.596], [0.017, 0.04, 0.01]);
  }
  ball(head, skin, [0, -0.26, 0.47], [0.5, 0.24, 0.22]);
  ball(head, black, [0, -0.12, 0.72], [0.13, 0.105, 0.14]);
  const smile = box(head, black, [0.25, -0.3, 0.64], [0.15, 0.025, 0.012]);
  smile.rotation.z = 0.12;
  for (const side of [-1, 1]) {
    const arm = (bones[side < 0 ? "armL" : "armR"] = joint(hip, "upper_arm", [
      side * 0.42,
      0.48,
      0,
    ]));
    ball(arm, blue, [side * 0.03, -0.25, 0], [0.12, 0.34, 0.13]);
    const elbow = (bones[side < 0 ? "elbowL" : "elbowR"] = joint(arm, "elbow", [
      side * 0.05,
      -0.49,
      0,
    ]));
    ball(elbow, skin, [0, -0.2, 0], [0.105, 0.25, 0.11]);
    ball(elbow, white, [0, -0.43, 0], [0.21, 0.12, 0.2]);
    ball(elbow, white, [0, -0.59, 0.04], [0.23, 0.24, 0.2]);
    ball(elbow, white, [-side * 0.18, -0.55, 0.12], [0.11, 0.13, 0.11]);
    const leg = (bones[side < 0 ? "legL" : "legR"] = joint(hip, "thigh", [
      side * 0.22,
      -0.38,
      0,
    ]));
    ball(leg, blue, [0, -0.25, 0], [0.12, 0.35, 0.13]);
    const knee = (bones[side < 0 ? "kneeL" : "kneeR"] = joint(
      leg,
      "knee",
      [0, -0.48, 0],
    ));
    ball(knee, blue, [0, -0.14, 0], [0.105, 0.23, 0.1]);
    ball(knee, white, [0, -0.32, 0], [0.23, 0.13, 0.22]);
    ball(knee, red, [0, -0.44, 0.18], [0.27, 0.18, 0.48]);
    box(knee, white, [0, -0.38, 0.17], [0.48, 0.08, 0.2]);
    box(knee, white, [0, -0.56, 0.18], [0.51, 0.1, 0.8]);
    box(knee, gold, [side * 0.22, -0.37, 0.1], [0.04, 0.15, 0.18]);
  }
  root.userData = {
    bones,
    blue,
    gold,
    quills,
    materials: [blue, skin, white, red, black, green, gold],
    super: false,
  };
  return root;
}
const ease = (a, b, dt) => T.MathUtils.lerp(a, b, 1 - Math.exp(-dt * 14));
export function poseSonic(root, s, dt) {
  const b = root.userData.bones,
    p = s.avatar,
    superForm = s.emerald && s.stage !== "traversal" && s.stage !== "intro",
    t = s.time,
    run = Math.min(1, Math.hypot(p.vx, p.vz) / 18),
    wave = Math.sin(t * (run > 0.8 ? 22 : 13));
  if (root.userData.super !== superForm) {
    root.userData.super = superForm;
    root.userData.quills.forEach(
      (q) => (q.rotation.x = superForm ? -0.65 : q.userData.baseX),
    );
    root.traverse((m) => {
      if (m.isMesh && m.material === root.userData.blue)
        m.material = superForm ? root.userData.gold : root.userData.blue;
    });
  }
  root.position.set(p.x, p.y + 0.4, p.z);
  root.scale.setScalar(1.3);
  let facing = p.yaw + Math.PI;
  if (Math.hypot(p.vx, p.vz) > 1 && !superForm) facing = Math.atan2(p.vx, p.vz);
  if (superForm && s.lock) facing = Math.atan2(-p.x, -p.z);
  const turn = Math.atan2(
    Math.sin(facing - root.rotation.y),
    Math.cos(facing - root.rotation.y),
  );
  root.rotation.y = ease(root.rotation.y, root.rotation.y + turn, dt);
  b.hip.position.y = ease(
    b.hip.position.y,
    superForm
      ? 1.2 + Math.sin(t * 3) * 0.06
      : 1.15 + Math.abs(wave) * run * 0.05,
    dt,
  );
  let hipX = superForm ? -0.12 : run * 0.25,
    armLX = wave * run,
    armRX = -wave * run,
    armLZ = 0.18,
    armRZ = -0.18,
    legLX = -wave * run,
    legRX = wave * run,
    elbowL = -0.2,
    elbowR = -0.2,
    kneeL = Math.max(0, wave) * run * 0.5,
    kneeR = Math.max(0, -wave) * run * 0.5;
  if (!superForm && !p.onGround) {
    hipX = -0.2;
    armLX = -0.5;
    armRX = -0.5;
    legLX = 0.5;
    legRX = -0.4;
    kneeL = 0.8;
  }
  if (superForm) {
    armLX = -0.3;
    armRX = -0.3;
    armLZ = 0.35;
    armRZ = -0.35;
    legLX = 0.1;
    legRX = -0.2;
    kneeR = 0.3;
  }
  if (s.action === "punch" || s.action === "counter") {
    const q = Math.sin(
        (1 - s.actionTime / (s.action === "counter" ? 1.2 : 0.28)) * Math.PI,
      ),
      side = s.combo % 2;
    armLX = side ? -1.5 * q : -0.4;
    armRX = side ? -0.4 : -1.5 * q;
    elbowL = elbowR = -0.6;
    hipX = -q * 0.25;
  }
  if (s.parryHeld || s.action === "parry") {
    armLX = armRX = -1.4;
    elbowL = elbowR = -0.75;
    armLZ = -0.15;
    armRZ = 0.15;
  }
  if (s.action === "boom") {
    legRX = -1.25;
    kneeR = -0.1;
    armLX = 0.6;
    armRX = -0.8;
  }
  if (s.action === "dodge") {
    root.rotation.z = Math.sin((s.dodge / 0.5) * Math.PI) * 1.5;
    armLX = armRX = -0.8;
  } else root.rotation.z = ease(root.rotation.z, 0, dt);
  if (s.action === "rush" || s.action === "loop") {
    hipX = -0.9;
    armLX = armRX = 0.8;
    legLX = 0.8;
    legRX = -0.8;
    root.rotation.y += Math.sin(t * 18) * 0.08;
  }
  if (s.action === "hurt") {
    hipX = 0.5;
    armLX = armRX = -1.7;
    legLX = -0.7;
    legRX = 0.7;
  }
  b.hip.rotation.x = ease(b.hip.rotation.x, hipX, dt);
  for (const [k, v] of Object.entries({
    armL: armLX,
    armR: armRX,
    legL: legLX,
    legR: legRX,
    elbowL,
    kneeL,
    elbowR,
    kneeR,
  }))
    b[k].rotation.x = ease(b[k].rotation.x, v, dt);
  b.armL.rotation.z = ease(b.armL.rotation.z, armLZ, dt);
  b.armR.rotation.z = ease(b.armR.rotation.z, armRZ, dt);
  b.head.rotation.y = ease(b.head.rotation.y, Math.sin(t * 0.5) * 0.04, dt);
}
export function makeGiganto() {
  const root = new T.Group(),
    shell = material("#c5cbc5", "#8e9b9e", 0.6),
    dark = material("#252e38", "#35414b", 0.65),
    red = material("#d53849", "#f3665d", 0.2, 0.65),
    black = material("#151c28"),
    bone = material("#e4e1cb", "#bac7bd", 0.35),
    bones = {};
  const hip = (bones.hip = joint(root, "titan_hip", [0, 34, 0]));
  box(hip, dark, [0, 1, 0], [18, 10, 13]);
  const chest = (bones.chest = joint(hip, "titan_spine", [0, 4, 0]));
  ball(chest, dark, [0, 16, 0], [14, 20, 10]);
  for (let y = 4; y < 32; y += 5) {
    for (const side of [-1, 1]) {
      const plate = box(chest, shell, [side * 9, y, 7], [8, 3, 6]);
      plate.rotation.z = side * 0.2;
    }
    box(chest, red, [0, y, 10], [1.2, 3, 1]);
  }
  ball(chest, red, [0, 19, 10], [3.2, 3.2, 1.5]);
  const head = (bones.head = joint(chest, "titan_neck", [0, 39, 0]));
  ball(head, shell, [0, 4, 1], [9, 8, 7]);
  box(head, dark, [0, 1, 6], [13, 4, 3]);
  box(head, red, [0, 5, 7], [12, 0.8, 1]);
  for (const side of [-1, 1]) {
    const h = mesh(head, new T.ConeGeometry(2, 12, 6), shell, [
      side * 8,
      10,
      -1,
    ]);
    h.rotation.z = -side * 0.55;
    box(head, black, [side * 4, 5.5, 7], [4, 1.2, 1.1]);
  }
  const jaw = (bones.jaw = joint(head, "jaw", [0, -1, 4]));
  box(jaw, dark, [0, -1, 2], [13, 3, 6]);
  for (let x = -5; x <= 5; x += 2) {
    mesh(jaw, new T.ConeGeometry(0.75, 2, 4), bone, [x, 1, 4]);
    const tooth = mesh(head, new T.ConeGeometry(0.75, 2, 4), bone, [x, 0.2, 7]);
    tooth.rotation.x = Math.PI;
  }
  for (const side of [-1, 1]) {
    const arm = (bones[side < 0 ? "armL" : "armR"] = joint(
      chest,
      "titan_shoulder",
      [side * 15, 28, 0],
    ));
    ball(arm, shell, [side * 1, -3, 0], [7, 8, 7]);
    box(arm, dark, [0, -11, 0], [5, 15, 5]);
    box(arm, shell, [side * 2, -11, 0], [5, 13, 6]);
    const elbow = (bones[side < 0 ? "elbowL" : "elbowR"] = joint(
      arm,
      "titan_elbow",
      [0, -18, 0],
    ));
    ball(elbow, dark, [0, 0, 0], [4, 4, 4]);
    box(elbow, shell, [0, -10, 0], [7, 18, 7]);
    box(elbow, red, [side * 3.6, -9, 0], [0.4, 14, 3]);
    const hand = joint(elbow, "titan_wrist", [0, -20, 0]);
    box(hand, dark, [0, -3, 1], [8, 8, 6]);
    for (let n = 0; n < 4; n++) {
      const finger = joint(hand, "titan_finger", [-3 + n * 2, -5, 1]);
      box(finger, shell, [0, -3, 0], [1.6, 7, 2]);
      finger.rotation.x = -0.3;
    }
    box(hand, shell, [-side * 5, -3, 2], [3, 6, 3]);
    const leg = (bones[side < 0 ? "legL" : "legR"] = joint(hip, "titan_thigh", [
      side * 7,
      -3,
      0,
    ]));
    box(leg, shell, [0, -8, 0], [7, 15, 8]);
    const knee = (bones[side < 0 ? "kneeL" : "kneeR"] = joint(
      leg,
      "titan_knee",
      [0, -16, 0],
    ));
    ball(knee, dark, [0, 0, 0], [4, 4, 4]);
    box(knee, shell, [0, -7, 0], [6, 15, 7]);
    box(knee, dark, [0, -13, 4], [9, 5, 16]);
    box(knee, red, [0, -5, 3.7], [1, 9, 0.4]);
  }
  const rods = [];
  for (let n = 0; n < 6; n++) {
    const rod = joint(chest, "dorsal_emitter", [
      (n - 2.5) * 4,
      23 + Math.abs(n - 2.5) * 1.1,
      -9,
    ]);
    mesh(rod, new T.CylinderGeometry(1.1, 2, 17, 6), dark, [0, 8, 0]);
    ball(rod, red, [0, 17, 0], [1.3, 1.6, 1.3]);
    rod.rotation.z = (2.5 - n) * 0.13;
    rods.push(rod);
  }
  root.userData = {
    bones,
    rods,
    materials: [shell, dark, red, black, bone],
    red,
  };
  return root;
}
export function poseGiganto(root, s, dt) {
  const b = root.userData.bones,
    t = s.time;
  let chestY = 0,
    armLX = 0.08,
    armRX = 0.08,
    armLZ = 0.15,
    armRZ = -0.15,
    elbowL = -0.1,
    elbowR = -0.1,
    jaw = 0;
  if (["intro", "traversal"].includes(s.stage)) {
    chestY = Math.sin(t * 0.55) * 0.015;
  }
  if (s.stage === "combat" && s.attack !== "idle") {
    const tell =
        { swing: 1.5, slap: 1.2, beam: 1.8, crunch: 1.75 }[s.attack] *
        { easy: 1.25, normal: 1, hard: 0.85 }[s.config.difficulty],
      u = Math.min(1, s.attackTime / tell),
      strike = Math.max(0, Math.min(1, (s.attackTime - tell) / 0.3));
    if (s.attack === "swing") {
      armLX = -u * 0.4 - strike * 0.9;
      armLZ = -u * 1.2 + strike * 2;
      elbowL = -u * 0.8;
      chestY = u * 0.3 - strike * 0.55;
    }
    if (s.attack === "slap") {
      armRX = -u * 0.5 - strike * 1.2;
      armRZ = u * 1.1 - strike * 1.9;
      elbowR = -u * 0.7;
    }
    if (s.attack === "beam") {
      jaw = u * 0.75;
      chestY = Math.sin(t * 0.2) * 0.1;
      armLZ = 0.35;
      armRZ = -0.35;
    }
    if (s.attack === "crunch") {
      armLX = armRX = -u * 0.85 - strike * 0.35;
      armLZ = -u * 0.7 + strike * 0.8;
      armRZ = u * 0.7 - strike * 0.8;
      elbowL = elbowR = -strike * 1.1;
      jaw = 0.45;
    }
  }
  if (s.stagger > 0) {
    armLX = armRX = 0.3;
    b.head.rotation.x = ease(b.head.rotation.x, 0.2, dt);
  } else b.head.rotation.x = ease(b.head.rotation.x, 0, dt);
  b.chest.rotation.y = ease(b.chest.rotation.y, chestY, dt);
  for (const [k, v] of Object.entries({
    armL: armLX,
    armR: armRX,
    elbowL,
    elbowR,
  }))
    b[k].rotation.x = ease(b[k].rotation.x, v, dt);
  b.armL.rotation.z = ease(b.armL.rotation.z, armLZ, dt);
  b.armR.rotation.z = ease(b.armR.rotation.z, armRZ, dt);
  b.jaw.rotation.x = ease(b.jaw.rotation.x, jaw, dt);
  root.position.y =
    s.stagger > 0 && s.action === "loop"
      ? Math.sin((1 - s.actionTime / 1.6) * Math.PI) * 5
      : 0;
  root.rotation.x =
    s.stage === "finale"
      ? Math.min(1, s.stageTime / 6) * 0.35
      : s.stage === "victory"
        ? 0.35
        : 0;
  root.userData.rods.forEach(
    (r) => (r.scale.y = ease(r.scale.y, s.phase === 2 ? 1.6 : 1, dt)),
  );
  root.userData.red.emissiveIntensity =
    0.45 + Math.sin(t * 3) * 0.2 + (s.stage === "phase" ? 0.8 : 0);
}
export function makeTitanArena(route) {
  const group = new T.Group(),
    geos = [],
    color = new T.Color();
  function add(g, pos, c) {
    g.translate(...pos);
    color.set(c);
    const a = new Float32Array(g.attributes.position.count * 3);
    for (let n = 0; n < a.length; n += 3) a.set([color.r, color.g, color.b], n);
    g.setAttribute("color", new T.BufferAttribute(a, 3));
    geos.push(g);
  }
  add(new T.CylinderGeometry(180, 183, 8, 64), [0, -4, 0], "#788d65");
  for (let n = 0; n < 38; n++) {
    const a = (n / 38) * Math.PI * 2,
      r = 174 + (n % 4) * 7;
    add(
      new T.ConeGeometry(12 + (n % 5), 35 + (n % 7) * 9, 5),
      [Math.sin(a) * r, 5, Math.cos(a) * r],
      n % 2 ? "#4b565a" : "#727b71",
    );
  }
  for (const p of route.slice(1))
    add(new T.BoxGeometry(p.w, 1.5, p.w), [p.x, p.y - 0.75, p.z], "#555f65");
  const merged = mergeGeometries(geos);
  geos.forEach((g) => g.dispose());
  group.add(
    new T.Mesh(
      merged,
      new T.MeshStandardMaterial({
        vertexColors: true,
        roughness: 0.95,
        flatShading: true,
      }),
    ),
  );
  const ringMat = new T.MeshBasicMaterial({ color: "#42ddd6" });
  const rings = [];
  for (const p of route) {
    const m = new T.Mesh(
      new T.TorusGeometry(2.5, 0.13, 5, 24),
      ringMat.clone(),
    );
    m.rotation.x = -Math.PI / 2;
    m.position.set(p.x, p.y + 0.08, p.z);
    group.add(m);
    rings.push(m);
  }
  group.userData.rings = rings;
  return group;
}
export function makeEmerald() {
  const group = new T.Group(),
    mat = new T.MeshStandardMaterial({
      color: "#62eac8",
      emissive: "#27bfa5",
      emissiveIntensity: 0.7,
      metalness: 0.4,
      roughness: 0.18,
      flatShading: true,
    });
  mesh(group, new T.OctahedronGeometry(1.25, 0), mat);
  const light = new T.PointLight("#42e6d8", 25, 15, 2);
  group.add(light);
  return group;
}
export function disposeTitanObject(root) {
  const materials = new Set(),
    geos = new Set();
  root.traverse((n) => {
    if (n.isInstancedMesh) n.dispose();
    if (n.geometry) geos.add(n.geometry);
    for (const m of Array.isArray(n.material) ? n.material : [n.material])
      if (m) materials.add(m);
  });
  geos.forEach((g) => g.dispose());
  materials.forEach((m) => m.dispose());
  root.removeFromParent();
}
