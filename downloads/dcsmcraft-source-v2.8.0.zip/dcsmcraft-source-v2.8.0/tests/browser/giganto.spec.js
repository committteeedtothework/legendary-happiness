import { test, expect } from "@playwright/test";
import { readFileSync, mkdirSync, writeFileSync } from "node:fs";
import { createServer } from "node:http";
const html = readFileSync("dist/DCSMCRAFT-Standalone.html"),
  out = "/workspace/artifacts/giganto-280";
mkdirSync(out, { recursive: true });
let server, origin;
test.use({ trace: "off" });
test.beforeAll(async () => {
  server = createServer((q, r) => {
    r.setHeader("Content-Type", "text/html");
    r.end(html);
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  origin = `http://127.0.0.1:${server.address().port}`;
});
test.afterAll(async () => {
  server?.closeAllConnections();
  if (server) await new Promise((r) => server.close(r));
});
async function boot(page) {
  const errors = [],
    external = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (m) => {
    if (/Shader Error|GL_INVALID|WebGLProgram/.test(m.text()))
      errors.push(m.text());
  });
  await page.addInitScript(
    () =>
      localStorage.getItem("dcsmcraft-settings") ||
      localStorage.setItem(
        "dcsmcraft-settings",
        JSON.stringify({
          graphics: 1,
          renderDistance: 2,
          distantTerrain: false,
          volume: 0,
          musicEnabled: false,
          ambientSounds: false,
          frameLimit: 30,
          skin: "explorer",
        }),
      ),
  );
  await page.route("**/*", (r) =>
    r
      .request()
      .url()
      .startsWith(origin + "/")
      ? r.continue()
      : (external.push(r.request().url()), r.abort()),
  );
  await page.goto(origin + "/titan.html");
  await page.waitForFunction(() => dcsmcraft?.initialized);
  await page.locator("[data-action=create]").click();
  await page.locator("[name=seed]").fill("Wildflower");
  await page.locator("[name=mode][value=creative]").check();
  await page.locator("[name=difficulty]").selectOption("peaceful");
  await page.locator("[data-action=start-world]").click();
  await page.waitForFunction(
    () => dcsmcraft.running && dcsmcraft.ui.screen === "play",
  );
  await page.evaluate(() => {
    const g = dcsmcraft;
    g.pause();
    g.ui.play();
    g.entities = [];
    g.inventory.slots.fill(null);
    g.world.set(0, 199, 0, 3);
    g.inventory.selected = 0;
    Object.assign(g.player, {
      x: 0.5,
      y: 200,
      z: 0.5,
      yaw: 0,
      pitch: 0,
      vy: 0,
      onGround: true,
      health: 20,
    });
  });
  return { errors, external };
}

async function portal(page, full = false) {
  await page.evaluate((full) => {
    const g = dcsmcraft;
    if (full)
      g.inventory.slots = Array.from({ length: 36 }, () => ({
        id: "stone",
        count: 64,
      }));
    for (let x = 0; x <= 10; x++)
      for (let z = 0; z <= 10; z++) {
        g.world.set(x, 199, z, 3);
        for (let y = 200; y < 206; y++) g.world.set(x, y, z, 0);
      }
    Object.assign(g.player, {
      x: 4.5,
      y: 200,
      z: 7,
      yaw: 0,
      pitch: 0,
      onGround: true,
      health: 17,
      hunger: 12,
      saturation: 3,
    });
    g.inventory.slots[0] = {
      id: "diamond_sword",
      count: 1,
      durability: 500,
      enchantments: { sharpness: 2 },
    };
    g.giganto.record.config.spawnChance = 0;
    g.giganto.record.portal = {
      id: "browser-titan",
      cell: "0,0",
      x: 4,
      y: 200,
      z: 4,
    };
    g.giganto.overworld(0.01);
    g.running = true;
    g.pointerLockFallback = true;
  }, full);
  await page.keyboard.press("KeyE");
  await page.waitForFunction(
    () => dcsmcraft.giganto.active && !dcsmcraft.giganto.pending,
  );
}
async function bot(page) {
  await page.evaluate(() => {
    window.titanBot = setInterval(() => {
      const g = dcsmcraft,
        e = g.giganto,
        s = e.session;
      if (!e.active || !s || !g.running) return;
      const k = e.controls,
        p = s.avatar;
      if (s.stage === "traversal") {
        const route = [
            [0, 0, 78],
            [0, 5, 59],
            [12, 12, 43],
            [26, 20, 27],
            [32, 28, 9],
            [30, 36, -9],
            [22, 44, -25],
            [4, 52, -33],
            [-18, 60, -25],
            [-28, 68, -2],
            [-18, 76, 19],
            [-4, 84, 18],
            [0, 92, 0],
          ],
          q = route[s.route + 1];
        if (!q) return;
        const dx = q[0] - p.x,
          dz = q[2] - p.z,
          d = Math.hypot(dx, dz);
        if (d > 1) p.yaw = Math.atan2(-dx, -dz);
        if (d > 1.3) k.add("KeyW");
        else k.delete("KeyW");
        if (d > 4) k.add("ShiftLeft");
        else k.delete("ShiftLeft");
        if (p.onGround) {
          dispatchEvent(
            new KeyboardEvent("keydown", { code: "Space", bubbles: true }),
          );
          dispatchEvent(
            new KeyboardEvent("keyup", { code: "Space", bubbles: true }),
          );
        }
      } else if (s.stage === "combat") {
        k.delete("ShiftLeft");
        k.add("Mouse0");
        k.add("Mouse2");
        if (s.qte) {
          dispatchEvent(
            new KeyboardEvent("keydown", { code: "Space", bubbles: true }),
          );
          dispatchEvent(
            new KeyboardEvent("keyup", { code: "Space", bubbles: true }),
          );
          return;
        }
        const dx = -p.x,
          dz = 30 - p.z,
          d = Math.hypot(dx, dz);
        if (d > 1) p.yaw = Math.atan2(-dx, -dz);
        if (d > 2) k.add("KeyW");
        else k.delete("KeyW");
        if (p.y < 56) k.add("Space");
        else k.delete("Space");
        if (p.y > 58) k.add("ControlLeft");
        else k.delete("ControlLeft");
        for (const code of ["KeyR", "KeyF", "KeyE"]) {
          dispatchEvent(new KeyboardEvent("keydown", { code, bubbles: true }));
          dispatchEvent(new KeyboardEvent("keyup", { code, bubbles: true }));
        }
      }
    }, 70);
  });
}
test("playable portal → Sonic traversal → final Emerald → Super Sonic → both combat phases → victory → exactly-once reward and original-world return", async ({
  page,
}) => {
  test.setTimeout(240000);
  const evidence = await boot(page);
  const original = await page.evaluate(() => ({
    dimension: dcsmcraft.dimension,
    time: dcsmcraft.time,
    seed: dcsmcraft.world.seed,
  }));
  await portal(page);
  const entryTime = await page.evaluate(() => dcsmcraft.time);
  await expect(page.locator("#titan-hud")).toBeVisible();
  expect(
    await page.locator("#hud").evaluate((n) => getComputedStyle(n).visibility),
  ).toBe("hidden");
  await page.screenshot({ path: out + "/intro.png" });
  await page.keyboard.press("Enter");
  await bot(page);
  await page.waitForFunction(() => dcsmcraft.giganto.session.emerald, {
    timeout: 75000,
  });
  await page.screenshot({ path: out + "/transformation.png" });
  await page.waitForFunction(() => dcsmcraft.giganto.session.phase === 2, {
    timeout: 90000,
  });
  await page.screenshot({ path: out + "/phase-two.png" });
  await page.waitForFunction(
    () => dcsmcraft.giganto.session.stage === "victory",
    { timeout: 120000 },
  );
  await expect(page.locator("[data-titan=exit]")).toBeVisible();
  await page.screenshot({ path: out + "/victory.png" });
  await page.evaluate(() => clearInterval(window.titanBot));
  const before = await page.evaluate(() => {
    const g = dcsmcraft;
    return {
      hp: g.player.health,
      time: g.time,
      rings: g.giganto.session.rings,
      route: g.giganto.session.route,
      geometry: g.renderer.gl.info.render.calls,
    };
  });
  expect(before.hp).toBe(17);
  expect(before.time).toBe(entryTime);
  expect(before.route).toBe(12);
  expect(before.geometry).toBeLessThan(380);
  await page.locator("[data-titan=exit]").click();
  await page.waitForFunction(
    () => !dcsmcraft.giganto.active && !dcsmcraft.giganto.closing,
  );
  const restored = await page.evaluate(async () => {
    const g = dcsmcraft;
    g.pause();
    await g.save();
    return {
      id: g.id,
      health: g.player.health,
      dimension: g.dimension,
      seed: g.world.seed,
      ledger: g.giganto.record.ledger,
      inventory: g.inventory.export(),
      duplicateExit: await g.giganto.exit(),
      cooldown: g.giganto.record.cooldownUntil - g.tickCount,
    };
  });
  expect(restored.health).toBe(17);
  expect(restored.dimension).toBe(original.dimension);
  expect(restored.seed).toBe(original.seed);
  expect(restored.ledger).toEqual(["browser-titan"]);
  expect(restored.duplicateExit).toBe(false);
  expect(restored.inventory.slots[0].enchantments.sharpness).toBe(2);
  expect(
    restored.inventory.slots
      .filter((q) => q?.id === "diamond")
      .reduce((n, q) => n + q.count, 0),
  ).toBe(6);
  expect(
    restored.inventory.slots
      .filter((q) => q?.id === "hellfire_ingot")
      .reduce((n, q) => n + q.count, 0),
  ).toBe(8);
  await page.evaluate(async (id) => {
    await dcsmcraft.loadWorld(id);
    dcsmcraft.pause();
  }, restored.id);
  expect(
    await page.evaluate(() => dcsmcraft.giganto.record.ledger.length),
  ).toBe(1);
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
  writeFileSync(
    out + "/victory-report.json",
    JSON.stringify({ before, restored }, null, 2),
  );
});
test("arena saves resume fairly, pause freezes resources, and forfeit restores equipment without rewards", async ({
  page,
}) => {
  test.setTimeout(150000);
  const evidence = await boot(page);
  await portal(page);
  await page.keyboard.press("Enter");
  await page.evaluate(async () => {
    const g = dcsmcraft;
    g.pause();
    await g.save();
    window.arenaSaveId = g.id;
  });
  await page.evaluate(async () => {
    await dcsmcraft.loadWorld(window.arenaSaveId);
    dcsmcraft.pause();
  });
  expect(
    await page.evaluate(
      () =>
        dcsmcraft.giganto.active &&
        dcsmcraft.giganto.session.stage === "traversal",
    ),
  ).toBe(true);
  const paused = await page.evaluate(() => ({
    time: dcsmcraft.giganto.session.time,
    rings: dcsmcraft.giganto.session.rings,
  }));
  await page.waitForTimeout(200);
  expect(
    await page.evaluate(() => ({
      time: dcsmcraft.giganto.session.time,
      rings: dcsmcraft.giganto.session.rings,
    })),
  ).toEqual(paused);
  await page.locator("[data-titan=exit]").click();
  await page.waitForFunction(() => !dcsmcraft.giganto.active);
  expect(await page.evaluate(() => dcsmcraft.player.health)).toBe(17);
  expect(
    await page.evaluate(() => dcsmcraft.giganto.record.ledger.length),
  ).toBe(0);
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
});

test("defeat retries the saved phase checkpoint; failed victory saves roll back rewards, and full inventories receive exactly one persistent overflow drop per reward", async ({
  page,
}) => {
  test.setTimeout(150000);
  const evidence = await boot(page);
  await portal(page, true);
  await page.evaluate(() => {
    const e = dcsmcraft.giganto,
      s = e.session;
    s.stage = "combat";
    s.emerald = true;
    s.phase = 2;
    s.checkpoint = "phase2";
    s.hp = s.maxHp / 2;
    s.rings = 0.0001;
    s.config.drain = 3;
  });
  await page.waitForFunction(
    () =>
      dcsmcraft.ui.screen === "titan-result" &&
      dcsmcraft.giganto.session.stage === "defeat",
  );
  await page.locator("[data-titan=retry]").click();
  expect(
    await page.evaluate(() => [
      dcsmcraft.giganto.session.phase,
      dcsmcraft.giganto.session.stage,
    ]),
  ).toEqual([2, "combat"]);
  await page.evaluate(() => {
    const g = dcsmcraft;
    g.giganto.session.stage = "victory";
    g.giganto.session.won = true;
    g.giganto.renderResultIfNeeded();
    window.realSave = g.store.save.bind(g.store);
    g.store.save = async () => {
      throw Error("simulated interrupted save");
    };
  });
  await page.locator("[data-titan=exit]").click();
  await page.waitForFunction(() => !dcsmcraft.giganto.closing);
  expect(
    await page.evaluate(() => ({
      active: dcsmcraft.giganto.active,
      ledger: dcsmcraft.giganto.record.ledger.length,
      drops: dcsmcraft.drops.filter((d) => d.uid?.startsWith("titan:")).length,
    })),
  ).toEqual({ active: true, ledger: 0, drops: 0 });
  await page.evaluate(() => (dcsmcraft.store.save = window.realSave));
  await page.locator("[data-titan=exit]").click();
  await page.waitForFunction(
    () => !dcsmcraft.giganto.active && !dcsmcraft.giganto.closing,
  );
  const result = await page.evaluate(async () => {
    const g = dcsmcraft;
    g.pause();
    await g.save();
    const id = g.id;
    await g.loadWorld(id);
    g.pause();
    return {
      ledger: g.giganto.record.ledger.length,
      items: g.drops
        .filter((d) => d.uid?.startsWith("titan:"))
        .map((d) => ({ id: d.id, count: d.count, uid: d.uid })),
      again: await g.giganto.exit(),
      health: g.player.health,
    };
  });
  expect(result.ledger).toBe(1);
  expect(result.items.map((q) => [q.id, q.count]).sort()).toEqual([
    ["diamond", 6],
    ["hellfire_ingot", 8],
  ]);
  expect(new Set(result.items.map((q) => q.uid)).size).toBe(2);
  expect(result.again).toBe(false);
  expect(result.health).toBe(17);
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
  writeFileSync(out + "/recovery-report.json", JSON.stringify(result, null, 2));
});

test("portal settings and seeded natural placement validate every occupied cell, enforce single encounter/cooldown and reject co-op activation", async ({
  page,
}) => {
  test.setTimeout(120000);
  const evidence = await boot(page);
  const result = await page.evaluate(async () => {
    const g = dcsmcraft,
      e = g.giganto;
    g.dimension = "overworld";
    const originalTerrain = g.world.terrain.bind(g.world);
    g.world.terrain = (x, z) => ({ ...originalTerrain(x, z), h: 199 });
    for (let x = -40; x <= 100; x++)
      for (let z = -40; z <= 100; z++) {
        g.world.set(x, 199, z, 3);
        for (let y = 200; y < 205; y++) g.world.set(x, y, z, 0);
      }
    e.record.config.spawnChance = 1;
    const found = e.findPortal(true),
      p = e.record.portal;
    const duplicate = e.findPortal(true);
    g.player.x = p.x + 0.5;
    g.player.y = p.y;
    g.player.z = p.z + 2;
    g.player.onGround = true;
    g.running = true;
    e.overworld(0.01);
    g.world.set(p.x + 1, p.y + 2, p.z, 3);
    const blocked = await e.enter();
    g.world.set(p.x + 1, p.y + 2, p.z, 0);
    g.multiplayer.connected = true;
    const coop = await e.enter();
    g.multiplayer.connected = false;
    e.record.cooldownUntil = g.tickCount + 100;
    const cooldown = await e.enter();
    g.world.terrain = originalTerrain;
    return { found, duplicate, blocked, coop, cooldown, active: e.active };
  });
  expect(result).toEqual({
    found: true,
    duplicate: false,
    blocked: false,
    coop: false,
    cooldown: false,
    active: false,
  });
  await page.evaluate(() => dcsmcraft.pause());
  await page.locator("[data-action=titan-menu]").click();
  await expect(page.locator("[data-titan-config=drain]")).toBeVisible();
  await page.locator("[data-titan-config=drain]").fill("0");
  await page.locator("[data-titan-config=drain]").dispatchEvent("change");
  expect(await page.evaluate(() => dcsmcraft.giganto.record.config.drain)).toBe(
    0,
  );
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
});
