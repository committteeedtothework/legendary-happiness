import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import * as T from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { auditTitanGlb } from "../scripts/audit-titan-glb.mjs";
import {
  importedRig,
  updateImportedSonic,
  updateImportedGiganto,
  disposeImportedRig,
} from "../src/titan-imports.js";
import { disposeTitanObject } from "../src/giganto-models.js";
import { titanSession } from "../src/giganto-simulation.js";
globalThis.self ||= globalThis;
globalThis.ProgressEvent ||= class ProgressEvent {
  constructor(type, init = {}) {
    this.type = type;
    Object.assign(this, init);
  }
};
const cache = {};
async function asset(role) {
  if (cache[role]) return cache[role];
  const b = fs.readFileSync(
      new URL(`../public/models/titan/${role}.glb`, import.meta.url),
    ),
    len = b.readUInt32LE(12),
    g = JSON.parse(b.subarray(20, 20 + len)),
    bin = b.subarray(28 + len);
  // Unit tests load the real geometry/skins/clips, omitting image decode only.
  // Browser tests parse the exact complete file, including all actual textures.
  const metadata = g.extras.dcsmRig,
    superIndex = g.extras.dcsmSuperMaterial;
  g.extensionsRequired = [];
  g.extensionsUsed = [];
  g.images = [];
  g.textures = [];
  for (const mat of g.materials) {
    for (const key of Object.keys(mat))
      if (key.endsWith("Texture")) delete mat[key];
    for (const key of Object.keys(mat.pbrMetallicRoughness || {}))
      if (key.endsWith("Texture")) delete mat.pbrMetallicRoughness[key];
  }
  for (const mesh of g.meshes)
    for (const pr of mesh.primitives) delete pr.extensions;
  g.buffers = [
    {
      byteLength: bin.length,
      uri: "data:application/octet-stream;base64," + bin.toString("base64"),
    },
  ];
  const gltf = await new GLTFLoader().parseAsync(JSON.stringify(g), "");
  const a = {
    role,
    gltf,
    metadata,
    superMaterial:
      role === "sonic"
        ? await gltf.parser.getDependency("material", superIndex)
        : undefined,
  };
  cache[role] = a;
  return a;
}
test("both finished GLBs pass real container, embedded image, skin, clip-name, socket and triangle-budget checks", () => {
  for (const role of ["sonic", "giganto"]) {
    const b = fs.readFileSync(
        new URL(`../public/models/titan/${role}.glb`, import.meta.url),
      ),
      r = auditTitanGlb(b, role);
    assert.equal(r.valid, true, JSON.stringify(r.errors));
    assert.ok(r.animationNames.length >= 20);
    assert.ok(r.images.every((i) => i.embedded));
    assert.ok(r.triangles < 60000);
  }
});
test("every real imported clip targets existing skinned joints with finite bounded deformation, including raised Super quills", async () => {
  for (const role of ["sonic", "giganto"]) {
    const a = await asset(role),
      r = importedRig(a),
      u = r.userData;
    let skinned = 0;
    r.traverse((o) => {
      if (o.isSkinnedMesh) {
        skinned++;
        const j = o.geometry.attributes.skinIndex,
          w = o.geometry.attributes.skinWeight;
        for (let i = 0; i < j.count; i++) {
          let sum = 0;
          for (let k = 0; k < 4; k++) {
            const n = j.array[i * 4 + k],
              v = w.array[i * 4 + k];
            assert.ok(n < o.skeleton.bones.length);
            assert.ok(v >= 0 && Number.isFinite(v));
            sum += v;
          }
          assert.ok(Math.abs(sum - 1) < 0.002);
        }
      }
    });
    assert.ok(skinned > 0);
    for (const clip of a.gltf.animations) {
      u.mixer.stopAllAction();
      const action = u.mixer.clipAction(clip);
      action.reset().play();
      for (const t of [0, clip.duration * 0.5, clip.duration * 0.97]) {
        u.mixer.setTime(t);
        r.updateMatrixWorld(true);
        const box = new T.Box3();
        r.traverse((o) => {
          if (o.isSkinnedMesh) {
            o.skeleton.update();
            o.computeBoundingBox();
            box.union(o.boundingBox.clone().applyMatrix4(o.matrixWorld));
          }
        });
        assert.ok(
          [...box.min.toArray(), ...box.max.toArray()].every(Number.isFinite),
          role + " " + clip.name,
        );
        const size = box.getSize(new T.Vector3());
        assert.ok(
          size.length() < (role === "sonic" ? 9 : 190),
          role + " " + clip.name + " " + size.toArray(),
        );
      }
    }
    disposeImportedRig(r);
  }
});
test("Sonic changes animation and blue/gold materials without moving the simulated avatar, and restores the base pose after held parry", async () => {
  const r = importedRig(await asset("sonic")),
    s = titanSession({ drain: 0 });
  const before = JSON.stringify(s);
  updateImportedSonic(r, s, 1 / 60);
  assert.equal(JSON.stringify(s), before);
  assert.equal(r.userData.currentClip, "idle");
  s.stage = "transform";
  s.emerald = true;
  updateImportedSonic(r, s, 1 / 60);
  assert.equal(r.userData.super, true);
  assert.equal(r.userData.currentClip, "transform");
  s.stage = "combat";
  s.parryHeld = true;
  updateImportedSonic(r, s, 1 / 60);
  assert.equal(r.userData.currentClip, "parry");
  s.parryHeld = false;
  s.action = "punch";
  s.actionTime = 0.2;
  updateImportedSonic(r, s, 1 / 60);
  assert.match(r.userData.currentClip, /attack_/);
  s.stage = "traversal";
  s.emerald = false;
  s.action = "idle";
  updateImportedSonic(r, s, 1 / 60);
  assert.equal(r.userData.super, false);
  disposeImportedRig(r);
});
test("Giganto arm windup/strike and beam/grab poses follow the existing attack clock and animated sockets remain attached", async () => {
  const r = importedRig(await asset("giganto")),
    s = titanSession({ drain: 0 });
  s.stage = "combat";
  s.emerald = true;
  for (const [attack, time, clip] of [
    ["swing", 0.5, "arm_swing_windup"],
    ["swing", 1.6, "arm_swing"],
    ["slap", 0.4, "arm_slap_windup"],
    ["slap", 1.3, "arm_slap"],
    ["crunch", 0.5, "grab_windup"],
    ["crunch", 2, "grab"],
    ["beam", 0.5, "beam_charge"],
  ]) {
    s.attack = attack;
    s.attackTime = time;
    updateImportedGiganto(r, s, 1 / 60);
    assert.equal(r.userData.currentClip, clip);
  }
  s.qte = { kind: "beam", left: 3 };
  updateImportedGiganto(r, s, 1 / 60);
  assert.equal(r.userData.currentClip, "beam_fire");
  r.updateMatrixWorld(true);
  assert.ok(
    r.userData.jawSocket
      .getWorldPosition(new T.Vector3())
      .toArray()
      .every(Number.isFinite),
  );
  assert.equal(r.userData.laserSockets.filter(Boolean).length, 10);
  const original = JSON.stringify(s);
  s.phase = 2;
  s.stage = "phase";
  updateImportedGiganto(r, s, 1 / 60);
  assert.equal(r.userData.currentClip, "phase_transition");
  s.stage = "finale";
  updateImportedGiganto(r, s, 1 / 60);
  assert.equal(r.userData.currentClip, "defeat");
  disposeImportedRig(r);
});
test("forked encounters own independent skeletons, mixers and materials while sharing bounded cached mesh resources", async () => {
  const a = await asset("sonic"),
    r = importedRig(a),
    q = importedRig(a);
  assert.notEqual(r.userData.bones.head, q.userData.bones.head);
  assert.notEqual(r.userData.materials[0], q.userData.materials[0]);
  const s = titanSession({ drain: 0 });
  s.emerald = true;
  s.stage = "combat";
  s.action = "punch";
  s.actionTime = 0.12;
  for (let n = 0; n < 30; n++) updateImportedSonic(r, s, 1 / 60);
  assert.equal(q.userData.super, false);
  let materialDisposals = 0;
  for (const material of r.userData.materials)
    material.addEventListener("dispose", () => materialDisposals++);
  disposeImportedRig(r);
  disposeTitanObject(r);
  assert.equal(materialDisposals, r.userData.materials.length);
  disposeImportedRig(q);
  disposeTitanObject(q);
});

test("locomotion/attack blends keep bind limb scales and bounded active actions at 30, 60 and 144 FPS", async () => {
  for (const rate of [30, 60, 144]) {
    const r = importedRig(await asset("sonic")),
      s = titanSession({ drain: 0 }),
      u = r.userData;
    s.stage = "combat";
    s.emerald = true;
    s.avatar.y = 57;
    for (let i = 0; i < rate * 4; i++) {
      s.time = i / rate;
      s.avatar.vz = i % rate < rate / 2 ? 30 : 0;
      s.avatar.onGround = i < rate;
      s.action = i % Math.ceil(rate / 3) < rate / 6 ? "punch" : "idle";
      s.actionTime = 0.2;
      s.strike = s.action === "punch" ? { hand: "R", duration: 0.32 } : null;
      updateImportedSonic(r, s, 1 / rate);
      for (const [bone, scale] of u.bindScales)
        assert.ok(bone.scale.distanceTo(scale) < 1e-8);
      assert.ok(
        [...u.actions.values()].filter((a) => a.isScheduled()).length <= 3,
      );
      if (i % Math.ceil(rate / 4) === 0) {
        r.updateMatrixWorld(true);
        const box = new T.Box3();
        r.traverse((o) => {
          if (o.isSkinnedMesh) {
            o.skeleton.update();
            o.computeBoundingBox();
            box.union(o.boundingBox.clone().applyMatrix4(o.matrixWorld));
          }
        });
        const size = box.getSize(new T.Vector3());
        assert.ok(
          size.y > 2.6 && size.y < 5,
          `${rate} ${u.currentClip}: ${size.y}`,
        );
      }
    }
    disposeImportedRig(r);
  }
});
test("procedural IK cannot accumulate on an unchanged or paused animation sample", async () => {
  for (const role of ["sonic", "giganto"]) {
    const r = importedRig(await asset(role)),
      s = titanSession({ drain: 0 }),
      update = role === "sonic" ? updateImportedSonic : updateImportedGiganto;
    s.stage = "combat";
    s.emerald = true;
    s.parryHeld = true;
    s.avatar.y = 57;
    s.avatar.z = 25;
    for (let i = 0; i < 25; i++) update(r, s, 1 / 60);
    const bones = Object.values(r.userData.bones),
      before = bones.map((b) => b.quaternion.clone());
    for (let i = 0; i < 100; i++) update(r, s, 0);
    bones.forEach((b, i) =>
      assert.ok(
        b.quaternion
          .toArray()
          .every((v, j) => Math.abs(v - before[i].toArray()[j]) < 0.00001),
        `${role} ${b.name}: ${b.quaternion.toArray()} / ${before[i].toArray()}`,
      ),
    );
    disposeImportedRig(r);
  }
});
test("runtime homing, Cross Slash and left/right stomp clips animate the existing skeleton without adding meshes", async () => {
  for (const role of ["sonic", "giganto"]) {
    const r = importedRig(await asset(role)),
      u = r.userData,
      names =
        role === "sonic"
          ? ["homing_attack", "cross_slash"]
          : ["stomp_L", "stomp_R"];
    const count = () => {
        let n = 0;
        r.traverse((o) => {
          if (o.isMesh) n++;
        });
        return n;
      },
      meshes = count();
    for (const name of names) {
      const clip = u.actions.get(name).getClip();
      assert.ok(clip.tracks.length > 5);
      assert.ok(clip.tracks.every((t) => t.name.endsWith(".quaternion")));
      assert.ok(clip.tracks.some((t) => new Set(t.values).size > 4));
      u.mixer.stopAllAction();
      const a = u.actions.get(name);
      a.reset().setEffectiveWeight(1).play();
      u.mixer.setTime(clip.duration * 0.45);
      r.updateMatrixWorld(true);
      assert.equal(count(), meshes);
      for (const bone of Object.values(u.bones))
        assert.ok(bone.quaternion.toArray().every(Number.isFinite));
    }
    disposeImportedRig(r);
  }
});

test("both stomp plants bring the imported ankle back to the real sole height and the shockwave origin", async () => {
  const { titanStompWave } = await import("../src/titan-contact.js");
  for (const side of ["L", "R"]) {
    const r = importedRig(await asset("giganto")),
      s = titanSession({ drain: 0 });
    Object.assign(s, {
      stage: "combat",
      attack: "stomp",
      swatSide: side,
      attackTime: 1.95,
    });
    s.avatar.z = 25;
    const ankle = r.userData.model.getObjectByName(
      side === "L" ? "Foot_L_092" : "Foot_R_098",
    );
    for (let i = 0; i < 30; i++) updateImportedGiganto(r, s, 1 / 60);
    const p = ankle.getWorldPosition(new T.Vector3()),
      wave = titanStompWave(s);
    assert.ok(wave.active);
    assert.ok(Math.abs(p.y - 1.48) < 0.18, p.toArray());
    assert.ok(
      Math.hypot(p.x - wave.center.x, p.z - wave.center.z) < 0.18,
      p.toArray(),
    );
    disposeImportedRig(r);
  }
});

test("a moving/turning imported Titan plants its feet and keeps both knee hit regions aligned", async () => {
  const { beginTitanStep } = await import("../src/titan-mobility.js"),
    { titanBodyRegions, titanFootPath } = await import(
      "../src/titan-contact.js"
    );
  const { stepTitan } = await import("../src/giganto-simulation.js");
  const r = importedRig(await asset("giganto")),
    s = titanSession({ drain: 0 });
  s.stage = "combat";
  s.emerald = true;
  s.idle = 999;
  s.avatar.x = 50;
  s.avatar.z = 35;
  Object.assign(s.boss, { x: 15, z: -8, yaw: 0.2 });
  beginTitanStep(s);
  for (let i = 0; i < 170; i++) {
    stepTitan(s, {}, 1 / 60);
    updateImportedGiganto(r, s, 1 / 60);
    assert.equal(r.position.x, s.boss.x);
    assert.equal(r.rotation.y, s.boss.yaw);
    if (!s.boss.walk || i % 12) continue;
    for (const side of ["L", "R"]) {
      const foot = r.userData.footBindings
          .get(side)
          .foot.getWorldPosition(new T.Vector3()),
        target = titanFootPath(s, side),
        knee = r.userData.bones["knee" + side].getWorldPosition(
          new T.Vector3(),
        ),
        region = titanBodyRegions(s).find((q) => q.id === side + " shin");
      assert.ok(
        foot.distanceTo(new T.Vector3(target.x, target.y, target.z)) < 0.2,
        `${side} ${i}: ${foot.toArray()} / ${JSON.stringify(target)} hip ${r.userData.bones["leg" + side].getWorldPosition(new T.Vector3()).toArray()}`,
      );
      assert.ok(
        knee.distanceTo(new T.Vector3(region.a.x, region.a.y, region.a.z)) <
          0.3,
        `${side} ${i}: ${knee.toArray()} / ${JSON.stringify(region.a)}`,
      );
    }
  }
  disposeImportedRig(r);
});
