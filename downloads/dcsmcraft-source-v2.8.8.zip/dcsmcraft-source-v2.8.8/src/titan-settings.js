export const ARENA_DEFAULTS = Object.freeze({
  graphicsQuality: "auto",
  masterVolume: null,
  musicVolume: null,
  effectsVolume: 0.75,
  motionBlur: false,
  speedTrails: true,
  cameraShake: 0.35,
  cameraFov: 67,
  cameraSensitivity: 0.0025,
});
export function arenaConfig(raw) {
  const clamp = (k, lo, hi) =>
    Number.isFinite(raw[k])
      ? Math.max(lo, Math.min(hi, raw[k]))
      : ARENA_DEFAULTS[k];
  return {
    graphicsQuality: ["auto", "low", "balanced", "high"].includes(
      raw.graphicsQuality,
    )
      ? raw.graphicsQuality
      : "auto",
    masterVolume: clamp("masterVolume", 0, 1),
    musicVolume: clamp("musicVolume", 0, 1),
    effectsVolume: clamp("effectsVolume", 0, 1),
    cameraShake: clamp("cameraShake", 0, 1),
    cameraFov: clamp("cameraFov", 45, 95),
    cameraSensitivity: clamp("cameraSensitivity", 0.0005, 0.01),
    motionBlur: raw.motionBlur === true,
    speedTrails: raw.speedTrails !== false,
  };
}
export function initializeArenaSettings(config, world) {
  if (config.masterVolume == null) config.masterVolume = world.volume ?? 0.65;
  if (config.musicVolume == null)
    config.musicVolume = world.musicVolume ?? 0.45;
  return config;
}
export function arenaAudioSettings(config, world = {}) {
  return {
    volume: config.masterVolume ?? world.volume ?? 0.65,
    musicVolume: config.musicVolume ?? world.musicVolume ?? 0.45,
    musicEnabled: config.music !== false,
  };
}
export function arenaQuality(config, world = {}) {
  return (
    { low: 1, balanced: 2, high: 3 }[config.graphicsQuality] ||
    world.graphics ||
    2
  );
}
