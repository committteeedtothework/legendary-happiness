// Original vocal synthesis: harmonic/formant bodies, breath, irregular pulse
// envelopes and pitch motion. No recordings or copied game audio.
export const VOICE_PROFILES = {
  zombie: [67, 0.82, 510, 0.47],
  creeper: [152, 0.48, 2300, 0.96],
  spider: [235, 0.32, 2700, 0.72],
  skeleton: [83, 0.28, 1800, 0.78],
  panda: [112, 0.72, 640, 0.24],
  koala: [175, 0.48, 780, 0.4],
  tiger: [64, 0.9, 620, 0.33],
  ash_deer: [260, 0.65, 1080, 0.18],
  cinderback: [52, 0.75, 330, 0.32],
  basalt_crawler: [76, 0.45, 1700, 0.6],
  cinder_wraith: [173, 0.9, 1850, 0.5],
  devin_guardian: [58, 0.85, 590, 0.14],
  iron_golem: [48, 0.58, 340, 0.08],
  cow: [86, 0.82, 480, 0.15],
  woolling: [205, 0.6, 1050, 0.28],
  grazer: [123, 0.36, 650, 0.55],
  chicken: [410, 0.48, 1550, 0.12],
  rabbit: [890, 0.22, 2500, 0.3],
  villager: [124, 0.44, 840, 0.22],
  shade: [59, 0.65, 470, 0.4],
  stalker: [90, 0.53, 1300, 0.7],
  emberling: [132, 0.6, 2100, 0.6],
};
export function voiceSamples(type, rate, variant = 0) {
  const [pitch, duration, formant, breath] = VOICE_PROFILES[type],
    data = new Float32Array(Math.ceil(rate * duration));
  let state = 7177 + variant * 291 + Math.floor(pitch),
    phase = 0,
    low = 0;
  for (let i = 0; i < data.length; i++) {
    const t = i / rate,
      p = t / duration;
    state = (Math.imul(state, 1664525) + 1013904223) | 0;
    const noise = (state >>> 0) / 2147483648 - 1;
    low += 0.12 * (noise - low);
    const modulation =
        1 + 0.035 * Math.sin(t * 37 + variant) + 0.018 * Math.sin(t * 91),
      f =
        pitch *
        (1 + variant * 0.025) *
        (1 + 0.16 * Math.sin(p * Math.PI) - p * 0.22) *
        modulation;
    phase += (2 * Math.PI * f) / rate;
    let body = 0;
    for (let n = 1; n <= 9; n++) {
      const harmonic = n * f,
        weight =
          (0.22 + Math.exp(-(((harmonic - formant) / 500) ** 2))) /
          Math.pow(n, 0.85);
      body += Math.sin(phase * n + Math.sin(t * 11) * 0.12) * weight;
    }
    const pulses =
      type === "chicken" || type === "woolling"
        ? 0.25 + 0.75 * Math.sin(p * Math.PI * 3) ** 2
        : 1;
    const env =
      Math.min(1, t / 0.018, (duration - t) / 0.06) *
      Math.sin(Math.PI * p) ** 0.55;
    data[i] =
      Math.tanh(
        (body * (1 - breath) + (noise - low) * breath * 0.65) * pulses * env,
      ) * 0.65;
  }
  return data;
}
export function createVoiceBank(context) {
  return Object.fromEntries(
    Object.keys(VOICE_PROFILES).map((type) => [
      type,
      Array.from({ length: 3 }, (_, v) => {
        const samples = voiceSamples(type, context.sampleRate, v),
          buffer = context.createBuffer(1, samples.length, context.sampleRate);
        buffer.copyToChannel(samples, 0);
        return buffer;
      }),
    ]),
  );
}
