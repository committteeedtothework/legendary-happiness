import {
  createPistolModel,
  animatePistolModel,
  pistolRecoil,
} from "./pistol-model.js";
import * as THREE from "three";
import { ITEMS } from "./data.js";
import { skinFor } from "./skins.js";
import { createHeldModel } from "./first-person.js";
export function createPlayerModel(skinId, equipment = [], held, atlas) {
  const s = skinFor(skinId),
    root = new THREE.Group(),
    rig = new THREE.Group();
  root.add(rig);
  const materials = {};
  const mat = (color) =>
    (materials[color] ||= new THREE.MeshLambertMaterial({ color }));
  function box(parent, size, pos, color) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), mat(color));
    mesh.position.set(...pos);
    mesh.castShadow = mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  }
  const joint = (pos, size, color) => {
    const g = new THREE.Group();
    g.position.set(...pos);
    rig.add(g);
    box(g, size, [0, -size[1] / 2, 0], color);
    return g;
  };
  const legs = [-1, 1].map((side) =>
    joint([side * 0.115, 0.6, 0], [0.21, 0.6, 0.24], s.trousers),
  );
  legs.forEach((g) =>
    box(g, [0.215, 0.13, 0.27], [0, -0.535, -0.01], "#302e2a"),
  );
  const body = box(
    rig,
    [0.44, 0.7, 0.24],
    [0, 0.95, 0],
    s.style === "dante" ? s.skin : s.shirt,
  );
  box(rig, [0.16, 0.14, 0.16], [0, 1.35, 0], s.skin);
  const arms = [-1, 1].map((side) =>
    joint([side * 0.32, 1.3, 0], [0.18, 0.43, 0.22], s.shirt),
  );
  arms.forEach((g) => box(g, [0.18, 0.18, 0.22], [0, -0.51, 0], s.skin));
  const head = new THREE.Group();
  head.position.y = 1.4;
  rig.add(head);
  box(head, [0.4, 0.4, 0.4], [0, 0.2, 0], s.skin);
  box(head, [0.414, 0.09, 0.414], [0, 0.36, 0], s.hair);
  box(head, [0.08, 0.15, 0.41], [-0.165, 0.26, 0], s.hair);
  for (const x of [-0.09, 0.09])
    box(head, [0.045, 0.045, 0.012], [x, 0.22, -0.205], "#283039");
  box(head, [0.08, 0.02, 0.012], [0, 0.1, -0.205], "#845d4c");
  const coat = [];
  if (s.style === "dante") {
    // Open coat, bare chest, dark harness, silver clasps and fingerless gloves.
    box(rig, [0.45, 0.67, 0.045], [0, 0.97, 0.14], s.shirt);
    for (const side of [-1, 1]) {
      box(rig, [0.075, 0.67, 0.28], [side * 0.202, 0.97, 0], s.shirt);
      const lapel = box(
        rig,
        [0.073, 0.34, 0.035],
        [side * 0.138, 1.14, -0.145],
        "#c0444b",
      );
      lapel.rotation.z = side * -0.24;
      const strap = box(
        rig,
        [0.045, 0.39, 0.025],
        [side * 0.073, 1.105, -0.143],
        "#39323a",
      );
      strap.rotation.z = side * 0.42;
      box(rig, [0.047, 0.035, 0.012], [side * 0.116, 1.21, -0.161], s.accent);
      box(
        arms[side === -1 ? 0 : 1],
        [0.187, 0.115, 0.23],
        [0, -0.49, 0],
        "#272630",
      );
      box(
        legs[side === -1 ? 0 : 1],
        [0.218, 0.24, 0.255],
        [0, -0.47, 0],
        "#24232a",
      );
      box(
        legs[side === -1 ? 0 : 1],
        [0.223, 0.026, 0.261],
        [0, -0.39, 0],
        s.accent,
      );
      const tail = new THREE.Group();
      tail.position.set(side * 0.125, 0.78, 0.145);
      rig.add(tail);
      box(tail, [0.225, 0.62, 0.035], [0, -0.31, 0], s.shirt);
      box(tail, [0.035, 0.61, 0.27], [side * 0.103, -0.305, -0.12], s.shirt);
      box(tail, [0.02, 0.6, 0.039], [side * 0.102, -0.31, 0], "#6f1e30");
      coat.push(tail);
      const fringe = box(
        head,
        [0.12, 0.15, 0.045],
        [side * 0.105, 0.31, -0.22],
        s.hair,
      );
      fringe.rotation.z = side * -0.36;
      box(head, [0.065, 0.16, 0.24], [side * 0.18, 0.255, 0.06], s.hair);
    }
    box(rig, [0.45, 0.07, 0.255], [0, 0.685, 0], "#282630");
    box(rig, [0.085, 0.06, 0.018], [0, 0.685, -0.14], s.accent);
    box(rig, [0.14, 0.015, 0.012], [0, 1.055, -0.127], "#c69b83");
    box(head, [0.075, 0.016, 0.016], [0.025, 0.105, -0.218], "#86574d");
    box(head, [0.025, 0.018, 0.016], [0.07, 0.12, -0.218], "#86574d");
  } else if (s.style === "devin") {
    box(rig, [0.45, 0.18, 0.25], [0, 0.58, 0], s.shirt);
    box(rig, [0.452, 0.075, 0.257], [0, 0.75, 0], "#624532");
    box(rig, [0.09, 0.09, 0.025], [0, 0.75, -0.145], s.accent);
    for (const side of [-1, 1]) {
      const collar = box(
        rig,
        [0.11, 0.17, 0.025],
        [side * 0.065, 1.19, -0.135],
        "#e1d5b8",
      );
      collar.rotation.z = side * 0.4;
      box(rig, [0.028, 0.51, 0.026], [side * 0.195, 0.98, -0.135], s.accent);
    }
    // Two stepped pixels give the mouth a clearly asymmetric, friendly smirk.
    box(head, [0.07, 0.016, 0.014], [0.025, 0.1, -0.217], "#69402e");
    box(head, [0.025, 0.018, 0.014], [0.069, 0.118, -0.217], "#69402e");
  } else if (s.style === "astronaut") {
    box(head, [0.44, 0.08, 0.44], [0, 0.43, 0], s.shirt);
    box(head, [0.405, 0.19, 0.03], [0, 0.23, -0.222], "#243a52");
    box(head, [0.13, 0.025, 0.015], [-0.075, 0.28, -0.242], s.accent);
    box(rig, [0.25, 0.22, 0.03], [0, 1.03, -0.14], "#43536a");
    box(rig, [0.36, 0.48, 0.18], [0, 0.99, 0.2], s.shirt);
  } else if (s.style === "ranger") {
    box(head, [0.44, 0.1, 0.44], [0, 0.42, 0], s.shirt);
    for (const side of [-1, 1])
      box(head, [0.055, 0.3, 0.43], [side * 0.212, 0.25, 0], s.shirt);
    box(rig, [0.38, 0.52, 0.028], [0, 0.95, 0.15], "#394d38");
    const strap = box(rig, [0.065, 0.7, 0.026], [0, 0.97, -0.14], s.accent);
    strap.rotation.z = 0.48;
    box(rig, [0.15, 0.22, 0.1], [0.2, 0.77, -0.12], "#79553e");
  } else if (s.style === "smith") {
    box(rig, [0.32, 0.55, 0.03], [0, 0.88, -0.14], "#a46b42");
    for (const side of [-1, 1]) {
      box(head, [0.11, 0.09, 0.025], [side * 0.1, 0.23, -0.222], s.accent);
      box(head, [0.065, 0.05, 0.026], [side * 0.1, 0.23, -0.24], "#25364a");
    }
  } else if (s.style === "sailor") {
    for (const y of [0.86, 1, 1.14])
      box(rig, [0.445, 0.045, 0.248], [0, y, 0], "#d5ddd2");
    box(rig, [0.45, 0.08, 0.255], [0, 0.74, 0], s.accent);
  } else if (s.style === "clown") {
    box(head, [0.075, 0.06, 0.045], [0, 0.17, -0.225], "#d94341");
    for (const side of [-1, 1])
      box(head, [0.09, 0.16, 0.3], [side * 0.23, 0.22, 0], s.hair);
    for (const [x, y] of [
      [-0.1, 1.04],
      [0.1, 0.86],
      [-0.08, 0.7],
    ])
      box(rig, [0.08, 0.08, 0.015], [x, y, -0.128], s.accent);
    box(rig, [0.29, 0.08, 0.03], [0, 1.18, -0.14], s.accent);
  } else if (s.style === "bandit") {
    for (const y of [0.72, 0.86, 1, 1.14])
      box(rig, [0.442, 0.055, 0.244], [0, y, 0], "#494652");
    box(head, [0.402, 0.07, 0.015], [0, 0.22, -0.21], "#494652");
    for (const x of [-0.09, 0.09])
      box(head, [0.045, 0.035, 0.012], [x, 0.22, -0.222], "#e4dccc");
    arms.forEach((g) => box(g, [0.183, 0.1, 0.224], [0, -0.55, 0], "#37343b"));
  } else {
    box(rig, [0.09, 0.35, 0.025], [0, 0.96, -0.133], s.accent);
    if (s.style === "hero") {
      box(rig, [0.2, 0.13, 0.03], [0, 1.05, -0.15], s.accent).rotation.z =
        Math.PI / 4;
      box(rig, [0.43, 0.55, 0.03], [0, 0.93, 0.145], "#913c47");
    }
  }
  // Armor follows each articulated body part rather than floating beside it.
  equipment.forEach((stack, slot) => {
    const i = ITEMS[stack?.id];
    if (i?.armorSlot !== slot) return;
    if (stack.id.startsWith("hellfire_")) {
      if (slot === 0)
        box(head, [0.08, 0.28, 0.03], [0, 0.3, -0.235], "#ffd093");
      if (slot === 1) {
        box(rig, [0.14, 0.31, 0.025], [0, 1, -0.155], "#533442");
        box(rig, [0.06, 0.18, 0.025], [0, 1, -0.17], "#ffd093");
      }
    }
    if (slot === 0) {
      box(head, [0.43, 0.15, 0.43], [0, 0.35, 0], i.color);
      box(head, [0.07, 0.28, 0.42], [-0.185, 0.21, 0.015], i.color);
      box(head, [0.07, 0.28, 0.42], [0.185, 0.21, 0.015], i.color);
    }
    if (slot === 1) {
      box(rig, [0.47, 0.69, 0.28], [0, 0.96, 0], i.color);
      arms.forEach((g) => box(g, [0.21, 0.2, 0.25], [0, -0.1, 0], i.color));
    }
    if (slot === 2)
      legs.forEach((g) => box(g, [0.225, 0.42, 0.26], [0, -0.2, 0], i.color));
    if (slot === 3)
      legs.forEach((g) =>
        box(g, [0.235, 0.2, 0.29], [0, -0.5, -0.01], i.color),
      );
  });
  const grip = new THREE.Group();
  const blockHeld = ITEMS[held]?.block !== undefined;
  grip.position.set(0, -0.53, blockHeld ? -0.02 : -0.07);
  grip.rotation.x = blockHeld ? -0.1 : -0.85;
  arms[1].add(grip);
  const heldModel = createHeldModel(held, atlas);
  if (heldModel) {
    heldModel.scale.setScalar(1.1);
    grip.add(heldModel);
  }
  const leftGrip = new THREE.Group();
  if (held === "matthew_dual_pistols") {
    leftGrip.position.copy(grip.position);
    leftGrip.rotation.copy(grip.rotation);
    const left = createPistolModel(true);
    left.scale.setScalar(1.1);
    leftGrip.add(left);
    arms[0].add(leftGrip);
  }
  root.userData = {
    coat,
    leftGrip,
    rig,
    head,
    arms,
    legs,
    body,
    grip,
    skin: skinId,
    heldKind:
      ITEMS[held]?.tool ||
      (ITEMS[held]?.block !== undefined ? "block" : "item"),
  };
  return root;
}
export function animatePlayerModel(
  model,
  p,
  dt,
  moving,
  action = 0,
  actionKind = "attack",
  pistolRemaining = 0,
  pistolEffects = true,
) {
  const u = model.userData;
  u.stride = (u.stride || 0) + (moving ? dt * (p.sprinting ? 14 : 9) : 0);
  const alpha = 1 - Math.exp(-14 * dt),
    gait = moving ? (p.sprinting ? 0.65 : 0.4) : 0;
  u.gait = (u.gait || 0) + (gait - (u.gait || 0)) * alpha;
  u.legs.forEach(
    (g, i) => (g.rotation.x = Math.sin(u.stride + i * Math.PI) * u.gait),
  );
  u.arms.forEach((g, i) => {
    g.rotation.x =
      -Math.sin(u.stride + i * Math.PI) * u.gait * 0.8 +
      (i === 1 ? -action * 1.6 : 0);
  });
  const use = actionKind === "eat" || actionKind === "use";
  const thrust = u.heldKind === "spear";
  const swimming = p.inWater && !p.onGround;
  u.arms.forEach((arm, i) => {
    arm.rotation.z = 0;
    arm.rotation.y = 0;
    if (swimming) arm.rotation.x = Math.sin(u.stride + i * Math.PI) * 0.6 + 1.5;
    else if (!p.onGround && !p.flying) arm.rotation.z = (i ? 1 : -1) * 0.12;
    if (i === 1 && action > 0) {
      arm.rotation.x = use
        ? action * 2.0
        : thrust
          ? action * 1.45
          : action * (actionKind === "place" ? 1.25 : 1.8);
      arm.rotation.y = use ? 0 : thrust ? -action * 0.15 : -action * 0.5;
      arm.rotation.z = use ? -action * 0.2 : thrust ? 0 : action * 0.5;
    }
  });
  u.body.rotation.z =
    actionKind === "attack" ? Math.sin(action * Math.PI) * 0.035 : 0;
  u.grip.rotation.x =
    u.heldKind === "block"
      ? -0.1
      : thrust
        ? -1.4 - u.arms[1].rotation.x
        : (use ? -1.05 : -0.85) - u.arms[1].rotation.x * 0.65;
  if (u.heldKind === "pistols") {
    const kick = pistolRecoil(pistolRemaining).kick;
    u.carry =
      (u.carry || 0) +
      ((p.sprinting && moving && pistolRemaining <= 0 ? 1 : 0) -
        (u.carry || 0)) *
        alpha;
    u.arms.forEach((arm, i) => {
      const firing = i === (p.matthewHand || 0) ? kick : 0;
      arm.rotation.x = 1.3 + p.pitch * 0.6 + firing * 0.24 - u.carry * 0.65;
      arm.rotation.y = (i ? -1 : 1) * (0.07 + u.carry * 0.18);
      arm.rotation.z = (i ? 1 : -1) * (firing * 0.035 + u.carry * 0.12);
    });
    u.grip.rotation.x = u.leftGrip.rotation.x = -1.3 + p.pitch * 0.4;
    animatePistolModel(
      u.grip.children[0],
      p.matthewHand === 1 ? pistolRemaining : 0,
      pistolEffects,
    );
    animatePistolModel(
      u.leftGrip.children[0],
      p.matthewHand === 1 ? 0 : pistolRemaining,
      pistolEffects,
    );
  }
  u.coat?.forEach((tail, i) => {
    const target =
      (moving ? 0.12 : 0) +
      Math.abs(Math.sin(u.stride + i * 0.5)) * u.gait * 0.2 +
      Math.min(0.2, Math.abs(p.vy || 0) * 0.012);
    tail.rotation.x += (-target - tail.rotation.x) * alpha;
    tail.rotation.z = (i ? 1 : -1) * (0.035 + u.gait * 0.08);
  });
  u.head.rotation.x = p.pitch;
  u.rig.rotation.x = p.crouching ? 0.18 : 0;
  u.rig.position.y = p.crouching ? -0.25 : 0;
}
