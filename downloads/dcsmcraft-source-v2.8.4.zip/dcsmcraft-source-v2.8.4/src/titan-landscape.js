import * as T from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { TITAN_RING_TRAILS } from "./giganto-simulation.js";
const clamp = T.MathUtils.clamp;
function hash(x, y) {
  const n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return n - Math.floor(n);
}
function noise(x, y) {
  const a = Math.floor(x),
    b = Math.floor(y),
    u = x - a,
    v = y - b,
    s = u * u * (3 - 2 * u),
    t = v * v * (3 - 2 * v);
  return T.MathUtils.lerp(
    T.MathUtils.lerp(hash(a, b), hash(a + 1, b), s),
    T.MathUtils.lerp(hash(a, b + 1), hash(a + 1, b + 1), s),
    t,
  );
}
function fbm(x, y) {
  return (
    noise(x, y) * 0.56 +
    noise(x * 2.03, y * 2.03) * 0.27 +
    noise(x * 4.07, y * 4.07) * 0.12 +
    noise(x * 8.1, y * 8.1) * 0.05
  );
}
function surface(kind) {
  const size = 256,
    color = new Uint8Array(size * size * 4),
    normal = new Uint8Array(size * size * 4),
    heights = new Float32Array(size * size);
  const palette =
    kind === "rock"
      ? [
          [61, 67, 65],
          [145, 145, 127],
        ]
      : kind === "soil"
        ? [
            [67, 61, 44],
            [157, 143, 103],
          ]
        : [
            [32, 55, 27],
            [104, 127, 63],
          ];
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) {
      const p = (x + y * size) * 4,
        fine = hash(x + 17, y + 41),
        u = x / (size - 1),
        v = y / (size - 1),
        su = u * u * (3 - 2 * u),
        sv = v * v * (3 - 2 * v),
        n = T.MathUtils.lerp(
          T.MathUtils.lerp(
            fbm(x / 25, y / 25),
            fbm((x - size + 1) / 25, y / 25),
            su,
          ),
          T.MathUtils.lerp(
            fbm(x / 25, (y - size + 1) / 25),
            fbm((x - size + 1) / 25, (y - size + 1) / 25),
            su,
          ),
          sv,
        ),
        f = clamp(n * 0.8 + fine * 0.2, 0, 1);
      heights[x + y * size] =
        kind === "rock" ? n * 0.8 + fine * 0.2 : n * 0.3 + fine * 0.7;
      for (let c = 0; c < 3; c++)
        color[p + c] = palette[0][c] + (palette[1][c] - palette[0][c]) * f;
      color[p + 3] = 255;
    }
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) {
      const h = (a, b) =>
          heights[((a + size) % size) + ((b + size) % size) * size],
        nx = (h(x - 1, y) - h(x + 1, y)) * 1.2,
        ny = (h(x, y - 1) - h(x, y + 1)) * 1.2,
        l = Math.hypot(nx, ny, 1),
        i = (x + y * size) * 4;
      normal.set(
        [
          ((nx / l) * 0.5 + 0.5) * 255,
          ((ny / l) * 0.5 + 0.5) * 255,
          ((1 / l) * 0.5 + 0.5) * 255,
          255,
        ],
        i,
      );
    }
  const make = (data, srgb) => {
    const tex = new T.DataTexture(data, size, size);
    tex.wrapS = tex.wrapT = T.RepeatWrapping;
    tex.magFilter = T.LinearFilter;
    tex.minFilter = T.LinearMipmapLinearFilter;
    tex.generateMipmaps = true;
    tex.colorSpace = srgb ? T.SRGBColorSpace : T.NoColorSpace;
    tex.needsUpdate = true;
    return tex;
  };
  return { map: make(color, true), normalMap: make(normal, false) };
}
function rimHeight(x, z) {
  const rr = Math.hypot(x, z);
  if (rr <= 186) return 0;
  const a = Math.atan2(x, z),
    f = fbm(Math.sin(a) * 3 + 9, Math.cos(a) * 3 + 9);
  if (rr < 195) return Math.pow((rr - 186) / 9, 0.78) * (57 + f * 60) - 1;
  const t = Math.min(1, (rr - 195) / 285);
  return 56 + f * 60 + Math.sin(t * Math.PI) * (37 + f * 70);
}
export function makeTitanLandscape(route, quality = 2) {
  const root = new T.Group();
  root.name = "Kronos-inspired highland basin";
  const textures = [],
    materials = [],
    anim = [];
  function material(kind, repeat = 1) {
    const maps = surface(kind);
    for (const tex of Object.values(maps)) {
      tex.repeat.set(repeat, repeat);
      textures.push(tex);
    }
    const m = new T.MeshStandardMaterial({
      ...maps,
      roughness: kind === "rock" ? 0.91 : 1,
      normalScale: new T.Vector2(0.55, 0.55),
    });
    materials.push(m);
    return m;
  }
  const grassMat = material("grass", 90),
    rockMat = material("rock", 12),
    stoneMat = material("rock", 1.2),
    soilMat = material("soil", 45);
  const floorGeo = new T.PlaneGeometry(370, 370, 92, 92);
  floorGeo.rotateX(-Math.PI / 2);
  const fc = [],
    fp = floorGeo.attributes.position;
  for (let i = 0; i < fp.count; i++) {
    const n = fbm(fp.getX(i) / 27 + 30, fp.getZ(i) / 27 + 30),
      v = 0.75 + n * 0.5;
    fc.push(v * 0.97, v, v * 0.92);
  }
  floorGeo.setAttribute("color", new T.Float32BufferAttribute(fc, 3));
  grassMat.vertexColors = true;
  const floor = new T.Mesh(floorGeo, grassMat);
  floor.receiveShadow = true;
  root.add(floor);
  // Continuous, densely tessellated cliff strata; the entire walkable floor
  // remains flat and clear. Relief starts beyond the simulation's 175 m limit.
  const angular = 240,
    layers = 22,
    positions = [],
    uv = [],
    colors = [],
    indices = [];
  for (let r = 0; r <= layers; r++)
    for (let i = 0; i <= angular; i++) {
      const a = (i / angular) * Math.PI * 2,
        t = r / layers,
        f = fbm(Math.sin(a) * 3 + 9, Math.cos(a) * 3 + 9),
        rr =
          186 +
          Math.min(t / 0.32, 1) * 9 +
          (Math.max(0, t - 0.32) / 0.68) * 285;
      const h =
        t < 0.32
          ? Math.pow(t / 0.32, 0.78) * (57 + f * 60)
          : 57 +
            f * 60 +
            Math.sin(((t - 0.32) / 0.68) * Math.PI) * (37 + f * 70);
      const x = Math.sin(a) * rr,
        z = Math.cos(a) * rr,
        y = h + Math.sin(a * 29 + t * 22) * Math.sin(t * Math.PI) * 2;
      positions.push(x, y - 1, z);
      uv.push((i / angular) * 4, t * 3);
      const moss = clamp((Math.abs(Math.cos(t * 4 + a * 3)) - 0.55) * 2, 0, 1),
        shade = 0.62 + f * 0.38;
      colors.push(shade * (1 - moss * 0.18), shade, shade * (1 - moss * 0.28));
      if (r < layers && i < angular) {
        const k = r * (angular + 1) + i;
        indices.push(
          k,
          k + angular + 1,
          k + 1,
          k + 1,
          k + angular + 1,
          k + angular + 2,
        );
      }
    }
  const geo = new T.BufferGeometry();
  geo.setAttribute("position", new T.Float32BufferAttribute(positions, 3));
  geo.setAttribute("uv", new T.Float32BufferAttribute(uv, 2));
  geo.setAttribute("color", new T.Float32BufferAttribute(colors, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  const cliffMat = rockMat.clone();
  cliffMat.vertexColors = true;
  cliffMat.side = T.DoubleSide;
  cliffMat.normalScale.set(0.2, 0.2);
  cliffMat.onBeforeCompile = (shader) => {
    shader.vertexShader =
      "varying vec3 cliffWorld;varying vec3 cliffNormal;\n" +
      shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace(
      "#include <worldpos_vertex>",
      "#include <worldpos_vertex>\n cliffWorld=(modelMatrix*vec4(transformed,1.)).xyz;cliffNormal=normalize(mat3(modelMatrix)*objectNormal);",
    );
    shader.fragmentShader =
      "varying vec3 cliffWorld;varying vec3 cliffNormal;\n" +
      shader.fragmentShader;
    shader.fragmentShader = shader.fragmentShader.replace(
      "#include <map_fragment>",
      `#ifdef USE_MAP
      vec3 w=pow(abs(cliffNormal),vec3(4.));w/=max(.001,w.x+w.y+w.z);
      vec3 stone=texture2D(map,cliffWorld.yz*.17).rgb*w.x+texture2D(map,cliffWorld.xz*.17).rgb*w.y+texture2D(map,cliffWorld.xy*.17).rgb*w.z;
      diffuseColor.rgb*=stone;
    #endif`,
    );
  };
  materials.push(cliffMat);
  const cliffs = new T.Mesh(geo, cliffMat);
  cliffs.receiveShadow = true;
  root.add(cliffs);
  // Distant reflective ribbon is scenery outside movement bounds.
  const riverGeo = new T.PlaneGeometry(13, 360, 1, 48);
  riverGeo.rotateX(-Math.PI / 2);
  const rv = riverGeo.attributes.position;
  for (let i = 0; i < rv.count; i++) {
    rv.setX(i, rv.getX(i) + 168 + Math.sin(rv.getZ(i) * 0.021) * 7);
    rv.setY(i, 0.05);
  }
  riverGeo.computeVertexNormals();
  const river = new T.Mesh(
    riverGeo,
    new T.MeshStandardMaterial({
      color: "#587b82",
      roughness: 0.22,
      metalness: 0.45,
      transparent: true,
      opacity: 0.72,
    }),
  );
  river.position.x = 0;
  root.add(river);
  materials.push(river.material);
  // Smooth eroded boulders are batched. Their silhouette avoids regular cones
  // and pyramids; none obstructs the playable floor or aerial body boundary.
  const boulderGeo = new T.IcosahedronGeometry(1, 2),
    bp = boulderGeo.attributes.position;
  for (let i = 0; i < bp.count; i++) {
    const x = bp.getX(i),
      y = bp.getY(i),
      z = bp.getZ(i),
      k = 0.85 + fbm(x * 2 + 2, z * 2 + 7) * 0.3;
    bp.setXYZ(i, x * k, y * (0.8 + noise(x + 3, z + 8) * 0.3), z * k);
  }
  const bn = boulderGeo.attributes.normal;
  for (let i = 0; i < bp.count; i++) {
    const x = bp.getX(i),
      y = bp.getY(i),
      z = bp.getZ(i),
      l = Math.hypot(x, y, z);
    bn.setXYZ(i, x / l, y / l, z / l);
  }
  const boulders = new T.InstancedMesh(boulderGeo, stoneMat, 110),
    dummy = new T.Object3D();
  for (let i = 0; i < 110; i++) {
    const a = i * 2.399963,
      rr = i < 35 ? 179 + hash(i, 12) * 6 : 235 + hash(i, 12) * 135,
      k = 3 + hash(i, 5) * 8;
    dummy.position.set(
      Math.sin(a) * rr,
      rimHeight(Math.sin(a) * rr, Math.cos(a) * rr) + k * 0.3,
      Math.cos(a) * rr,
    );
    dummy.rotation.set(hash(i, 8), a, hash(i, 1));
    dummy.scale.set(k, k * 0.8, k * (0.8 + hash(i, 7)));
    dummy.updateMatrix();
    boulders.setMatrixAt(i, dummy.matrix);
  }
  boulders.receiveShadow = true;
  root.add(boulders);
  const debris = new T.InstancedMesh(boulderGeo, stoneMat, 28);
  debris.frustumCulled = false;
  root.add(debris);
  // A layered forest uses shared smooth crown geometry and textured bark.
  const leafData = new Uint8Array(128 * 128 * 4);
  for (let y = 0; y < 128; y++)
    for (let x = 0; x < 128; x++) {
      const dx = (x - 63.5) / 63.5,
        dy = (y - 63.5) / 63.5,
        n = noise(x * 0.19, y * 0.19),
        a = clamp(
          (1 - Math.hypot(dx, dy) * 0.78) * 1.8 - (n > 0.6 ? 0.9 : 0),
          0,
          1,
        ),
        i = (x + y * 128) * 4;
      leafData.set([64 + n * 80, 87 + n * 74, 39 + n * 42, a * 255], i);
    }
  const leaves = new T.DataTexture(leafData, 128, 128);
  leaves.colorSpace = T.SRGBColorSpace;
  leaves.magFilter = T.LinearFilter;
  leaves.minFilter = T.LinearMipmapLinearFilter;
  leaves.generateMipmaps = true;
  leaves.needsUpdate = true;
  textures.push(leaves);
  const trunks = new T.InstancedMesh(
      new T.CylinderGeometry(0.45, 0.8, 1, 8),
      soilMat,
      260,
    ),
    crowns = new T.InstancedMesh(
      new T.IcosahedronGeometry(1, 1),
      new T.MeshStandardMaterial({
        map: leaves,
        color: "#ffffff",
        alphaTest: 0.5,
        side: T.DoubleSide,
        roughness: 1,
      }),
      1040,
    );
  materials.push(crowns.material);
  for (let i = 0; i < 260; i++) {
    const a = i * 2.399963,
      rr = 235 + hash(i, 21) * 145,
      x = Math.sin(a) * rr,
      z = Math.cos(a) * rr,
      h = 8 + hash(i, 3) * 14;
    dummy.position.set(x, rimHeight(x, z) + h * 0.5, z);
    dummy.rotation.set(0, a, 0);
    dummy.scale.set(1, h, 1);
    dummy.updateMatrix();
    trunks.setMatrixAt(i, dummy.matrix);
    for (let j = 0; j < 4; j++) {
      dummy.position.set(
        x + Math.sin(j * 2.4) * h * 0.15,
        rimHeight(x, z) + h * 0.75 + j * h * 0.12,
        z + Math.cos(j * 2.4) * h * 0.15,
      );
      dummy.scale.set(h * 0.26, h * 0.27, h * 0.23);
      dummy.rotation.set(0.2 * j, a + j, 0.14);
      dummy.updateMatrix();
      crowns.setMatrixAt(i * 4 + j, dummy.matrix);
      const shade = 0.8 + hash(i, j) * 0.35;
      crowns.setColorAt(i * 4 + j, new T.Color(shade, shade, shade));
    }
  }
  root.add(trunks, crowns);
  const blade = new T.BufferGeometry();
  blade.setAttribute(
    "position",
    new T.Float32BufferAttribute([-0.13, 0, 0, 0.13, 0, 0, 0.02, 0.7, 0.08], 3),
  );
  blade.setAttribute(
    "normal",
    new T.Float32BufferAttribute([0, 0, 1, 0, 0, 1, 0, 0, 1], 3),
  );
  const bladeMat = new T.MeshStandardMaterial({
    color: "#75884d",
    side: T.DoubleSide,
    roughness: 1,
  });
  materials.push(bladeMat);
  bladeMat.onBeforeCompile = (shader) => {
    shader.uniforms.titanWind = { value: 0 };
    anim.push(shader.uniforms.titanWind);
    shader.vertexShader = "uniform float titanWind;\n" + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace(
      "#include <begin_vertex>",
      "#include <begin_vertex>\n transformed.x += sin(titanWind*1.7+instanceMatrix[3].x*.17+instanceMatrix[3].z*.1)*position.y*.12;",
    );
  };
  const blades = new T.InstancedMesh(blade, bladeMat, 9000);
  blades.frustumCulled = false;
  for (let i = 0; i < 9000; i++) {
    const a = i * 2.399963,
      rr = Math.sqrt(hash(i, 61)) * 173;
    dummy.position.set(Math.sin(a) * rr, 0, Math.cos(a) * rr);
    dummy.rotation.set(0, i * 1.234, 0);
    dummy.scale.setScalar(0.6 + hash(i, 71));
    dummy.updateMatrix();
    blades.setMatrixAt(i, dummy.matrix);
    blades.setColorAt(
      i,
      new T.Color().setHSL(
        0.22 + hash(i, 2) * 0.07,
        0.3,
        0.2 + hash(i, 3) * 0.1,
      ),
    );
  }
  root.add(blades);
  const stones = [];
  for (const p of route.slice(1)) {
    const g = new T.BoxGeometry(p.w, 1.5, p.w, 2, 1, 2);
    g.translate(p.x, p.y - 0.75, p.z);
    stones.push(g);
  }
  const platforms = new T.Mesh(mergeGeometries(stones), stoneMat);
  stones.forEach((g) => g.dispose());
  platforms.receiveShadow = true;
  root.add(platforms);
  const rings = [];
  for (const p of route) {
    const m = new T.Mesh(
      new T.TorusGeometry(2.5, 0.055, 6, 48),
      new T.MeshBasicMaterial({
        color: "#abc9bc",
        transparent: true,
        opacity: 0.55,
      }),
    );
    m.rotation.x = -Math.PI / 2;
    m.position.set(p.x, p.y + 0.08, p.z);
    root.add(m);
    rings.push(m);
    materials.push(m.material);
  }
  const ringMesh = new T.InstancedMesh(
    new T.TorusGeometry(0.48, 0.12, 8, 20),
    new T.MeshStandardMaterial({
      color: "#f6ca58",
      metalness: 0.8,
      roughness: 0.22,
      emissive: "#513b0b",
      emissiveIntensity: 0.5,
    }),
    TITAN_RING_TRAILS.length * 10,
  );
  root.add(ringMesh);
  materials.push(ringMesh.material);
  ringMesh.frustumCulled = false;
  const glow = new T.Mesh(
    new T.CircleGeometry(8, 40),
    new T.MeshBasicMaterial({
      color: "#1b2116",
      transparent: true,
      opacity: 0.16,
      depthWrite: false,
    }),
  );
  glow.rotation.x = -Math.PI / 2;
  glow.position.y = 0.018;
  root.add(glow);
  materials.push(glow.material);
  root.userData = {
    platforms,
    rings,
    ringMesh,
    debris,
    blades,
    textures,
    materials,
    anim,
    quality,
  };
  updateTitanLandscape(
    root,
    {
      stage: "intro",
      ringPickups: [],
      time: 0,
      avatar: { y: 0 },
      config: { particles: true },
    },
    0,
  );
  return root;
}
export function updateTitanLandscape(root, s, dt) {
  const u = root.userData,
    t = s.time || 0,
    dummy = new T.Object3D(),
    picked = new Set(s.ringPickups || []);
  for (const uniform of u.anim) uniform.value = t;
  u.blades.visible = s.avatar.y < 28;
  u.blades.count = u.quality >= 3 ? 9000 : u.quality >= 2 ? 6000 : 2800;
  u.ringMesh.visible = ["intro", "traversal"].includes(s.stage);
  if (u.ringMesh.visible) {
    for (const r of TITAN_RING_TRAILS)
      for (let i = 0; i < 10; i++) {
        dummy.position.set(
          r.x + (i - 4.5) * 0.64,
          r.y + Math.sin(i * 0.6 + t * 2) * 0.12,
          r.z + Math.sin(i * 0.6) * 0.6,
        );
        dummy.rotation.set(0, t * 1.4 + i * 0.11, 0);
        dummy.scale.setScalar(picked.has(r.id) ? 0 : 1);
        dummy.updateMatrix();
        u.ringMesh.setMatrixAt(r.id * 10 + i, dummy.matrix);
      }
  }
  u.ringMesh.instanceMatrix.needsUpdate = true;
  u.debris.visible = s.config.particles && s.phase === 2;
  for (let i = 0; i < 28; i++) {
    const a = i * 2.399963 + t * 0.012,
      rr = 146 + hash(i, 29) * 15,
      k = 2 + hash(i, 72) * 5;
    dummy.position.set(
      Math.sin(a) * rr,
      40 + hash(i, 14) * 95 + Math.sin(t * 0.25 + i) * 3,
      Math.cos(a) * rr,
    );
    dummy.rotation.set(t * 0.08 + i, a, t * 0.1);
    dummy.scale.set(k, k * 0.7, k * 0.9);
    dummy.updateMatrix();
    u.debris.setMatrixAt(i, dummy.matrix);
  }
  u.debris.instanceMatrix.needsUpdate = true;
}
export function disposeTitanLandscape(root) {
  for (const tex of root.userData.textures || []) tex.dispose();
}
