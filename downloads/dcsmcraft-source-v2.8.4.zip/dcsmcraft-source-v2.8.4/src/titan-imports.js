import { performTitanSonic, performTitanBoss } from "./titan-kinematics.js";
import * as T from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { clone as cloneSkeleton } from "three/addons/utils/SkeletonUtils.js";
import { TITAN_GLB_DATA } from "./titan-model-data.js";
import { TITAN_MOVES } from "./giganto-simulation.js";
let pending;
function bytes(base64) {
  const s = atob(base64),
    b = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i);
  return b.buffer;
}
export async function prepareTitanModels() {
  if (!pending)
    pending = Promise.all(
      ["sonic", "giganto"].map(async (role) => {
        const loader = new GLTFLoader();
        loader.setCrossOrigin("anonymous");
        // All buffers and WebP images are embedded. No CDN or decoder request.
        const gltf = await loader.parseAsync(
          bytes(TITAN_GLB_DATA[role].base64),
          "",
        );
        const metadata = gltf.parser.json.extras?.dcsmRig;
        if (!metadata || metadata.role !== role)
          throw Error("Imported Titan rig metadata is missing: " + role);
        const required =
          role === "sonic"
            ? [
                "idle",
                "move",
                "run",
                "boost",
                "jump",
                "fly",
                "parry",
                "transform",
                "attack",
                "damage",
                "defeat",
              ]
            : [
                "idle",
                "arm_swing",
                "arm_slap",
                "grab",
                "beam_fire",
                "defeat",
                "dorsal_extend",
              ];
        for (const name of required)
          if (!gltf.animations.some((a) => a.name === name))
            throw Error(role + " is missing animation " + name);
        for (const name of Object.values(metadata.bones))
          if (!gltf.scene.getObjectByName(name))
            throw Error(role + " is missing joint " + name);
        let superMaterial;
        if (role === "sonic")
          superMaterial = await gltf.parser.getDependency(
            "material",
            gltf.parser.json.extras.dcsmSuperMaterial,
          );
        gltf.scene.traverse((o) => {
          if (o.geometry) o.geometry.userData.dcsmShared = true;
        });
        return { role, gltf, metadata, superMaterial };
      }),
    ).catch((e) => {
      pending = null;
      throw e;
    });
  return pending;
}
export function importedRig(asset) {
  const root = new T.Group(),
    model = cloneSkeleton(asset.gltf.scene),
    materials = new Map();
  root.name = "Imported " + asset.role;
  root.add(model);
  model.traverse((o) => {
    if (o.isMesh) {
      o.material = Array.isArray(o.material)
        ? o.material.map(copy)
        : copy(o.material);
      o.castShadow = o.receiveShadow = true;
      o.frustumCulled = false;
    }
  });
  function copy(m) {
    if (!materials.has(m)) materials.set(m, m.clone());
    return materials.get(m);
  }
  const meta = asset.metadata,
    bones = Object.fromEntries(
      Object.entries(meta.bones).map(([key, name]) => [
        key,
        model.getObjectByName(name),
      ]),
    );
  const mixer = new T.AnimationMixer(model),
    actions = new Map(
      asset.gltf.animations.map((clip) => {
        const action = mixer.clipAction(clip);
        action.setLoop(
          meta.clips[clip.name]?.loop ? T.LoopRepeat : T.LoopOnce,
          Infinity,
        );
        action.clampWhenFinished = true;
        return [clip.name, action];
      }),
    );
  const superMat = asset.superMaterial?.clone();
  root.userData = {
    imported: true,
    role: asset.role,
    model,
    bones,
    materials: [...materials.values(), ...(superMat ? [superMat] : [])],
    mixer,
    actions,
    metadata: meta,
    super: false,
    superMaterial: superMat,
    blueMaterials: [],
    rods: (meta.rods || []).map((name) => model.getObjectByName(name)),
    laserSockets: Array.from({ length: 10 }, (_, i) =>
      model.getObjectByName("socket_dorsal_" + String(i + 1).padStart(2, "0")),
    ),
    jawSocket: model.getObjectByName("socket_mouth"),
    quills: (meta.quills || []).map((name) => model.getObjectByName(name)),
    lastAttack: "idle",
  };
  if (asset.role === "sonic")
    model.traverse((o) => {
      if (o.isMesh) root.userData.blueMaterials.push([o, o.material]);
    });
  return root;
}
function actionAt(u, name, time, dt, layer = "body") {
  const action = u.actions.get(name);
  if (!action) throw Error("Missing imported clip " + name);
  const previous = u[layer];
  if (previous !== action) {
    action.reset().play();
    action.setEffectiveWeight(1);
    action.setEffectiveTimeScale(0);
    if (previous) {
      const blend = /attack|counter|boom|rush|dodge/.test(name) ? 0.055 : 0.17;
      previous.fadeOut(blend);
      action.fadeIn(blend);
    }
    u[layer] = action;
  }
  const duration = action.getClip().duration,
    loop = u.metadata.clips[name]?.loop;
  action.paused = false;
  action.enabled = true;
  action.time = loop
    ? ((Math.max(0, time) % duration) + duration) % duration
    : Math.max(0, Math.min(duration - 1e-6, time));
  return action;
}
export function updateImportedSonic(root, s, dt) {
  const u = root.userData,
    p = s.avatar,
    speed = Math.hypot(p.vx, p.vz),
    gold = s.emerald && !["intro", "traversal"].includes(s.stage);
  root.position.set(p.x, p.y + 0.12, p.z);
  root.rotation.z = 0;
  let facing = p.yaw + Math.PI;
  if (!gold && speed > 1) facing = Math.atan2(p.vx, p.vz);
  if (gold && s.lock) facing = Math.atan2(-p.x, -p.z);
  const turn = Math.atan2(
    Math.sin(facing - root.rotation.y),
    Math.cos(facing - root.rotation.y),
  );
  root.rotation.y += turn * (1 - Math.exp(-dt * 14));
  let name = gold
      ? "fly"
      : !p.onGround
        ? p.vy > 0
          ? "jump"
          : "fall"
        : speed > 25
          ? "boost"
          : speed > 16
            ? "run"
            : speed > 1
              ? "move"
              : "idle",
    time = s.time;
  if (s.stage === "transform") {
    name = "transform";
    time = s.stageTime;
  } else if (s.stage === "defeat") {
    name = "defeat";
    time = s.stageTime;
  } else if (gold) {
    const map = {
      punch: [s.combo % 2 ? "attack_left" : "attack_right", 0.28],
      counter: ["counter", 1.2],
      boom: ["sonic_boom", 0.65],
      rush: ["wild_rush", 0.8],
      loop: ["quick_cyloop", 1.6],
      dodge: ["dodge", 0.5],
      hurt: ["damage", 0.75],
    };
    if (s.parryHeld) {
      name = "parry";
      time = s.time;
    }
    if (map[s.action]) {
      const q = map[s.action];
      name = q[0];
      time = q[1] - s.actionTime;
    }
  }
  if (u.super !== gold) {
    u.super = gold;
    for (const [m, blue] of u.blueMaterials)
      m.material = gold ? u.superMaterial : blue;
  }
  actionAt(u, name, time, dt);
  const quills = u.actions.get("super_quills");
  if (gold) {
    if (!u.quillsPlaying) {
      quills.reset().play().setEffectiveTimeScale(0).fadeIn(0.65);
      u.quillsPlaying = true;
    }
  } else if (u.quillsPlaying) {
    quills.fadeOut(0.4);
    u.quillsPlaying = false;
  }
  u.mixer.update(dt);
  actionAt(u, name, time, 0);
  u.mixer.update(0);
  u.currentClip = name;
  performTitanSonic(root, s);
}
export function updateImportedGiganto(root, s, dt) {
  const u = root.userData,
    scale = { easy: 1.25, normal: 1, hard: 0.85 }[s.config.difficulty];
  let name = "idle",
    time = s.time;
  if (u.lastAttack !== "idle" && s.attack === "idle")
    u.recovery = { attack: u.lastAttack, start: s.time };
  u.lastAttack = s.attack;
  if (s.stage === "phase") {
    name = "phase_transition";
    time = s.stageTime;
  } else if (["finale", "victory"].includes(s.stage)) {
    name = "defeat";
    time = s.stageTime;
  } else if (s.stagger > 0) {
    name = "stagger";
    time = s.time;
  } else if (s.stage === "combat" && s.attack !== "idle") {
    const m = TITAN_MOVES[s.attack],
      tell = m.tell * scale,
      t = s.attackTime;
    if (s.attack === "beam") {
      name = s.qte ? "beam_fire" : "beam_charge";
      time = s.qte ? 4.5 - s.qte.left : t / scale;
    } else if (s.attack === "crunch") {
      name = t < tell ? "grab_windup" : "grab";
      time = t < tell ? t / scale : s.qte ? 4.2 - s.qte.left : t - tell;
    } else {
      const base = s.attack === "swing" ? "arm_swing" : "arm_slap";
      name = t < tell ? base + "_windup" : base;
      time = t < tell ? t / scale : t - tell;
    }
  } else if (s.stage === "combat" && u.recovery) {
    const q = u.recovery,
      base =
        q.attack === "swing"
          ? "arm_swing"
          : q.attack === "slap"
            ? "arm_slap"
            : q.attack === "crunch"
              ? "grab"
              : null;
    time = s.time - q.start;
    if (base && time < u.actions.get(base + "_recovery").getClip().duration)
      name = base + "_recovery";
  }
  actionAt(u, name, time, dt);
  const dorsal =
      s.phase === 2 && s.stage !== "phase" ? "dorsal_pulse" : "dorsal_extend",
    dorsalTime =
      s.phase === 2 ? (s.stage === "phase" ? s.stageTime : s.time) : 0;
  actionAt(u, dorsal, dorsalTime, dt, "dorsal");
  u.mixer.update(dt);
  actionAt(u, name, time, 0);
  actionAt(u, dorsal, dorsalTime, 0, "dorsal");
  u.mixer.update(0);
  u.currentClip = name;
  root.position.y =
    s.stagger > 0 && s.action === "loop"
      ? Math.sin((1 - s.actionTime / 1.6) * Math.PI) * 5
      : 0;
  root.rotation.x = 0;
  performTitanBoss(root, s);
}
export function disposeImportedRig(root) {
  if (!root?.userData.imported) return;
  const u = root.userData;
  u.mixer.stopAllAction();
  u.mixer.uncacheRoot(u.model);
  // Alternate form materials may no longer be attached when a fight ends.
  // Shared maps/geometry stay in the bounded asset cache; skeleton textures
  // and unused per-encounter material instances must still be released.
  const attached = new Set(),
    skeletons = new Set();
  root.traverse((o) => {
    if (o.isMesh)
      for (const m of Array.isArray(o.material) ? o.material : [o.material])
        attached.add(m);
    if (o.isSkinnedMesh) skeletons.add(o.skeleton);
  });
  for (const m of u.materials) if (!attached.has(m)) m.dispose();
  for (const skeleton of skeletons) skeleton.dispose();
}
