import * as T from "three";
const up = new T.Vector3(0, 1, 0);
function rotateWorld(bone, from, to, weight) {
  if (from.lengthSq() < 1e-8 || to.lengthSq() < 1e-8) return;
  const delta = new T.Quaternion().setFromUnitVectors(
      from.normalize(),
      to.normalize(),
    ),
    q = bone.getWorldQuaternion(new T.Quaternion()).premultiply(delta),
    parent =
      bone.parent?.getWorldQuaternion(new T.Quaternion()) || new T.Quaternion();
  q.premultiply(parent.invert());
  bone.quaternion.slerp(q, weight).normalize();
}
export function solveTitanArm(
  root,
  upper,
  elbow,
  hand,
  target,
  pole,
  weight = 1,
) {
  if (!upper || !elbow || !hand || weight <= 0) return;
  root.updateMatrixWorld(true);
  const a = upper.getWorldPosition(new T.Vector3()),
    b = elbow.getWorldPosition(new T.Vector3()),
    c = hand.getWorldPosition(new T.Vector3()),
    l1 = a.distanceTo(b),
    l2 = b.distanceTo(c),
    direction = target.clone().sub(a);
  if (l1 < 1e-4 || l2 < 1e-4 || direction.lengthSq() < 1e-8) return;
  const distance = T.MathUtils.clamp(
    direction.length(),
    Math.abs(l1 - l2) + 0.001,
    l1 + l2 - 0.001,
  );
  direction.normalize();
  const side = pole
    .clone()
    .sub(a)
    .addScaledVector(direction, -pole.clone().sub(a).dot(direction));
  if (side.lengthSq() < 1e-8) side.crossVectors(direction, up);
  if (side.lengthSq() < 1e-8) side.set(1, 0, 0);
  side.normalize();
  const along = (l1 * l1 - l2 * l2 + distance * distance) / (2 * distance),
    height = Math.sqrt(Math.max(0, l1 * l1 - along * along));
  const bend = a
    .clone()
    .addScaledVector(direction, along)
    .addScaledVector(side, height);
  rotateWorld(upper, b.clone().sub(a), bend.clone().sub(a), weight);
  root.updateMatrixWorld(true);
  const now = elbow.getWorldPosition(new T.Vector3()),
    end = hand.getWorldPosition(new T.Vector3());
  rotateWorld(elbow, end.sub(now), target.clone().sub(now), weight);
  root.updateMatrixWorld(true);
}
export function performTitanSonic(root, s) {
  const b = root.userData.bones;
  if (s.stage === "combat" && s.action === "loop" && s.config.cinematics) {
    const u = T.MathUtils.clamp(1 - s.actionTime / 1.6, 0, 1),
      a = u * Math.PI * 2;
    root.position.set(
      Math.sin(a) * 24,
      57 + Math.sin(u * Math.PI) * 8,
      17 + Math.cos(a) * 24,
    );
    root.rotation.y = Math.atan2(Math.cos(a), -Math.sin(a));
  }

  if (s.stage === "combat" && s.action === "punch") {
    const u = T.MathUtils.clamp(1 - s.actionTime / 0.28, 0, 1),
      strike = Math.sin(Math.PI * u) ** 1.6,
      left = s.combo % 2 !== 0;
    const direction = new T.Vector3(
        -s.avatar.x,
        57 - s.avatar.y,
        17 - s.avatar.z,
      ),
      distance = direction.length();
    if (distance > 2)
      root.position.addScaledVector(
        direction.normalize(),
        Math.min(7, distance - 2) * strike,
      );
    root.updateMatrixWorld(true);
    const target = root.localToWorld(
        new T.Vector3(left ? 0.38 : -0.38, 2.25, 0.15 + strike * 1.25),
      ),
      pole = root.localToWorld(new T.Vector3(left ? 1.5 : -1.5, 1.5, 0.1));
    solveTitanArm(
      root,
      b[left ? "armL" : "armR"],
      b[left ? "elbowL" : "elbowR"],
      b[left ? "handL" : "handR"],
      target,
      pole,
      0.85,
    );
  }
  if (
    s.stage === "combat" &&
    s.parryHeld &&
    !["punch", "counter"].includes(s.action)
  ) {
    for (const side of ["L", "R"]) {
      const sign = side === "L" ? 1 : -1,
        target = root.localToWorld(new T.Vector3(sign * 0.3, 2.45, 0.78)),
        pole = root.localToWorld(new T.Vector3(sign * 1.4, 1.7, 0));
      solveTitanArm(
        root,
        b["arm" + side],
        b["elbow" + side],
        b["hand" + side],
        target,
        pole,
        0.72,
      );
    }
  }
}
export function performTitanBoss(root, s) {
  const head = root.userData.bones.head;
  if (head && ["intro", "traversal", "combat"].includes(s.stage)) {
    root.updateMatrixWorld(true);
    const origin = head.getWorldPosition(new T.Vector3()),
      forward = new T.Vector3(1, 0, 0).applyQuaternion(
        head.getWorldQuaternion(new T.Quaternion()),
      ),
      target = new T.Vector3(s.avatar.x, s.avatar.y + 2, s.avatar.z).sub(
        origin,
      );
    rotateWorld(head, forward, target, 0.38);
  }

  if (s.stage !== "combat" || s.attack === "idle") return;
  const b = root.userData.bones,
    tell =
      ({ swing: 1.5, slap: 1.2, crunch: 1.75, beam: 1.8 }[s.attack] || 1) *
      { easy: 1.25, normal: 1, hard: 0.85 }[s.config.difficulty],
    u = T.MathUtils.clamp((s.attackTime - tell) / 0.42, 0, 1);
  if (["swing", "slap"].includes(s.attack)) {
    const side = s.attack === "swing" ? "L" : "R",
      sign = side === "L" ? 1 : -1,
      wind = T.MathUtils.clamp(s.attackTime / tell, 0, 1),
      target = new T.Vector3(
        sign * (45 - 72 * u),
        55 + Math.sin(u * Math.PI) * 5,
        -12 + 48 * u,
      ),
      pole = new T.Vector3(sign * 64, 46, 10);
    solveTitanArm(
      root,
      b["arm" + side],
      b["elbow" + side],
      b["hand" + side],
      target,
      pole,
      s.attackTime < tell ? wind * 0.28 : 0.8,
    );
  }
  if (s.attack === "crunch")
    for (const side of ["L", "R"]) {
      const sign = side === "L" ? 1 : -1,
        target = new T.Vector3(
          s.avatar.x + sign * 4,
          s.avatar.y + 2,
          s.avatar.z - 1,
        ),
        pole = new T.Vector3(sign * 58, 50, 20),
        w = T.MathUtils.clamp(s.attackTime / tell, 0, 1) * 0.8;
      solveTitanArm(
        root,
        b["arm" + side],
        b["elbow" + side],
        b["hand" + side],
        target,
        pole,
        w,
      );
    }
}
