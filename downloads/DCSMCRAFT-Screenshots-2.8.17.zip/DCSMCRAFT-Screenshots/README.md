Actual staged game renders. Open index.html.
Standalone SHA-256: 11c5cbf68dedfd18c0d8d54d90c7a67b57b77c3be6db448820d3125a50c7567f
