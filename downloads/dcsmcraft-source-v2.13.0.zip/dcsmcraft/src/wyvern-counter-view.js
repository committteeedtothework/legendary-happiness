import * as T from 'three';
import {solveTitanArm} from './titan-kinematics.js';
export class WyvernBlinkView {
 constructor(scene){this.rings=[];for(let i=0;i<3;i++){const ring=new T.Mesh(new T.TorusGeometry(1,0.045,6,48),new T.MeshBasicMaterial({color:'#ffe8a0',transparent:true,opacity:0,depthWrite:false,blending:T.AdditiveBlending,toneMapped:false}));ring.name='Parry blink '+i;ring.visible=false;scene.add(ring);this.rings.push(ring);}}
 update(s){const age=s.wyvern.teleportAge??1,from=s.wyvern.teleportFrom,p=s.avatar;
  this.rings.forEach((ring,i)=>{ring.visible=age<0.3&&!!from&&s.config.particles!==false;if(!ring.visible)return;
   const q=i===0?from:p;ring.position.set(q.x,q.y+1.65,q.z);ring.rotation.set(i===2?Math.PI/2:0,s.wyvern.yaw||0,age*8+i);
   ring.scale.setScalar((i===0?1.4:0.6)+age*(i===0?10:7));ring.material.opacity=Math.max(0,(1-age/0.3)*0.8);
  });}
 dispose(){for(const m of this.rings){m.geometry.dispose();m.material.dispose();m.removeFromParent();}}
}
export function wyvernQtePose(sonic,boss,s){
 if(!s.qte||s.qte.kind!=='mash')return;
 const b=sonic.userData.bones,model=boss.userData.model;
 const jointNames=['Jaw_up4_014','Jaw_under4_074'];
 sonic.updateMatrixWorld(true);boss.updateMatrixWorld(true);
 const center=sonic.localToWorld(new T.Vector3(0,1.9,0));
 for(const [i,side] of ['L','R'].entries()){
  const joint=model.getObjectByName(jointNames[i]);if(!joint)continue;
  const aim=joint.getWorldPosition(new T.Vector3()).sub(center).normalize().multiplyScalar(1.25).add(center);
  const pole=sonic.localToWorld(new T.Vector3(side==='L'?1.1:-1.1,1.8,0.2));
  solveTitanArm(sonic,b['arm'+side],b['elbow'+side],b['hand'+side],aim,pole,0.92);
 }
}
export function wyvernShotOffset(s,x,y,z){const a=s.wyvern.yaw||0;return new T.Vector3(x*Math.cos(a)+z*Math.sin(a),y,z*Math.cos(a)-x*Math.sin(a));}
