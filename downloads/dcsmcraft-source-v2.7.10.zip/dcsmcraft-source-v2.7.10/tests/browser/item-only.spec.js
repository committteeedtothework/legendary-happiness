import { test, expect } from "@playwright/test";
import { readFileSync, mkdirSync } from "node:fs";
import { createServer } from "node:http";
import { SKINS } from "../../src/skins.js";
const html = readFileSync("dist/DCSMCRAFT-Standalone.html");
const oldCenterY = JSON.parse(
  readFileSync("tests/fixtures/item-mount-v279.json", "utf8"),
);
const out = "/workspace/artifacts/item-mount-2710";
mkdirSync(out, { recursive: true });
let server, origin;
test.use({ trace: "off" });
test.beforeAll(async () => {
  server = createServer((req, res) => {
    res.setHeader("Content-Type", "text/html");
    res.end(html);
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  origin = `http://127.0.0.1:${server.address().port}`;
});
test.afterAll(async () => {
  server?.closeAllConnections();
  if (server) await new Promise((r) => server.close(r));
});
async function boot(page) {
  const errors = [],
    external = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (m) => {
    if (/Shader Error|GL_INVALID|WebGLProgram/.test(m.text()))
      errors.push(m.text());
  });
  await page.addInitScript(() =>
    localStorage.setItem(
      "dcsmcraft-settings",
      JSON.stringify({
        graphics: 1,
        renderDistance: 2,
        distantTerrain: false,
        volume: 0,
        frameLimit: 30,
        skin: "dante",
      }),
    ),
  );
  await page.route("**/*", (r) =>
    r
      .request()
      .url()
      .startsWith(origin + "/")
      ? r.continue()
      : (external.push(r.request().url()), r.abort()),
  );
  await page.goto(origin + "/item-only.html");
  await page.waitForFunction(() => window.dcsmcraft?.initialized);
  await page.locator("[data-action=create]").click();
  await page.locator("[name=seed]").fill("Wildflower");
  await page.locator("[name=mode][value=creative]").check();
  await page.locator("[name=difficulty]").selectOption("peaceful");
  await page.locator("[data-action=start-world]").click();
  await page.waitForFunction(() => dcsmcraft.active);
  await page.evaluate(() => {
    const g = dcsmcraft;
    g.pause();
    g.ui.play();
    g.entities = [];
    g.inventory.selected = 0;
    g.inventory.equipment[1] = { id: "diamond_chestplate", count: 1 };
    Object.assign(g.player, {
      y: 200,
      vy: 0,
      yaw: 0,
      pitch: 0,
      onGround: true,
    });
    for (const s of ["#toast", "#cycle-banner"])
      document.querySelector(s)?.style.setProperty("visibility", "hidden");
  });
  return { errors, external };
}
test("held blocks, tools, ordinary items and both pistols render without any arm geometry through actions, armor refresh and swimming", async ({
  page,
}) => {
  test.setTimeout(120000);
  const evidence = await boot(page);
  const ids = [
    "stone",
    "log",
    "diamond_pickaxe",
    "iron_sword",
    "devin_sword",
    "matthew_dual_pistols",
    "flint_and_steel",
    "apple",
    "water_bucket",
    "torch",
    "iron_chestplate",
    "zombie_spawn_egg",
    "music_disc_amber",
    "saint_corpse_part",
  ];
  for (const id of ids) {
    await page.evaluate((id) => {
      dcsmcraft.inventory.slots[0] = { id, count: 1 };
    }, id);
    await page.waitForFunction(
      (id) => dcsmcraft.renderer.heldId === id && !!dcsmcraft.renderer.heldMesh,
      id,
    );
    const result = await page.evaluate(() => {
      const g = dcsmcraft,
        r = g.renderer;
      let hidden = true,
        itemPresent = true,
        finite = true,
        near = true;
      const armNames = [
        "block-hand",
        "block-sleeve",
        "block-glove",
        "armor-shoulder",
      ];
      for (const kind of ["attack", "mine", "place", "use", "fire"])
        for (const progress of [0, 0.3, 0.6, 1]) {
          r.setArmor(g.inventory.equipment);
          r.animator.trigger(kind);
          r.animator.action.age = r.animator.action.duration * progress;
          r.animator.swim = 1;
          r.draw({
            player: g.player,
            playing: true,
            elapsed: g.elapsed,
            animating: false,
          });
          const visible = [];
          r.handScene.traverseVisible((o) => {
            if (o.isMesh) visible.push(o);
          });
          hidden &&= !visible.some((o) => armNames.includes(o.name));
          let count = 0;
          r.heldMesh.traverseVisible((o) => {
            if (o.isMesh) count++;
          });
          itemPresent &&= count > 0 && r.heldMesh.parent === r.handRig.grip;
          finite &&= r.heldMesh.matrixWorld.elements.every(Number.isFinite);
          near &&= r.handRig.viewBounds.max.z <= -0.1099;
          if (r.leftHandRig.root.visible)
            near &&= r.leftHandRig.viewBounds.max.z <= -0.1099;
          if (r.heldId === "matthew_dual_pistols")
            itemPresent &&= r.leftHandRig.root.visible && r.leftPistol.visible;
          else hidden &&= !r.leftHandRig.root.visible;
        }
      return {
        hidden,
        itemPresent,
        finite,
        near,
        rightArm: r.handRig.armVisuals.visible,
        leftArm: r.leftHandRig.armVisuals.visible,
        error: r.gl.getContext().getError(),
      };
    });
    expect(result, id).toEqual({
      hidden: true,
      itemPresent: true,
      finite: true,
      near: true,
      rightArm: false,
      leftArm: false,
      error: 0,
    });
    const mounted = await page.evaluate(() => {
      const g = dcsmcraft,
        r = g.renderer;
      r.animator = new r.animator.constructor();
      r.pistolStyle = 0;
      r.pistolKick = 0;
      r.draw({
        player: g.player,
        playing: true,
        elapsed: g.elapsed,
        animating: false,
      });
      const center = r.handRig.viewBounds
        .getCenter(r.handRig.arm.hand.clone())
        .project(r.handCamera);
      return { y: center.y, x: center.x, root: r.handGroup.position.toArray() };
    });
    if (oldCenterY[id] !== undefined)
      expect(mounted.y, id + " should occupy the former arm area").toBeLessThan(
        oldCenterY[id] - 0.18,
      );
    expect(mounted.y, id + " should remain visible").toBeGreaterThan(-0.95);
    expect(mounted.x).toBeGreaterThan(0);
    expect(mounted.x).toBeLessThan(1);
    if (["stone", "matthew_dual_pistols", "flint_and_steel"].includes(id)) {
      await page.evaluate(() => {
        const g = dcsmcraft,
          r = g.renderer;
        r.animator.reset();
        r.animator.equip = 0;
        r.animator.swim = 0;
        r.draw({
          player: g.player,
          playing: true,
          elapsed: g.elapsed,
          animating: false,
        });
      });
      await page.screenshot({ path: `${out}/${id}-only.png` });
    }
  }
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
});
test("empty hotbar slots restore each skin arm, glove and armor; switching back hides them and F5 keeps the full player", async ({
  page,
}) => {
  test.setTimeout(120000);
  const evidence = await boot(page);
  await page.evaluate(() => {
    dcsmcraft.inventory.slots[0] = { id: "stone", count: 64 };
    dcsmcraft.inventory.slots[8] = null;
  });
  for (const id of Object.keys(SKINS)) {
    await page.evaluate((id) => {
      dcsmcraft.settings.skin = id;
    }, id);
    await page.keyboard.press("Digit9");
    await page.waitForFunction(
      () =>
        !dcsmcraft.renderer.heldId &&
        dcsmcraft.renderer.handRig.armVisuals.visible,
    );
    const empty = await page.evaluate(() => {
      const g = dcsmcraft,
        r = g.renderer;
      r.animator.reset();
      r.animator.equip = 0;
      r.animator.swim = 0;
      r.draw({
        player: g.player,
        playing: true,
        elapsed: g.elapsed,
        animating: false,
      });
      const names = [];
      r.handRig.root.traverseVisible((o) => {
        if (o.isMesh) names.push(o.name);
      });
      return {
        hand: names.includes("block-hand"),
        sleeve: names.includes("block-sleeve"),
        glove: names.includes("block-glove"),
        armor: names.includes("armor-shoulder"),
        appearance: r.handRig.appearance.id,
        handOnScreen: (() => {
          const point = r.handRig.forearm
            .localToWorld(r.handRig.arm.hand.clone().set(0, -0.5, 0))
            .project(r.handCamera);
          return (
            Math.abs(point.x) < 1 &&
            Math.abs(point.y) < 1 &&
            Math.abs(point.z) < 1
          );
        })(),
      };
    });
    expect(empty).toEqual({
      hand: true,
      sleeve: true,
      glove: ["dante", "vergil", "criminal"].includes(id),
      armor: true,
      appearance: id,
      handOnScreen: true,
    });
    await page.keyboard.press("Digit1");
    await page.waitForFunction(
      () =>
        dcsmcraft.renderer.heldId === "stone" &&
        !dcsmcraft.renderer.handRig.armVisuals.visible,
    );
  }
  await page.keyboard.press("Digit9");
  await page.waitForFunction(() => !dcsmcraft.renderer.heldId);
  await page.evaluate(() => {
    const g = dcsmcraft,
      r = g.renderer;
    r.animator.reset();
    r.animator.equip = 0;
    r.animator.swim = 0;
    r.draw({
      player: g.player,
      playing: true,
      elapsed: g.elapsed,
      animating: false,
    });
  });
  await page.screenshot({ path: `${out}/empty-hand.png` });
  const swim = await page.evaluate(() => {
    const g = dcsmcraft,
      r = g.renderer;
    r.animator.swim = 1;
    r.draw({
      player: g.player,
      playing: true,
      elapsed: g.elapsed,
      animating: false,
    });
    return {
      left: r.leftHandRig.root.visible,
      arm: r.leftHandRig.armVisuals.visible,
      pistol: r.leftPistol.visible,
    };
  });
  expect(swim).toEqual({ left: true, arm: true, pistol: false });
  await page.keyboard.press("Digit1");
  await page.keyboard.press("F5");
  await page.waitForFunction(
    () => dcsmcraft.cameraMode === 1 && dcsmcraft.renderer.playerModel?.visible,
  );
  const f5 = await page.evaluate(() => {
    const u = dcsmcraft.renderer.playerModel.userData;
    return {
      arms: u.arms.every((a) => a.visible && a.children[0].visible),
      hands: u.forearms.every((a) => a.children[1].visible),
      held: !!u.grip.children[0],
    };
  });
  expect(f5).toEqual({ arms: true, hands: true, held: true });
  expect(evidence.errors).toEqual([]);
  expect(evidence.external).toEqual([]);
});
