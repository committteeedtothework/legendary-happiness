@echo off
start "" "%~dp0Multiplayer-Server\dist\DCSMCRAFT-Standalone.html"
