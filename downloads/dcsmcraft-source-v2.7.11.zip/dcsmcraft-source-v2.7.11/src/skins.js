export const SKINS = {
  devin: {
    name: "Devin The Hero",
    story: "A fine emerald tunic, gilded belt, and a knowing smirk.",
    skin: "#c79b77",
    shirt: "#2e735a",
    trousers: "#4b3b31",
    hair: "#4a3026",
    accent: "#e4bd62",
    style: "devin",
  },
  stargazer: {
    name: "Moonwalker",
    story: "A pale flight suit and a midnight-blue visor.",
    skin: "#a9cde0",
    shirt: "#d4d8d5",
    trousers: "#586779",
    hair: "#25394e",
    accent: "#6ed5d9",
    style: "astronaut",
  },
  ranger: {
    name: "Moss Ranger",
    story: "A hood, a satchel, and boots for the long way home.",
    skin: "#a57455",
    shirt: "#526444",
    trousers: "#3d4737",
    hair: "#31352a",
    accent: "#cf9a5e",
    style: "ranger",
  },
  smith: {
    name: "Cinder Smith",
    story: "A leather apron, copper goggles, and warm forge light.",
    skin: "#79513d",
    shirt: "#6b4242",
    trousers: "#343943",
    hair: "#24232a",
    accent: "#dba467",
    style: "smith",
  },
  tidekeeper: {
    name: "Tidekeeper",
    story: "A striped ocean coat with a bright coral sash.",
    skin: "#d6ab88",
    shirt: "#3a7d94",
    trousers: "#324553",
    hair: "#203b4c",
    accent: "#ec9476",
    style: "sailor",
  },
  explorer: {
    name: "Explorer",
    story: "Boots dusty. Pockets full of possibility.",
    skin: "#bd906c",
    shirt: "#376c71",
    trousers: "#424e54",
    hair: "#493725",
    accent: "#ddb65d",
    style: "scarf",
  },
  clown: {
    name: "Carnival Clown",
    story: "A bright patchwork suit and a very red nose.",
    skin: "#f1dfc4",
    shirt: "#ad4155",
    trousers: "#426a96",
    hair: "#db7940",
    accent: "#e8c65b",
    style: "clown",
  },
  hero: {
    name: "Trail Hero",
    story: "A mountain crest for a wandering defender.",
    skin: "#a97753",
    shirt: "#31588a",
    trousers: "#303d55",
    hair: "#302b29",
    accent: "#e4bc54",
    style: "hero",
  },
  criminal: {
    name: "Bandit",
    story: "Striped coat, black gloves, midnight adventures.",
    skin: "#c49370",
    shirt: "#d1c9b7",
    trousers: "#46434c",
    hair: "#292932",
    accent: "#635968",
    style: "bandit",
  },
  dante: {
    name: "Dante",
    story:
      "DMC3-inspired: silver hair, an open crimson coat, and a devilish grin.",
    skin: "#dfbba2",
    shirt: "#9d2636",
    trousers: "#262630",
    hair: "#e4e5e8",
    accent: "#c9cbd1",
    style: "dante",
  },
  vergil: {
    name: "Vergil",
    story:
      "DMC3-inspired: swept silver hair, a blue long coat with silver embroidery, black gloves and a sheathed katana.",
    skin: "#dfbba2",
    shirt: "#254b83",
    trousers: "#252b38",
    hair: "#e3e7ee",
    accent: "#c6d8e6",
    style: "vergil",
  },
};
export const skinFor = (id) => SKINS[id] || SKINS.explorer;
// The same costume palette and hand proportions serve F5 and first person.
// Glove distances are measured from the fingertips along the 0.6-unit F5 arm.
const ARM_APPEARANCES = Object.fromEntries(
  Object.entries(SKINS).map(([id, s]) => [
    id,
    Object.freeze({
      id,
      skin: s.skin,
      sleeve: s.shirt,
      handLength: 0.18,
      glove:
        s.style === "dante"
          ? Object.freeze({ color: "#272630", start: 0.0525, end: 0.1675 })
          : s.style === "vergil"
            ? Object.freeze({ color: "#222938", start: 0.035, end: 0.185 })
            : s.style === "bandit"
              ? Object.freeze({ color: "#37343b", start: 0, end: 0.1 })
              : null,
    }),
  ]),
);
export const armAppearanceFor = (id) =>
  ARM_APPEARANCES[id] || ARM_APPEARANCES.explorer;
// Original tiny sprite for the wardrobe: same palette and costume as the 3D rig.
export function skinPreview(id) {
  const s = skinFor(id);
  const detail =
    s.style === "vergil"
      ? `<path d="M12 17h8v15h-8zM3 30h4v5H3zM25 30h4v5h-4z" fill="#202735"/><path d="M7 29h5v14H6zM20 29h5l1 14h-6z" fill="${s.shirt}"/><path d="M10 17v23h2V17zM20 17v23h2V17zM9 21h3v2H9zM20 24h3v2h-3z" fill="${s.accent}"/><path d="M8 2h16V0h-4v2h-3V0h-3v2h-3V0H8z" fill="${s.hair}"/><path d="M25 27l-4 18h2l4-18z" fill="#343440"/><path d="M25 25h3v4h-3z" fill="${s.accent}"/>`
      : s.style === "dante"
        ? `<path d="M12 17h8v13h-8z" fill="${s.skin}"/><path d="M7 29h5v13H6zM20 29h5l1 13h-6z" fill="${s.shirt}"/><path d="M10 18l5 8h2l5-8h-3l-3 5-3-5zM7 30h18v3H7zM2 30h5v5H2zM25 30h5v5h-5z" fill="#292833"/><path d="M8 3h7l-3 5H9zM17 3h7v5h-3zM14 30h4v2h-4z" fill="${s.accent}"/><path d="M15 12h5v1h-5zM19 11h2v1h-2z" fill="#86574d"/>`
        : s.style === "devin"
          ? `<path d="M11 17h10v5H11zM7 30h18v3H7z" fill="${s.accent}"/><path d="M13 12h5v1h-5zM18 11h2v1h-2z" fill="#744735"/><path d="M12 17h8l-4 8z" fill="#e4dac0"/>`
          : s.style === "astronaut"
            ? `<path d="M9 6h14v7H9z" fill="#25394e"/><path d="M11 7h8v2h-8zM10 22h12v6H10z" fill="${s.accent}"/>`
            : s.style === "ranger"
              ? `<path d="M7 1h18v5H7zM7 4h3v11H7zM22 4h3v11h-3zM8 18l14 15h3L11 18z" fill="${s.accent}"/>`
              : s.style === "smith"
                ? `<path d="M10 20h12v14H10z" fill="#a46b42"/><path d="M10 7h12v4H10z" fill="${s.accent}"/>`
                : s.style === "sailor"
                  ? `<path d="M7 21h18v3H7zM7 27h18v3H7z" fill="#d5ddd2"/><path d="M7 30h18v3H7z" fill="${s.accent}"/>`
                  : s.style === "clown"
                    ? `<rect x="14" y="9" width="4" height="3" fill="#d84a43"/><rect x="10" y="21" width="3" height="3" fill="${s.accent}"/><rect x="18" y="26" width="3" height="3" fill="${s.accent}"/>`
                    : s.style === "bandit"
                      ? [20, 25, 30]
                          .map(
                            (y) =>
                              `<rect x="7" y="${y}" width="18" height="2" fill="#494652"/>`,
                          )
                          .join("")
                      : `<path d="M12 20h8l-4 9z" fill="${s.accent}"/>`;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="96" height="144" viewBox="0 0 32 48" shape-rendering="crispEdges"><path fill="${s.trousers}" d="M8 32h7v13H8zM17 32h7v13h-7z"/><path fill="${s.shirt}" d="M7 17h18v17H7zM2 18h5v14H2zM25 18h5v14h-5z"/><path fill="${s.skin}" d="M9 3h14v13H9zM2 31h5v5H2zM25 31h5v5h-5z"/><path fill="${s.hair}" d="M8 2h16v4H8zM8 4h3v5H8z"/><path fill="#292b32" d="M11 8h2v2h-2zM19 8h2v2h-2zM8 43h7v3H8zM17 43h7v3h-7z"/>${detail}</svg>`;
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}
