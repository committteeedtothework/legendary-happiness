// Original pixel artwork, painted onto square body surfaces rather than raised
// boxes. A face strip keeps the same texel density on every side of each part.
import * as THREE from "three";
import { skinFor } from "./skins.js";
const cache = new Map();
const dimensions = {
  head: [8, 8, 8],
  body: [8, 12, 4],
  leg: [4, 12, 4],
  sleeve: [4, 8, 4],
  hand: [4, 4, 4],
};
const rgb = (hex) =>
  hex
    .replace("#", "")
    .match(/../g)
    .map((n) => parseInt(n, 16));
function paint(s, part, face, x, y, w, h) {
  const front = face === 5,
    back = face === 4;
  if (part === "sleeve" || part === "hand") return "#ffffff";
  let c = part === "head" ? s.skin : part === "body" ? s.shirt : s.trousers;
  if (part === "head") {
    if (face === 2 || (face !== 3 && (y < 2 || back || (!front && x > w - 3))))
      c = s.hair;
    if (front) {
      if (y === 2 && (x === 0 || (s.style === "dante" && x === 5))) c = s.hair;
      if (y === 4 && [1, 2, 5, 6].includes(x))
        c = [2, 5].includes(x)
          ? s.style === "vergil"
            ? "#648b9d"
            : "#616688"
          : "#ece9dd";
      if (y === 5 && [3, 4].includes(x)) c = "#aa785b";
      if (y === 6 && [3, 4].includes(x)) c = "#845b4b";
      if (["devin", "dante"].includes(s.style) && x === 5 && y === 5)
        c = "#845b4b";
      if (s.style === "bandit" && y === 3) c = "#494652";
      if (s.style === "clown") {
        if (y === 5 && [3, 4].includes(x)) c = "#d94341";
        if (y === 6 && [2, 5].includes(x)) c = "#a1374b";
        if (y === 4 && [0, 7].includes(x)) c = "#da8174";
      }
      if (s.style === "smith" && y >= 3 && y <= 4 && x > 0 && x < 7)
        c = [2, 5].includes(x) ? "#4d7384" : s.accent;
    }
    if (s.style === "astronaut") {
      c = s.shirt;
      if (front && y >= 2 && y <= 5 && x > 0 && x < 7)
        c = y === 2 && x < 4 ? s.accent : "#25394e";
    }
    if (s.style === "ranger" && (face !== 5 || x === 0 || x === 7 || y < 2))
      c = s.shirt;
    if (s.style === "vergil" && front && y < 3) c = s.hair;
    return c;
  }
  if (part === "leg") {
    if (y > 9 || face === 3) c = "#302e32";
    if (y === 0) c = "#393139";
    if ((front || back) && y === 4 && x === 0) c = "#4d4950";
    if (["dante", "vergil"].includes(s.style) && y > 7) c = "#252630";
    if (s.style === "dante" && y === 8) c = s.accent;
    if (s.style === "clown" && front && x < 2 && y > 3 && y < 6) c = s.shirt;
    if (s.style === "astronaut" && y === 8) c = s.accent;
    return c;
  }
  if (face === 2) return s.shirt;
  if (front && y === 0 && x >= 3 && x <= 4) c = s.skin;
  switch (s.style) {
    case "devin":
      if (front && y < 3 && x > 1 && x < 6 && Math.abs(x - 3.5) < (3 - y) / 2)
        c = "#dfd2ac";
      if (front && (x === 0 || x === 7) && y < 9) c = s.accent;
      if (y === 9) c = "#604532";
      if (front && y === 9 && x >= 3 && x <= 4) c = s.accent;
      break;
    case "dante":
      if (front && x >= 2 && x <= 5 && y < 9) c = s.skin;
      if (
        front &&
        y > 1 &&
        y < 7 &&
        (x === Math.floor(y / 2) + 1 || x === 6 - Math.floor(y / 2))
      )
        c = "#39323a";
      if (front && y < 4 && (x === 1 || x === 6)) c = "#c0444b";
      if (y === 10) c = "#292833";
      if (front && y === 10 && x === 3) c = s.accent;
      break;
    case "vergil":
      if (front && x >= 3 && x <= 4) c = "#222938";
      if (
        front &&
        (x === 2 || x === 5 || (y % 3 === 1 && (x === 1 || x === 6)))
      )
        c = s.accent;
      break;
    case "astronaut":
      if (front && x > 1 && x < 6 && y > 2 && y < 7) c = "#43536a";
      if (front && y === 4 && [2, 4].includes(x)) c = s.accent;
      if (y === 9) c = "#586779";
      break;
    case "ranger":
      if (front && Math.abs(x - y * 0.6) < 1) c = s.accent;
      if (front && x > 4 && y > 7) c = "#79553e";
      if (back) c = "#394d38";
      break;
    case "smith":
      if (front && y > 2 && x > 0 && x < 7) c = "#a46b42";
      if (front && y === 7 && x > 1 && x < 6) c = "#764a37";
      if (front && y < 3 && [1, 6].includes(x)) c = s.accent;
      break;
    case "sailor":
      if (y % 3 === 1) c = "#d5ddd2";
      if (y === 9) c = s.accent;
      break;
    case "clown":
      if (front && y > 1 && [3, 4].includes(x) && y % 3 === 0) c = s.accent;
      if (front && y === 1 && x > 0 && x < 7) c = s.accent;
      if (front && y > 7 && x < 2) c = "#426a96";
      break;
    case "bandit":
      if (y % 3 === 1) c = "#494652";
      break;
    case "hero":
      if (front && y > 1 && y < 6 && Math.abs(x - 3.5) < (6 - y) * 0.65)
        c = s.accent;
      if (back && y > 0) c = "#913c47";
      if (y === 10) c = "#283344";
      break;
    default:
      if (front && y < 3 && x > 1 && x < 6) c = s.accent;
      if (front && x === 3 && y >= 3 && y < 7) c = s.accent;
      if (front && y > 7 && [1, 6].includes(x)) c = "#294b50";
  }
  return c;
}
export function skinPartTexture(id, part) {
  const s = skinFor(id),
    key = `${s.style}:${part}`;
  if (cache.has(key)) return cache.get(key);
  const [w, h, d] = dimensions[part],
    widths = [d, d, w, w, w, w];
  const width = widths.reduce((a, b) => a + b, 0),
    height = Math.max(h, d);
  const data = new Uint8Array(width * height * 4),
    rects = [];
  let offset = 0;
  widths.forEach((fw, face) => {
    const fh = face === 2 || face === 3 ? d : h;
    rects.push([offset, 0, fw, fh]);
    for (let y = 0; y < fh; y++)
      for (let x = 0; x < fw; x++) {
        const base = rgb(paint(s, part, face, x, y, fw, fh));
        // Subtle, deterministic pixel shading. Features remain clean at distance.
        const shade = (x * 17 + y * 13 + face * 7) % 11 === 0 ? 0.93 : 1;
        const p = ((height - 1 - y) * width + offset + x) * 4;
        for (let c = 0; c < 3; c++) data[p + c] = Math.round(base[c] * shade);
        data[p + 3] = 255;
      }
    offset += fw;
  });
  const texture = new THREE.DataTexture(data, width, height);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.magFilter = texture.minFilter = THREE.NearestFilter;
  texture.generateMipmaps = false;
  texture.needsUpdate = true;
  texture.userData = { rects, skin: s.style, part };
  cache.set(key, texture);
  return texture;
}
export function skinBoxGeometry(size, texture) {
  const geometry = new THREE.BoxGeometry(...size),
    uv = geometry.attributes.uv;
  const { width, height } = texture.image;
  texture.userData.rects.forEach(([x, y, w, h], face) => {
    for (let i = face * 4; i < face * 4 + 4; i++) {
      const u = uv.getX(i),
        v = uv.getY(i);
      uv.setXY(
        i,
        (x + 0.01 + u * (w - 0.02)) / width,
        1 - (y + 0.01 + (1 - v) * (h - 0.02)) / height,
      );
    }
  });
  return geometry;
}
export function skinMaterial(id, part) {
  const s = skinFor(id);
  const material = new THREE.MeshLambertMaterial({
    map: skinPartTexture(id, part),
    color: part === "sleeve" ? s.shirt : part === "hand" ? s.skin : "#ffffff",
  });
  material.userData.sharedMap = true;
  return material;
}
