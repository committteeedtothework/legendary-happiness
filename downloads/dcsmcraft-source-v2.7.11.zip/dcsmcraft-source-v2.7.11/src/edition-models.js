import * as THREE from "three";
import { blockParts, shapeSurfaces } from "./block-shapes.js";
import { blockArtUV } from "./block-art.js";
import { ITEMS, BLOCKS } from "./data.js";
const verts = [
  [
    [1, 0, 1],
    [1, 0, 0],
    [1, 1, 0],
    [1, 1, 1],
  ],
  [
    [0, 0, 0],
    [0, 0, 1],
    [0, 1, 1],
    [0, 1, 0],
  ],
  [
    [0, 1, 1],
    [1, 1, 1],
    [1, 1, 0],
    [0, 1, 0],
  ],
  [
    [0, 0, 0],
    [1, 0, 0],
    [1, 0, 1],
    [0, 0, 1],
  ],
  [
    [0, 0, 1],
    [1, 0, 1],
    [1, 1, 1],
    [0, 1, 1],
  ],
  [
    [1, 0, 0],
    [0, 0, 0],
    [0, 1, 0],
    [1, 1, 0],
  ],
];
const normals = [
  [1, 0, 0],
  [-1, 0, 0],
  [0, 1, 0],
  [0, -1, 0],
  [0, 0, 1],
  [0, 0, -1],
];
export function editionBlockModel(id, atlas) {
  const item = ITEMS[id],
    b = BLOCKS[item?.block];
  if (!b?.edition || b.plant) return null;
  const parts = blockParts(item.block);
  const centerParts = parts.filter(
    (p) => p[0] <= 0.5 && p[3] >= 0.5 && p[2] <= 0.5 && p[5] >= 0.5,
  );
  const anchor =
    centerParts[0] ||
    parts.reduce(
      (best, p) =>
        Math.hypot((p[0] + p[3]) / 2 - 0.5, (p[2] + p[5]) / 2 - 0.5) <
        Math.hypot((best[0] + best[3]) / 2 - 0.5, (best[2] + best[5]) / 2 - 0.5)
          ? p
          : best,
      parts[0],
    );
  const ax = centerParts.length ? 0.5 : (anchor[0] + anchor[3]) / 2,
    az = centerParts.length ? 0.5 : (anchor[2] + anchor[5]) / 2;
  const support = Math.min(
    ...parts
      .filter((p) => p[0] <= 0.5 && p[3] >= 0.5 && p[2] <= 0.5 && p[5] >= 0.5)
      .map((p) => p[1]),
  );
  const oy = (Number.isFinite(support) ? support : anchor[1]) + 0.5;
  const offset = [ax, oy, az];
  const p = [],
    n = [],
    uv = [],
    indices = [];
  for (const q of shapeSurfaces(blockParts(item.block))) {
    const start = p.length / 3;
    for (let i = 0; i < 4; i++) {
      const v = verts[q.face][i].map(
        (c, a) => q.bounds[a] + c * (q.bounds[a + 3] - q.bounds[a]),
      );
      p.push(...v.map((c, a) => (c - offset[a]) * 0.235));
      n.push(...normals[q.face]);
      uv.push(
        ...blockArtUV(
          item.block,
          q.face,
          [0, 1, 1, 0][i],
          [0, 0, 1, 1][i],
          atlas.pack,
        ),
      );
    }
    indices.push(start, start + 1, start + 2, start, start + 2, start + 3);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.Float32BufferAttribute(p, 3));
  geometry.setAttribute("normal", new THREE.Float32BufferAttribute(n, 3));
  geometry.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  geometry.setIndex(indices);
  const material = new THREE.MeshLambertMaterial({
    map: atlas.texture,
    alphaTest: 0.5,
  });
  material.userData.sharedMap = true;
  const mesh = new THREE.Mesh(geometry, material);
  mesh.userData.voxelParts = parts.map((p) =>
    p.map((v, a) => (v - offset[a % 3]) * 0.235),
  );
  mesh.position.set(-0.025, 0.015, -0.14);
  mesh.rotation.y = -0.35;
  const g = new THREE.Group();
  g.add(mesh);
  g.userData.kind = "block";
  g.userData.item = id;
  return g;
}
export function editionWeaponModel(id) {
  if (!["bow", "crossbow", "shield"].includes(id)) return null;
  const root = new THREE.Group(),
    wood = new THREE.MeshLambertMaterial({ color: "#a17a4a" }),
    edge = new THREE.MeshLambertMaterial({ color: "#ccb583" }),
    metal = new THREE.MeshLambertMaterial({ color: "#aab3b8" }),
    string = new THREE.MeshLambertMaterial({ color: "#dedbd0" });
  const box = (w, h, d, x, y, z, mat = wood) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z);
    root.add(m);
    return m;
  };
  if (id === "shield") {
    box(0.065, 0.15, 0.055, 0, 0, 0, wood);
    box(0.3, 0.32, 0.04, 0, 0.08, -0.095, wood);
    box(0.24, 0.08, 0.04, 0, -0.12, -0.095, wood);
    box(0.15, 0.08, 0.04, 0, -0.2, -0.095, wood);
    box(0.34, 0.025, 0.055, 0, 0.25, -0.095, metal);
    box(0.025, 0.34, 0.055, -0.16, 0.07, -0.095, metal);
    box(0.025, 0.34, 0.055, 0.16, 0.07, -0.095, metal);
    for (const x of [-0.08, 0, 0.08])
      box(0.01, 0.3, 0.045, x, 0.08, -0.098, edge);
  } else if (id === "bow") {
    box(0.045, 0.13, 0.045, 0, 0, 0);
    for (const s of [-1, 1]) {
      const a = box(0.034, 0.16, 0.035, -0.035, s * 0.125, 0, edge);
      a.rotation.z = -s * 0.38;
      const b = box(0.03, 0.1, 0.03, -0.075, s * 0.24, 0);
      b.rotation.z = s * 0.25;
    }
    const cord = box(0.008, 0.56, 0.008, 0.015, 0, 0, string);
    root.userData.cord = cord;
  } else {
    box(0.05, 0.09, 0.05, 0, -0.02, 0.005);
    box(0.055, 0.04, 0.3, 0, 0.04, -0.12);
    box(0.36, 0.025, 0.035, 0, 0.065, -0.22, edge);
    for (const s of [-1, 1]) {
      const a = box(0.13, 0.025, 0.035, s * 0.2, 0.065, -0.185);
      a.rotation.y = -s * 0.42;
    }
    const cord = box(0.45, 0.008, 0.008, 0, 0.065, -0.14, string);
    root.userData.cord = cord;
    box(0.02, 0.025, 0.25, 0, 0.085, -0.18, metal);
  }
  root.userData.kind = id;
  root.userData.item = id;
  root.userData.editionWeapon = true;
  return root;
}
export function animateEditionWeapon(model, player, time) {
  if (!model?.userData.editionWeapon) return;
  const draw =
    player.editionDraw?.id === model.userData.item
      ? Math.max(0, Math.min(1, time - player.editionDraw.start))
      : 0;
  const cord = model.userData.cord;
  if (cord) {
    cord.scale.x = model.userData.kind === "crossbow" ? 1 - draw * 0.08 : 1;
    cord.position.z = draw * 0.07;
  }
  model.rotation.z =
    model.userData.kind === "shield" && player.shieldRaised ? -0.45 : 0;
}
