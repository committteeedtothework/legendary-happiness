import * as THREE from "three";
import { createPlayerModel, animatePlayerModel } from "./player-model.js";
export function disposeSkinModel(model) {
  if (!model) return;
  const materials = new Set();
  model.traverse((o) => {
    o.geometry?.dispose();
    for (const m of o.material
      ? Array.isArray(o.material)
        ? o.material
        : [o.material]
      : [])
      materials.add(m);
  });
  for (const m of materials) {
    if (!m.userData.sharedMap) m.map?.dispose();
    m.dispose();
  }
  model.removeFromParent();
}
// A single, bounded preview context exists only while the wardrobe is open.
export class SkinPreview {
  constructor(container, id) {
    this.container = container;
    this.disposed = false;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(33, 1, 0.1, 20);
    this.camera.position.set(0, 1.12, 3.6);
    this.camera.lookAt(0, 0.95, 0);
    this.gl = new THREE.WebGLRenderer({
      alpha: true,
      antialias: false,
      powerPreference: "low-power",
    });
    this.gl.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
    this.gl.outputColorSpace = THREE.SRGBColorSpace;
    const canvas = this.gl.domElement;
    canvas.setAttribute(
      "aria-label",
      "Interactive 3D outfit preview. Drag to turn.",
    );
    canvas.setAttribute("role", "img");
    container.append(canvas);
    this.scene.add(new THREE.HemisphereLight("#f4f5ff", "#5b5a66", 2.4));
    const key = new THREE.DirectionalLight("#fff1d5", 2);
    key.position.set(-3, 5, 4);
    this.scene.add(key);
    const fill = new THREE.DirectionalLight("#c0dbff", 0.8);
    fill.position.set(3, 2, -4);
    this.scene.add(fill);
    const platform = new THREE.Mesh(
      new THREE.BoxGeometry(1.25, 0.065, 1.25),
      new THREE.MeshLambertMaterial({ color: "#575d54" }),
    );
    platform.position.y = -0.04;
    this.scene.add(platform);
    this.platform = platform;
    this.yaw = Math.PI - 0.32;
    this.abort = new AbortController();
    const options = { signal: this.abort.signal };
    canvas.addEventListener(
      "pointerdown",
      (e) => {
        if (e.button !== 0) return;
        this.drag = e.clientX;
        canvas.setPointerCapture(e.pointerId);
      },
      options,
    );
    canvas.addEventListener(
      "pointermove",
      (e) => {
        if (this.drag === undefined) return;
        this.yaw += (e.clientX - this.drag) * 0.012;
        this.drag = e.clientX;
      },
      options,
    );
    const end = () => {
      this.drag = undefined;
    };
    canvas.addEventListener("pointerup", end, options);
    canvas.addEventListener("pointercancel", end, options);
    canvas.addEventListener("lostpointercapture", end, options);
    this.reduced = matchMedia("(prefers-reduced-motion: reduce)");
    this.observer = new ResizeObserver(() => this.resize());
    this.observer.observe(container);
    this.setSkin(id);
    this.resize();
    const frame = (now) => {
      if (this.disposed) return;
      this.frame = requestAnimationFrame(frame);
      if (document.hidden || now - (this.last || 0) < 1000 / 30) return;
      const dt = Math.min(0.05, (now - (this.last || now)) / 1000);
      this.last = now;
      if (!this.reduced.matches)
        animatePlayerModel(
          this.model,
          { onGround: true, pitch: 0, vy: 0 },
          dt,
          false,
        );
      this.model.rotation.y = this.yaw;
      this.gl.render(this.scene, this.camera);
    };
    this.frame = requestAnimationFrame(frame);
  }
  resize() {
    const w = Math.max(1, this.container.clientWidth),
      h = Math.max(1, this.container.clientHeight);
    this.gl.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }
  setSkin(id) {
    if (this.id === id) return;
    disposeSkinModel(this.model);
    this.model = createPlayerModel(id);
    this.scene.add(this.model);
    this.id = id;
    this.model.rotation.y = this.yaw;
  }
  turn(amount) {
    this.yaw += amount;
  }
  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    cancelAnimationFrame(this.frame);
    this.observer.disconnect();
    this.abort.abort();
    disposeSkinModel(this.model);
    disposeSkinModel(this.platform);
    this.gl.dispose();
    this.gl.forceContextLoss();
    this.gl.domElement.remove();
  }
}
