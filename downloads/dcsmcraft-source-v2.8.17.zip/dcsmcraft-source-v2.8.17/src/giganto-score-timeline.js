// Cue seconds refer to the user-supplied 264.96-second recording, not a remote
// stream. The 200 BPM grid was checked against decoded onset peaks (10 ms hop).
export const TITAN_SCORE_CUES = Object.freeze({
  bpm: 200,
  phaseOne: { start: 0, loopStart: 26.44, loopEnd: 103.24 },
  phaseTwo: { start: 179.14, loopStart: 160.54, loopEnd: 198.94 },
  transition: { start: 175.14, duration: 4 },
  finale: { start: 221.14, duration: 7 },
});
export const TITAN_CUE_FIELDS = Object.freeze([
  ["phaseOne.start", "Battle opening"],
  ["phaseOne.loopStart", "Phase 1 loop in"],
  ["phaseOne.loopEnd", "Phase 1 loop out"],
  ["phaseTwo.start", "Phase 2 downbeat"],
  ["phaseTwo.loopStart", "Phase 2 loop in"],
  ["phaseTwo.loopEnd", "Phase 2 loop out"],
  ["finale.start", "Finishing passage"],
]);
// Source seconds belong to a particular recording. Custom files never inherit
// purported official markers. Invalid groups fall back atomically, not piecemeal.
export function titanScoreCues(raw) {
  const c = structuredClone(TITAN_SCORE_CUES);
  if (!raw) return c;
  const number = (x) => Number.isFinite(x) && x >= 0 && x <= 900;
  for (const name of ["phaseOne", "phaseTwo"]) {
    const p = raw[name];
    if (
      p &&
      [p.start, p.loopStart, p.loopEnd].every(number) &&
      p.loopEnd - p.loopStart >= 1 &&
      p.start < p.loopEnd &&
      (name === "phaseOne"
        ? p.start <= p.loopStart
        : p.start >= 4 && p.start >= p.loopStart)
    )
      c[name] = { start: p.start, loopStart: p.loopStart, loopEnd: p.loopEnd };
  }
  if (number(raw.finale?.start) && raw.finale.start <= 893)
    c.finale.start = raw.finale.start;
  if (Number.isFinite(raw.bpm) && raw.bpm >= 40 && raw.bpm <= 300)
    c.bpm = raw.bpm;
  c.transition.start = c.phaseTwo.start - c.transition.duration;
  return c;
}
export function titanScoreLength(cues) {
  return Math.max(
    cues.phaseOne.loopEnd,
    cues.phaseTwo.loopEnd,
    cues.transition.start + cues.transition.duration,
    cues.finale.start + cues.finale.duration,
  );
}
export function titanScorePlan(s, cues = titanScoreCues(s?.config?.scoreCues)) {
  const time = Number.isFinite(s?.stageTime) ? Math.max(0, s.stageTime) : 0;
  let section;
  if (s?.stage === "combat") section = s.phase === 2 ? "phaseTwo" : "phaseOne";
  else if (s?.stage === "phase") section = "transition";
  else if (s?.stage === "finale") section = "finale";
  else return null;
  const cue = cues[section];
  let offset = cue.start + Math.min(time, cue.duration ?? Infinity);
  if (cue.loopEnd && offset >= cue.loopEnd)
    offset =
      cue.loopStart + ((offset - cue.loopEnd) % (cue.loopEnd - cue.loopStart));
  return { section, offset, loopStart: cue.loopStart, loopEnd: cue.loopEnd };
}
export function scorePosition(voice, now) {
  let position = voice.offset + Math.max(0, now - voice.when);
  if (voice.loopEnd && position >= voice.loopEnd)
    position =
      voice.loopStart +
      ((position - voice.loopEnd) % (voice.loopEnd - voice.loopStart));
  return position;
}
