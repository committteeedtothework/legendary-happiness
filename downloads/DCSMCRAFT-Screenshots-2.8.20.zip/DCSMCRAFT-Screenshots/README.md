Actual Chromium captures from the verified standalone: working return portal and soundtrack settings. No graphics changes in this release.
Standalone SHA-256: 2d19d70efc5132d33bfa9a0865a64f2d92540a6a86528951033e76e4e98f733c
