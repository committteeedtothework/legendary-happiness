import { wear, enchantLevel } from "./equipment.js";
import { cloneState } from "./compat.js";
import { ITEMS, RECIPES, makeStack } from "./data.js";
export const compatible = (a, b) =>
  a &&
  b &&
  a.id === b.id &&
  a.durability === b.durability &&
  a.origin === b.origin &&
  JSON.stringify(a.mapTarget || null) === JSON.stringify(b.mapTarget || null) &&
  JSON.stringify(a.fishData || null) === JSON.stringify(b.fishData || null) &&
  JSON.stringify(Object.entries(a.enchantments || {}).sort()) ===
    JSON.stringify(Object.entries(b.enchantments || {}).sort());
export class Inventory {
  constructor(saved) {
    this.slots = Array.from({ length: 36 }, (_, i) =>
      saved?.slots?.[i] ? cloneState(saved.slots[i]) : null,
    );
    this.craft = Array.from({ length: 9 }, (_, i) =>
      saved?.craft?.[i] ? cloneState(saved.craft[i]) : null,
    );
    this.cursor = saved?.cursor ? cloneState(saved.cursor) : null;
    this.selected = saved?.selected || 0;
    this.equipment = Array.from({ length: 4 }, (_, i) =>
      saved?.equipment?.[i] ? cloneState(saved.equipment[i]) : null,
    );
  }
  get held() {
    return this.slots[this.selected];
  }
  add(stack) {
    if (!ITEMS[stack.id]) return stack.count;
    let left = stack.count,
      max = ITEMS[stack.id].stack;
    for (let i = 0; i < 36 && left; i++)
      if (compatible(this.slots[i], stack)) {
        const n = Math.min(left, max - this.slots[i].count);
        this.slots[i].count += n;
        left -= n;
      }
    for (let i = 0; i < 36 && left; i++)
      if (!this.slots[i]) {
        const n = Math.min(left, max);
        this.slots[i] = { ...stack, count: n };
        left -= n;
      }
    return left;
  }
  consume(slot = this.selected, count = 1) {
    const s = this.slots[slot];
    if (!s || s.count < count) return false;
    s.count -= count;
    if (!s.count) this.slots[slot] = null;
    return true;
  }
  damageTool() {
    if (wear(this.held)) this.slots[this.selected] = null;
  }
  click(array, index, right = false) {
    const slot = array[index];
    if (!this.cursor) {
      if (!slot) return;
      const n = right ? Math.ceil(slot.count / 2) : slot.count;
      this.cursor = { ...slot, count: n };
      slot.count -= n;
      if (!slot.count) array[index] = null;
      return;
    }
    if (!slot) {
      const n = right ? 1 : this.cursor.count;
      array[index] = { ...this.cursor, count: n };
      this.cursor.count -= n;
    } else if (compatible(slot, this.cursor)) {
      const n = Math.min(
        right ? 1 : this.cursor.count,
        ITEMS[slot.id].stack - slot.count,
      );
      slot.count += n;
      this.cursor.count -= n;
    } else if (!right) {
      array[index] = this.cursor;
      this.cursor = slot;
    }
    if (this.cursor?.count === 0) this.cursor = null;
  }
  transfer(source, index, target) {
    const s = source[index];
    if (!s) return;
    let left = s.count;
    const max = ITEMS[s.id].stack;
    for (let i = 0; i < target.length && left; i++) {
      if (source === target && index === i) continue;
      if (compatible(target[i], s)) {
        const n = Math.min(left, max - target[i].count);
        target[i].count += n;
        left -= n;
      }
    }
    for (let i = 0; i < target.length && left; i++) {
      if (source === target && index === i) continue;
      if (!target[i]) {
        const n = Math.min(left, max);
        target[i] = { ...s, count: n };
        left -= n;
      }
    }
    if (left) source[index] = { ...s, count: left };
    else source[index] = null;
  }
  recipe(size = 2) {
    return matchRecipe(this.craft, size);
  }
  craftOne(size = 2) {
    const r = this.recipe(size);
    if (!r) return false;
    const output = makeStack(r.result, r.count);
    if (
      this.cursor &&
      (!compatible(this.cursor, output) ||
        this.cursor.count + r.count > ITEMS[r.result].stack)
    )
      return false;
    if (this.cursor) this.cursor.count += r.count;
    else this.cursor = output;
    for (let i = 0; i < size * size; i++)
      if (this.craft[i]) {
        this.craft[i].count--;
        if (!this.craft[i].count) this.craft[i] = null;
      }
    return true;
  }
  export() {
    return {
      slots: this.slots,
      craft: this.craft,
      cursor: this.cursor,
      selected: this.selected,
      equipment: this.equipment,
    };
  }
}
export function matchRecipe(grid, size) {
  const occupied = [];
  let minX = size,
    minY = size,
    maxX = -1,
    maxY = -1;
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++)
      if (grid[y * size + x]) {
        occupied.push(grid[y * size + x].id);
        minX = Math.min(x, minX);
        maxX = Math.max(x, maxX);
        minY = Math.min(y, minY);
        maxY = Math.max(y, maxY);
      }
  if (!occupied.length) return null;
  for (const r of RECIPES) {
    if (r.ingredients) {
      if (
        [...occupied].sort().join(",") === [...r.ingredients].sort().join(",")
      )
        return r;
      continue;
    }
    const w = r.pattern[0].length,
      h = r.pattern.length;
    if (w !== maxX - minX + 1 || h !== maxY - minY + 1) continue;
    for (const flip of [false, true]) {
      let valid = true;
      for (let y = 0; y < h; y++)
        for (let x = 0; x < w; x++) {
          const c = r.pattern[y][flip ? w - 1 - x : x],
            need = r.key[c] || null,
            actual = grid[(minY + y) * size + minX + x]?.id || null;
          if (need !== actual) valid = false;
        }
      if (valid) return r;
    }
  }
  return null;
}
export function miningTicks(block, held, inWater = false, airborne = false) {
  if (block.hardness === Infinity) return Infinity;
  if (block.hardness === 0) return 1;
  const item = ITEMS[held?.id],
    correct = !!block.tool && item?.tool === block.tool,
    canHarvest = !block.tier || (correct && item.tier >= block.tier);
  let speed = correct ? item.speed : 1;
  if (correct && speed > 1) {
    const level = enchantLevel(held, "efficiency");
    if (level) speed += level * level + 1;
  }
  if (inWater) speed /= 5;
  if (airborne) speed /= 5;
  return Math.ceil((block.hardness * (canHarvest ? 30 : 100)) / speed);
}
export function canHarvest(block, held) {
  return (
    !block.tier ||
    (ITEMS[held?.id]?.tool === block.tool &&
      ITEMS[held?.id]?.tier >= block.tier)
  );
}
