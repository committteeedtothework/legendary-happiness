# Validation record — DCSMCRAFT 1.6.0

Reference: **Minecraft Java Edition 1.20.4**, with the existing partial/missing mechanics in FEATURES.md. Titan's Grasp retains generator 11 and all older generators; it expands the saved pistol encounter without resetting completed rewards.

## Automated mechanics

**325 core tests pass**, including 15 new trial cases. Checks cover elite guard health/roles and exactly four identities, one-time proportional legacy upgrades, seeded/tick-limited/capped orb shots, swept player and wall collisions, straight bullet flight, warning escape, Creative/Peaceful/co-op exclusions, actual collision-safe tentacle pulling, movement restraint, entry into the real Cinderworld, preservation of existing edited builds, one-time supply containers, Titan bullet/knockback immunity and melee vulnerability, four telegraphed moves and jumpable slams, cross-realm save/restore, checkpoint respawn, boundary recovery, Peaceful dormancy, unique victory rewards, an indestructible return rune, counterfeit-rune rejection, sealed/unlocked return interactions, and bounded articulated boss geometry.

All existing recipe, inventory, fluids, collision, chunk-boundary, save recovery, unique weapons, structures, progression, chat, and relay tests pass. This is selected automated coverage, not a claim that every possible player action is bug-free.

## Browser playtests

The two new scenarios **pass using the exact built standalone HTML with external requests blocked**. They check creation, all four elite guards, naturally emitted orb projectiles, real projectile damage and solid cover, rendered tentacles, forced trial entry, an interactive supply chest, boss HUD, actual pistol deflection and melee damage, saving/reloading a damaged Titan, blocking ordinary portals, actual death and checkpoint respawn, victory through production targeting/combat/durability, the unlocked return rune, original Hellspawn preserved after return, and persistent escaped state. No page errors or checked WebGL errors occurred.

Combat tests use controlled positions, equipment and cooldown setup for reproducibility. The completed boss fight is a test of actual combat code, not an unaided full Survival playthrough. Screenshots of the shrine, supplies and Titan were visually inspected.

**Nine distinct selected browser scenarios pass on the frozen runtime/build inputs:** the two new trial scenarios, three retained Cinderworld/Vergil/temple scenarios (including actual 30-second held-mouse sword extraction), the complete pistol-claim/reload scenario, one actual HTTPS/WSS scenario, and two Survival co-op scenarios covering chat, mining, crafting, workstations, death/respawn, reconnects, owner commands and concurrent chest transfers without duplication.

An initial Guardian fixture could aim at another nearby Guardian; it now isolates its selected target. The old stationary pistol-fight actor died against the stronger defenders; that playtest now builds real cover and retreats between charged, mouse-driven attacks without reducing enemy health/damage or healing the test actor. One initial co-op run timed out during guest mining; it passed on a fresh rerun without a runtime change. The transient test-environment disconnect also recovered. These records support the tested flows, not a promise of flawless multiplayer or exhaustive bug coverage.

## Compatibility and packaging

A separate probe compares **60 chunks** against the published **1.5.0 complete source**, across **both dimensions and every generator 2–11**, including negative chunk coordinates. Voxel data is byte-identical. This is representative evidence, not exhaustive validation of every seed/chunk. See the versioned compatibility JSON.

The runtime/build source hashes are frozen before browser testing. Production WebGL assets and the self-contained HTML build successfully. The Windows x64 launcher cross-compiles and its embedded HTML extraction matches byte-for-byte. The packaging script verifies frozen input hashes, ZIP CRCs and SHA-256 checksums. Complete source includes assets, dependency lockfile, build and launch scripts, server, tests, feature checklist and documentation.

**Actual Windows execution is unverified on this Linux host.** The managed browser does not allow a direct file:// navigation; the identical standalone HTML is tested from a local HTTP origin with external requests blocked. Live public Cloudflare tunneling and real YouTube playback remain unverified, as described in MULTIPLAYER.md and README.md. A normal Edge/Chrome desktop browser is required by the Windows launcher.

## Scope and known limits

- Tentacle abduction is single-player Survival only. Co-op keeps elite defenders and dangerous orb bullets, but independent dimension travel is still unavailable.
- Each incursion permits one abduction. Escaping the Titan does not grant the pistols; all four original defenders must still be defeated. Claimed rewards in existing worlds remain claimed.
- The trial is an enclosed edited arena at Y244 in untouched distant Cinderworld space. It uses local steering rather than full pathfinding. Cover can obstruct the boss.
- Peaceful pauses the boss and leaves its return rune locked; select another difficulty to finish. Death respawns inside the trial, with the original five-active-minute drop despawn rule. The supply cache is provided once and is never refilled by reloads/death.
- Older living incursion guards retain their original species but receive proportional health increases and stronger attacks. Newly spawned defenders use the elite species/health.
- Broader unfinished systems, dimensions, automation and reference-version differences remain explicitly listed in FEATURES.md.
