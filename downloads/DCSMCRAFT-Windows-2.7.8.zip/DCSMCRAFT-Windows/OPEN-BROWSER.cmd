@echo off
start /wait "" "%~dp0DCSMCRAFT.exe" --extract-only
if errorlevel 1 exit /b 1
start "" "%LOCALAPPDATA%\DCSMCRAFT\Game\index.html"
