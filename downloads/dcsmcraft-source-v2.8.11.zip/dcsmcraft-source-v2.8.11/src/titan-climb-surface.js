import * as T from "three";
const CELL = 4;
const key = (x, y, z) => `${x},${y},${z}`;
let activeSurface = null;
export function installTitanClimbSurface(surface) {
  activeSurface = surface;
}
export const getTitanClimbSurface = () => activeSurface;
const a = new T.Vector3(),
  b = new T.Vector3(),
  c = new T.Vector3(),
  query = new T.Vector3(),
  hit = new T.Vector3(),
  normal = new T.Vector3(),
  tri = new T.Triangle();
export function createTitanClimbSurface(vertices) {
  const data =
      vertices instanceof Float32Array ? vertices : new Float32Array(vertices),
    cells = new Map(),
    normals = new Float32Array(data.length / 3);
  for (let n = 0; n < data.length; n += 9) {
    a.fromArray(data, n);
    b.fromArray(data, n + 3);
    c.fromArray(data, n + 6);
    tri.set(a, b, c);
    tri.getNormal(normal);
    normal.toArray(normals, n / 3);
    const min = [
        Math.floor(Math.min(a.x, b.x, c.x) / CELL),
        Math.floor(Math.min(a.y, b.y, c.y) / CELL),
        Math.floor(Math.min(a.z, b.z, c.z) / CELL),
      ],
      max = [
        Math.floor(Math.max(a.x, b.x, c.x) / CELL),
        Math.floor(Math.max(a.y, b.y, c.y) / CELL),
        Math.floor(Math.max(a.z, b.z, c.z) / CELL),
      ];
    for (let x = min[0]; x <= max[0]; x++)
      for (let y = min[1]; y <= max[1]; y++)
        for (let z = min[2]; z <= max[2]; z++) {
          const k = key(x, y, z);
          if (!cells.has(k)) cells.set(k, []);
          cells.get(k).push(n / 9);
        }
  }
  return { data, normals, cells, triangles: data.length / 9 };
}
export function extractTitanClimbSurface(root) {
  root.updateMatrixWorld(true);
  const out = [],
    p = new T.Vector3(),
    q = new T.Vector3(),
    r = new T.Vector3();
  root.traverse((o) => {
    if (!o.isMesh || o.name.startsWith("dorsal_")) return;
    const g = o.geometry,
      idx = g.index,
      pos = g.attributes.position;
    if (o.isSkinnedMesh) o.skeleton.update();
    const vertex = (i, v) => {
      v.fromBufferAttribute(pos, i);
      if (o.isSkinnedMesh) o.applyBoneTransform(i, v);
      return v.applyMatrix4(o.matrixWorld);
    };
    for (let j = 0; j < (idx ? idx.count : pos.count); j += 3) {
      const ids = [0, 1, 2].map((k) => (idx ? idx.getX(j + k) : j + k));
      vertex(ids[0], p);
      vertex(ids[1], q);
      vertex(ids[2], r);
      tri.set(p, q, r);
      if (tri.getArea() < 0.00001) continue;
      tri.getNormal(normal);
      if (o.matrixWorld.determinant() < 0) {
        const t = q.clone();
        q.copy(r);
        r.copy(t);
      }
      out.push(...p.toArray(), ...q.toArray(), ...r.toArray());
    }
  });
  return createTitanClimbSurface(out);
}
export function nearestArmorPoint(
  p,
  radius = 3,
  options = {},
  surface = activeSurface,
) {
  if (!surface) return null;
  query.set(p.x, p.y, p.z);
  const seen = new Set();
  let best = null,
    score = Infinity;
  const lo = [p.x - radius, p.y - radius, p.z - radius].map((v) =>
      Math.floor(v / CELL),
    ),
    hi = [p.x + radius, p.y + radius, p.z + radius].map((v) =>
      Math.floor(v / CELL),
    );
  for (let x = lo[0]; x <= hi[0]; x++)
    for (let y = lo[1]; y <= hi[1]; y++)
      for (let z = lo[2]; z <= hi[2]; z++)
        for (const id of surface.cells.get(key(x, y, z)) || []) {
          if (seen.has(id)) continue;
          seen.add(id);
          normal.fromArray(surface.normals, id * 3);
          if (options.normal && normal.dot(options.normal) < -0.15) continue;
          const off = id * 9;
          a.fromArray(surface.data, off);
          b.fromArray(surface.data, off + 3);
          c.fromArray(surface.data, off + 6);
          tri.set(a, b, c).closestPointToPoint(query, hit);
          const d = hit.distanceTo(query);
          if (d > radius) continue;
          if (
            options.from &&
            hit.distanceTo(options.from) > (options.step || 0) + 0.75
          )
            continue;
          const value =
            d * d - (options.upward && d < 0.25 ? normal.y * 0.008 : 0);
          if (value < score) {
            score = value;
            best = {
              point: { x: hit.x, y: hit.y, z: hit.z },
              normal: { x: normal.x, y: normal.y, z: normal.z },
              triangle: id,
              distance: d,
            };
          }
        }
  return best;
}
export function armorSurfaceStep(
  contact,
  delta,
  surface = activeSurface,
  corner = false,
) {
  if (!surface) return null;
  let result = contact;
  const total = Math.hypot(delta.x, delta.y, delta.z),
    parts = Math.max(1, Math.ceil(total / 0.28));
  if (total < 1e-8) return { ...contact };
  let direction = new T.Vector3(delta.x, delta.y, delta.z).normalize();
  const rotation = new T.Quaternion();
  for (let part = 0; part < parts; part++) {
    const p = new T.Vector3(result.point.x, result.point.y, result.point.z),
      old = new T.Vector3(result.normal.x, result.normal.y, result.normal.z),
      step = total / parts,
      seen = new Set();
    let picked = null,
      score = Infinity;
    const lo = [p.x - 0.8, p.y - 0.8, p.z - 0.8].map((v) =>
        Math.floor(v / CELL),
      ),
      hi = [p.x + 0.8, p.y + 0.8, p.z + 0.8].map((v) => Math.floor(v / CELL));
    for (let x = lo[0]; x <= hi[0]; x++)
      for (let y = lo[1]; y <= hi[1]; y++)
        for (let z = lo[2]; z <= hi[2]; z++)
          for (const id of surface.cells.get(key(x, y, z)) || []) {
            if (seen.has(id)) continue;
            seen.add(id);
            const n = new T.Vector3().fromArray(surface.normals, id * 3),
              dot = old.dot(n);
            if (dot < (corner ? -0.85 : -0.1)) continue;
            rotation.setFromUnitVectors(old, n);
            const dir = direction.clone().applyQuaternion(rotation).normalize(),
              target = p.clone().addScaledVector(dir, step),
              off = id * 9;
            a.fromArray(surface.data, off);
            b.fromArray(surface.data, off + 3);
            c.fromArray(surface.data, off + 6);
            tri.set(a, b, c).closestPointToPoint(target, hit);
            const move = hit.clone().sub(p),
              distance = move.length(),
              progress = move.dot(dir);
            if (distance > step + 0.3 || progress < step * 0.15) continue;
            const value =
              hit.distanceToSquared(target) +
              (1 - dot) * 0.006 +
              Math.max(0, step - distance) ** 2;
            if (value < score) {
              score = value;
              picked = {
                point: { x: hit.x, y: hit.y, z: hit.z },
                normal: { x: n.x, y: n.y, z: n.z },
                triangle: id,
                distance: 0,
                dir,
              };
            }
          }
    if (!picked) break;
    direction = picked.dir;
    delete picked.dir;
    result = picked;
  }
  return result;
}

export function raycastArmor(from, to, surface = activeSurface) {
  if (!surface) return null;
  const origin = new T.Vector3(from.x, from.y, from.z),
    dir = new T.Vector3(to.x - from.x, to.y - from.y, to.z - from.z),
    limit = dir.length();
  if (limit < 0.001) return null;
  dir.divideScalar(limit);
  const ray = new T.Ray(origin, dir),
    cell = [from.x, from.y, from.z].map((v) => Math.floor(v / CELL)),
    end = [to.x, to.y, to.z].map((v) => Math.floor(v / CELL)),
    sign = [dir.x, dir.y, dir.z].map(Math.sign),
    delta = [dir.x, dir.y, dir.z].map((v) =>
      v ? CELL / Math.abs(v) : Infinity,
    ),
    max = [0, 1, 2].map((k) =>
      sign[k]
        ? ((cell[k] + (sign[k] > 0 ? 1 : 0)) * CELL - origin.getComponent(k)) /
          dir.getComponent(k)
        : Infinity,
    ),
    seen = new Set();
  let best = null;
  for (let count = 0; count < 256; count++) {
    for (const id of surface.cells.get(key(...cell)) || []) {
      if (seen.has(id)) continue;
      seen.add(id);
      const off = id * 9;
      a.fromArray(surface.data, off);
      b.fromArray(surface.data, off + 3);
      c.fromArray(surface.data, off + 6);
      const p = ray.intersectTriangle(a, b, c, false, new T.Vector3());
      if (!p) continue;
      const distance = p.distanceTo(origin);
      if (
        distance > 0.2 &&
        distance <= limit &&
        (!best || distance < best.distance)
      )
        best = { point: { x: p.x, y: p.y, z: p.z }, distance };
    }
    if (cell.every((v, k) => v === end[k])) break;
    let axis = 0;
    if (max[1] < max[axis]) axis = 1;
    if (max[2] < max[axis]) axis = 2;
    if (max[axis] > limit || !Number.isFinite(max[axis])) break;
    cell[axis] += sign[axis];
    max[axis] += delta[axis];
  }
  return best;
}
