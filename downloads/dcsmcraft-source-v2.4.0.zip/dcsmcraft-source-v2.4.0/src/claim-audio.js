import { DEVIN_CLAIM_MP3 } from "./devin-claim-audio-data.js";

// Prepare the embedded file after the first audio unlock, without playing it.
// It never depends on a URL, fetch, local file permission or internet access.
export class ClaimFanfare {
  constructor(context, output) {
    this.context = context;
    this.output = output;
    this.started = 0;
    this.source = null;
    this.pending = false;
    this.failed = false;
    this.ready = Promise.resolve()
      .then(() => {
        const bytes = Uint8Array.from(atob(DEVIN_CLAIM_MP3), (c) =>
          c.charCodeAt(0),
        );
        return context.decodeAudioData(bytes.buffer);
      })
      .catch(() => {
        this.failed = true;
        return null;
      });
  }
  async play(enabled = () => true) {
    if (this.pending || this.source || !enabled()) return false;
    this.pending = true;
    let source, gain;
    try {
      const buffer = await this.ready;
      if (!buffer || !enabled() || this.context.state !== "running")
        return false;
      source = this.context.createBufferSource();
      gain = this.context.createGain();
      source.buffer = buffer;
      source.loop = false;
      gain.gain.value = 0.7;
      source.connect(gain);
      gain.connect(this.output);
      source.onended = () => {
        source.disconnect();
        gain.disconnect();
        if (this.source === source) this.source = null;
      };
      this.source = source;
      source.start();
      this.started++;
      return true;
    } catch {
      source?.disconnect();
      gain?.disconnect();
      this.source = null;
      this.failed = true;
      return false;
    } finally {
      this.pending = false;
    }
  }
}
