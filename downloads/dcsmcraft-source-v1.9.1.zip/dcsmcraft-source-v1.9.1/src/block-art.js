import { B, BLOCKS } from "./data.js";
// Extra directional faces use spare atlas cells, leaving saved block IDs intact.
export const EXTRA_ART_NAMES = [
  "furnace_front",
  "crafting_table_front",
  "chest_front",
];
export const EXTRA_ART = Object.fromEntries(
  EXTRA_ART_NAMES.map((name, i) => [name, BLOCKS.length * 3 + i]),
);
const normals = [
  [1, 0, 0],
  [-1, 0, 0],
  [0, 1, 0],
  [0, -1, 0],
  [0, 0, 1],
  [0, 0, -1],
];
export function blockArtTile(id, faceIndex, pack) {
  const slot = [1, 1, 0, 2, 1, 1][faceIndex];
  if (pack === "supplied" && faceIndex === 5) {
    if (id === B.furnace) return EXTRA_ART.furnace_front;
    if (id === B.crafting_table) return EXTRA_ART.crafting_table_front;
    if (id === B.chest) return EXTRA_ART.chest_front;
  }
  return id * 3 + slot;
}
export function blockArtUV(id, faceIndex, u, v, pack) {
  const tile = blockArtTile(id, faceIndex, pack),
    block = BLOCKS[id];
  if (pack === "supplied" && block?.door) {
    const facing = (block.door.facing + (block.door.open ? 3 : 0)) % 4;
    const n = normals[faceIndex];
    if (n[1]) {
      u = 0.125 + u * 0.75;
      v = 0.025 + v * 0.055;
    } else if ((facing % 2 === 0 && n[0]) || (facing % 2 === 1 && n[2])) {
      u = u * 0.125;
    } else if (facing >= 2) u = 1 - u;
  }
  return [
    ((tile % 16) + 0.015 + u * 0.97) / 16,
    1 - (Math.floor(tile / 16) + 0.985 - v * 0.97) / 32,
  ];
}
