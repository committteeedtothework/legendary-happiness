// Every exposed setting is consumed by the renderer, mesher or frame scheduler.
export const VIDEO_GROUPS = [
  [
    "Display & performance",
    "Resolution and view distance have the largest performance cost.",
    [
      ["graphics", "Resolution scale", 1, 5, 1],
      ["renderDistance", "Render distance", 2, 24, 1],
      [
        "frameLimit",
        "Max Framerate",
        [
          [0, "Unlimited"],
          [30, "30 FPS"],
          [60, "60 FPS"],
          [120, "120 FPS"],
          [144, "144 FPS"],
        ],
      ],
      ["entityDistance", "Entity Distance", 0.5, 1.5, 0.25],
      [
        "particles",
        "Particles",
        [
          ["all", "All"],
          ["decreased", "Decreased"],
          ["minimal", "Minimal"],
        ],
      ],
      ["distantTerrain", "Extended Terrain"],
      ["showFPS", "Show FPS"],
    ],
  ],
  [
    "Lighting",
    "Smooth Lighting shades block corners. Sun Shadows is an optional local shadow map; Entity Shadows casts creature shadows when it is enabled.",
    [
      ["ambientOcclusion", "Smooth Lighting / AO"],
      ["shadows", "Sun Shadows"],
      ["entityShadows", "Entity Shadows"],
      ["brightness", "Brightness", 0, 1, 0.05],
    ],
  ],
  [
    "World detail",
    "Texture packs change artwork without changing your world or menus. Mipmaps reduce distant texture shimmer.",
    [
      [
        "texturePack",
        "Texture Pack",
        [
          ["renewed", "Renewed — sculpted pixel art"],
          ["soft", "Soft — v1.0 artwork"],
          ["classic", "Classic — v0.5 artwork"],
          ["supplied", "Supplied Assets — Minecraft textures"],
        ],
      ],
      ["mipmapLevels", "Mipmap Levels", 0, 4, 1],
      ["biomeColors", "Biome Colors"],
      ["biomeBlend", "Biome Blend", 0, 4, 1],
      ["fancyGraphics", "Fancy Graphics"],
      ["clouds", "Clouds"],
      ["cloudHeight", "Cloud Height", 96, 256, 16],
      ["stars", "Stars"],
      ["animatedTextures", "Animated Textures"],
      ["entityAnimations", "Creature Animations"],
      ["droppedItemAnimation", "Dropped Item Animation"],
      ["sunMoon", "Sun & Moon"],
      ["weatherEffects", "Rain, Snow & Hail"],
      ["lightningFlashes", "Lightning Flashes"],
      ["fog", "Distance Fog"],
    ],
  ],
  [
    "Camera",
    "View Bobbing controls camera and hand movement while walking. Combat animations remain active.",
    [
      ["viewBobbing", "View Bobbing"],
      ["dynamicFOV", "FOV Effects"],
      ["damageTilt", "Damage Tilt"],
    ],
  ],
];
export const VIDEO_CHOICES = Object.fromEntries(
  VIDEO_GROUPS.flatMap((g) => g[2])
    .filter((f) => Array.isArray(f[2]))
    .map((f) => [f[0], f[2]]),
);
export function frameDue(now, last, limit) {
  return !limit || last === undefined || now - last >= 1000 / limit - 0.5;
}
export function easeAngle(current, target, amount) {
  return (
    current +
    Math.atan2(Math.sin(target - current), Math.cos(target - current)) * amount
  );
}
export function particleCount(settings, normal) {
  return settings.particles === "minimal"
    ? 0
    : settings.particles === "decreased"
      ? Math.ceil(normal / 3)
      : normal;
}
