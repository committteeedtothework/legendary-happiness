import { activeTrial } from "./rift-trial.js";
import {
  probeRelay,
  relayAddressInfo,
  validateRelayAccess,
  readSavedRelay,
  saveRelay,
} from "./relay-connection.js";
import { weaponMoveText } from "./weapon-hud.js";
import { beginInvasion, invasionState, INVADERS } from "./invasion.js";
import { relayURL } from "./multiplayer.js";
import { CINDER_BIOMES, nearbyCinderSites } from "./cinderworld.js";
import { setWeather } from "./weather.js";
import { debugNavigation } from "./navigation.js";
import { SKINS, skinPreview } from "./skins.js";
import { VIDEO_GROUPS, VIDEO_CHOICES } from "./graphics.js";
import { BIOMES } from "./biomes.js";
import {
  ENCHANTMENTS,
  enchantItem,
  enchantLevel,
  enchantCost,
  enchantText,
  armorStats,
} from "./equipment.js";
import { uniqueId, cloneState } from "./compat.js";
import {
  BLOCKS,
  MOB_INFO,
  ITEMS,
  RECIPES,
  CREATIVE_ITEMS,
  VERSION,
  REFERENCE,
  makeStack,
  CYCLE_TEXT,
  VILLAGER_TRADES,
  attackCooldown,
  ARMOR_SLOTS,
  FUELS,
  SMELTS,
} from "./data.js";
import { iconURL } from "./textures.js";
import { compatible } from "./inventory.js";
import { tradeWithVillager } from "./ecology.js";
export const esc = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const cube = `<svg viewBox="0 0 40 44" aria-hidden="true"><path fill="#a9bf7b" d="m20 1 19 11-19 11L1 12Z"/><path fill="#6f8c55" d="m1 12 19 11v21L1 33Z"/><path fill="#3c5940" d="m39 12-19 11v21l19-11Z"/><path fill="#cad79c" d="m20 1 19 11-6 3L14 4Z"/></svg>`;
const arrow =
  '<span class="arrow-icon" aria-hidden="true"><svg viewBox="0 0 18 18"><path d="M4 14 14 4M4 4h10v10" fill="none" stroke="currentColor" stroke-width="1.4"/></svg></span>';
const itemHTML = (s, large = false) =>
  s
    ? `<img draggable="false" alt="${esc(ITEMS[s.id]?.name || s.id)}" src="${iconURL(s.id)}" class="${s.enchantments || ITEMS[s.id]?.legendary ? "enchanted-item" : ""}"/>${s.count > 1 ? `<b>${s.count}</b>` : ""}${s.durability !== undefined && s.durability < ITEMS[s.id].durability ? `<i class="durability" style="--wear:${(s.durability / ITEMS[s.id].durability) * 100}%"></i>` : ""}`
    : "";
export class UI {
  constructor(game) {
    this.game = game;
    this.screen = "title";
    this.debug = false;
    this.root = document.createElement("div");
    this.root.id = "ui";
    this.root.innerHTML = `<div id="overlay"></div><div id="hud" hidden></div><div id="toast" role="status"></div><div id="cursor-item"></div><div id="tooltip"></div><div id="cycle-banner" aria-live="polite"><strong></strong><span></span></div>`;
    document.querySelector("#app").append(this.root);
    this.overlay = this.root.querySelector("#overlay");
    this.hud = this.root.querySelector("#hud");
    this.cursorEl = this.root.querySelector("#cursor-item");
    this.tooltip = this.root.querySelector("#tooltip");
    this.bind();
  }
  bind() {
    this.overlay.addEventListener("click", (e) => {
      const button = e.target.closest("[data-action]");
      if (!button) return;
      const action = button.dataset.action;
      if (action === "start-world") {
        this.startWorld(button.closest("#world-form"));
        return;
      }
      this.game.audio.unlock();
      this.game.audio.tone("ui");
      if (action === "multiplayer") this.multiplayerMenu();
      if (action === "world-chat") this.game.chat.open();
      if (action === "connect-multiplayer") this.connectMultiplayer(button);
      if (action === "test-relay") this.testRelay(button);
      if (action === "copy-invite") this.copyInvite();
      if (action === "disconnect-multiplayer") {
        if (this.game.multiplayer.isGuest) this.game.quit();
        else {
          this.game.multiplayer.disconnect();
          this.pause("Co-op closed. Your world is now singleplayer.");
        }
      }
      if (action === "kick-player")
        this.game.multiplayer.send({ type: "kick", id: button.dataset.id });
      if (action === "send-chat") this.sendChat();
      if (action === "create") this.create();
      if (action === "title") this.title();
      if (action === "worlds") this.worlds();
      if (action === "guide") this.guide();
      if (action === "features") this.features();
      if (action === "settings") this.settings();
      if (action === "weather") this.weather();
      if (action === "jukebox") this.game.jukebox.open();
      if (action === "set-weather" && this.game.mode === "creative") {
        setWeather(this.game.world, button.dataset.weather);
        this.weather();
      }
      if (action === "skins") this.skins();
      if (action === "choose-skin" && SKINS[button.dataset.skin]) {
        this.game.settings.skin = button.dataset.skin;
        this.saveSettings();
        this.skins();
      }
      if (action === "enchant-select")
        this.enchanting(Number(button.dataset.index));
      if (action === "enchant-item") {
        const result = enchantItem(
          this.game,
          this.enchantIndex,
          button.dataset.enchantment,
        );
        this.toast(result.message);
        this.enchanting(this.enchantIndex);
      }
      if (action === "cinder-guide") this.cinderGuide();
      if (action === "journal") this.game.openJournal();
      if (
        action === "summon-incursion" &&
        this.game.mode === "creative" &&
        !this.game.multiplayer?.isGuest
      ) {
        if (beginInvasion(this.game)) this.game.resume();
        else
          this.toast(
            "Move to an open, unbuilt clearing, wait for chunks to load, then try again. Each world has one incursion.",
            7000,
          );
      }
      if (action === "toggle-audio") {
        const key = button.dataset.audio;
        this.game.settings[key] = !this.game.settings[key];
        this.saveSettings();
        if (!this.game.settings.ambientSounds) this.game.audio.silenceAmbient();
        this.settings();
      }
      if (action === "video-settings") this.videoSettings();
      if (action === "toggle-graphics") {
        const key = button.dataset.graphics;
        this.game.settings[key] = !this.game.settings[key];
        this.saveSettings();
        this.game.renderer.applyGraphics();
        this.videoSettings();
      }
      if (action === "fullscreen") {
        const op = document.fullscreenElement
          ? document.exitFullscreen()
          : document.documentElement.requestFullscreen?.();
        op?.catch(() =>
          this.toast("Fullscreen is unavailable in this viewer."),
        );
      }
      if (action === "trade") {
        const result = tradeWithVillager(
          this.game,
          this.tradingEntity,
          Number(button.dataset.trade),
        );
        this.toast(result.message);
        this.trading(this.tradingEntity);
      }

      if (action === "download-game") this.downloadGame();
      if (action === "backup-current")
        this.game
          .save()
          .then(() => this.exportWorld(this.game.id))
          .catch((e) => this.toast(e.message));
      if (action === "reset-cycle") {
        this.game.settings.cycleText = { ...CYCLE_TEXT };
        this.saveSettings();
        this.settings();
      }
      if (action === "preview-cycle") {
        const entries = Object.entries(this.game.settings.cycleText),
          item = entries[(this.previewCycleIndex || 0) % entries.length];
        this.previewCycleIndex = (this.previewCycleIndex || 0) + 1;
        this.overlay.querySelector("#message-preview").textContent =
          item[1] || "(This message is disabled)";
        this.game.audio.tone(item[0].includes("night") ? "dusk" : "dawn");
      }
      if (action === "back")
        this.screen === "video"
          ? this.settings()
          : this.game.active
            ? this.pause()
            : this.title();
      if (action === "resume") this.game.resume();
      if (action === "quit") this.game.quit();
      if (action === "respawn") this.game.respawn();
      if (action === "close-inv") this.game.closeInventory();
      if (action === "load") this.game.loadWorld(button.dataset.id);
      if (action === "export") this.exportWorld(button.dataset.id);
      if (action === "recipe") {
        this.game.autofill(
          RECIPES[Number(button.dataset.recipe)],
          this.craftSize,
        );
      }
      if (action === "creative-tab") {
        this.creativeTab = button.dataset.tab;
        this.buildInventory();
      }
      if (action === "craft") this.craft(e.shiftKey);
      if (action === "delete") {
        if (button.dataset.confirm === "yes") {
          this.game.store.remove(button.dataset.id).then(() => this.worlds());
        } else {
          button.dataset.confirm = "yes";
          button.textContent = "Confirm delete";
          button.classList.add("danger");
        }
      }
    });
    this.overlay.addEventListener("submit", (e) => {
      e.preventDefault();
      if (e.target.id === "world-form") this.startWorld(e.target);
      if (e.target.id === "chat-form") this.sendChat();
    });
    this.overlay.addEventListener("keydown", (e) => {
      const form = e.target.closest("#world-form");
      if (form && e.key === "Enter" && !e.target.closest("button")) {
        e.preventDefault();
        this.startWorld(form);
      }
    });
    this.overlay.addEventListener("change", (e) => {
      if (e.target.name === "relay-access") {
        const input = this.overlay.querySelector("#multiplayer-server");
        if (e.target.value === "public" && input) {
          try {
            if (!relayAddressInfo(input.value).publicHTTPS) input.value = "";
          } catch {
            input.value = "";
          }
        } else if (input && !input.value) input.value = "http://localhost:8787";
      }
      if (e.target.id === "import-world" && e.target.files?.[0])
        this.importWorld(e.target.files[0]);
    });
    this.overlay.addEventListener("input", (e) => {
      if (e.target.dataset.preference) {
        const key = e.target.dataset.preference,
          choices = VIDEO_CHOICES[key];
        const entry = choices?.find(
          ([value]) => String(value) === e.target.value,
        );
        if (entry) {
          this.game.settings[key] = entry[0];
          this.game.renderer.applyGraphics();
          this.saveSettings();
        }
      }
      if (e.target.dataset.setting) {
        const key = e.target.dataset.setting,
          value = Number(e.target.value);
        this.game.settings[key] = value;
        this.saveSettings();
        if (key === "graphics") {
          this.game.renderer.applyGraphics();
          this.saveSettings();
        }
        if (["mipmapLevels", "brightness", "biomeBlend"].includes(key))
          this.game.renderer.applyGraphics();
        if (key === "volume") this.game.audio.updateVolume();
        const output = this.overlay.querySelector(`[data-value="${key}"]`);
        if (output) output.textContent = this.settingValue(key, value);
      }
      if (e.target.dataset.cycle) {
        this.game.settings.cycleText[e.target.dataset.cycle] =
          e.target.value.slice(0, 140);
        this.saveSettings();
      }
      if (e.target.id === "recipe-search") {
        const q = e.target.value.toLowerCase();
        this.overlay
          .querySelectorAll(".recipe-card")
          .forEach((c) => (c.hidden = !c.dataset.name.includes(q)));
      }
      if (e.target.id === "creative-search") {
        const q = e.target.value.toLowerCase();
        this.overlay
          .querySelectorAll(".creative-slot")
          .forEach((c) => (c.hidden = !c.dataset.name.includes(q)));
      }
    });
    this.overlay.addEventListener("mousedown", (e) => {
      const cell = e.target.closest(".slot[data-ref]");
      if (!cell || this.screen !== "inventory") return;
      e.preventDefault();
      this.slotClick(cell, e);
    });
    this.overlay.addEventListener("mouseover", (e) => {
      const cell = e.target.closest(".slot[data-ref]");
      if (
        this.dragging &&
        cell &&
        e.buttons &&
        this.dragVisited?.has(cell.dataset.ref + cell.dataset.index) === false
      ) {
        this.dragVisited.add(cell.dataset.ref + cell.dataset.index);
        this.slotClick(cell, { button: 2, shiftKey: false, drag: true });
      }
    });
    addEventListener("mouseup", () => {
      this.dragging = false;
      this.dragVisited = null;
    });
    addEventListener("mousemove", (e) => {
      this.cursorEl.style.transform = `translate(${e.clientX + 12}px,${e.clientY + 12}px)`;
      this.tooltip.style.left =
        Math.min(innerWidth - 220, e.clientX + 16) + "px";
      this.tooltip.style.top =
        Math.min(innerHeight - 80, e.clientY + 20) + "px";
      const s = e.target.closest("[data-tooltip]");
      this.tooltip.hidden = !s || !!this.game.inventory.cursor;
      if (s) this.tooltip.textContent = s.dataset.tooltip;
    });
  }
  startWorld(form) {
    if (!form || this.creatingWorld || !form.reportValidity()) return;
    this.creatingWorld = true;
    const button = form.querySelector('[data-action="start-world"]');
    if (button) button.disabled = true;
    // A script-enabled HTML preview may prohibit native form submission.
    // Read the fields and call the game directly instead of navigating a form.
    this.game
      .newWorld(Object.fromEntries(new FormData(form)))
      .catch((error) => this.error(error.message))
      .finally(() => {
        this.creatingWorld = false;
        if (button?.isConnected) button.disabled = false;
      });
  }
  header(active = "play") {
    if (!this.game.active || active !== "settings") return "";
    return `<nav class="pause-options-nav" aria-label="Pause options"><button class="secondary" data-action="resume">Back to Game</button><button class="secondary" data-action="guide">Controls</button><button class="secondary" data-action="skins">Skins</button><button class="secondary" data-action="features">Feature checklist</button></nav>`;
  }
  setScreen(screen, html) {
    this.screen = screen;
    this.hud.hidden = screen !== "play";
    this.overlay.className = screen === "play" ? "" : "visible";
    this.overlay.dataset.screen = screen;
    this.overlay.innerHTML = html;
    this.cursorEl.hidden = screen !== "inventory";
    this.tooltip.hidden = true;
  }
  async title() {
    this.game.running = false;
    this.game.resetControls();
    this.setScreen(
      "title",
      `${this.header()}<main class="title-layout block-title"><section class="hero"><h1>DCSMCRAFT</h1><div class="title-splash">One file. A whole world.</div></section><section class="world-panel"><h2 class="sr-only">Singleplayer</h2><div id="recent-world"></div><button class="primary wide" data-action="create">Create a world</button><button class="primary wide saved-worlds" data-action="worlds">Your saved worlds <span id="world-count">0</span></button><button class="secondary wide" data-action="multiplayer">Multiplayer · Survival & Creative</button><div class="title-button-grid"><button class="secondary" data-action="settings">Options</button><button class="secondary" data-action="guide">How to play</button></div><div class="title-button-grid"><button class="secondary" data-action="skins">Skins</button>${window.DCSMCRAFT_HTML_SOURCE ? '<button class="secondary" data-action="download-game">Save game HTML</button>' : '<button class="secondary" data-action="guide">Controls</button>'}</div><p class="offline-note">Singleplayer works offline. Your worlds stay on this device.</p></section></main><footer class="title-footer"><div class="footer-line"><span>v${VERSION} · Original code, graphics & sound</span><span>Reference: ${REFERENCE}</span><button data-action="features">Independent sandbox · Feature checklist</button></div></footer>`,
    );
    try {
      const worlds = await this.game.store.list();
      if (this.screen !== "title") return;
      this.overlay.querySelector("#world-count").textContent = worlds.length;
      if (worlds.length) {
        const w = worlds[0];
        this.overlay.querySelector("#recent-world").innerHTML =
          `<button class="recent-world" data-action="load" data-id="${esc(w.id)}"><span class="world-thumb">${cube}</span><span><small>CONTINUE YOUR STORY</small><b>${esc(w.name)}</b></span><span>→</span></button>`;
      }
    } catch (e) {
      this.toast("Browser storage is unavailable: " + e.message, 7000);
    }
  }
  multiplayerMenu(invite = "") {
    const m = this.game.multiplayer;
    const suggested =
      readSavedRelay() ||
      (location.protocol === "http:" || location.protocol === "https:"
        ? location.origin
        : "http://localhost:8787");
    const publicMode = relayAddressInfo(suggested).publicHTTPS;
    this.setScreen(
      "multiplayer",
      `<main class="dialog multiplayer-dialog"><div class="dialog-top"><button class="close" data-action="back" aria-label="Back">×</button></div><h2>Multiplayer · Survival & Creative</h2><p>Up to 8 players. The host's game runs and saves the shared world. Survival beta: shared mining, inventories, crafting, chests/furnaces, combat, death and respawn. T opens chat; / opens owner commands. Keep the host online. Dimension travel, guest trading/enchanting and PvP remain unavailable.</p>${m.connected ? `<section class="session-panel"><h3>World: ${esc(this.game.name)}</h3><label>Invitation link<input id="session-invite" value="${esc(m.invite)}" readonly/></label><button class="secondary wide" data-action="copy-invite">Copy Invitation</button><p class="relay-badge">${relayAddressInfo(m.invite).publicHTTPS ? "PUBLIC HTTPS · ENCRYPTED WSS" : relayAddressInfo(m.invite).secure ? "HTTPS/WSS · LOCAL ADDRESS" : "HTTP/WS · LOCAL / LAN ADDRESS"}</p><p class="fine">Share this link with people you trust. Keep the host game and relay open. A localhost address works only on this PC; use your LAN address or a public HTTPS server for other players.</p><div id="session-players"></div><div id="chat-log" role="log" aria-live="polite"></div><form id="chat-form"><label>Message<input id="chat-message" maxlength="160" autocomplete="off" placeholder="Say hello…"/></label><button type="submit" class="secondary">Send</button></form><button class="secondary wide" data-action="disconnect-multiplayer">${m.isGuest ? "Leave Server" : "Close Co-op"}</button></section>` : `<label>Your name<input id="multiplayer-name" maxlength="20" value="Player" autocomplete="nickname"/></label><section class="multiplayer-choices"><div><h3>Host a World</h3><p>Open a Survival or Creative world, pause, then return here.</p><fieldset class="relay-access"><legend>Relay connection</legend><label><input type="radio" name="relay-access" value="public" ${publicMode ? "checked" : ""}>Public HTTPS · different networks</label><label><input type="radio" name="relay-access" value="local" ${!publicMode ? "checked" : ""}>Local / LAN</label></fieldset><label>Relay address<input id="multiplayer-server" value="${esc(suggested)}" placeholder="https://your-relay.trycloudflare.com"/></label><button class="secondary wide" data-action="test-relay">Test Relay Connection</button><p class="fine">For a public address, run HOST-PUBLIC.cmd from the server download. Paste its HTTPS address here, open your world to friends, then share the invitation. Node.js and cloudflared are required. Temporary hosting ends when that window closes.</p><button class="secondary wide" data-action="connect-multiplayer" data-role="host" ${!this.game.active ? "disabled" : ""}>Open This World to Friends</button></div><div><h3>Join a World</h3><label>Invitation link<input id="multiplayer-invite" value="${esc(invite)}" placeholder="Paste the full invitation link"/></label><button class="secondary wide" data-action="connect-multiplayer" data-role="guest">Join World</button></div></section><p class="fine">Hosting needs the included Node.js relay: run npm install, npm run build:standalone, then npm run multiplayer. It serves the game at port 8787. For friends on different networks, use a publicly reachable HTTPS/WSS relay. The download includes internet deployment instructions; an invitation alone cannot open a router or create a public server. Offline singleplayer needs no server.</p>`}<div id="multiplayer-status" role="status"></div><button class="primary wide" data-action="back">Done</button></main>`,
    );
    if (m.connected) this.updateSession();
  }
  async testRelay(button) {
    const status = this.overlay.querySelector("#multiplayer-status");
    button.disabled = true;
    status.textContent = "Checking secure WebSocket connection…";
    try {
      const info = await probeRelay(
        this.overlay.querySelector("#multiplayer-server").value,
        {
          access:
            this.overlay.querySelector("[name=relay-access]:checked")?.value ||
            "local",
        },
      );
      if (status.isConnected)
        status.textContent = info.publicHTTPS
          ? "Connected via encrypted WSS. Keep the public relay running; friends can use its invitation."
          : "Relay connected. This local address is for this PC/LAN; use Public HTTPS for other networks.";
      saveRelay(info.url);
    } catch (error) {
      if (status.isConnected) status.textContent = error.message;
    } finally {
      if (button.isConnected) button.disabled = false;
    }
  }
  async connectMultiplayer(button) {
    const status = this.overlay.querySelector("#multiplayer-status");
    button.disabled = true;
    status.textContent = "Connecting…";
    try {
      const server = this.overlay.querySelector("#multiplayer-server")?.value;
      const invite =
        button.dataset.role === "guest"
          ? this.overlay.querySelector("#multiplayer-invite").value
          : null;
      if (invite && this.game.active)
        throw Error(
          "Save and quit your current world before joining another host.",
        );
      if (!invite && server)
        validateRelayAccess(
          server,
          this.overlay.querySelector("[name=relay-access]:checked")?.value ||
            "local",
        );
      const name = this.overlay.querySelector("#multiplayer-name").value;
      await this.game.multiplayer.connect({ server, name, invite });
      if (!invite && server) saveRelay(server);
      if (this.game.multiplayer.isGuest) {
        // The browser may require another gesture for pointer lock after joining.
        this.game.pause();
        this.pause(
          "Connected! Press Back to Game to explore with your friends.",
        );
      } else this.multiplayerMenu();
    } catch (e) {
      if (status.isConnected) status.textContent = e.message;
      else this.toast(e.message, 7000);
    } finally {
      if (button.isConnected) button.disabled = false;
    }
  }
  updateSession() {
    const m = this.game.multiplayer,
      players = this.overlay.querySelector("#session-players"),
      log = this.overlay.querySelector("#chat-log");
    if (players)
      players.innerHTML = `<h3>Players (${m.players.length}/8) · ${m.ping ?? "—"} ms</h3>${m.players.map((p) => `<div class="session-player"><span>${esc(p.name)}${p.host ? " · Host" : ""}</span>${!m.isGuest && !p.host ? `<button class="secondary" data-action="kick-player" data-id="${esc(p.id)}">Remove</button>` : ""}</div>`).join("")}`;
    if (log) {
      log.innerHTML = m.chat
        .map((line) => `<p><b>${esc(line.name)}</b>: ${esc(line.message)}</p>`)
        .join("");
      log.scrollTop = log.scrollHeight;
    }
  }
  sendChat() {
    const input = this.overlay.querySelector("#chat-message");
    if (input?.value.trim()) {
      this.game.chat.send(input.value);
      input.value = "";
    }
  }
  async copyInvite() {
    const input = this.overlay.querySelector("#session-invite");
    if (!input) return;
    try {
      await navigator.clipboard.writeText(input.value);
      this.toast("Invitation copied.");
    } catch {
      input.focus();
      input.select();
      this.toast("Press Ctrl+C to copy the selected invitation.");
    }
  }
  skins() {
    this.setScreen(
      "skins",
      `${this.header()}<main class="dialog skin-dialog"><div class="dialog-top"><button class="close" data-action="back" aria-label="Back">×</button></div><h2>The Outfit Chest</h2><p>Pick an adventurer. Your outfit stays on this device and follows you into every world. Press F5 in game to see it.</p><div class="skin-grid">${Object.entries(
        SKINS,
      )
        .map(
          ([id, s]) =>
            `<button class="skin-card secondary" data-action="choose-skin" data-skin="${id}" aria-pressed="${this.game.settings.skin === id}"><img src="${skinPreview(id)}" alt="${esc(s.name)} outfit"/><strong>${esc(s.name)}</strong><small>${esc(s.story)}</small><span>${this.game.settings.skin === id ? "Wearing this outfit" : "Wear this outfit"}</span></button>`,
        )
        .join(
          "",
        )}</div><p class="fine">${Object.keys(SKINS).length} outfits. Equipment is worn over your outfit.</p><button class="primary wide" data-action="back">Done</button></main>`,
    );
  }
  create() {
    this.setScreen(
      "create",
      `${this.header()}<main class="dialog create-dialog"><form id="world-form"><div class="dialog-top"><span class="eyebrow">NEW WORLD</span><button type="button" class="close" data-action="title" aria-label="Close">×</button></div><h2>Create New World</h2><label>WORLD NAME<input name="name" maxlength="48" value="A little wilderness" required autocomplete="off"/></label><label>WORLD SEED <small>Optional · letters or numbers</small><input name="seed" maxlength="80" placeholder="Leave a little up to chance" autocomplete="off"/></label><fieldset><legend>HOW WILL YOU PLAY?</legend><label class="radio-card"><input type="radio" name="mode" value="survival" checked/><span><b>Survival</b><small>Gather. Craft. Make it through the night.</small></span><span>◈</span></label><label class="radio-card"><input type="radio" name="mode" value="creative"/><span><b>Creative</b><small>Every available block. Free flight. Your imagination.</small></span><span>▧</span></label></fieldset><label class="select-label">DIFFICULTY<select name="difficulty"><option value="peaceful">Peaceful</option><option value="easy">Easy</option><option value="normal" selected>Normal</option><option value="hard">Hard</option></select></label><button class="primary wide" type="button" data-action="start-world">Let's make a world ${arrow}</button><p class="form-note">Pixel &amp; Grip · New menus, item artwork and connected first-person arms work in existing worlds. Create a new world for the Cave Update terrain. Some reference systems remain incomplete.<br/><button type="button" data-action="features">Read the feature checklist ${arrow}</button></p></form></main>`,
    );
  }
  async worlds() {
    this.setScreen(
      "worlds",
      `${this.header()}<main class="dialog list-dialog"><div class="dialog-top"><span class="eyebrow">THE WORLD SHELF</span><button class="close" data-action="title" aria-label="Close">×</button></div><h2>Your Worlds</h2><p class="muted">Saved on this device, in this browser. Export a backup before clearing browser data.</p><div id="world-list" class="world-list">Finding your worlds…</div><div class="world-list-actions"><button class="primary" data-action="create">Create another world ${arrow}</button><label class="import-button">Import backup<input id="import-world" type="file" accept="application/json,.json" hidden/></label></div></main>`,
    );
    try {
      const worlds = await this.game.store.list();
      if (this.screen !== "worlds") return;
      this.overlay.querySelector("#world-list").innerHTML = worlds.length
        ? worlds
            .map(
              (w) =>
                `<article class="world-row"><div class="world-thumb">${cube}</div><div class="world-details"><h3>${esc(w.name)}</h3><p>${esc(w.mode)} · Day ${w.day} · Seed ${esc(w.seed)}</p><small>${new Date(w.updated).toLocaleString()}</small></div><button class="primary small" data-action="load" data-id="${esc(w.id)}">Play →</button><button class="icon-button" data-action="export" data-id="${esc(w.id)}" title="Export world backup">↓</button><button class="icon-button" data-action="delete" data-id="${esc(w.id)}" title="Delete world">×</button></article>`,
            )
            .join("")
        : `<div class="empty-state">${cube}<h3>No saved worlds yet.</h3><p>Create a world to fill this shelf.</p></div>`;
    } catch (e) {
      this.error(e.message);
    }
  }
  async importWorld(file) {
    try {
      if (file.size > 20 * 1024 * 1024)
        throw new Error("The backup is larger than 20 MB.");
      const data = JSON.parse(await file.text());
      if (
        data.format !== 1 ||
        typeof data.seed !== "string" ||
        !data.player ||
        !data.inventory ||
        !data.edits ||
        !["survival", "creative"].includes(data.mode)
      )
        throw new Error("This is not a supported DCSMCRAFT backup.");
      for (const s of [
        ...(data.inventory.slots || []),
        ...(data.inventory.craft || []),
        ...(data.inventory.equipment || []),
        data.inventory.cursor,
      ])
        if (
          s &&
          (!ITEMS[s.id] ||
            !Number.isInteger(s.count) ||
            s.count < 1 ||
            s.count > ITEMS[s.id].stack)
        )
          throw new Error("Invalid inventory in backup.");
      for (const [pos, id] of Object.entries(data.edits))
        if (
          !/^-?\d+,-?\d+,-?\d+$/.test(pos) ||
          !Number.isInteger(id) ||
          !BLOCKS[id]
        )
          throw new Error("Invalid terrain edits in backup.");
      if (
        ![data.player.x, data.player.y, data.player.z, data.time].every(
          Number.isFinite,
        )
      )
        throw new Error("Invalid player data in backup.");
      data.id = uniqueId();
      data.name = String(data.name || "Imported world").slice(0, 48);
      await this.game.store.save(data);
      this.worlds();
      this.toast("Backup imported as a separate world.");
    } catch (e) {
      this.toast("Import failed: " + e.message, 6000);
    }
  }
  async exportWorld(id) {
    try {
      const { data } = await this.game.store.load(id),
        url = URL.createObjectURL(
          new Blob([JSON.stringify(data)], { type: "application/json" }),
        ),
        a = document.createElement("a");
      a.href = url;
      a.download = `dcsmcraft-${data.name.replace(/[^a-z0-9]/gi, "-")}.json`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      this.toast("World backup exported.");
    } catch (e) {
      this.toast(e.message);
    }
  }
  loading(message) {
    this.setScreen(
      "loading",
      `<div class="loading-screen">${cube}<h2>${esc(message)}</h2><span class="loading-dots">■ ■ ■</span><p>ONE BLOCK AT A TIME</p></div>`,
    );
  }
  error(message) {
    this.setScreen(
      "error",
      `<main class="dialog compact"><span class="eyebrow">A BUMP IN THE TRAIL</span><h2>Let's find our feet.</h2><p>${esc(message)}</p><button class="primary" data-action="${this.game.active ? "resume" : "title"}">${this.game.active ? "Return to world" : "Back to title"} →</button></main>`,
    );
  }
  play() {
    this.lastHUD = null;
    this.setScreen("play", "");
    this.hud.innerHTML = `<div class="hud-brand">${cube}<span>DCSMCRAFT<small id="hud-biome"></small></span></div><div class="world-clock"><span id="day-icon">☀</span><span id="day-label"></span><span class="clock-rule"></span><small id="mode-label"></small></div><div id="target-label"></div><div id="crosshair"><i></i><i></i></div><div id="attack-cooldown" role="progressbar" aria-label="Attack recovery" aria-valuemin="0" aria-valuemax="100" hidden><i></i></div><div id="mining-bar"><i></i></div><div id="hurt-vignette"></div><div id="water-vignette"></div><div id="fps-counter"></div><div id="hud-debug" hidden></div><div class="hud-bottom"><div id="weapon-moves" aria-label="Weapon moves" hidden></div><div class="selected-name" id="selected-name"></div><div id="survival-bars"><div id="armor-bar"></div><div id="oxygen"></div><div class="vital-row"><div id="hearts"></div><div id="hunger"></div></div><div class="xp-line"><span id="xp-level"></span><i id="xp-fill"></i></div></div><div id="hotbar" class="hotbar"></div><div class="hud-hint"><span><kbd>E</kbd> Inventory</span><span><kbd>ESC</kbd> Pause & controls</span><span id="save-status">${this.game.multiplayer?.isGuest ? "SAVED BY HOST" : this.game.store.temporary ? "SESSION ONLY · EXPORT TO KEEP" : "SAVED LOCALLY"}</span></div></div>`;
    this.updateHotbar();
    this.updateHUD();
  }
  pause(message = "Game paused.") {
    this.game.running = false;
    this.setScreen(
      "pause",
      `<div class="pause-shade"></div><main class="dialog compact pause-dialog"><div class="pause-mark">${cube}</div><div class="eyebrow">${esc(this.game.name)}</div><h2>Game Menu</h2><p>${esc(message)}</p><button class="primary wide" data-action="resume">Back to Game</button><div class="pause-actions"><button class="secondary" data-action="settings">Settings</button><button class="secondary" data-action="guide">Field guide</button></div><button class="secondary wide" data-action="multiplayer">${this.game.multiplayer?.connected ? "Co-op · Players & Chat" : "Open Survival / Creative Co-op"}</button><button class="secondary wide" data-action="world-chat">Chat & Owner Commands</button><button class="secondary wide" data-action="journal">Relic Journal</button><button class="secondary wide" data-action="jukebox">Jukebox · YouTube player</button><button class="secondary wide" data-action="cinder-guide">Cinderworld Expedition</button>${this.game.mode === "creative" ? '<button class="secondary wide" data-action="weather">Weather</button>' : ""}${!this.game.multiplayer?.isGuest ? '<button class="secondary wide" data-action="backup-current">Export world backup</button>' : ""}${window.DCSMCRAFT_HTML_SOURCE ? '<button class="secondary wide" data-action="download-game">Save game HTML</button>' : ""}<button class="text-button wide" data-action="quit">${this.game.multiplayer?.isGuest ? "Leave Server" : "Save and Quit to Title"}</button><span class="pause-foot">${this.game.multiplayer?.connected ? "SHARED WORLD KEEPS RUNNING" : "SIMULATION PAUSED · AUTOSAVE EVERY 30 SECONDS"}</span></main>`,
    );
  }
  settingValue(key, value) {
    if (key === "graphics")
      return [
        "50% · Fast",
        "70% · Low",
        "100% · Native",
        "125% · High",
        "150% · Ultra",
      ][value - 1];
    if (key === "cloudHeight") return `Y ${Math.round(value)}`;
    if (key === "brightness") return `${Math.round(value * 100)}%`;
    if (key === "entityDistance") return `${Math.round(value * 100)}%`;
    if (key === "mipmapLevels") return value === 0 ? "OFF" : `${value} levels`;
    if (key === "biomeBlend")
      return value === 0 ? "OFF" : `${value} block radius`;
    return key === "sensitivity"
      ? `${Math.round((value / 0.002) * 100)}%`
      : ["volume", "ambientVolume", "mobVolume", "musicVolume"].includes(key)
        ? `${Math.round(value * 100)}%`
        : key === "FOV"
          ? `${value}°`
          : `${value} chunks`;
  }
  weather() {
    const w = this.game.world.weather;
    this.setScreen(
      "weather",
      `${this.header()}<main class="dialog compact"><div class="dialog-top"><button class="close" data-action="back" aria-label="Back">×</button></div><h2>Weather</h2><p>Creative control · Current sky: ${esc(w.kind)}. Cold biomes receive snow; deserts stay dry. Weather fades in gradually.</p><div class="weather-options">${[
        ["auto", "Natural cycle"],
        ["clear", "Clear skies"],
        ["rain", "Rain / snow"],
        ["thunder", "Thunderstorm"],
        ["hail", "Hailstorm"],
        ["tornado", "Tornado"],
      ]
        .map(
          ([key, label]) =>
            `<button class="secondary wide" data-action="set-weather" data-weather="${key}" aria-pressed="${(w.override || "auto") === key}">${label}</button>`,
        )
        .join(
          "",
        )}</div><p class="fine">Thunderstorms have rain, distant lightning and thunder. Hail hurts exposed players; tornado funnels pull and lift nearby players. Solid roofs shelter both. Funnels never destroy your buildings. Peaceful/Creative disable weather damage. Snow is visual, without accumulating layers. Natural weather and Creative overrides save with the world.</p><button class="primary wide" data-action="back">Done</button></main>`,
    );
  }
  settings() {
    const fields = [
      ["graphics", "Resolution scale", 1, 5, 1],
      ["sensitivity", "Mouse sensitivity", 0.0005, 0.005, 0.0001],
      ["FOV", "Field of view", 55, 110, 1],
      ["volume", "Master volume", 0, 1, 0.05],
      ["ambientVolume", "Ambient volume", 0, 1, 0.05],
      ["mobVolume", "Creature volume", 0, 1, 0.05],
      ["musicVolume", "Music volume", 0, 1, 0.05],
      ["renderDistance", "Render distance", 2, 24, 1],
    ];
    this.setScreen(
      "settings",
      `${this.header("settings")}<main class="dialog settings-dialog"><div class="dialog-top"><span class="eyebrow">OPTIONS</span><button class="close" data-action="back" aria-label="Back">×</button></div><h2>Options</h2><p class="muted">Your preferences stay with this browser.</p><button class="secondary wide" data-action="video-settings">Video Settings...</button><div class="options-sliders">${fields.map(([key, label, min, max, step]) => `<label class="range-label"><span>${label}<output data-value="${key}">${this.settingValue(key, this.game.settings[key])}</output></span><input type="range" data-setting="${key}" min="${min}" max="${max}" step="${step}" value="${this.game.settings[key]}"/></label>`).join("")}</div><div class="title-button-grid">${[
        ["ambientSounds", "World Ambience"],
        ["mobSounds", "Creature Voices"],
        ["musicEnabled", "Music"],
      ]
        .map(
          ([key, label]) =>
            `<button class="secondary" data-action="toggle-audio" data-audio="${key}" aria-pressed="${this.game.settings[key]}">${label}: ${this.game.settings[key] ? "ON" : "OFF"}</button>`,
        )
        .join(
          "",
        )}</div><p class="fine">Music plays original, evolving piano and bell pieces while exploring. World Ambience follows the biome, water, shelter and weather without repeating short loops.</p><fieldset class="cycle-settings"><legend>Custom day & night messages</legend>${Object.entries(
        {
          dayEnd: "Sunset · day ending",
          nightStart: "Night begins",
          nightEnd: "Dawn · night ending",
          dayStart: "Day begins",
        },
      )
        .map(
          ([key, label]) =>
            `<label>${label}<input data-cycle="${key}" value="${esc(this.game.settings.cycleText[key])}" maxlength="140"/></label>`,
        )
        .join(
          "",
        )}<div class="title-button-grid"><button class="secondary" data-action="preview-cycle">Preview messages</button><button class="secondary" data-action="reset-cycle">Restore messages</button></div><div id="message-preview" role="status">Your messages appear at sunset, nightfall, dawn, and sunrise. An empty line disables that message.</div></fieldset><p class="settings-note">Resolution scale changes pixel resolution. Clouds, particles and view distance have independent controls.<br/>All textures, sounds, and code are included in the standalone HTML. The optional Supplied Assets pack contains attributed Minecraft artwork.</p><button class="primary wide" data-action="back">Done</button></main>`,
    );
  }
  videoSettings() {
    const s = this.game.settings;
    const field = ([key, label, ...args]) => {
      if (Array.isArray(args[0]))
        return `<label class="video-choice"><span>${label}</span><select data-preference="${key}" aria-label="${label}">${args[0].map(([value, name]) => `<option value="${value}" ${s[key] === value ? "selected" : ""}>${name}</option>`).join("")}</select></label>`;
      if (args.length)
        return `<label class="range-label"><span>${label}<output data-value="${key}">${this.settingValue(key, s[key])}</output></span><input aria-label="${label}" type="range" data-setting="${key}" min="${args[0]}" max="${args[1]}" step="${args[2]}" value="${s[key]}"/></label>`;
      return `<button class="secondary" data-action="toggle-graphics" data-graphics="${key}" aria-pressed="${s[key]}">${label}: ${s[key] ? "ON" : "OFF"}</button>`;
    };
    const group = ([name, note, fields]) =>
      `<section class="video-group"><h3>${name}</h3><p>${note}</p><div class="video-fields">${fields.map(field).join("")}</div></section>`;
    this.setScreen(
      "video",
      `${this.header("settings")}<main class="dialog settings-dialog video-dialog"><div class="dialog-top"><span class="eyebrow">GRAPHICS</span><button class="close" data-action="back" aria-label="Back">×</button></div><h2>Video Settings</h2><p class="video-intro">Set the view for your next expedition. Changes apply as you make them.</p><div class="video-groups"><div class="video-column">${[VIDEO_GROUPS[0], VIDEO_GROUPS[3]].map(group).join("")}</div><div class="video-column">${[VIDEO_GROUPS[1], VIDEO_GROUPS[2]].map(group).join("")}</div></div><p class="settings-note">Supplied Assets uses the uploaded Minecraft block textures and item icons; custom content keeps Renewed artwork. Creature and weapon models use DCSMCRAFT designs across all packs; menus keep their existing style. Animated strips use their first frame with the existing fluid shimmer.<br/>Detailed terrain loads within four chunks; simplified voxel surfaces extend through eight, then batched heightfields reach 24. Distant trees/buildings are approximate. Biome Blend samples the center and four neighboring biome colors, rather than the reference's full area filter. Fancy Graphics controls torch lights; Animated Textures controls fluid shimmer. Creature Animations freezes idle/walk joints while combat warnings stay visible. Shadows cost extra GPU time.</p><div class="title-button-grid"><button class="secondary" data-action="fullscreen">Toggle Fullscreen</button><button class="primary" data-action="back">Done</button></div></main>`,
    );
  }

  enchanting(index = -1) {
    this.enchantIndex = index;
    const g = this.game,
      stack = g.inventory.slots[index],
      item = ITEMS[stack?.id];
    this.setScreen(
      "enchanting",
      `<main class="dialog enchanting-dialog"><div class="dialog-top"><span class="eyebrow">ENCHANTING TABLE</span><button class="close" data-action="close-inv" aria-label="Close enchanting">×</button></div><h2>Enchant Equipment</h2><p>Choose an item below. Each upgrade costs XP points and lapis; Creative upgrades are free.</p><div class="enchant-selected">${stack ? itemHTML(stack) : "Select a weapon, tool or armor piece"}<strong>${esc(item?.name || "Your equipment")}</strong><small>${esc(enchantText(stack))}</small></div><div class="enchant-options">${Object.entries(
        ENCHANTMENTS,
      )
        .map(([id, e]) => {
          const level = enchantLevel(stack, id) + 1,
            cost = enchantCost(level),
            valid = e.fits(item) && level <= e.max;
          return `<button class="secondary" data-action="enchant-item" data-enchantment="${id}" ${!valid ? "disabled" : ""}>${e.name} ${level > e.max ? "MAX" : level}<small>${cost.xp} XP + ${cost.lapis} lapis</small></button>`;
        })
        .join(
          "",
        )}</div><p>${Math.floor(g.player.xp)} XP points available · Costs apply only when an upgrade succeeds.</p><div class="slot-grid nine enchant-inventory">${g.inventory.slots.map((s, i) => `<button class="slot ${i === index ? "chosen" : ""}" data-action="enchant-select" data-index="${i}" aria-label="${esc(ITEMS[s?.id]?.name || "Empty slot")}" ${!s || !Object.values(ENCHANTMENTS).some((e) => e.fits(ITEMS[s.id])) ? "disabled" : ""}>${itemHTML(s)}</button>`).join("")}</div><p class="fine">Deterministic upgrades: Sharpness, Efficiency, Unbreaking, Protection, Feather Falling and Knockback. This is a simplified enchanting system, without bookshelf power, random offers, lapis tiers or anvil combining.</p><button class="primary wide" data-action="close-inv">Done</button></main>`,
    );
  }
  arsenalGuide() {
    const g = this.game,
      s = invasionState(g.world);
    return `<h3>Matthew's Dual Wielded Pistols</h3><p>A rare Cinderworld incursion can open untouched, loaded Overworld ground near you. From the second minute onward, each 30-second check has a 25% chance, provided a dry clearing is available. Peaceful pauses encounters. Tentacles open a fissure, then a shrine rises. Defeat its four elite persistent Hellspawn (two Soul Reavers, a Dread Knight and a Magma Maw) and right-click the rune altar with an empty inventory slot. Each world awards one pair. While sealed, the orb fires dangerous random bullets; use cover. Nearby tentacles have a 25% grab chance per five-second check, with a two-second escape warning. In single-player Survival, a completed grab drags you into Cinderworld to face A Mad Titan: 320 health, bullet immunity and four telegraphed special attacks. The recovery alcove has a one-time equipment chest and remains your respawn point until victory. Defeat the Titan, then right-click its return rune to resume the incursion. Co-op tentacle abduction is unavailable.</p><p class="relic-coordinates">${s && s.phase !== "waiting" ? `X ${s.x} · Y ${s.y} · Z ${s.z} · ${esc(s.phase.toUpperCase())} · ${s.defeated.length}/${INVADERS.length} Hellspawn defeated` : "No incursion discovered yet. Explore open, dry ground."}</p><p><strong>Hold left-click</strong> for alternating, rune-powered shots: 5 damage, 40-block reach, no ammunition. <strong>Right-click + WASD</strong>: Dash; in the air: Sky Star (once per jump). <strong>R</strong>: Air Trick toward any aimed, visible creature within 18 blocks, or free-blink toward your crosshair if none is targeted. Free aim stops before blocks; a blocked creature approach fails without spending a charge. Grounded downward aim stays level. <strong>Space + right-click beside a wall</strong> while airborne: Wall Hike. Two style charges recover individually in two seconds; Air Trick also recharges for five seconds. Movement sweeps stop at walls. No invulnerability or fall immunity.</p><p class="fine">Original code, models and sound. The four evasive moves are inspired by Dante’s Trickster style in Devil May Cry 3; this is a custom adaptation, without its complete combat, lock-on or upgrade system. Creative co-op supports host-approved shots, Dash, Sky Star and Wall Hike; Air Trick and the unique reward are host-only.</p>${g.mode === "creative" && g.dimension === "overworld" && !g.multiplayer?.isGuest && (!s || s.phase === "waiting") ? '<button class="secondary wide" data-action="summon-incursion">Call an incursion · Creative</button>' : ""}`;
  }
  journal(site) {
    const claimed = this.game.world.relicClaimed;
    this.setScreen(
      "journal",
      `<main class="dialog compact relic-journal"><div class="dialog-top"><span class="eyebrow">RELIC JOURNAL</span><button class="close" data-action="back" aria-label="Close journal">×</button></div><h2>The Devin Sword</h2><p>A runed star-metal blade sleeps in ancient stone.</p><p class="relic-coordinates">${claimed ? "CLAIMED IN THIS WORLD" : site ? `Overworld · X ${site.x} · Y ${site.y} · Z ${site.z}` : "Create a new Overworld world for a relic site."}</p>${site?.temple ? `<p>Temple seal: <strong>${Math.min(3, this.game.world.settlements?.["devin-temple"]?.defeated?.length || 0)} / 3 Guardians defeated</strong>. This temple is far from spawn. Bring iron/diamond or Hellfire equipment and food. Fresh Guardians have 140 health, 35% damage resistance and bulletproof armor. Their melee attacks deal 12 damage before armor; six telegraphed special attacks are also stronger. Bullets do no damage; use enchanted blades, spears or magic. Watch the amber warnings: jump the shockwave, dodge aimed volleys and lunges, and flank the sweeping cleave. Leave the cyan ground sigil before it erupts and slows you. Wounded Guardians recover faster. In new temples the inner sanctuary stays sealed until all three fall. Melee strikes also have a visible wind-up. They stay near the temple and do not return after defeat. Defeat all three to release the seal. All three Guardians must be defeated before the planted sword can be extracted, including in Creative and Peaceful. Peaceful pauses their attacks.</p>` : ""}<p>${this.game.world.generationVersion >= 11 ? `Outer ward: <strong>${this.game.world.settlements?.["devin-temple"]?.attuned ? "ATTUNED" : "CINDER SIGIL REQUIRED"}</strong>. Defeat the six defenders of a Cinderworld vault, claim its Cinder Sigil, hold it and right-click the front cyan ward. Cross the narrow bridge over the moat. The inner sword seal still needs all three Guardians defeated.` : "This older temple retains its original entry and requires no Cinder Sigil."}</p><p>Hold left click on the planted sword for <strong>30 uninterrupted seconds</strong>. Releasing, looking away, pausing, taking damage or leaving reach resets extraction. Keep an inventory slot free.</p><p><strong>Unbreakable.</strong> Fully charged hits restore one health point. Right-click for <strong>Devin's Pulse</strong>: eight damage and collision-safe knockback to visible hostiles within seven blocks. Animals and villagers are spared. Ten-second recharge; cooldown survives saves.</p><p>Press <strong>R</strong> for <strong>Devin's Seeker</strong>: a luminous homing bolt deals 12 damage to a visible hostile within 28 blocks. The bolt turns toward moving targets, collides with walls, and ignores peaceful creatures. Fourteen-second recharge, saved with the player. No target means no cooldown.</p><p class="fine">Spears and The Devin Sword are original additions beyond the Java Edition 1.20.4 reference.</p>${this.arsenalGuide()}<button class="primary wide" data-action="back">Back</button></main>`,
    );
  }
  cinderGuide() {
    const w = this.game.world,
      p = this.game.player;
    const sites =
      w.dimension === "cinderwild"
        ? nearbyCinderSites(w, p.x, p.z, 560)
            .sort(
              (a, b) =>
                Math.hypot(a.x - p.x, a.z - p.z) -
                Math.hypot(b.x - p.x, b.z - p.z),
            )
            .slice(0, 3)
        : [];
    this.setScreen(
      "cinder-guide",
      `${this.header()}<main class="dialog compact"><h2>Cinderworld Expedition</h2><p>${w.generationVersion >= 11 ? "Beyond the obsidian portal: six infernal regions, deep lava rifts, jagged spires and enormous strongholds." : "Beyond the obsidian portal: four volcanic regions, exclusive resources and guarded relics."}</p><ol><li>Bring a diamond pickaxe, an iron pickaxe, food, blocks and flint and steel.</li><li>Search caves between Y 15 and 70. Orange Hellfire veins need diamond; yellow Brimstone needs iron. Veins are uncommon coherent clusters.</li><li>Smelt Raw Hellfire in a furnace. Craft 2 Hellfire ingots + 1 Brimstone into 2 Hellfire alloy, using the personal grid.</li><li>Use alloy in the usual armor/tool/spear recipes. Hellfire tools exceed diamond speed/durability. Each armor piece adds 10% lava/fire resistance; a full set adds 40%, without immunity.</li><li>${w.generationVersion >= 11 ? "Explore the Citadel of the Damned, Cathedral of Souls and Hellfire Crucible. Six persistent defenders bind each vault: defeat them all to open its amber ward. Breaking the chest cannot bypass its defenders. Rewards include a Cinder Sigil, powerful enchanted Hellfire equipment, alloy and diamonds. Take the Sigil to the Devin Temple and use it on the front cyan ward. Dread knights telegraph a jumpable ground slam; soul reavers cast aimed three-bolt volleys; magma maws wind up a straight charge. Dodge, use cover, and bring armor." : "Explore Emberwatch bastions, crystal shrines and ruined waystations. Chests contain supplies and rare crafting resources; bastions/shrines have defenders."}</li></ol><p>Ash deer are peaceful. Cinderbacks retaliate when attacked. Basalt crawlers and cinder wraiths are hostile, alongside emberlings. All use original models and voices.</p>${sites.length ? `<h3>Nearby expeditions</h3><ul>${sites.map((v) => `<li>${esc(v.name || v.kind)} · X ${v.x} / Y ${v.y + 1} / Z ${v.z}</li>`).join("")}</ul>` : `<p class="fine">New world terrain or a first visit to Cinderworld unlocks the new generator. Previously visited realms keep their old landscape. Build a 4×5 obsidian frame with a 2×3 opening and ignite it to travel.</p>`}<button class="primary wide" data-action="back">Back</button></main>`,
    );
  }
  trading(entity) {
    this.tradingEntity = entity;
    const trades = VILLAGER_TRADES[entity.profession] || [];
    this.setScreen(
      "trading",
      `<main class="dialog compact trade-dialog"><div class="dialog-top"><span class="eyebrow">VILLAGER</span><button class="close" data-action="close-inv" aria-label="Close trading">×</button></div><h2>${esc(entity.profession || "villager")}</h2><p class="muted">Level 1 · Resident<br/>Trades restock after sunrise.</p><div class="trade-list">${trades.map((t, i) => `<button class="secondary trade-row" data-action="trade" data-trade="${i}" ${entity.tradeUses?.[i] >= 12 ? "disabled" : ""}><span>${itemHTML(makeStack(t.input, t.cost))}<small>${esc(ITEMS[t.input].name)} × ${t.cost}</small></span><b>→</b><span>${itemHTML(makeStack(t.output, t.count))}<small>${esc(ITEMS[t.output].name)} × ${t.count}</small></span><em>${Math.max(0, 12 - (entity.tradeUses?.[i] || 0))} left</em></button>`).join("")}</div><p class="fine">Carry payment in your inventory. Each completed trade awards 2 XP. This is a limited trading system; reputation and profession leveling are not implemented.</p><button class="primary wide" data-action="close-inv">Done</button></main>`,
    );
  }
  guide() {
    this.setScreen(
      "guide",
      `${this.header("guide")}<main class="dialog guide-dialog"><div class="dialog-top"><span class="eyebrow">A POCKET FIELD GUIDE</span><button class="close" data-action="back" aria-label="Back">×</button></div><h2>How to Play</h2><div class="guide-columns"><section><h3>Your first day</h3><p class="muted fine">Local play: download DCSMCRAFT-Standalone.html, double-click it, and use a desktop browser with WebGL 2. Share that one HTML file to share the game. Worlds stay in your browser: export/import a backup to move a world. If browser storage is blocked, export before closing.</p><ol><li>Hold left mouse on an oak trunk to gather logs. Walk close to pick them up.</li><li>Press E. Choose the planks recipe, click its output, then place the planks in your inventory.</li><li>Make sticks and a crafting table in your personal 2 × 2 grid. Place the table and right-click it.</li><li>Use the table's 3 × 3 grid to make a wooden pickaxe. Mine stone for cobblestone, then upgrade.</li><li>Craft a furnace with eight cobblestone. Add raw iron above, coal or wood below; smelting takes ten seconds.</li><li>Build a shelter before night. Craft torches with coal and sticks. Zombies, skeletons, spiders and creepers emerge after dusk.</li></ol><h3>Obsidian portal → Cinderwild</h3><p class="muted fine">New worlds: search underground cave chambers from Y −42 to 17 for obsidian rims around lava pools. Mine them with a diamond pickaxe. Older saved terrain keeps its original outcrops. Gravel has a 10% chance to drop flint. Craft flint + one iron ingot into flint and steel in your personal grid. Build an upright obsidian frame 4 blocks wide and 5 high, leaving a 2 × 3 empty opening; corners are optional (10 obsidian minimum). Right-click the frame with flint and steel. Stand inside for 4 seconds in Survival; Creative travels instantly. A linked portal in the Cinderwild brings you back. Keep out of lava and watch for emberlings. Both realms save separately.</p><p class="muted fine">Creative shortcut: find Obsidian and Flint and steel in the searchable inventory catalog. Peaceful difficulty disables hostile creatures. Edit the four cycle messages in Settings.</p><button class="text-button" data-action="features">What's implemented? Read the checklist ${arrow}</button></section><section><h3>Villages & wildlife</h3><p class="muted fine">New worlds generate eight-home villages at least 384 blocks apart, with eight biome-specific roof/wall/clothing styles, branching lanes, two farms and an Iron Golem protector. Hostiles can attack villagers; the golem fights nearby hostiles. Older villages receive one defender when visited. Old terrain is preserved; expanded villages require a new world. Villages generate on suitable dry ground. Follow paths to houses, the well, and communal wheat plots. Right-click a villager to trade with a farmer, mason, or shepherd. Houses have oak doors: right-click either half to open or close. Villagers operate their own doors and close them after passing. Craft three doors with six planks in two columns at a crafting table. Villagers return home at night and remain in your saved world. Pigs, sheep, cows, chickens, and rabbits wander the Overworld. New jungles have pandas and koalas, while savannas have dangerous tigers. Pandas retaliate if attacked. Koalas forage on the ground; climbing and breeding are not implemented. Old worlds preserve their original terrain; create a new world for villages. Open Options → Video Settings for grouped display, lighting, world-detail and camera controls. Choose Classic for the preserved v0.5 textures or Renewed for clearer pixel art. New worlds have thirteen biome types; older terrain stays on its saved generator. Options has independent ambience, creature and original piano/bell music controls. Weather shifts naturally between clear, rain and thunder. Cold biomes receive snow; deserts stay dry. Roofs shelter rain, and exposed crops receive rain hydration. Creative pause → Weather selects an override. Video Settings toggles Rain &amp; Snow and Lightning Flashes. No snow accumulation or lightning damage/fire.</p><h3>Equipment &amp; The Devin Sword</h3><p class="muted fine">Craft dirt, leather, iron or diamond armor at a table. Shift-click armor in your inventory, or right-click it while held, to equip it. Spears use a diagonal material tip and two sticks; they reach 4.25 blocks. Find lapis underground and sugar cane at shores. Three cane make paper; three paper and leather make a book. A book, two diamonds and four obsidian craft an enchanting table. Right-click it to spend XP points and lapis on six deterministic upgrades. This is simplified enchanting.</p><p class="muted fine">Press J or open the pause menu’s Relic Journal for the seeded location of The Devin Sword. Hold left click on the planted sword for 30 uninterrupted seconds with inventory space. Charged hits heal one health point; right-click unleashes a hostile-only pulse with a ten-second recharge. F3 shows exact axes, compass bearing and signed travel distances to the sword. Dirt equipment lasts only 8–12 uses, offers little protection and cannot harvest stone: upgrade to wood. Dirt gear, spears and this sword are original additions beyond the reference.</p><h3>The Cave Update</h3><p class="fine">New worlds contain hollow halls, dripstone vaults, moss grottos and deep rifts, with rare abandoned mineshafts. Search their wooden corridors for supply chests, rails and cobwebs. Diamond veins are small and scattered, between Y −56 and 8. Dark caves can spawn night hostiles even during the day; bring torches. A rare pale Watcher may stare from afar and laugh when noticed. It never attacks, cannot be killed, and retreats from light. Creative: press E and search “spawn egg” for passive and hostile creatures. Eggs have no Survival recipe.</p><h3>Matthew’s arsenal</h3><p class="fine">Rare Overworld incursions raise a tentacled shrine. Defeat four Hellspawn, then right-click its altar to earn Matthew’s Dual Wielded Pistols. Open J → Relic Journal for coordinates and controls: hold left-click to fire, right-click to Dash / Sky Star, R to Air Trick, Space + right-click near a wall to Wall Hike. Two rechargeable style charges; no invulnerability or fall immunity.</p><h3>A few useful moves</h3><p class="fine">Hold The Devin Sword and press R for its homing Seeker (28-block acquisition, 12 damage, 14-second saved cooldown). Right-click keeps Pulse. In Creative co-op, T or Tab opens players, invitations and chat.</p><dl class="controls-list"><dt><kbd>W A S D</kbd></dt><dd>Move</dd><dt><kbd>MOUSE</kbd></dt><dd>Look around</dd><dt><kbd>SPACE</kbd></dt><dd>Jump / swim up</dd><dt><kbd>SHIFT</kbd></dt><dd>Hold to crouch / flight down</dd><dt><kbd>W → W</kbd></dt><dd>Double-tap to sprint; keep moving to stay running</dd><dt><kbd>CTRL + W</kbd></dt><dd>Sprint (alternative)</dd><dt><kbd>LEFT CLICK</kbd></dt><dd>Mine / attack</dd><dt><kbd>RIGHT CLICK</kbd></dt><dd>Use / place / eat</dd><dt><kbd>1–9 / SCROLL</kbd></dt><dd>Select hotbar slot</dd><dt><kbd>E</kbd></dt><dd>Open / close inventory</dd><dt><kbd>Q / CTRL+Q</kbd></dt><dd>Drop one / stack</dd><dt><kbd>ESC</kbd></dt><dd>Pause</dd><dt><kbd>J</kbd></dt><dd>Relic Journal</dd><dt><kbd>F3</kbd></dt><dd>Coordinates, compass & sword guidance</dd><dt><kbd>F5</kbd></dt><dd>First person → behind → front</dd></dl><p class="muted fine">Release movement to stop sprinting; holding either Shift key crouches and cancels sprint.<br/>Creative: double-tap Space for flight.<br/>Inventory: right-click splits stacks or places one; drag across slots to distribute one per slot. Shift-click transfers. Recipe cards fill the grid using your own materials.</p></section></div></main>`,
    );
  }
  features() {
    this.setScreen(
      "features",
      `${this.header()}<main class="dialog checklist-dialog"><div class="dialog-top"><span class="eyebrow">HONESTLY, BLOCK BY BLOCK</span><button class="close" data-action="back" aria-label="Back">×</button></div><h2>A foundation. Room to grow.</h2><p class="muted">Mechanics reference: ${REFERENCE}. Independent project with original code, sound, branding and default art. The optional Supplied Assets texture pack contains user-provided Minecraft artwork. This is an early playable foundation, not a complete reproduction.</p><div class="status-legend"><span>● Implemented</span><span>◐ Partial / simplified</span><span>○ Missing</span></div><div class="checklist"><p><b>● Core sandbox</b><span>First-person WebGL and F5 third-person player with selectable original skins; seeded terrain, chunk loading, face culling, breaking, placement, collision, Creative flight and block catalog. Gripped 3D tools/blocks, combat and use animations, mob attacks, flinches and death reactions.</span></p><p><b>● Inventory & saves</b><span>36 slots, cursor, stacks, splitting, dragging, transfer, drop/pickup, crafting, tools, durability, chests, furnaces, 3D block/weapon drops and flat ordinary-item sprites, transactional browser saves and recovery generation.</span></p><p><b>◐ World generation</b><span>Thirteen biome types, including jungles, in new worlds, pine and birch trees, mossy marshes, terracotta badlands, snowy taiga and varied ridges, ocean/river/lake depressions, caves, ravine-like cuts, scattered ore, trees stone waystations, and original villages with houses, paths, wells, farms, and loot. Original generation; different from the reference.</span></p><p><b>◐ Survival & combat</b><span>Health, hunger, saturation, oxygen, fall damage, suffocation, cooldown attacks, basic critical hits, death drops, respawn and beds. Dirt, leather, gold, iron, diamond and Hellfire armor reduce damage and wear; food is instant. Player shields, bows and status effects remain missing; Skeleton arrows work.</span></p><p><b>◐ Creatures & farming</b><span>Zombies, Creepers, Spiders and Skeletons with original models/voices, melee, cancellable fuses, simplified terrain explosions, wall climbing and visible arrows; Cinderworld creatures retained. Simplified spawning and local steering. Hydrated wheat and bone meal growth. Rotten flesh has no Hunger penalty; gunpowder crafts TNT. Five animal types; eight-home villages in new worlds, persistent villagers and Iron Golem defenders, day/night routines, and limited trading. No breeding, reputation, raids or full pathfinding.</span></p><p><b>◐ Environment & lighting</b><span>20 Hz world tick with smooth visual dawn/dusk, warm sunlight, moonlight, fading stars and distance fog. Independent ambient occlusion and optional local sun shadows; torch placement suppresses nearby hostile spawning. Original wind, water, birds, insects, cave and dimension ambience, plus layered material impacts and spatial creature voices. Continuous biome/location/weather soundscape without short loops; optional original piano/bell music. Rain, snow, thunder, damaging hail and local tornado funnels with shelter, saved state and visual controls. Tornadoes move players; no terrain destruction or physical hail accumulation. No propagated block light, snow accumulation or lightning damage/fire.</span></p><p><b>◐ Advanced blocks & fluids</b><span>Water and lava flow downward and spread at different speeds, drain when sources disappear and cool into rock on contact. Buckets collect sources and place fluids. Fire burns flammable blocks, flint and steel ignites surfaces/TNT, and cacti hurt on contact. Oak doors support four orientations, two linked halves, collision, crafting and villager use. No door redstone/hinge variants, waterlogging, slabs, stairs, trapdoors, fences or ladders. Fluid routing, fire spread and explosions are simplified. TNT has a saved four-second fuse and chain reactions. Creepers have a cancellable 1.5-second fuse and a simplified terrain-damaging blast; containers and ancient temple blocks are protected. Gravity applies to edited sand and gravel.</span></p><p><b>◐ Advanced progression & dimensions</b><span>A custom Cinderworld (saved internally as Cinderwild) and linked obsidian portals work. Generator 7 adds four volcanic regions, Hellfire/Brimstone veins, alloy equipment, bastions, shrines, waystations, peaceful ash deer, neutral cinderbacks, crawlers and wraiths. Generator 10 retains linked caves/tunnels and adds copper, gold, emerald deposits, clay beds and a fortified sword citadel. Its sealed inner sanctuary is protected by three persistent Guardians with six telegraphed attacks. Golden equipment, mineral storage and new masonry have real recipes. Six deterministic enchantments, lapis, cane, books, armor, spears and the persistent Devin Sword relic work. Enchanting is simplified. Full Nether/End parity, anvils, brewing, fishing and bosses remain missing.</span></p><p><b>◐ Multiplayer beta</b><span>Survival and Creative co-op beta for up to 8 players through an optional Node.js relay. Host-controlled inventories, mining, crafting, containers, health, death/respawn, reconnect profiles, chat, owner commands and invitations work. Internet play needs a public HTTPS/WSS relay or deliberate port forwarding. Host must remain online. No independent dimension travel, PvP, automatic internet hosting, host migration or dedicated simulation; AI/spawning still follow the host vicinity.</span></p><p><b>○ Automation</b><span>No wires, signals, repeaters, comparators, pistons, observers, hoppers, dispensers or droppers.</span></p></div><p class="fine muted">See FEATURES.md and README.md in the source for the detailed milestone checklist, tested workflows, and known differences.</p><button class="primary" data-action="back">Back to the trail →</button></main>`,
    );
  }
  death() {
    this.setScreen(
      "death",
      `<div class="death-shade"></div><main class="dialog compact death-dialog"><span class="eyebrow">EVERY STORY HAS A DETOUR</span><h2>A little too far.</h2><p>You were lost to ${esc(this.game.lastDeath?.cause || "the wilderness")}.<br/>Your next chapter starts at your spawn point.</p><p class="death-coordinates">${Math.floor(this.game.player.x)} / ${Math.floor(this.game.player.y)} / ${Math.floor(this.game.player.z)}</p><button class="primary wide" data-action="respawn">Find your feet again ${arrow}</button><button class="text-button wide" data-action="quit">Save & return to title</button></main>`,
    );
  }
  openInventory(type, container, target) {
    this.invType = type;
    this.container = container;
    this.containerTarget = target;
    this.craftSize = type === "table" ? 3 : 2;
    this.creativeTab =
      this.game.mode === "creative" && type === "personal"
        ? "catalog"
        : "inventory";
    this.buildInventory();
  }
  slots(ref, count, start = 0) {
    return Array.from(
      { length: count },
      (_, i) =>
        `<button class="slot" data-ref="${ref}" data-index="${i + start}" aria-label="Empty slot"></button>`,
    ).join("");
  }
  buildInventory() {
    const g = this.game,
      creative = g.mode === "creative",
      catalog = creative && this.creativeTab === "catalog";
    let top = "";
    if (this.invType === "furnace") {
      top = `<div class="furnace-layout"><div><span class="grid-caption">INPUT</span>${this.slots("container", 1, 0)}<div class="flame" id="furnace-flame">♨</div>${this.slots("container", 1, 1)}<span class="grid-caption">FUEL</span></div><div class="smelt-arrow"><span>→</span><div id="smelt-progress"><i></i></div><small>10 SECOND SMELT</small></div><div><span class="grid-caption">OUTPUT</span>${this.slots("container", 1, 2)}</div></div>`;
    } else if (this.invType === "chest") {
      top = `<div class="container-grid slot-grid nine">${this.slots("container", 27)}</div>`;
    } else if (catalog) {
      top = `<input id="creative-search" placeholder="Find blocks, items or spawn eggs…" aria-label="Search Creative catalog"/><div class="creative-catalog">${CREATIVE_ITEMS.map((id, i) => `<button class="slot creative-slot" data-ref="creative" data-index="${i}" data-name="${esc(ITEMS[id].name.toLowerCase())}" data-tooltip="${esc(ITEMS[id].name)}">${itemHTML(makeStack(id))}</button>`).join("")}</div>`;
    } else {
      top = `<div class="crafting-layout"><div><span class="grid-caption">${this.craftSize} × ${this.craftSize} CRAFTING</span><div class="slot-grid craft-grid" style="--cols:${this.craftSize}">${this.slots("craft", this.craftSize ** 2)}</div></div><span class="craft-arrow">→</span><div><span class="grid-caption">RESULT</span><button class="slot output-slot" data-action="craft" aria-label="Craft result"></button></div><div class="craft-tip">Choose a recipe<small>Choose a recipe to fill the grid.</small></div></div>`;
    }
    if (this.invType === "personal")
      top =
        `<section class="equipment-panel"><div><span class="grid-caption">ARMOR · SHIFT-CLICK TO EQUIP</span><div class="equipment-slots">${ARMOR_SLOTS.map((slot, i) => `<label><small>${slot}</small>${this.slots("armor", 1, i)}</label>`).join("")}</div></div><p><span id="equipment-points">${armorStats(g.inventory).armor} armor points</span><br/><small>Right-click held armor to equip.</small></p></section>` +
        top;
    const recipes = !catalog && !["furnace", "chest"].includes(this.invType);
    this.setScreen(
      "inventory",
      `<main class="inventory-window ${recipes ? "with-recipes" : ""}">${recipes ? `<aside class="recipe-book"><span class="eyebrow">RECIPE BOOK</span><h3>Crafting Recipes</h3><input id="recipe-search" placeholder="Find a recipe…" aria-label="Search recipes"/><div class="recipe-list">${RECIPES.map((r, i) => `<button class="recipe-card" data-action="recipe" data-recipe="${i}" data-name="${ITEMS[r.result].name.toLowerCase()}"><img src="${iconURL(r.result)}" alt=""/><span>${ITEMS[r.result].name}<small>${r.count > 1 ? `MAKES ${r.count}` : "CRAFT ONE"}${r.pattern && (r.pattern.length > 2 || r.pattern[0].length > 2) ? " · TABLE" : ""}</small></span><span>${arrow}</span></button>`).join("")}</div></aside>` : ""}<section class="inventory-main"><div class="dialog-top"><span class="eyebrow">${this.invType === "personal" ? "PLAYER INVENTORY" : this.invType === "table" ? "CRAFTING TABLE" : this.invType.toUpperCase()}</span><button class="close" data-action="close-inv" aria-label="Close inventory">×</button></div><div class="inventory-title"><h2>${this.invType === "furnace" ? "Furnace" : this.invType === "chest" ? "Chest" : "Crafting"}</h2>${creative && this.invType === "personal" ? `<div class="tabs"><button data-action="creative-tab" data-tab="catalog" class="${catalog ? "active" : ""}">Catalog</button><button data-action="creative-tab" data-tab="inventory" class="${!catalog ? "active" : ""}">Crafting</button></div>` : ""}</div>${top}<div class="inventory-divider"><span>INVENTORY</span><small>SHIFT + CLICK TO TRANSFER</small></div><div class="slot-grid nine main-slots">${this.slots("inventory", 27, 9)}</div><div class="slot-grid nine inventory-hotbar">${this.slots("inventory", 9)}</div><div class="inventory-foot"><span>LEFT CLICK · PICK UP / PLACE</span><span>RIGHT CLICK · SPLIT / PLACE ONE</span></div></section></main>`,
    );
    this.refreshInventory();
  }
  slotClick(cell, e) {
    const g = this.game,
      inv = g.inventory,
      ref = cell.dataset.ref,
      index = Number(cell.dataset.index),
      right = e.button === 2;
    if (e.button !== 0 && !right) return;
    if (g.multiplayer?.isGuest && g.mode === "survival") {
      this.dragging = !e.drag;
      this.dragVisited = this.dragVisited || new Set([ref + index]);
      g.multiplayer.command("inventory", {
        action: "slot",
        ref,
        index,
        right,
        shift: e.shiftKey,
      });
      return;
    }
    this.dragging = !e.drag;
    this.dragVisited = this.dragVisited || new Set([ref + index]);
    if (ref === "creative") {
      const id = CREATIVE_ITEMS[index];
      if (e.shiftKey) {
        inv.add(makeStack(id, ITEMS[id].stack));
      } else inv.cursor = makeStack(id, right ? 1 : ITEMS[id].stack);
      this.refreshInventory();
      return;
    }
    const array =
      ref === "inventory"
        ? inv.slots
        : ref === "armor"
          ? inv.equipment
          : ref === "craft"
            ? inv.craft
            : this.container.slots;
    if (
      ref === "armor" &&
      inv.cursor &&
      ITEMS[inv.cursor.id]?.armorSlot !== index
    )
      return;
    const armorSlot =
      ref === "inventory" ? ITEMS[array[index]?.id]?.armorSlot : undefined;
    if (e.shiftKey && armorSlot !== undefined && !inv.equipment[armorSlot]) {
      inv.equipment[armorSlot] = array[index];
      array[index] = null;
      this.refreshInventory();
      return;
    }
    if (
      this.invType === "furnace" &&
      ref === "container" &&
      index === 2 &&
      inv.cursor
    ) {
      const output = array[index];
      if (
        output &&
        compatible(output, inv.cursor) &&
        output.count + inv.cursor.count <= ITEMS[output.id].stack
      ) {
        inv.cursor.count += output.count;
        array[index] = null;
        g.player.xp += Math.floor(this.container.xp || 0);
        this.container.xp = 0;
      }
      this.refreshInventory();
      return;
    }
    if (e.shiftKey) {
      if (ref === "inventory" && this.container) {
        const target = this.container.slots;
        if (this.invType === "furnace") {
          // Insert only into input/fuel, never into result.
          const s = array[index];
          if (s) {
            const destination = FUELS[s.id] ? 1 : SMELTS[s.id] ? 0 : -1;
            if (destination < 0) return;
            const slot = target[destination],
              max = ITEMS[s.id].stack;
            if (!slot) {
              target[destination] = s;
              array[index] = null;
            } else if (compatible(slot, s)) {
              const n = Math.min(s.count, max - slot.count);
              slot.count += n;
              s.count -= n;
              if (!s.count) array[index] = null;
            }
          }
        } else inv.transfer(array, index, target);
      } else if (ref !== "inventory") inv.transfer(array, index, inv.slots);
      else {
        const start = index < 9 ? 9 : 0,
          end = index < 9 ? 36 : 9;
        this.transferRange(index, start, end);
      }
    } else {
      inv.click(array, index, right);
      if (ref === "container" && this.invType === "furnace" && index === 2) {
        g.player.xp += Math.floor(this.container.xp || 0);
        this.container.xp = 0;
      }
    }
    g.audio.tone("ui");
    this.refreshInventory();
  }
  transferRange(index, start, end) {
    const inv = this.game.inventory,
      s = inv.slots[index];
    if (!s) return;
    for (let i = start; i < end && s.count; i++)
      if (compatible(inv.slots[i], s)) {
        const n = Math.min(s.count, ITEMS[s.id].stack - inv.slots[i].count);
        inv.slots[i].count += n;
        s.count -= n;
      }
    for (let i = start; i < end && s.count; i++)
      if (!inv.slots[i]) {
        inv.slots[i] = { ...s };
        s.count = 0;
      }
    if (!s.count) inv.slots[index] = null;
  }
  craft(all = false) {
    if (this.game.multiplayer?.isGuest && this.game.mode === "survival") {
      this.game.multiplayer.command("inventory", { action: "craft", all });
      return;
    }
    const inv = this.game.inventory;
    if (all) {
      for (let i = 0; i < 64; i++) {
        const r = inv.recipe(this.craftSize);
        if (!r) break;
        const backup = cloneState(inv.export());
        if (inv.cursor) break;
        if (!inv.craftOne(this.craftSize)) break;
        const left = inv.add(inv.cursor);
        if (left) {
          Object.assign(inv, new inv.constructor(backup));
          break;
        }
        inv.cursor = null;
      }
    } else inv.craftOne(this.craftSize);
    this.game.audio.tone("craft");
    this.refreshInventory();
  }
  refreshInventory() {
    if (this.screen !== "inventory") return;
    const inv = this.game.inventory;
    this.overlay.querySelectorAll(".slot[data-ref]").forEach((cell) => {
      const ref = cell.dataset.ref;
      if (ref === "creative") return;
      const i = Number(cell.dataset.index),
        stack =
          ref === "inventory"
            ? inv.slots[i]
            : ref === "armor"
              ? inv.equipment[i]
              : ref === "craft"
                ? inv.craft[i]
                : this.container?.slots[i];
      cell.innerHTML = itemHTML(stack);
      cell.dataset.tooltip = stack
        ? `${ITEMS[stack.id]?.name || stack.id}${enchantText(stack) ? " · " + enchantText(stack) : ""}${stack.durability !== undefined ? " · Durability " + stack.durability : ""}`
        : "";
      cell.setAttribute(
        "aria-label",
        stack ? `${stack.count} ${ITEMS[stack.id]?.name}` : "Empty slot",
      );
    });
    const points = this.overlay.querySelector("#equipment-points");
    if (points) points.textContent = `${armorStats(inv).armor} armor points`;
    const r = inv.recipe(this.craftSize),
      out = this.overlay.querySelector(".output-slot");
    if (out) {
      out.innerHTML = r ? itemHTML(makeStack(r.result, r.count)) : "";
      out.dataset.tooltip = r
        ? `Craft ${ITEMS[r.result].name}`
        : "No matching recipe";
    }
    if (this.invType === "furnace") {
      const bar = this.overlay.querySelector("#smelt-progress i");
      if (bar) bar.style.width = (this.container.progress || 0) / 2 + "%";
      this.overlay
        .querySelector("#furnace-flame")
        ?.classList.toggle("burning", this.container.burn > 0);
    }
    this.cursorEl.hidden = !inv.cursor;
    this.cursorEl.innerHTML = itemHTML(inv.cursor);
  }
  updateHotbar() {
    if (this.screen !== "play") return;
    const inv = this.game.inventory,
      bar = this.hud.querySelector("#hotbar");
    bar.innerHTML = inv.slots
      .slice(0, 9)
      .map(
        (s, i) =>
          `<div class="hotbar-slot ${i === inv.selected ? "selected" : ""}"><small>${i + 1}</small>${itemHTML(s)}</div>`,
      )
      .join("");
    this.hud.querySelector("#selected-name").textContent =
      ITEMS[inv.held?.id]?.name || "";
    this.nameUntil = this.game.elapsed + 2;
  }
  updateHUD() {
    if (this.screen !== "play") return;
    const g = this.game,
      p = g.player,
      creative = g.mode === "creative";
    const trial = activeTrial(g);
    let bossBar = this.hud.querySelector("#titan-boss");
    if (!bossBar) {
      bossBar = document.createElement("div");
      bossBar.id = "titan-boss";
      this.hud.append(bossBar);
    }
    bossBar.hidden = !trial;
    if (trial) {
      const hp = Math.max(
        0,
        Math.ceil(
          g.entities.find((e) => e.id === trial.bossId)?.hp ?? trial.bossHP,
        ),
      );
      bossBar.innerHTML = `<b>A MAD TITAN</b><div><i style="width:${Math.min(100, (hp / 320) * 100)}%"></i></div><small>${trial.phase === "victory" ? "Return rune unlocked · recovery alcove" : `${hp} / 320 · Bullets cannot pierce its hide`}</small>`;
    }
    const state = JSON.stringify([
      p.health,
      p.food,
      p.oxygen,
      p.underwater,
      p.xp,
      armorStats(g.inventory).armor,
      g.mode,
      Math.floor(g.time / 1000),
      Math.floor(p.x),
      Math.floor(p.z),
    ]);
    if (this.lastHUD === state) return;
    this.lastHUD = state;
    this.hud.querySelector("#survival-bars").hidden = creative;
    this.hud.querySelector("#hearts").innerHTML = Array.from(
      { length: 10 },
      (_, i) =>
        `<span class="heart ${p.health >= i * 2 + 2 ? "full" : p.health > i * 2 ? "half" : ""}">♥</span>`,
    ).join("");
    this.hud.querySelector("#hunger").innerHTML = Array.from(
      { length: 10 },
      (_, i) =>
        `<span class="food ${p.food >= i * 2 + 2 ? "full" : p.food > i * 2 ? "half" : ""}">◆</span>`,
    ).join("");
    const armor = armorStats(g.inventory).armor,
      armorBar = this.hud.querySelector("#armor-bar");
    armorBar.hidden = !armor;
    armorBar.setAttribute("aria-label", `${armor} armor points`);
    armorBar.innerHTML = Array.from(
      { length: 10 },
      (_, i) => `<i class="armor-pip ${armor > i * 2 ? "full" : ""}"></i>`,
    ).join("");
    const oxygen = this.hud.querySelector("#oxygen");
    oxygen.hidden = !p.underwater;
    oxygen.innerHTML = Array.from(
      { length: Math.ceil(Math.max(0, p.oxygen) / 30) },
      () => "<span>○</span>",
    ).join("");
    const level = Math.floor(Math.sqrt(p.xp / 7));
    this.hud.querySelector("#xp-level").textContent = level || "";
    this.hud.querySelector("#xp-fill").style.width =
      `${((p.xp - level * level * 7) / Math.max(7, (level + 1) ** 2 * 7 - level * level * 7)) * 100}%`;
    this.hud.querySelector("#day-label").textContent =
      `DAY ${Math.floor(g.time / 24000) + 1}`;
    this.hud.querySelector("#day-icon").textContent =
      g.time % 24000 > 13000 && g.time % 24000 < 23000 ? "☾" : "☀";
    this.hud.querySelector("#mode-label").textContent = creative
      ? "CREATIVE"
      : "SURVIVAL";
    const biome = g.world.terrain(p.x, p.z).biome;
    this.hud.querySelector("#hud-biome").textContent = (
      g.dimension === "cinderwild" ? "CINDERWILD" : BIOMES[biome]?.name || biome
    ).toUpperCase();
  }
  frame() {
    this.hud.dataset.view = String(this.game.cameraMode || 0);
    if (this.screen !== "play") return;
    const g = this.game,
      p = g.player;
    const fps = this.hud.querySelector("#fps-counter");
    if (fps) {
      fps.hidden = !g.settings.showFPS;
      fps.textContent = `${Math.round(g.fps || 0)} FPS`;
    }
    this.hud.querySelector("#hurt-vignette").style.opacity = p.hurt * 0.9;
    this.hud.querySelector("#water-vignette").style.opacity = p.underwater
      ? 0.5
      : 0;
    const crosshair = this.hud.querySelector("#crosshair");
    const hit = g.hitFeedback && g.elapsed < g.hitFeedback.until;
    crosshair.classList.toggle("combat-hit", !!hit);
    crosshair.classList.toggle("critical-hit", !!hit && g.hitFeedback.critical);
    const recovery = this.hud.querySelector("#attack-cooldown");
    const charge = Math.max(
      0,
      Math.min(
        1,
        (g.elapsed - (g.lastAttack ?? -10)) /
          attackCooldown(g.inventory.held?.id),
      ),
    );
    recovery.hidden = charge >= 1;
    recovery.firstElementChild.style.width = `${charge * 100}%`;
    recovery.setAttribute("aria-valuenow", Math.round(charge * 100));
    const label = this.hud.querySelector("#target-label");
    label.textContent = g.target ? BLOCKS[g.target.id].name : "";
    if (g.target && BLOCKS[g.target.id].key === "crop") {
      const t = g.target,
        age = g.world.cropTicks[`${t.x},${t.y},${t.z}`]?.age || 0;
      label.textContent += age === 7 ? " · Mature" : ` · Growing ${age}/7`;
    }
    const enemy = g.targetEntity?.();
    if (enemy && MOB_INFO[enemy.type])
      label.textContent = `${MOB_INFO[enemy.type].name} · ${Math.ceil(enemy.hp)} HP${enemy.windup ? " · STRIKE INCOMING" : ""}`;
    if (enemy?.type === "watcher") label.textContent = "The Watcher";
    if (g.extraction)
      label.textContent = `The Devin Sword · ${Math.floor(g.extraction.progress * 30)} / 30 seconds · keep holding`;
    const moves = this.hud.querySelector("#weapon-moves");
    moves.textContent = weaponMoveText(g);
    moves.hidden = !moves.textContent;
    if (g.target?.id === BLOCKS.findIndex((b) => b.key === "matthew_altar")) {
      const s = invasionState(g.world);
      label.textContent =
        s?.phase === "ready"
          ? "Matthew’s Rift Altar · right-click to claim the pistols"
          : s?.phase === "claimed"
            ? "Matthew’s Rift Altar · claimed"
            : `Sealed altar · ${s?.defeated.length || 0}/4 Hellspawn defeated`;
    }
    if (g.target?.id === BLOCKS.findIndex((b) => b.key === "trial_exit"))
      label.textContent =
        activeTrial(g)?.phase === "victory"
          ? "Return rune · right-click to escape"
          : "Return rune sealed · defeat A Mad Titan";
    label.hidden = !label.textContent;
    this.hud.classList.toggle("in-portal", (g.portalCharge || 0) > 0);
    this.hud.style.setProperty(
      "--portal-charge",
      Math.min(0.55, (g.portalCharge || 0) / 100),
    );
    const mining = this.hud.querySelector("#mining-bar");
    mining.hidden = !g.mining && !g.extraction;
    mining.classList.toggle("relic-extraction", !!g.extraction);
    mining.firstElementChild.style.width =
      Math.min(100, (g.extraction?.progress || g.mining) * 100) + "%";
    this.hud.querySelector("#selected-name").style.opacity =
      g.elapsed < this.nameUntil ? 1 : 0;
    const debug = this.hud.querySelector("#hud-debug");
    debug.hidden = !this.debug;
    if (this.debug)
      debug.textContent = `DCSMCRAFT v${VERSION}\n${debugNavigation(g.world, p)}\n\nSeed ${g.world.seed}\nChunks ${g.renderer.meshes.size} · Entities ${g.entities.length}\nDraw calls ${g.renderer.gl.info.render.calls} · Triangles ${g.renderer.gl.info.render.triangles}\n20 Hz simulation · ${g.world.edits.size} edits\n${p.flying ? "CREATIVE FLIGHT" : ""}`;
  }
  saveSettings() {
    try {
      localStorage.setItem(
        "dcsmcraft-settings",
        JSON.stringify(this.game.settings),
      );
    } catch {
      /* Settings remain usable in storage-restricted HTML viewers. */
    }
  }
  announce(title, message) {
    if (!message) return;
    const banner = this.root.querySelector("#cycle-banner");
    banner.querySelector("strong").textContent = title;
    banner.querySelector("span").textContent = message;
    banner.classList.add("show");
    clearTimeout(this.bannerTimer);
    this.bannerTimer = setTimeout(() => banner.classList.remove("show"), 6500);
  }
  downloadGame() {
    const html = window.DCSMCRAFT_HTML_SOURCE;
    if (!html) {
      this.toast(
        "Use the standalone HTML download to share a self-contained copy.",
      );
      return;
    }
    const url = URL.createObjectURL(new Blob([html], { type: "text/html" })),
      a = document.createElement("a");
    a.href = url;
    a.download = "DCSMCRAFT-Standalone.html";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    this.toast(
      "Game HTML saved. Share that file; export a world backup separately to share your world.",
      6500,
    );
  }
  toast(message, duration = 3500) {
    const el = this.root.querySelector("#toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => el.classList.remove("show"), duration);
  }
  saved() {
    const el = this.hud.querySelector("#save-status");
    if (el) {
      if (this.game.store.temporary) {
        el.textContent = "SESSION ONLY · EXPORT TO KEEP";
        return;
      }
      el.textContent = "✓ SAVED LOCALLY";
      setTimeout(() => {
        if (el.isConnected) el.textContent = "SAVED LOCALLY";
      }, 2200);
    }
  }
}
