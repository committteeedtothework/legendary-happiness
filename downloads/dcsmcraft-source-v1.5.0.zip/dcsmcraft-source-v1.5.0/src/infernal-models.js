// Original voxel silhouettes, batched by the existing creature model pipeline.
export function buildInfernalModel(type, { g, head, box, limb, material }) {
  if (!["dread_knight", "soul_reaver", "magma_maw"].includes(type))
    return false;
  const armor = material(type === "soul_reaver" ? "#342940" : "#30252a");
  const bone = material("#b3a28a"),
    trim = material("#7e4a38");
  const glow = material(type === "soul_reaver" ? "#9edee9" : "#ff963f");
  glow.emissive.set(type === "soul_reaver" ? "#327a94" : "#a0390d");
  if (type === "magma_maw") {
    box(g, 1.15, 0.55, 1.5, 0, 0.63, 0, armor);
    head.position.set(0, 0.65, -0.86);
    box(head, 0.85, 0.6, 0.58, 0, 0, 0, armor);
    box(head, 0.7, 0.28, 0.05, 0, -0.08, -0.31, glow);
    for (const side of [-1, 1]) {
      box(head, 0.13, 0.12, 0.04, side * 0.25, 0.15, -0.31, glow);
      for (let i = 0; i < 3; i++)
        box(
          head,
          0.08,
          0.14,
          0.06,
          side * (0.08 + i * 0.11),
          -0.04,
          -0.35,
          bone,
        );
      for (const z of [-0.5, 0.45])
        g.userData.legs.push(limb(0.23, 0.4, 0.28, side * 0.5, 0.4, z, trim));
      for (let i = 0; i < 4; i++)
        box(
          g,
          0.16,
          0.35,
          0.14,
          side * 0.32,
          1.02,
          -0.45 + i * 0.32,
          bone,
        ).rotation.z = side * -0.4;
    }
  } else {
    const knight = type === "dread_knight";
    box(g, knight ? 0.85 : 0.48, 1.0, 0.44, 0, 1.3, 0, armor);
    head.position.set(0, 2.18, 0);
    box(head, 0.55, 0.56, 0.46, 0, 0, 0, armor);
    box(head, 0.38, 0.09, 0.04, 0, 0.04, -0.25, glow);
    box(head, 0.26, 0.21, 0.05, 0, -0.17, -0.25, bone);
    for (const side of [-1, 1]) {
      box(head, 0.13, 0.53, 0.14, side * 0.32, 0.3, 0, bone).rotation.z =
        side * -0.5;
      box(g, 0.36, 0.22, 0.56, side * 0.48, 1.74, 0, trim);
      const arm = limb(
        knight ? 0.27 : 0.16,
        1.08,
        0.26,
        side * 0.48,
        1.7,
        0,
        armor,
      );
      g.userData.arms ||= [];
      g.userData.arms.push(arm);
      for (let i = 0; i < 3; i++)
        box(
          arm,
          0.035,
          0.23,
          0.035,
          side * 0.06 + i * 0.05,
          -1.16,
          -0.08,
          bone,
        );
      g.userData.legs.push(limb(0.26, 0.8, 0.31, side * 0.22, 0.8, 0, armor));
      for (let i = 0; i < 4; i++)
        box(
          g,
          0.23,
          0.06,
          0.05,
          side * 0.15,
          1.55 - i * 0.17,
          -0.25,
          bone,
        ).rotation.z = side * 0.25;
    }
    box(g, 0.13, 0.35, 0.055, 0, 1.3, -0.27, glow);
    if (knight) {
      box(g.userData.arms[1], 0.12, 1.15, 0.13, 0, -0.55, -0.25, trim);
      box(g.userData.arms[1], 0.63, 0.42, 0.26, 0, -1.1, -0.25, armor);
      box(g.userData.arms[1], 0.65, 0.07, 0.28, 0, -1.2, -0.25, glow);
    } else
      for (const side of [-1, 1]) {
        box(g, 0.12, 1.25, 0.5, side * 0.31, 0.75, 0.2, armor).rotation.z =
          side * -0.17;
        for (let i = 0; i < 3; i++)
          box(
            g,
            0.055,
            0.18,
            0.055,
            side * (0.6 + i * 0.13),
            1.2 + i * 0.2,
            0,
            glow,
          ).rotation.z = 0.6;
      }
  }
  return true;
}
