# DCSMCRAFT validation

## Pixel & Grip — 1.9.1

**370 core tests and eight selected browser scenarios pass.** The production web build, self-contained HTML and Windows x64 executable compile successfully. All 316 runtime/build/source-asset inputs are frozen before the final browser run and verified again before packaging. The executable extractor produces HTML identical to the standalone.

The new unit checks sweep both mirrored first-person arms through all stages of six weapon families, pistol fire and ordinary interactions: skin overlaps the palm, sleeve and skin meet, the elbow stays below the viewport, matrices remain finite and grips never stretch. All 103 new original icon silhouettes fit the 16px grid, keep alpha space and use valid material palettes; helmet/boot/flint cutouts stay open and gems retain different silhouettes.

The exact standalone bytes run over local HTTP with all outside requests blocked. Selected browser scenarios cover:

1. Independent pistol slide recoil, rigid palm sockets, F5, particle controls and item swaps.
2. Actual W movement in water, first-person paddling, F5 prone swimming/stationary treading and land recovery.
3. Real menu navigation, keyboard slider changes, Space activation and Tab focus between buttons, graphics toggles, dropdown/pack selection, 1280px/two-column and 640px/one-column layouts, world-creation radio controls and persisted preferences.
4. Recipe-sidebar search/autofill, actual crafting/output transfer, Creative catalog/tabs, furnace flame/progress, pause/resume and persistent reload of inventory plus an edited chunk-boundary block.
5. Deterministic full action sweeps for six ordinary weapon families, Devin, flat items, building blocks and pistols; connected rendered forearms, actual sword-click damage, retained F5 palm joints, transparent held flint/steel and Q drops.
6. All 330 supplied atlas face tiles and 97 native item icons match the imported pixels, including alpha; held/dropped items and Creative inventory render correctly.
7. All four packs switch reversibly without editing the world; supplied preference, inventory and block edits survive reload.
8. The production Vite entry creates a world using a saved Supplied preference and responds to actual W movement.

Menu checks exposed an existing global keyboard handler swallowing Space and Tab outside play; those defaults are now suppressed only during gameplay. Tests were also updated for the Options button's new Done label and its existing Video-to-Options return path. Screenshots of the title/options/video menus, crafting/furnace, flat items, swings, recoil and F5 were inspected. All final scenarios pass against unchanged frozen runtime inputs, without JavaScript/shader/WebGL errors in the new scenarios. This is targeted regression testing, not an exhaustive no-bug guarantee or a complete new Survival playthrough.

Eighty prior JavaScript modules are byte-identical to 1.9.0, including generation, world, physics, simulation, recipes/inventory, storage, equipment, combat, weapon/pistol models, animation curves, audio and networking. data.js differs only by the version string; generator 12, IDs, recipes and stats are retained. The compatibility JSON lists changed/unchanged modules. No world regeneration or save conversion is required. Native supplied images take priority; Classic/Soft continue through their unchanged artwork paths.

Native Windows launch is unverified on this Linux host. Managed Chromium blocks direct file:// navigation, so the identical self-contained payload is exercised over HTTP with outside requests blocked. Desktop launch needs Edge or Chrome installed. ZIP CRCs, embedded payloads and artifact SHA-256 values are verified during packaging. UI, item art and arm articulation remain original interpretations rather than exact Minecraft pixel/layout/animation parity. Existing foundation limitations remain documented below and in FEATURES.md.

## Field & Form — 1.9.0

**368 core tests and six browser scenarios pass on the shipped build.** The web, standalone HTML and Windows x64 PE compile successfully. All **314 runtime/build/source-asset inputs** are frozen before the final browser run and rechecked before packaging. The Windows payload extracts HTML byte-identical to the standalone. Native Windows launch remains unverified on this Linux host.

Core checks cover all 18 redesigned/legacy appearances, finite geometry, grounded rest poses, preserved collision height and bounded rigid batches; 16 current Overworld types are all covered. The largest unshadowed rigid model has 22 draw meshes, excluding optional warnings. This is a draw-budget check, not a measured hardware FPS claim. Eight villager palettes and three professions retain connected folded arms. Head-look tests cover repeated wrapped angles across 30/60/144 Hz and paused poses. All 97 ordinary/plant/door item types have one zero-extrusion, double-sided alpha-cutout mesh in hand and normalized drops. Solid building blocks and modeled weapons retain depth. Source image hashes, all baked RGBA runs, directional atlas allocation, upper/lower door UVs and full-height bamboo connections are checked.

The six browser scenarios verify:

1. All current Overworld and legacy models render, all eight village outfits appear, repeated camera/body rotations keep actual villager head yaw within 60 degrees and pitch within 0.32 radians, and a saved styled villager reloads correctly.
2. All 97 flat item geometries, actual representative textures in hand/F5, real Q dropping, camera-facing drops and retained solid block/weapon models.
3. Actual terrain-worker directional faces, local pack remeshing, fitted chest/workstation/torch/door surfaces, plant cutouts, thin rails and the real bamboo atlas's 48 opaque shaft pixels.
4. Exact standalone with outside requests blocked: 330 imported block-face pixel comparisons and all 97 imported item icons, transparent held/dropped flint and steel and Creative inventory rendering. Canvas rounding is allowed only for translucent pixels.
5. Reversible switching through all four packs with identical original-pack snapshots and no world edits, then actual world save/reload preserving the supplied preference, an inventory stack and a block edit across a chunk boundary.
6. Normal Vite web entry with a saved supplied preference, successful world creation and real W movement.

Controlled screenshots of all creature groups, village palettes, flat items/F5 and repaired world blocks were visually inspected. That review found the native opaque bamboo UV texture appearing as broad crossed panels. The supplied three-pixel shaft is now centered on transparency; matching provenance and regression checks were added, then the builds, all core tests and all six browser scenarios were repeated. An earlier model fixture omitted the production turn/dir fields; the fixture was corrected without changing simulation. Solid-block/pistol fingerprint tests remain; the old thick door inventory model is an explicit intentional exception, now tested as a flat cutout.

Compatibility with v1.8.1: 66 sampled chunks across generators 2–12 and both dimensions, and 22 accumulated container snapshots, match byte-for-byte. All 24 non-version data exports and 70 existing JS modules are unchanged. Data source differs only in version. World, physics, simulation, inventory, combat, recipes, audio, storage and networking are unchanged. Nine retained Cinderworld creature model fingerprints match their prior geometry/material values. These are representative samples, not proof across all worlds. The complete historical Survival progression and multiplayer browser suite were not repeated.

Remaining limits: source animation strips use frame zero; full resource-pack metadata/models and exact reference block orientation/geometry remain partial. Unmapped custom/bed artwork retains fallback art. Workstation fronts are fixed north-facing. Models retain the existing collision bodies and AI limits. Managed Chromium blocks direct file:// navigation, so identical standalone bytes are tested over HTTP with outside requests blocked. ZIP CRCs, embedded payloads, artifact SHA-256 values and fetched public download bytes are verified before release publication. This is not a zero-bug guarantee.

## Supplied Assets — 1.8.1

**363 core tests and three browser scenarios pass.** The web build, standalone HTML and Windows x64 PE compile successfully. All 304 runtime/build/source-asset inputs are frozen before browser verification and rechecked before packaging. The executable's extracted HTML matches the standalone byte-for-byte.

The exact standalone HTML runs over local HTTP with every outside request blocked. Browser tests compare all **327 imported block-face tiles** and **87 item icons**, preserving transparency (allowing normal canvas rounding for translucent pixels). Real UI selection updates the atlas, hotbar, Creative catalog and held/dropped flint-and-steel cutout. Q creates a rendered dropped item. All four packs switch reversibly with identical original-pack atlas snapshots and no world edits. The supplied preference, an inventory stack and a block edit across a chunk boundary survive actual save/reload. The normal Vite web entry starts with a saved Supplied preference, creates a world and responds to W movement. Screenshots of the pack selector, terrain, held cutout and inventory were visually inspected.

The first browser run had a fixture error reading `drop.stack.id`; existing drop records use `drop.id`. Correcting the test required no game change. It was expanded to compare every imported icon, then all three scenarios passed against the same frozen runtime.

All selected source PNG hashes match the manifest. **66 sampled terrain chunks** across generators 2–12 and both dimensions, plus **22 accumulated container snapshots**, match published v1.8.0 byte-for-byte. All 24 non-version data exports are identical; the data source differs only in version/attribution comment. Of the prior JS modules, 76 are byte-identical; only data.js, graphics.js, textures.js and ui.js change. Simulation, physics, recipes, models, combat, audio, storage and networking are unchanged. The previous release's broader model/Survival/multiplayer validations are retained below as history; they were not all repeated for this texture-only update.

Limits: source animations use frame zero with existing fluid shimmer; custom blocks/items and unsupported modeled surfaces keep original art. This does not import new block/item gameplay or guarantee bug-free operation. Native Windows launch and direct file:// persistence cannot be verified on this Linux host; managed Chromium blocks direct file navigation. The exact self-contained payload is tested over HTTP with outside requests blocked. Existing documented foundation limitations remain.

Reference remains Minecraft Java Edition 1.20.4 with partial/missing mechanics in FEATURES.md. This release changes original models and cosmetic animation. Generator 12, item/block IDs, recipes, stats and authoritative movement/combat/progression code are retained. Existing worlds receive the update without regeneration.

## Core checks

**361 core tests pass**, including 11 new model/animation cases. New checks cover all 42 weapon/tool silhouettes, finite vertex colours and transforms, thin geometry, bounded merged batches, dropped-size normalization, actual gold-grip metadata/pixels, raised Devin ridges, three stationary blade glints and Minimal-particle suppression. Distinct staged action curves settle to rest and remain visual only.

Each weapon keeps its grip in the articulated palm through attack/mining/use poses with armor. Swimming checks cover prone strokes, continuous stationary treading, full submersion near the floor, wading/Creative-flight exclusions, smooth land exit, hip-centered rotation, pause, held-item phase continuity and first-person phase consistency across 30/60/144 Hz. Validated co-op appearance flags/visual velocity are tested separately from authoritative physics.

All eight Cinderworld designs have distinct geometry, finite animated special poses, preserved collision heights, glowing rest materials and bounded batches. Added jaw/claw/cloak subassemblies initially exceeded the old Titan draw budget; batching each rigid joint group corrected this without raising the existing budget. A water playtest found swimming stopping near the bottom: the visual pose now also accepts full submersion, without changing water physics. Hip-centered rotation and accumulated stroke phase prevent position drift and phase jumps.

Published v1.7 pistol geometry, first-person fire poses and F5 player poses have matching fingerprints. The pistol model, audio, abilities and effects source files are byte-identical. Working block/door models have matching fingerprints. World, physics, simulation, inventory, equipment, relic, cave and hostile-combat source files are byte-identical. The planted Devin display shares the new held model, stays inside its existing target cell, respects Minimal particles, hides after claim/removal and leaves the extraction blocks intact.

## Browser playtests

**Eight selected browser scenarios pass** on the frozen build:

1. Exact standalone: generate all 42 held models, render representative weapon/tool families, inspect flint/steel's actual transparent hole and flat geometry, ignite ordinary ground with durability loss, drop it using Q, preserve ordinary blocks/pistols, then save/reload an edited world.
2. Actual sword-click damage; F5 staged weapon poses, attached elbow/palm grips, Minimal-particle suppression, and a naturally generated temple's matching planted Devin model. Deterministic animation phase is frozen for action screenshots.
3. Actual W movement through real water with existing fluid/body physics, first-person paddling, F5 prone swimming, continuous stationary treading and smooth land recovery.
4. Eight redesigned Cinderworld foe/neutral rigs in the actual dimension, special-pose rendering and glowing material restoration after a damage flash.
5. Retained pistol palm sockets, independent recoil, F5, particle controls and item swaps.
6. Flint ignition and actual portal entry, linked Cinderworld return, realm saves and persistent reload.
7. All-Guardians sword requirement: Creative/Peaceful refusal, real defeats across reload, Sigil attunement, the actual 30-second held-mouse extraction and a unique persistent sword.
8. Actual HTTPS/WSS Survival relay, invitation, synchronized chat/inventory/world interactions and rendered co-op player appearances.

New model/cinder/swim screenshots are visually inspected. Creature positions, gear, target health, animation phases and portal/Guardian fixtures are controlled for reproducibility; this is not an unaided complete Survival playthrough or a guarantee of no bugs. The first visual pass exposed the bottom-of-pool pose gap and the new joint batching budget issue; both are fixed. One final test initially expected durability loss in Creative; its fixture was corrected to verify Creative keeps 64 uses and Survival ignition consumes one, without changing gameplay. The corrected scenario was rerun against the identical frozen build. Tests exercise production input, rendering, physics and inventory/save paths. Every historical browser scenario was not repeated.

## Compatibility and builds

Sixty-six sampled chunks across generators 2–12 and both dimensions are byte-identical to published v1.7.0, as are 22 accumulated container snapshots. Block/item definitions, recipes, mob stats, Creative catalogs and generation version compare equal. Thirteen relevant gameplay/pistol source files have identical SHA-256 values. These are representative terrain samples, not exhaustive proof across all seeds/chunks. The versioned compatibility report includes comparisons and fingerprints.

The production web build, self-contained HTML and Windows x64 executable build successfully. The companion extractor yields HTML identical to the standalone; the PE embeds the same bytes. Runtime/build inputs are frozen before browser tests and rechecked before packaging. ZIP CRCs and artifact SHA-256 values are verified; public download bytes are fetched and compared again before release publication.

Native Windows execution is unverified on this Linux host. Managed Chromium blocks direct file:// navigation before the game loads, so the identical standalone HTML is tested over local HTTP with outside requests blocked. The flint/portal and HTTPS cases rebuild the same frozen source into a temporary standalone copy; it is compared with the shipped HTML. Live Cloudflare tunneling and actual YouTube streaming remain unverified. Historical PERFORMANCE.json data is labelled by its original versions; no new hardware FPS claim is made.

## Intentional limits

These are original assets and cosmetic animations, not exact Minecraft skin UV/animation parity. The swimming model retains the authoritative upright collision body, so a horizontal visual limb can intersect nearby terrain. Animation wind-up does not delay existing click damage. Pistol models/recoil/F5 player rig/poses remain excluded; that retained stance is an intentional exception to the new non-pistol swimming rig. Co-op player movement/swimming appearances update, while complete remote attack animation synchronization remains partial. Enemy navigation/combat limits remain as previously documented.