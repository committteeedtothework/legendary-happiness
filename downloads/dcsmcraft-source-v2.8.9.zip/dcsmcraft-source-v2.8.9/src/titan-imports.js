import { TITAN_FINALE, titanCounterContact } from "./titan-cinematics.js";
import { titanBodyHeight, titanWorldPoint } from "./titan-space.js";
import { titanStepProgress } from "./titan-mobility.js";
import { addTitanMotionClips } from "./titan-motion-clips.js";
import { titanActionDuration } from "./titan-combat.js";
import { nearestTitanSurface, titanAttackSide } from "./titan-contact.js";
import { performTitanSonic, performTitanBoss } from "./titan-kinematics.js";
import * as T from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { clone as cloneSkeleton } from "three/addons/utils/SkeletonUtils.js";
import { TITAN_GLB_DATA } from "./titan-model-data.js";
import { TITAN_MOVES } from "./giganto-simulation.js";
let pending;
function bytes(base64) {
  const s = atob(base64),
    b = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i);
  return b.buffer;
}
export async function prepareTitanModels() {
  if (!pending)
    pending = Promise.all(
      ["sonic", "giganto"].map(async (role) => {
        const loader = new GLTFLoader();
        loader.setCrossOrigin("anonymous");
        // All buffers and WebP images are embedded. No CDN or decoder request.
        const gltf = await loader.parseAsync(
          bytes(TITAN_GLB_DATA[role].base64),
          "",
        );
        const metadata = gltf.parser.json.extras?.dcsmRig;
        if (!metadata || metadata.role !== role)
          throw Error("Imported Titan rig metadata is missing: " + role);
        const required =
          role === "sonic"
            ? [
                "idle",
                "move",
                "run",
                "boost",
                "jump",
                "fly",
                "parry",
                "transform",
                "attack",
                "damage",
                "defeat",
              ]
            : [
                "idle",
                "arm_swing",
                "arm_slap",
                "grab",
                "beam_fire",
                "defeat",
                "dorsal_extend",
              ];
        for (const name of required)
          if (!gltf.animations.some((a) => a.name === name))
            throw Error(role + " is missing animation " + name);
        for (const name of Object.values(metadata.bones))
          if (!gltf.scene.getObjectByName(name))
            throw Error(role + " is missing joint " + name);
        let superMaterial;
        if (role === "sonic")
          superMaterial = await gltf.parser.getDependency(
            "material",
            gltf.parser.json.extras.dcsmSuperMaterial,
          );
        gltf.scene.traverse((o) => {
          if (o.geometry) o.geometry.userData.dcsmShared = true;
        });
        return { role, gltf, metadata, superMaterial };
      }),
    ).catch((e) => {
      pending = null;
      throw e;
    });
  return pending;
}
export function importedRig(asset) {
  const root = new T.Group(),
    model = cloneSkeleton(asset.gltf.scene),
    materials = new Map();
  root.name = "Imported " + asset.role;
  root.add(model);
  model.traverse((o) => {
    if (o.isMesh) {
      o.material = Array.isArray(o.material)
        ? o.material.map(copy)
        : copy(o.material);
      o.castShadow = o.receiveShadow = true;
      o.frustumCulled = false;
    }
  });
  function copy(m) {
    if (!materials.has(m)) materials.set(m, m.clone());
    return materials.get(m);
  }
  const meta = asset.metadata,
    bones = Object.fromEntries(
      Object.entries(meta.bones).map(([key, name]) => [
        key,
        model.getObjectByName(name),
      ]),
    );
  const mixer = new T.AnimationMixer(model),
    actions = new Map(
      asset.gltf.animations.map((clip) => {
        // Locomotion clips contain redundant bind-pose translation/scale keys.
        // Keep limb lengths and model scale in the character's own bind space.
        let playback = clip;
        if (asset.role === "sonic" && ["move", "run"].includes(clip.name)) {
          playback = clip.clone();
          playback.tracks = playback.tracks.filter(
            (t) =>
              !t.name.endsWith(".scale") &&
              (!t.name.endsWith(".position") || t.name === "Hips.position"),
          );
          const hips = playback.tracks.find((t) => t.name === "Hips.position");
          if (hips) {
            const rest = bones.hip.position,
              values = hips.values;
            let mean = 0;
            for (let i = 1; i < values.length; i += 3) mean += values[i];
            mean /= values.length / 3;
            for (let i = 0; i < values.length; i += 3) {
              values[i] = rest.x;
              values[i + 1] = rest.y + (values[i + 1] - mean) * 0.65;
              values[i + 2] = rest.z;
            }
          }
        }
        const action = mixer.clipAction(playback);
        action.setEffectiveWeight(0);
        action.setLoop(
          meta.clips[clip.name]?.loop ? T.LoopRepeat : T.LoopOnce,
          Infinity,
        );
        action.clampWhenFinished = true;
        return [clip.name, action];
      }),
    );
  const superMat = asset.superMaterial?.clone();
  root.userData = {
    imported: true,
    role: asset.role,
    model,
    bones,
    materials: [...materials.values(), ...(superMat ? [superMat] : [])],
    mixer,
    actions,
    metadata: meta,
    super: false,
    superMaterial: superMat,
    blueMaterials: [],
    rods: (meta.rods || []).map((name) => model.getObjectByName(name)),
    laserSockets: Array.from({ length: 10 }, (_, i) =>
      model.getObjectByName("socket_dorsal_" + String(i + 1).padStart(2, "0")),
    ),
    jawSocket: model.getObjectByName("socket_mouth"),
    quills: (meta.quills || []).map((name) => model.getObjectByName(name)),
    lastAttack: "idle",
    transitions: new Map(),
    bindScales: new Map(),
    sampledRotations: new Map(),
    hipRest: bones.hip.quaternion.clone(),
  };
  if (asset.role === "sonic")
    model.traverse((o) => {
      if (o.isBone) root.userData.bindScales.set(o, o.scale.clone());
    });
  if (asset.role === "sonic")
    model.traverse((o) => {
      if (o.isMesh) root.userData.blueMaterials.push([o, o.material]);
    });
  model.traverse((o) => {
    if (o.isBone) root.userData.sampledRotations.set(o, o.quaternion.clone());
  });
  addTitanMotionClips(root.userData);
  model.updateMatrixWorld(true);
  root.userData.footBindings = new Map(
    ["L", "R"]
      .map((side) => {
        const foot = model.getObjectByName(
          side === "L" ? "Foot_L_092" : "Foot_R_098",
        );
        return [
          side,
          foot
            ? { foot, orientation: foot.getWorldQuaternion(new T.Quaternion()) }
            : null,
        ];
      })
      .filter(([, v]) => v),
  );
  return root;
}
function actionAt(u, name, time, dt, layer = "body") {
  const action = u.actions.get(name);
  if (!action) throw Error("Missing imported clip " + name);
  const previous = u[layer];
  if (previous !== action) {
    action.reset().play();
    action.setEffectiveWeight(0);
    action.setEffectiveTimeScale(0);
    const existing = u.transitions.get(layer);
    if (existing?.previous && existing.previous !== previous)
      existing.previous.stop();
    u.transitions.set(layer, {
      previous,
      action,
      age: previous ? 0 : 0.16,
      duration: /attack|counter|boom|rush|dodge/.test(name) ? 0.065 : 0.16,
    });
    u[layer] = action;
  }
  const duration = action.getClip().duration,
    loop = u.metadata.clips[name]?.loop || u.loopClips?.has(name);
  action.paused = false;
  action.enabled = true;
  action.time = loop
    ? ((Math.max(0, time) % duration) + duration) % duration
    : Math.max(0, Math.min(duration - 1e-6, time));
  return action;
}
function blendRig(u, dt) {
  for (const [layer, transition] of u.transitions) {
    transition.age += Math.max(0, dt);
    const t = Math.min(1, transition.age / transition.duration),
      w = t * t * (3 - 2 * t);
    transition.action.setEffectiveWeight(w);
    if (transition.previous) transition.previous.setEffectiveWeight(1 - w);
    if (t === 1) {
      transition.previous?.stop();
      u.transitions.delete(layer);
    }
  }
  // Sample once. Reapplying the mixer after IK caused stateful pose feedback.
  // PropertyMixer skips assigning unchanged samples. Restore the last sampled
  // pose before IK, so static/paused poses cannot accumulate procedural offsets.
  for (const [bone, q] of u.sampledRotations) bone.quaternion.copy(q);
  u.mixer.update(0);
  for (const [bone, q] of u.sampledRotations) q.copy(bone.quaternion);
}
export function updateImportedSonic(root, s, dt) {
  const u = root.userData,
    p = s.avatar,
    speed = Math.hypot(p.vx, p.vz),
    gold = s.emerald && !["intro", "traversal"].includes(s.stage);
  root.position.set(p.x, p.y + 0.12, p.z);
  root.rotation.z = 0;
  root.rotation.x = 0;
  let facing = p.yaw + Math.PI;
  if (!gold && speed > 1) facing = Math.atan2(p.vx, p.vz);
  if (gold && s.lock) {
    const c = nearestTitanSurface(s, p).point;
    facing = Math.atan2(c.x - p.x, c.z - p.z);
  }
  if (s.action === "loop" && speed > 1) facing = Math.atan2(p.vx, p.vz);
  const turn = Math.atan2(
    Math.sin(facing - root.rotation.y),
    Math.cos(facing - root.rotation.y),
  );
  root.rotation.y += turn * (1 - Math.exp(-dt * 14));
  let name =
      gold && !p.onGround
        ? speed > 25
          ? "boost_flight"
          : "fly"
        : !p.onGround
          ? p.vy > 0
            ? "jump"
            : "fall"
          : speed > 25
            ? "run"
            : speed > 16
              ? "run"
              : speed > 1
                ? "move"
                : "idle",
    time = s.time;
  if (gold && !p.onGround && p.vy > 5 && p.y < 10) name = "jump";
  if (s.qte) {
    name = s.qte.kind === "beam" ? "brace_beam" : "brace_grab";
    time = s.time;
  } else if (s.counterScene) {
    name = "counter_break";
    time = s.counterScene.elapsed;
    const q = titanCounterContact(s);
    root.rotation.y = Math.atan2(q.point.x - p.x, q.point.z - p.z);
  } else if (s.stage === "finale") {
    name = "finale_strike";
    time = s.stageTime;
    const q = titanWorldPoint(s, { x: 0, y: 85, z: 18 });
    root.rotation.y = Math.atan2(q.x - p.x, q.z - p.z);
  } else if (s.stage === "transform") {
    name = "transform";
    time = s.stageTime;
  } else if (s.stage === "defeat") {
    name = "defeat";
    time = s.stageTime;
  } else if (gold) {
    const map = {
      punch: [
        (s.strike?.hand || (s.comboStep % 2 ? "L" : "R")) === "L"
          ? "attack_left"
          : "attack_right",
        titanActionDuration(s),
      ],
      homing: ["homing_attack", 0.72],
      cross: ["cross_slash", 0.8],
      counter: ["counter", 1.2],
      boom: ["sonic_boom", 0.65],
      rush: ["wild_rush", 0.8],
      loop: ["quick_cyloop", titanActionDuration(s)],
      dodge: ["dodge", 0.42],
      hurt: ["damage", 0.5],
    };
    if (s.parryHeld) {
      name = "parry";
      time = s.time;
    }
    if (map[s.action]) {
      const q = map[s.action];
      name = q[0];
      const duration = u.actions.get(name).getClip().duration;
      time = ((q[1] - s.actionTime) / q[1]) * duration;
    }
  }
  if (u.super !== gold) {
    u.super = gold;
    for (const [m, blue] of u.blueMaterials)
      m.material = gold ? u.superMaterial : blue;
  }
  actionAt(u, name, time, dt);
  const quills = u.actions.get("super_quills");
  if (gold) {
    if (!u.quillsPlaying) {
      quills.reset().play().setEffectiveTimeScale(0);
      u.quillsPlaying = true;
    }
  } else if (u.quillsPlaying) {
    u.quillsPlaying = false;
  }
  u.quillWeight =
    (u.quillWeight || 0) +
    ((gold ? 1 : 0) - (u.quillWeight || 0)) *
      (1 - Math.exp(-Math.max(0, dt) * 7));
  quills.setEffectiveWeight(u.quillWeight);
  if (!gold && u.quillWeight < 0.001) quills.stop();
  blendRig(u, dt);
  for (const [bone, scale] of u.bindScales) bone.scale.copy(scale);
  u.currentClip = name;
  performTitanSonic(root, s);
}
export function updateImportedGiganto(root, s, dt) {
  root.position.x = s.boss?.x || 0;
  root.position.z = s.boss?.z || 0;
  root.rotation.y = s.boss?.yaw || 0;
  const u = root.userData,
    scale = { easy: 1.25, normal: 1, hard: 0.85 }[s.config.difficulty];
  let name = "idle",
    time = s.time;
  if (u.lastAttack !== "idle" && s.attack === "idle")
    u.recovery = { attack: u.lastAttack, side: u.lastSide, start: s.time };
  if (s.attack !== "idle") u.lastSide = titanAttackSide(s);
  u.lastAttack = s.attack;
  if (s.stage === "phase") {
    name = "phase_transition";
    time = s.stageTime;
  } else if (s.stage === "finale") {
    name =
      s.stageTime < TITAN_FINALE.contact ? "finale_brace" : "finale_collapse";
    time =
      s.stageTime < TITAN_FINALE.contact
        ? s.stageTime
        : s.stageTime - TITAN_FINALE.contact;
  } else if (s.counterScene) {
    name = "counter_recoil";
    time = s.counterScene.elapsed;
  } else if (s.stage === "victory") {
    name = "defeat";
    time = 6;
  } else if (s.stagger > 0) {
    name = "stagger";
    time = s.time;
  } else if (s.stage === "combat" && s.boss?.walk) {
    name = "move";
    time = titanStepProgress(s) * u.actions.get(name).getClip().duration;
  } else if (s.stage === "combat" && s.attack !== "idle") {
    const m = TITAN_MOVES[s.attack],
      tell = m.tell * scale,
      t = s.attackTime;
    if (s.attack === "beam") {
      name = s.qte ? "beam_fire" : "beam_charge";
      time = s.qte ? 4.5 - s.qte.left : t / scale;
    } else if (s.attack === "stomp") {
      name = "stomp_" + (s.swatSide || "L");
      time = t;
    } else if (s.attack === "crunch") {
      name = t < tell ? "grab_windup" : "grab";
      time = t < tell ? t / scale : s.qte ? 4.2 - s.qte.left : t - tell;
    } else {
      const base = titanAttackSide(s) === "L" ? "arm_swing" : "arm_slap";
      name = t < tell ? base + "_windup" : base;
      time =
        t < tell
          ? t / scale
          : ((t - tell) / m.strike) * u.actions.get(name).getClip().duration;
    }
  } else if (s.stage === "combat" && u.recovery) {
    const q = u.recovery,
      base =
        q.attack === "swing" || (q.attack === "swat" && q.side === "L")
          ? "arm_swing"
          : ["slap", "swat"].includes(q.attack)
            ? "arm_slap"
            : q.attack === "crunch"
              ? "grab"
              : null;
    time = s.time - q.start;
    if (base && time < u.actions.get(base + "_recovery").getClip().duration)
      name = base + "_recovery";
  }
  actionAt(u, name, time, dt);
  const dorsal =
      s.phase === 2 && s.stage !== "phase" ? "dorsal_pulse" : "dorsal_extend",
    dorsalTime =
      s.phase === 2 ? (s.stage === "phase" ? s.stageTime : s.time) : 0;
  actionAt(u, dorsal, dorsalTime, dt, "dorsal");
  blendRig(u, dt);
  if (s.boss?.walk && s.stage !== "finale")
    u.bones.hip.quaternion.copy(u.hipRest);
  u.currentClip = name;
  root.position.y =
    titanBodyHeight(s.boss) -
    (s.stage === "finale"
      ? 12 *
        Math.max(
          0,
          Math.min(
            1,
            (s.stageTime - TITAN_FINALE.rupture) / (7 - TITAN_FINALE.rupture),
          ),
        ) **
          2
      : 0) +
    (s.stagger > 0 && s.action === "loop"
      ? Math.sin((1 - s.actionTime / titanActionDuration(s)) * Math.PI) * 5
      : 0);
  root.rotation.x = 0;
  // A brief recoil never replaces attack telegraphs or freezes the controller.
  if (
    s.hitFeedback?.until > s.time &&
    s.stage === "combat" &&
    s.attack === "idle" &&
    !s.boss?.walk
  ) {
    const w = Math.sin(((s.hitFeedback.until - s.time) / 0.3) * Math.PI);
    root.rotation.x =
      -0.006 * Math.min(2, (s.hitFeedback.amount || 0) / 90) * w;
  }
  performTitanBoss(root, s);
}
export function disposeImportedRig(root) {
  if (!root?.userData.imported) return;
  const u = root.userData;
  u.mixer.stopAllAction();
  u.mixer.uncacheRoot(u.model);
  // Alternate form materials may no longer be attached when a fight ends.
  // Shared maps/geometry stay in the bounded asset cache; skeleton textures
  // and unused per-encounter material instances must still be released.
  const attached = new Set(),
    skeletons = new Set();
  root.traverse((o) => {
    if (o.isMesh)
      for (const m of Array.isArray(o.material) ? o.material : [o.material])
        attached.add(m);
    if (o.isSkinnedMesh) skeletons.add(o.skeleton);
  });
  for (const m of u.materials) if (!attached.has(m)) m.dispose();
  for (const skeleton of skeletons) skeleton.dispose();
}
