import { createWeaponModel } from "./weapon-models.js";
import { createPistolModel } from "./pistol-model.js";
import * as THREE from "three";
import { BLOCKS, ITEMS } from "./data.js";
import { itemIconCanvas } from "./textures.js";
import { isFlatItem } from "./item-shapes.js";
import { blockArtUV } from "./block-art.js";

function box(parent, size, position, material) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  mesh.position.set(...position);
  parent.add(mesh);
  return mesh;
}
export function createHandRig() {
  const root = new THREE.Group(),
    wrist = new THREE.Group(),
    grip = new THREE.Group();
  root.add(wrist);
  root.position.set(0.37, -0.27, -0.72);
  wrist.rotation.set(-0.12, -0.12, -0.13);
  const skin = new THREE.MeshLambertMaterial({ color: "#bb8b64" });
  const sleeve = new THREE.MeshLambertMaterial({ color: "#355b6b" });
  box(wrist, [0.115, 0.24, 0.11], [0, -0.245, 0.07], sleeve).rotation.x = -0.3;
  box(wrist, [0.1, 0.16, 0.095], [0, -0.105, 0.025], skin);
  box(wrist, [0.108, 0.12, 0.08], [0, 0, 0.02], skin);
  // The handle fits between the palm and fingers; the head is above the fist.
  for (let i = 0; i < 3; i++)
    box(wrist, [0.1, 0.028, 0.028], [0, -0.03 + i * 0.032, -0.065], skin);
  box(wrist, [0.033, 0.065, 0.065], [-0.065, 0.015, -0.025], skin).rotation.z =
    -0.3;
  grip.position.set(0, 0, -0.042);
  wrist.add(grip);
  const glove = new THREE.Group();
  const leather = new THREE.MeshLambertMaterial({ color: "#292833" });
  box(glove, [0.111, 0.075, 0.085], [0, 0.02, 0.023], leather);
  box(glove, [0.104, 0.047, 0.1], [0, -0.075, 0.025], leather);
  glove.visible = false;
  wrist.add(glove);
  return { root, wrist, grip, sleeve, skin, glove };
}
export function createHeldModel(id, atlas) {
  const item = ITEMS[id];
  if (!item) return null;
  if (id === "matthew_dual_pistols") return createPistolModel();
  const weapon = createWeaponModel(id);
  if (weapon) return weapon;
  if (isFlatItem(id)) return createFlatTool(id);
  const g = new THREE.Group();
  g.userData.kind = item.block !== undefined ? "block" : item.tool || "item";
  if (item.block !== undefined) {
    const door = BLOCKS[item.block].door;
    const geometry = new THREE.BoxGeometry(
      door ? 0.15 : 0.235,
      door ? 0.32 : 0.235,
      door ? 0.035 : 0.235,
    );
    const uv = geometry.attributes.uv;
    for (let face = 0; face < 6; face++) {
      for (let i = face * 4; i < face * 4 + 4; i++) {
        const [u, v] = blockArtUV(
          item.block,
          face,
          uv.getX(i),
          uv.getY(i),
          atlas.pack,
        );
        uv.setXY(i, u, v);
      }
    }
    const cube = new THREE.Mesh(
      geometry,
      new THREE.MeshLambertMaterial({ map: atlas.texture, alphaTest: 0.5 }),
    );
    cube.material.userData.sharedMap = true;
    cube.position.set(-0.025, 0.11, door ? -0.055 : -0.18);
    cube.rotation.y = -0.35;
    g.add(cube);
  }
  return g;
}

function createFlatTool(id) {
  const root = new THREE.Group();
  const map = new THREE.CanvasTexture(itemIconCanvas(id));
  map.magFilter = map.minFilter = THREE.NearestFilter;
  map.colorSpace = THREE.SRGBColorSpace;
  const mesh = new THREE.Mesh(
    new THREE.PlaneGeometry(0.24, 0.24),
    new THREE.MeshLambertMaterial({
      map,
      alphaTest: 0.5,
      side: THREE.DoubleSide,
    }),
  );
  mesh.position.set(0, 0.075, -0.025);
  root.add(mesh);
  root.userData = { kind: "item", flatCutout: true, item: id };
  return root;
}
export function createDroppedModel(id, atlas) {
  const item = ITEMS[id];
  if (!item) return new THREE.Group();
  const model = createHeldModel(id, atlas);
  const bounds = new THREE.Box3().setFromObject(model),
    size = bounds.getSize(new THREE.Vector3()),
    center = bounds.getCenter(new THREE.Vector3());
  // Root offset preserves rigid tool grips while normalising dropped silhouettes.
  const root = new THREE.Group(),
    scale = 0.38 / Math.max(size.x, size.y, size.z, 0.01);
  model.position.sub(center);
  root.add(model);
  root.scale.setScalar(scale);
  root.userData.droppedItem = id;
  root.userData.flatCutout = !!model.userData.flatCutout;
  return root;
}
