import {
  controllerConfig,
  CONTROLLER_PRESETS,
  PAD_BUTTONS,
  padGlyph,
  arenaPadGlyph,
} from "./controller-data.js";
const esc = (s) =>
  String(s).replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
export function controllerPanel(c, status = "No controller connected") {
  const range = (k, label, a, b, step) =>
    `<label class="range-label"><span>${label}<output>${c[k]}</output></span><input type="range" data-pad-setting="${k}" min="${a}" max="${b}" step="${step}" value="${c[k]}"></label>`;
  const check = (k, label) =>
    `<label><input type="checkbox" data-pad-setting="${k}" ${c[k] ? "checked" : ""}> ${label}</label>`;
  return `<main class="dialog settings-dialog controller-dialog"><h2>Controller</h2><p id="controller-status" role="status">${esc(status)}</p>${check("enabled", "Controller enabled")}<label>Preset<select data-pad-setting="preset">${CONTROLLER_PRESETS.map(([id, label]) => `<option value="${id}" ${c.preset === id ? "selected" : ""}>${label}</option>`).join("")}</select></label>${range("deadzone", "Stick dead zone", 0.05, 0.45, 0.01)}${range("lookSensitivity", "Look sensitivity", 0.5, 6, 0.1)}${check("invertY", "Invert vertical look")}${check("vibration", "Vibration")}<details ${c.preset === "custom" ? "open" : ""}><summary>Custom mapping</summary><p>Button and axis numbers start at 0. Use −1 to disable a binding. Button mapping applies to the Custom preset.</p><div class="controller-mapping">${Object.entries(
    PAD_BUTTONS,
  )
    .map(
      ([key]) =>
        `<label>${esc(key.replace(/([A-Z])/g, " $1"))}<input type="number" min="-1" max="63" step="1" value="${c.bindings[key]}" data-pad-binding="${key}"></label>`,
    )
    .join(
      "",
    )}${["moveX", "moveY", "lookX", "lookY", "leftTriggerAxis", "rightTriggerAxis"].map((key) => `<label>${esc(key.replace(/([A-Z])/g, " $1"))}<input type="number" min="-1" max="15" step="1" value="${c[key]}" data-pad-setting="${key}"></label>`).join("")}</div><div id="controller-live" aria-live="off"></div></details><details><summary>Controls</summary><p>Left stick · Move. Right stick · Look. Triggers · Use / Mine. Bottom face · Jump. Right face · Crouch. Top face · Inventory. Stick click · Sprint. Shoulders · Hotbar.</p><p>View / Create / − opens Actions for weapon abilities, Stands, chat, dropping items and the camera. Menu / Options / + pauses.</p><p>Menus: D-pad or left stick · Navigate. Bottom face · Confirm (Switch: A). Right face · Back (Switch: B). Left/right · Adjust a slider or selection. Right stick · Scroll. Inventory: confirm · Move stack, left face · Split, top face · Quick transfer.</p><p>Unmapped devices can use Custom. A browser may report a translated controller as Xbox; choose a preset to set its prompts. System file pickers require the mouse or operating-system controls.</p></details><button class="secondary wide" data-pad-command="reset">Reset controller settings</button><button class="primary wide" data-pad-command="back">Done</button></main>`;
}
export function installControllerUI(manager) {
  const { game: g } = manager,
    ui = g.ui;
  ui.controllerMenu = () => {
    if (g.giganto?.active) return;
    ui.setScreen(
      "controller-settings",
      controllerPanel(
        controllerConfig(g.settings.controller),
        manager.status(),
      ),
    );
  };
  ui.overlay.addEventListener("click", (e) => {
    const open = e.target.closest('[data-action="controller-settings"]');
    if (open && !g.giganto?.active) {
      ui.controllerMenu();
      return;
    }
    const b = e.target.closest("[data-pad-command]");
    if (!b) return;
    if (b.dataset.padCommand === "back") ui.settings();
    if (b.dataset.padCommand === "reset") {
      g.settings.controller = controllerConfig();
      ui.saveSettings();
      manager.clear();
      manager.awaitNeutral = true;
      ui.controllerMenu();
    }
  });
  ui.overlay.addEventListener("change", (e) => {
    const key = e.target.dataset.padSetting,
      binding = e.target.dataset.padBinding;
    if (!key && !binding) return;
    const c = controllerConfig(g.settings.controller);
    if (binding) {
      c.preset = "custom";
      c.bindings[binding] = Number(e.target.value);
    } else
      c[key] =
        e.target.type === "checkbox"
          ? e.target.checked
          : e.target.tagName === "SELECT"
            ? e.target.value
            : Number(e.target.value);
    g.settings.controller = controllerConfig(c);
    ui.saveSettings();
    manager.clear();
    const out = e.target.closest("label")?.querySelector("output");
    if (out) out.textContent = e.target.value;
    if (key === "preset" || binding) {
      manager.awaitNeutral = true;
      ui.controllerMenu();
    }
  });
}
export function arenaControllerGuide(family) {
  const p = (k) => padGlyph(family, k),
    a = (k) => arenaPadGlyph(family, k);
  return `<section class="titan-control-sheet"><h3>Movement</h3><dl><dt>Left stick</dt><dd>Move</dd><dt>Right stick</dt><dd>Camera</dd><dt>${p("jump")}</dt><dd>Jump / Rise</dd><dt>${p("crouch")}</dt><dd>Descend</dd><dt>${p("mine")}</dt><dd>Boost</dd><dt>${p("target")}</dt><dd>Lock on</dd><dt>${p("view")}</dt><dd>Controls overlay</dd></dl><h3>Combat</h3><dl><dt>${p("attack")}</dt><dd>Attack / Counter</dd><dt>${p("use")}</dt><dd>Parry</dd><dt>${p("rightShoulder")}</dt><dd>Dodge</dd>${["homing", "boom", "rush", "loop", "cross", "shot", "stomp", "spin", "cyclone"].map((k) => `<dt>${a(k)}</dt><dd>${{ homing: "Homing attack", boom: "Sonic Boom", rush: "Wild Rush", loop: "Quick Cyloop", cross: "Cross Slash", shot: "Homing Shot", stomp: "Stomp", spin: "Spin Slash", cyclone: "Cyclone Kick" }[k]}</dd>`).join("")}</dl></section>`;
}
