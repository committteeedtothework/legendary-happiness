# Validation record — DCSMCRAFT 1.4.1

Mechanics reference remains **Minecraft Java Edition 1.20.4**. Open Skies HTTPS adds native TLS serving, an explicit optional public-tunnel launcher, and public relay connection controls. The existing Survival/Creative sandbox and parity limits remain in FEATURES.md.

## Checks

- **299 core tests pass**, including seven new public-relay cases. They verify public/private/insecure address classification; strict provider-URL extraction; actual certificate-verified HTTPS/WSS host/guest/chat/private routing; operator invitation updates; readiness retries, deadlines and cancellation; launcher address advertisement/instructions/idempotent shutdown; missing utility help; and refusal to report an unreachable tunnel as ready. The launcher lifecycle uses a separate test-only provider process and a test probe, not a real Cloudflare connection. No fake provider result ships in the game.
- **One new browser scenario passes** against the built standalone HTML served by a real native Node HTTPS listener. Two independent Chromium clients use actual WSS to share a Survival world, chat, an owner-granted private inventory and a world edit. It checks Public mode rejects an insecure/private endpoint, Local mode probes TLS without creating a room, the address persists, invitations use HTTPS, sockets use WSS, and an operator address change refreshes the invitation and connection label. The isolated browser test permits its own self-signed certificate; the core WSS/HTTPS test verifies that certificate against its explicit test CA. Shipping clients keep normal certificate validation. Test certificates/keys are generated under temporary directories and removed, never packaged as runtime credentials.
- **Four retained browser scenarios pass** on the same frozen build: full Survival gathering/crafting/building/chest/furnace/combat/death/respawn/host-reload/profile-rejoin; two Survival guests racing one chest stack and enforcing owner permissions; three Creative clients sharing invitations/edits/doors/skins/chat/weapon combat/saves/removal/reopen; and the standalone offline jukebox failure/fallback. These are controlled fixtures and real game controls/production simulation, not a claim of every repository browser test, an unaided complete Survival playthrough or zero possible bugs.
- A source comparison with 1.4.0 confirms **65 existing source modules are byte-identical**, including terrain, meshing/rendering, movement/physics, inventory, simulation, Survival authority, storage, realm handling, audio/music, weapons, skins and jukebox. Source changes are version metadata, one relay connection helper, multiplayer address handling, menu integration and scoped styles. No package dependency or world-generation version was added.

## External service and internet limits

Requests to the official Cloudflare documentation and GitHub cloudflared release API returned **HTTP 403 in this environment**. cloudflared is not installed/bundled here, and **live Quick Tunnel creation, its current provider behavior and play from distinct actual Wi-Fi networks remain unverified**. The implementation invokes the separately installed official utility only when the user explicitly starts HOST-PUBLIC; it never downloads a replacement, proxies around this environment's restrictions or starts during offline play.

The launcher binds the relay to localhost on an available port, extracts only the provider's HTTPS trycloudflare.com origin, advertises that address, and probes public HTTPS plus WSS before reporting READY. Failures/timeouts/cancellation close the local relay and child process. The address is written to PUBLIC-RELAY.txt and optionally opened. Friends use the game invitation; both the public process and the owner browser must stay open. A provider outage/limit/firewall can prevent readiness.

Quick Tunnel addresses change on restart. Guest credentials and browser saves are scoped to their relay address/origin; a changed address starts a fresh guest profile. Use a stable HTTPS address for ongoing guest inventory persistence. Existing desktop/file worlds can remain in their stable local save profile while connecting to the tunnel. No permanent public server, cloud account, certificate provisioning, dedicated simulation, host migration or server disk save was created in this delivery. Stable direct-TLS/proxy hosting remains available; operator setup is required. The previous Docker dependency-install DNS failure remains unresolved, and no public container deployment is claimed.

## Builds and packaging

`npm test`, `npm run build`, `npm run build:standalone` and `npm run build:desktop` succeed. **92 game/public/server/package/launcher/deployment inputs** are frozen by SHA-256 before browser testing and verified during packaging. Production smoke checks cover world creation, F5, held pistols and original sound output, hotbar moves, jukebox menu/no SDK before Play, and owner chat/time commands, collecting page/GPU errors. Screenshots were visually inspected.

Packaging checks ZIP CRCs, complete source/config/launcher inclusion, artifact SHA-256 hashes, Windows/public-host wrapper bytes, and byte-identical executable HTML extraction to a path containing spaces. The packaged Node relay and public-host entry module are checked independently. Previous versioned downloads remain intact.

The unsigned x64 Windows executable embeds the HTML and launches installed Edge/Chrome with its previous stable profile. **Actual Windows 10/11 launch and cloudflared execution on Windows remain unverified on this Linux host.** Managed browser policy blocks direct file navigation here; exact standalone bytes are tested over intercepted or local HTTP(S) URLs. Offline singleplayer needs no relay. YouTube retains its existing external-service and local-file embedding limitations. Other partial/missing mechanics and multiplayer limits remain in FEATURES.md and MULTIPLAYER.md.

## Reproduce

```sh
npm ci
npm test
npm run build
npm run build:standalone
npx playwright test tests/browser/https-relay.spec.js
npx playwright test tests/browser/survival-coop.spec.js tests/browser/multiplayer.spec.js tests/browser/jukebox.spec.js -g 'Survival players chat|two Survival guests race|real relay and three|offline standalone stays playable'
npm run build:desktop
# On a machine with cloudflared installed and provider internet access:
npm run multiplayer:public
```

TLS development tests require the OpenSSL CLI for temporary certificate generation; runtime hosting does not. Build before browser checks and freeze inputs during them. Use separate trace directories. Current checksums and DCSMCRAFT-v1.4.1-validation.json accompany the downloads. Launch/setup/temporary-profile limits are documented in MULTIPLAYER.md, README.md and desktop/README.md.
