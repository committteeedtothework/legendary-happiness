"""Package already-built DCSMCRAFT artifacts using only Python's standard library.

Run from the repository after npm run build, build:standalone and build:desktop.
Pass --verify-manifest /path/to/tested-input-hashes.json to enforce a test freeze.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import argparse
import hashlib
import json
import shutil

root = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument('--output', default=str(root.parent / 'artifacts'))
parser.add_argument('--verify-manifest')
args = parser.parse_args()
art = Path(args.output).resolve()
art.mkdir(parents=True, exist_ok=True)
version = json.loads((root / 'package.json').read_text())['version']
html = root / 'dist/DCSMCRAFT-Standalone.html'
exe = root / 'dist/desktop/DCSMCRAFT.exe'
if args.verify_manifest:
    expected = json.loads(Path(args.verify_manifest).read_text())
    for name, digest in expected.items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, f'Tested input changed: {name}'
for source, name in [(html, f'DCSMCRAFT-Standalone-v{version}.html'), (html, 'DCSMCRAFT-Standalone.html'), (exe, 'DCSMCRAFT.exe')]:
    shutil.copyfile(source, art / name)
docs = ['README.md', 'FEATURES.md', 'VALIDATION.md', 'MULTIPLAYER.md', 'LICENSE', 'THIRD_PARTY.md', 'PERFORMANCE.json', 'STANDS.md', 'AQUATIC.md', 'CONTENT.md']
root_files = ['.gitignore', '.dockerignore', 'render.yaml', *docs, 'index.html', 'package.json', 'package-lock.json', 'playwright.config.js', 'vite.config.js']
source_files = [root / n for n in root_files]
for folder in ['src', 'public', 'scripts', 'desktop', 'server', 'tests', 'reference']:
    source_files += [p for p in (root / folder).rglob('*') if p.is_file() and p.name != 'payload.hpp']
with ZipFile(art / f'dcsmcraft-source-v{version}.zip', 'w', ZIP_DEFLATED) as z:
    for p in sorted(source_files):
        z.write(p, f'dcsmcraft-source-v{version}/{p.relative_to(root)}')

# The optional relay package is ready to run after installing Node; it contains
# the pure-JS ws runtime and its license, with no npm/network step on first run.
relay_files = [(html, 'dist/DCSMCRAFT-Standalone.html'), (root / 'MULTIPLAYER.md', 'START-HERE.md'), (root / 'STANDS.md', 'STANDS.md')]
for folder, dest in [('server', 'server'), ('node_modules/ws', 'node_modules/ws')]:
    for p in sorted((root / folder).rglob('*')):
        if p.is_file():
            relay_files.append((p, f'{dest}/{p.relative_to(root / folder)}'))
relay_package = {'name': 'dcsmcraft-survival-creative-relay', 'version': version, 'private': True, 'type': 'module', 'scripts': {'start': 'node server/relay.mjs', 'public': 'node server/public-relay.mjs'}, 'dependencies': {'ws': '8.18.3'}}
with ZipFile(art / f'DCSMCRAFT-Multiplayer-Server-{version}.zip', 'w', ZIP_DEFLATED) as z:
    for p, dest in relay_files:
        z.write(p, f'Multiplayer-Server/{dest}')
    z.writestr('Multiplayer-Server/HOST-PUBLIC.cmd', '@echo off\r\ncall "%~dp0server\\HOST-PUBLIC.cmd"\r\n')
    z.writestr('Multiplayer-Server/HOST-SERVER.cmd', '@echo off\r\ncall "%~dp0server\\HOST-SERVER.cmd"\r\n')
    z.writestr('Multiplayer-Server/package.json', json.dumps(relay_package, indent=2) + '\n')
with ZipFile(art / f'DCSMCRAFT-Windows-{version}.zip', 'w', ZIP_DEFLATED) as z:
    for p in sorted((root / 'dist/desktop').rglob('*')):
        if p.is_file() and p.name != 'payload-check':
            z.write(p, f'DCSMCRAFT-Windows/{p.relative_to(root / "dist/desktop")}')
    z.write(html, 'DCSMCRAFT-Windows/DCSMCRAFT-Standalone.html')
    for n in docs:
        z.write(root / n, f'DCSMCRAFT-Windows/{n}')
    for p in sorted((root/'reference').rglob('*')):
        if p.is_file():z.write(p,f'DCSMCRAFT-Windows/{p.relative_to(root)}')
    for p, dest in relay_files:
        z.write(p, f'DCSMCRAFT-Windows/Multiplayer-Server/{dest}')
    z.writestr('DCSMCRAFT-Windows/HOST-PUBLIC.cmd', '@echo off\r\ncall "%~dp0Multiplayer-Server\\HOST-PUBLIC.cmd"\r\n')
    z.writestr('DCSMCRAFT-Windows/Multiplayer-Server/HOST-PUBLIC.cmd', '@echo off\r\ncall "%~dp0server\\HOST-PUBLIC.cmd"\r\n')
    z.writestr('DCSMCRAFT-Windows/Multiplayer-Server/HOST-SERVER.cmd', '@echo off\r\ncall "%~dp0server\\HOST-SERVER.cmd"\r\n')
    z.writestr('DCSMCRAFT-Windows/Multiplayer-Server/package.json', json.dumps(relay_package, indent=2) + '\n')
shutil.copyfile(art / f'DCSMCRAFT-Windows-{version}.zip', art / 'DCSMCRAFT-PC.zip')
with ZipFile(art / f'dcsmcraft-build-v{version}.zip', 'w', ZIP_DEFLATED) as z:
    for p in sorted((root / 'dist').rglob('*')):
        if p.is_file() and p.name != 'payload-check':
            z.write(p, f'dcsmcraft-build-v{version}/{p.relative_to(root / "dist")}')
    for n in docs:
        z.write(root / n, f'dcsmcraft-build-v{version}/{n}')
    for p in sorted((root/'reference').rglob('*')):
        if p.is_file():z.write(p,f'dcsmcraft-build-v{version}/{p.relative_to(root)}')

names = [f'DCSMCRAFT-Windows-{version}.zip', 'DCSMCRAFT.exe', f'DCSMCRAFT-Standalone-v{version}.html', f'DCSMCRAFT-Multiplayer-Server-{version}.zip', f'dcsmcraft-source-v{version}.zip', f'dcsmcraft-build-v{version}.zip']
manifest = {}
for name in names:
    p = art / name
    manifest[name] = {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    if p.suffix == '.zip':
        with ZipFile(p) as z:
            assert z.testzip() is None, f'ZIP integrity error: {name}'
with ZipFile(art / f'DCSMCRAFT-Windows-{version}.zip') as z:
    assert z.read('DCSMCRAFT-Windows/DCSMCRAFT.exe') == exe.read_bytes()
    assert z.read('DCSMCRAFT-Windows/DCSMCRAFT-Standalone.html') == html.read_bytes()
assert html.read_bytes() in exe.read_bytes(), 'Executable does not embed this HTML'
(art / f'DCSMCRAFT-v{version}-checksums.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
