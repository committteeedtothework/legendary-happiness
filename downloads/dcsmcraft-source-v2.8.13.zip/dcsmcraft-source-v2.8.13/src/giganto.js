import { titanSweepPrompt } from "./titan-sweep.js";
import { armorMode, armorAttached } from "./titan-climb.js";
import { titanCheckpointEvent } from "./titan-cinematics.js";
import { alignTitanCinematic } from "./titan-timing.js";
import { titanHudTemplate, updateTitanHudExtras } from "./titan-hud.js";
import { prepareTitanModels } from "./titan-imports.js";
import { playWorldSound } from "./spatial-audio.js";
import { B, BLOCKS, ITEMS, makeStack, MIN_Y, MAX_Y } from "./data.js";
import { Inventory } from "./inventory.js";
import { cloneState } from "./compat.js";
import { hash } from "./random.js";
import { awardXP } from "./equipment.js";
import { TitanView, titanPortal, animateTitanPortal } from "./giganto-view.js";
import { disposeTitanObject } from "./giganto-models.js";
import { initializeArenaSettings } from "./titan-settings.js";
import { titanSettingsPanel } from "./titan-menu.js";
import { TitanAudio } from "./giganto-audio.js";
import {
  TITAN_ROUTE,
  TITAN_MOVES,
  TITAN_EMERALD,
  titanConfig,
  titanSession,
  restoreTitanSession,
  stepTitan,
  titanInput,
} from "./giganto-simulation.js";
import "./giganto.css";
export function freshTitanRecord() {
  return {
    schema: 1,
    config: titanConfig(),
    portal: null,
    used: [],
    ledger: [],
    serial: 0,
    cooldownUntil: 0,
    session: null,
  };
}
export function safeTitanSite(g, x, y, z) {
  if (
    g.dimension !== "overworld" ||
    ![x, y, z].every(Number.isFinite) ||
    y < MIN_Y + 2 ||
    y > MAX_Y - 6
  )
    return false;
  const w = g.world;
  if (
    (w.protectedAreas || []).some(
      (a) => Math.hypot(a.x - x, a.z - z) < (a.radius || 20) + 8,
    )
  )
    return false;
  if (
    (g.entities || []).some(
      (e) =>
        e.health > 0 &&
        Math.hypot(e.x - x, e.z - z) < 3 &&
        Math.abs(e.y - y) < 5,
    )
  )
    return false;
  for (let dx = -2; dx <= 2; dx++)
    for (let dz = -2; dz <= 2; dz++) {
      if (
        !w.chunks.has(
          `${Math.floor((x + dx) / 16)},${Math.floor((z + dz) / 16)}`,
        )
      )
        return false;
      const ground = w.get(x + dx, y - 1, z + dz),
        b = BLOCKS[ground];
      if (
        !b?.solid ||
        b.fluid ||
        (b.shape && b.shape !== "cube") ||
        /leaves|log|cactus|bed|chest|magma/.test(b.key)
      )
        return false;
      for (let h = 0; h < 5; h++)
        if (w.get(x + dx, y + h, z + dz) !== B.air) return false;
    }
  return true;
}
function validOriginal(o, g) {
  return (
    o &&
    o.dimension === g.dimension &&
    o.player &&
    [o.player.x, o.player.y, o.player.z, o.player.health].every(
      Number.isFinite,
    ) &&
    o.player.y >= MIN_Y &&
    o.player.y < MAX_Y + 10 &&
    Array.isArray(o.inventory?.slots) &&
    o.inventory.slots.length === 36 &&
    [
      ...o.inventory.slots,
      ...(o.inventory.equipment || []),
      ...(o.inventory.craft || []),
      o.inventory.cursor,
      ...(o.inventory.offhand || []),
    ].every(
      (q) =>
        !q ||
        (ITEMS[q.id] &&
          Number.isInteger(q.count) &&
          q.count > 0 &&
          q.count <= ITEMS[q.id].stack),
    )
  );
}
export class GigantoEncounter {
  constructor(game) {
    this.game = game;
    this.record = freshTitanRecord();
    this.active = false;
    this.controls = new Set();
    this.audio = new TitanAudio(game);
    this.hud = document.createElement("div");
    this.hud.id = "titan-hud";
    this.hud.hidden = true;
    this.hud.innerHTML = titanHudTemplate();
    document.querySelector("#app").append(this.hud);
    this.prompt = document.createElement("div");
    this.prompt.id = "titan-portal-prompt";
    this.prompt.hidden = true;
    document.querySelector("#app").append(this.prompt);
    addEventListener(
      "keydown",
      (e) => {
        if (
          ["INPUT", "SELECT", "TEXTAREA"].includes(e.target.tagName) &&
          e.code !== "Escape"
        )
          return;
        if (this.active) {
          if (game.ui.screen !== "play" && e.code !== "Escape") return;
          e.preventDefault();
          e.stopImmediatePropagation();
          this.controls.add(e.code);
          if (!e.repeat) this.key(e.code);
          return;
        }
        if (
          e.code === "KeyE" &&
          !e.repeat &&
          this.nearPortal &&
          game.running &&
          game.ui.screen === "play"
        ) {
          e.preventDefault();
          e.stopImmediatePropagation();
          this.enter();
        }
      },
      true,
    );
    addEventListener(
      "keyup",
      (e) => {
        this.controls.delete(e.code);
      },
      true,
    );
    addEventListener(
      "mousedown",
      (e) => {
        if (
          !this.active ||
          e.target !== game.renderer.gl.domElement ||
          !game.running
        )
          return;
        e.preventDefault();
        e.stopImmediatePropagation();
        game.audio.unlock();
        if (e.button === 0) {
          this.controls.add("Mouse0");
          this.input("hit");
        }
        if (e.button === 2) this.controls.add("Mouse2");
      },
      true,
    );
    addEventListener(
      "mouseup",
      (e) => {
        this.controls.delete(`Mouse${e.button}`);
        if (this.active) {
          e.stopImmediatePropagation();
        }
      },
      true,
    );
    addEventListener(
      "wheel",
      (e) => {
        if (this.active && e.target === game.renderer.gl.domElement) {
          e.preventDefault();
          e.stopImmediatePropagation();
        }
      },
      { capture: true, passive: false },
    );
    addEventListener(
      "mousemove",
      (e) => {
        if (
          this.active &&
          game.running &&
          (document.pointerLockElement === game.renderer.gl.domElement ||
            (game.pointerLockFallback &&
              e.target === game.renderer.gl.domElement))
        ) {
          // Strong manual camera movement disengages targeting; a lock never
          // overwrites the player's camera or movement yaw.
          if (Math.abs(e.movementX) > 18) this.session.lock = false;
          this.session.avatar.yaw -=
            e.movementX * this.session.config.cameraSensitivity;
          this.session.avatar.pitch = Math.max(
            -0.6,
            Math.min(
              1.1,
              this.session.avatar.pitch +
                e.movementY * this.session.config.cameraSensitivity,
            ),
          );
          e.stopImmediatePropagation();
        }
      },
      true,
    );
    const backgroundPause = () => {
      this.controls.clear();
      if (this.active && game.running) game.pause();
    };
    addEventListener("blur", backgroundPause);
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) backgroundPause();
    });
    game.ui.overlay.addEventListener("click", (e) => {
      const b = e.target.closest("[data-titan]");
      if (!b || b.disabled) return;
      game.audio.unlock();
      if (this.active)
        this.audio.menu(
          ["resume", "back", "exit", "quit"].includes(b.dataset.titan)
            ? "exit"
            : "select",
        );
      else game.audio.menu("select");
      this.button(b.dataset.titan);
    });
    game.ui.overlay.addEventListener("change", (e) => {
      const damage = e.target.dataset.titanDamage;
      const k = damage ? "damage" : e.target.dataset.titanConfig;
      if (!k || (this.active && k === "climbMode")) return;
      this.record.config = titanConfig({
        ...this.record.config,
        [k]: damage
          ? { ...this.record.config.damage, [damage]: e.target.value }
          : e.target.type === "checkbox"
            ? e.target.checked
            : ["range", "number"].includes(e.target.type)
              ? Number(e.target.value)
              : e.target.value,
      });
      if (this.session) this.session.config = cloneState(this.record.config);
      if (this.active) this.audio.menu("slide");
      const output = e.target.closest("label")?.querySelector("output");
      if (output) output.textContent = e.target.value;
      game
        .save()
        .catch((err) => game.ui.toast("Settings save failed: " + err.message));
    });
  }
  get session() {
    return this.record.session;
  }
  export() {
    this.audio.score?.snapshot(this.session);
    return cloneState(this.record);
  }
  clear() {
    this.active = false;
    this.pending = false;
    this.closing = false;
    this.controls.clear();
    this.accumulator = 0;
    this.lastSave = 0;
    this.checkpointSave = false;
    this.scan = 0;
    this.nearPortal = false;
    this.view?.dispose();
    this.view = null;
    if (this.portalMesh) disposeTitanObject(this.portalMesh);
    this.portalMesh = null;
    this.record = freshTitanRecord();
    this.hud.hidden = true;
    this.prompt.hidden = true;
    document.querySelector("#app").classList.remove("titan-active");
    this.audio.silence();
  }
  load(data) {
    this.clear();
    if (!data || data.schema !== 1) return;
    this.record.config = titanConfig(data.config);
    this.record.used = Array.isArray(data.used)
      ? data.used
          .filter((x) => typeof x === "string" && x.length < 150)
          .slice(-4096)
      : [];
    this.record.ledger = Array.isArray(data.ledger)
      ? data.ledger
          .filter((x) => typeof x === "string" && x.length < 150)
          .slice(-4096)
      : [];
    this.record.serial = Math.max(
      0,
      Math.min(1e9, Math.floor(Number(data.serial) || 0)),
    );
    this.record.cooldownUntil = Number.isFinite(data.cooldownUntil)
      ? Math.max(0, Math.min(data.cooldownUntil, this.game.tickCount + 144000))
      : 0;
    const q = data.portal;
    if (
      q &&
      typeof q.id === "string" &&
      q.id.length < 150 &&
      [q.x, q.y, q.z].every(Number.isFinite) &&
      Math.abs(q.x) <= 30000000 &&
      Math.abs(q.z) <= 30000000 &&
      q.y >= MIN_Y &&
      q.y < MAX_Y - 5
    )
      this.record.portal = {
        id: q.id,
        x: q.x,
        y: q.y,
        z: q.z,
        cell: String(q.cell || "").slice(0, 100),
      };
    const s = restoreTitanSession(data.session);
    if (s && validOriginal(s.original, this.game)) {
      initializeArenaSettings(s.config, this.game.settings);
      this.record.config = cloneState(s.config);
      this.record.session = s;
      this.active = true;
      this.silenceWorld();
      this.audio.frame(s, false);
      this.game.player = cloneState(s.original.player);
      this.game.inventory = new Inventory(s.original.inventory);
      this.view = new TitanView(this.game);
      document.querySelector("#app").classList.add("titan-active");
      this.renderResultIfNeeded();
    }
  }
  input(action) {
    const s = this.session;
    if (!s || this.closing || this.pending || !this.view?.assetsReady)
      return false;
    s.events = [];
    const result = titanInput(s, action);
    for (const e of s.events) {
      this.view?.event(e, s);
      this.audio.event(e);
      if (titanCheckpointEvent(e)) this.checkpointSave = true;
    }
    return result;
  }
  key(code) {
    this.audio.prelude?.allowPlayback();
    const g = this.game,
      s = this.session;
    if (!s || this.closing || this.pending) return;
    if (code === "Escape") {
      this.controls.clear();
      if (g.ui.screen === "play") g.pause();
      else if (!["victory", "defeat"].includes(s.stage)) g.resume();
      return;
    }
    if (!g.running) return;
    const actions = {
      Space: "jump",
      KeyQ: "dodge",
      KeyX: "homing",
      KeyC: "cross",
      KeyV: "shot",
      KeyR: "boom",
      KeyF: "rush",
      KeyE: "loop",
      Tab: "target",
      Enter: "skip",
    };
    if (code === "KeyE" && s.stage === "traversal" && armorMode(s))
      this.input("climb");
    else if (actions[code]) this.input(actions[code]);
  }
  validPortal() {
    const p = this.record.portal;
    return p && safeTitanSite(this.game, p.x, p.y, p.z);
  }
  findPortal(force = false) {
    const g = this.game,
      r = this.record;
    if (
      r.portal ||
      r.session ||
      this.pending ||
      !g.active ||
      g.dimension !== "overworld" ||
      g.multiplayer?.connected ||
      !r.config.enabled ||
      g.tickCount < r.cooldownUntil
    )
      return false;
    const cx = Math.floor(g.player.x / 64),
      cz = Math.floor(g.player.z / 64);
    for (let dz = -1; dz <= 1; dz++)
      for (let dx = -1; dx <= 1; dx++) {
        const xcell = cx + dx,
          zcell = cz + dz,
          cell = `${xcell},${zcell}`;
        if (
          r.used.includes(cell) ||
          (!force &&
            hash(xcell, 71, zcell, g.world.seedInt) > r.config.spawnChance)
        )
          continue;
        for (let attempt = 0; attempt < 8; attempt++) {
          const x =
              xcell * 64 +
              10 +
              Math.floor(
                hash(xcell, 72 + attempt * 3, zcell, g.world.seedInt) * 42,
              ),
            z =
              zcell * 64 +
              10 +
              Math.floor(
                hash(xcell, 73 + attempt * 3, zcell, g.world.seedInt) * 42,
              ),
            distance = Math.hypot(x - g.player.x, z - g.player.z);
          if (distance < 14 || distance > 100) continue;
          const y = g.world.terrain(x, z).h + 1;
          if (!safeTitanSite(g, x, y, z)) continue;
          r.portal = {
            id: `${g.world.seedInt}:${cell}:${++r.serial}`,
            x,
            y,
            z,
            cell,
          };
          g.save().catch((e) => g.ui.toast("Portal save failed: " + e.message));
          g.ui.toast("A Titan signal shimmers nearby.", 6000);
          return true;
        }
      }
    return false;
  }
  overworld(dt) {
    const g = this.game;
    if (!g.active) {
      if (this.portalMesh) this.portalMesh.visible = false;
      this.prompt.hidden = true;
      return;
    }
    this.scan = (this.scan || 0) + dt;
    if (this.scan > 1) {
      this.scan = 0;
      if (g.running) this.findPortal();
    }
    const p = this.record.portal;
    if (!p || g.dimension !== "overworld") {
      if (this.portalMesh) this.portalMesh.visible = false;
      this.nearPortal = false;
      this.prompt.hidden = true;
      return;
    }
    if (!this.portalMesh) {
      this.portalMesh = titanPortal();
      g.renderer.scene.add(this.portalMesh);
    }
    const m = this.portalMesh;
    m.position.set(p.x + 0.5, p.y, p.z + 0.5);
    m.rotation.y = g.elapsed * 0.2;
    animateTitanPortal(
      m,
      g.elapsed,
      this.record.config.particles,
      this.record.config.lighting,
    );
    const portalDistance = Math.hypot(
      g.player.x - p.x,
      g.player.y - p.y,
      g.player.z - p.z,
    );
    if (
      this.record.config.audio &&
      g.running &&
      portalDistance < 12 &&
      g.elapsed - (this.lastPortalTone ?? -100) > 8
    ) {
      this.lastPortalTone = g.elapsed;
      playWorldSound(g, "rune", { x: p.x + 0.5, y: p.y + 2, z: p.z + 0.5 });
    }
    m.userData.inner.rotation.z = -g.elapsed * 0.25;
    m.userData.light.visible = this.record.config.lighting;
    m.visible = Math.hypot(g.player.x - p.x, g.player.z - p.z) < 100;
    m.userData.ring.visible = this.record.config.particles;
    this.nearPortal =
      m.visible &&
      Math.hypot(
        g.player.x - p.x - 0.5,
        g.player.y - p.y,
        g.player.z - p.z - 0.5,
      ) < 3.6;
    this.prompt.hidden =
      !this.nearPortal || !this.record.config.enabled || g.ui.screen !== "play";
    if (!this.prompt.hidden) this.prompt.innerHTML = "[E] ENTER TITAN SIGNAL";
  }
  async enter() {
    const g = this.game,
      r = this.record;
    if (
      this.pending ||
      this.active ||
      !g.active ||
      !r.config.enabled ||
      !g.running ||
      g.player.health <= 0 ||
      !g.player.onGround
    )
      return false;
    if (g.multiplayer?.connected || g.multiplayer?.isGuest) {
      g.ui.toast("Close co-op before entering this singleplayer encounter.");
      return false;
    }
    if (
      !this.nearPortal ||
      !this.validPortal() ||
      g.tickCount < r.cooldownUntil
    ) {
      g.ui.toast(
        "The portal needs clear, solid ground and an unobstructed entrance.",
      );
      return false;
    }
    this.pending = true;
    try {
      await prepareTitanModels();
      if (
        this.record !== r ||
        !g.active ||
        !g.running ||
        g.player.health <= 0 ||
        !g.player.onGround ||
        !this.nearPortal ||
        !this.validPortal() ||
        g.multiplayer?.connected
      )
        return false;
      if (g.saving) await g.saving;
      const original = {
        player: cloneState(g.player),
        inventory: g.inventory.export(),
        dimension: g.dimension,
        cameraMode: g.cameraMode,
      };
      initializeArenaSettings(r.config, g.settings);
      r.session = titanSession(r.config, r.portal.id);
      r.session.original = original;
      this.active = true;
      g.resetControls();
      this.silenceWorld();
      this.prompt.hidden = true;
      if (this.portalMesh) this.portalMesh.visible = false;
      this.view = new TitanView(g);
      this.audio.frame(r.session, false);
      document.querySelector("#app").classList.add("titan-active");
      await g.save();
      this.accumulator = 0;
      this.lastSave = 0;
      return true;
    } catch (e) {
      this.active = false;
      this.audio.silence();
      r.session = null;
      this.view?.dispose();
      this.view = null;
      document.querySelector("#app").classList.remove("titan-active");
      g.ui.toast("Could not save the return checkpoint: " + e.message, 7000);
      return false;
    } finally {
      this.pending = false;
    }
  }
  silenceWorld() {
    const g = this.game;
    g.audio.silenceAmbient();
    g.audio.music?.silence();
    for (const fanfare of [g.audio.claimFanfare, g.audio.pistolClaimFanfare]) {
      try {
        fanfare?.source?.stop();
      } catch {}
    }
    const j = g.jukebox;
    if (j?.audio && j.state === "playing") {
      j.audio.pause();
      j.state = "menu-paused";
      j.autoResume = true;
    }
  }
  frame(dt) {
    const g = this.game,
      s = this.session;
    if (!s) return;
    g.elapsed -= dt;
    g.audio.music?.silence();
    this.prompt.hidden = true;
    this.hud.hidden = g.ui.screen !== "play";
    if (!this.view?.assetsReady) {
      const obj = this.hud.querySelector("#titan-objective"),
        detail = this.hud.querySelector("#titan-detail");
      obj.textContent = this.view?.assetError
        ? "Model loading failed"
        : "Preparing Titan encounter…";
      detail.textContent = this.view?.assetError
        ? "Press Escape to return safely. " + this.view.assetError
        : "Combat and ring drain are paused while the arena prepares.";
      return;
    }
    if (g.running && g.ui.screen === "play" && !this.closing && !this.pending) {
      // Restore the audio transport before a resumed simulation can emit its
      // first contact. Otherwise the paused event gate drops that frame's hit.
      if (this.audio.playing === false) this.audio.frame(s, true);
      this.accumulator = (this.accumulator || 0) + dt;
      alignTitanCinematic(s, this.audio.score);
      const events = [];
      while (this.accumulator >= 1 / 60) {
        const k = this.controls;
        stepTitan(
          s,
          {
            forward: k.has("KeyW"),
            back: k.has("KeyS"),
            left: k.has("KeyA"),
            right: k.has("KeyD"),
            boost: k.has("ShiftLeft") || k.has("ShiftRight"),
            up: k.has("Space"),
            down: k.has("ControlLeft") || k.has("ControlRight"),
            parry: k.has("Mouse2"),
            hit: k.has("Mouse0"),
          },
          1 / 60,
        );
        events.push(...s.events);
        this.accumulator -= 1 / 60;
      }
      // Deliver once after catch-up, against the same pose the next frame draws.
      for (const e of events) {
        this.view.event(e, s);
        this.audio.event(e);
        if (titanCheckpointEvent(e)) this.checkpointSave = true;
      }
      if (this.checkpointSave || s.time - (this.lastSave || 0) > 15) {
        this.checkpointSave = false;
        this.lastSave = s.time;
        g.save().catch((e) => g.ui.toast("Arena save failed: " + e.message));
      }
      this.renderResultIfNeeded();
    }
    this.audio.frame(s, g.running && g.ui.screen === "play");
    this.view?.draw(s, g.running ? dt : 0);
    this.updateHUD();
  }
  updateHUD() {
    const s = this.session;
    if (!s) return;
    const q = (id) => this.hud.querySelector(id);
    updateTitanHudExtras(this.hud, s, this.view);
    const marker = this.view?.targetScreen,
      reticle = q("#titan-reticle");
    reticle.hidden = !(
      marker?.visible &&
      s.lock &&
      s.emerald &&
      s.stage === "combat" &&
      !s.qte &&
      !s.counterScene
    );
    if (marker) {
      reticle.style.left = `${marker.x * 100}%`;
      reticle.style.top = `${marker.y * 100}%`;
    }
    q(".titan-health i").style.width = `${(s.hp / s.maxHp) * 100}%`;
    q(".titan-health").setAttribute(
      "aria-valuenow",
      Math.round((s.hp / s.maxHp) * 100),
    );
    q("#titan-phase").textContent = s.emerald
      ? `PHASE ${s.phase}`
      : "TITAN APPROACH";
    q("#titan-rings").textContent = `${Math.ceil(s.rings)}/${s.config.rings}`;
    q("#titan-energy").textContent = Math.round(s.energy);
    const cinematic =
        !!s.counterScene ||
        ["intro", "transform", "phase", "finale"].includes(s.stage),
      next = TITAN_ROUTE[s.route + 1];
    q("#titan-objective").textContent =
      s.stage === "traversal"
        ? s.route === 0 && s.rings < Math.min(250, s.config.rings)
          ? "Gather rings for the battle"
          : armorMode(s)
            ? "Run up Giganto · Final Emerald"
            : "Climb Giganto · Final Emerald"
        : s.stage === "transform"
          ? "ALL SEVEN · SUPER SONIC"
          : s.stage === "phase"
            ? "DORSAL LASERS ONLINE"
            : s.stage === "finale"
              ? "FINISHING STRIKE"
              : s.emerald
                ? "Defeat Giganto"
                : "A signal beyond the world";
    q("#titan-detail").textContent =
      s.stage === "traversal"
        ? armorMode(s)
          ? armorAttached(s)
            ? "W / S · Up / Down   A / D · Traverse   Shift · Boost   Space · Jump   E · Release"
            : "Follow the golden armor trail · Hold W against a foot to climb"
          : `Ring trails surround the basin · Ascent ${s.route}/12${s.route === 0 ? " · Gather before climbing" : ""}`
        : s.emerald
          ? ""
          : "Collect the final Emerald.";
    q("#titan-tell").textContent = s.counterScene
      ? "COUNTERATTACK"
      : s.stage === "traversal" &&
          s.avatar.z < -12 &&
          s.time % 6 > 3 &&
          s.time % 6 < 4.5
        ? "DORSAL PULSE · WAIT OR BOOST PAST"
        : s.attack !== "idle" && !s.qte
          ? s.attack === "sweep"
            ? titanSweepPrompt(s)
            : TITAN_MOVES[s.attack]?.label || ""
          : [
                "boom",
                "rush",
                "loop",
                "counter",
                "cross",
                "homing",
                "shot",
              ].includes(s.action) && s.actionTime > 0
            ? {
                homing: "HOMING ATTACK",
                shot: "HOMING SHOT",
                cross: "CROSS SLASH",
                boom: "SONIC BOOM",
                rush: "WILD RUSH",
                loop: "QUICK CYLOOP",
                counter: "GRAND SLAM",
              }[s.action] + " · Q TO DODGE"
            : s.counter > 0
              ? "LEFT CLICK · GRAND SLAM COUNTER"
              : s.qte
                ? ""
                : s.attack !== "idle"
                  ? s.attack === "sweep"
                    ? titanSweepPrompt(s)
                    : TITAN_MOVES[s.attack]?.label || ""
                  : s.boss?.walk
                    ? "GIGANTO IS MOVING"
                    : s.stagger > 0
                      ? "STAGGERED · ATTACK NOW"
                      : "";
    const qt = q("#titan-qte");
    qt.hidden = !s.qte;
    if (s.qte) {
      qt.querySelector("b").textContent =
        s.qte.kind === "beam" ? "DEFLECT THE BEAM" : "BREAK THE GRAB";
      qt.querySelector("progress").value = s.qte.hits / s.qte.need;
      qt.querySelector("div").textContent =
        `TAP SPACE / LEFT CLICK · ${s.qte.left.toFixed(1)}s`;
    }
    this.hud.classList.toggle("cinematic", cinematic);
    q("#titan-controls").textContent = cinematic
      ? "ENTER · Skip cinematic     ESC · Pause"
      : s.stage === "traversal"
        ? armorMode(s)
          ? "WASD · Move / Climb   SHIFT · Boost   SPACE · Jump   E · Grip / Release   ESC · Pause"
          : "WASD · Move   MOUSE · Camera   SHIFT · Boost   SPACE · Jump   Collect golden rings · follow marked ruins   ESC · Pause / Exit"
        : "WASD · Fly   SPACE / CTRL · Rise / Fall   SHIFT · Boost   LMB · Combo   RMB · Parry   Q · Dodge   TAB · Target   ESC · Pause";
  }
  renderResultIfNeeded() {
    const s = this.session;
    if (
      !s ||
      !["victory", "defeat"].includes(s.stage) ||
      this.game.ui.screen === "titan-result"
    )
      return;
    const g = this.game;
    g.running = false;
    this.controls.clear();
    document.exitPointerLock?.();
    const win = s.stage === "victory";
    g.ui.setScreen(
      "titan-result",
      `<main class="dialog compact titan-result"><div class="eyebrow">TITAN SIGNAL</div><h2>${win ? "GIGANTO DEFEATED" : "SUPER FORM EXHAUSTED"}</h2><p>${win ? "Titan Sigil · 6 diamonds · 8 Hellfire ingots · 100 XP" : "Try again or return to your world."}</p>${!win ? '<button class="primary wide" data-titan="retry">Retry checkpoint</button>' : ""}<button class="primary wide" data-titan="exit">${win ? "Claim reward & return" : "Return to your world"}</button><button class="secondary wide" data-titan="menu">Encounter settings</button></main>`,
    );
  }
  pauseMenu() {
    this.audio.pause(this.session);
    const g = this.game;
    g.running = false;
    this.controls.clear();
    document.exitPointerLock?.();
    g.ui.setScreen(
      "pause",
      `<div class="pause-shade"></div><main class="dialog compact titan-result"><h2>Paused</h2><button class="primary wide" data-titan="resume">Resume encounter</button><button class="secondary wide" data-titan="menu">Battle settings</button><button class="secondary wide" data-titan="exit">Return to world</button><button class="text-button wide" data-titan="quit">Save checkpoint & quit</button></main>`,
    );
  }
  menu() {
    const g = this.game,
      c = this.record.config,
      p = this.record.portal;
    if (this.active) {
      g.running = false;
      this.controls.clear();
      document.exitPointerLock?.();
    }
    if (this.active) this.audio.pause(this.session);
    initializeArenaSettings(c, g.settings);
    g.ui.setScreen(
      "titan-menu",
      titanSettingsPanel(c, this.active, {
        portal: p,
        cooldown: Math.max(
          0,
          Math.ceil((this.record.cooldownUntil - g.tickCount) / 20),
        ),
        sigils: this.record.ledger.length,
        creative: g.mode === "creative",
      }),
    );
  }
  async button(action) {
    if (this.closing || this.pending) return;
    const g = this.game;
    if (action === "resume") {
      this.controls.clear();
      g.resume();
    }
    if (action === "menu") this.menu();
    if (action === "back") {
      if (this.active && ["victory", "defeat"].includes(this.session.stage)) {
        g.ui.screen = "titan-menu";
        this.renderResultIfNeeded();
      } else if (this.active) this.pauseMenu();
      else g.ui.pause();
    }
    if (action === "retry") {
      titanInput(this.session, "retry");
      this.controls.clear();
      g.resume();
      g.save().catch((e) => g.ui.toast(e.message));
    }
    if (action === "summon") {
      if (g.mode === "creative") {
        g.ui.toast(
          this.findPortal(true)
            ? "Titan portal discovered."
            : "No loaded safe site nearby. Explore clear ground and try again.",
        );
        this.menu();
      }
    }
    if (action === "exit") await this.exit();
    if (action === "quit") {
      g.running = false;
      try {
        await g.save();
        this.active = false;
        this.audio.silence();
        this.view?.dispose();
        this.view = null;
        this.hud.hidden = true;
        document.querySelector("#app").classList.remove("titan-active");
        g.active = false;
        document.exitPointerLock?.();
        g.ui.title();
      } catch (e) {
        g.ui.toast("Checkpoint save failed: " + e.message);
      }
    }
  }
  async exit() {
    const g = this.game,
      r = this.record,
      s = this.session;
    if (!s || this.closing) return false;
    this.closing = true;
    g.running = false;
    this.controls.clear();
    this.audio.pause(s);
    try {
      if (g.saving) await g.saving;
      const old = {
        player: g.player,
        inventory: g.inventory,
        drops: g.drops.slice(),
        record: cloneState(r),
        cameraMode: g.cameraMode,
      };
      try {
        g.player = cloneState(s.original.player);
        g.inventory = new Inventory(s.original.inventory);
        g.cameraMode = s.original.cameraMode || 0;
        g.mouseDown = g.rightMouseDown = false;
        delete g.player.editionDraw;
        g.player.shieldRaised = false;
        g.player.vx = g.player.vy = g.player.vz = 0;
        if (s.won && !r.ledger.includes(s.id)) {
          r.ledger.push(s.id);
          for (const [id, count] of [
            ["diamond", 6],
            ["hellfire_ingot", 8],
          ]) {
            const left = g.inventory.add(makeStack(id, count));
            if (left)
              g.drops.push({
                uid: `titan:${s.id}:${id}`,
                id,
                count: left,
                x: g.player.x,
                y: g.player.y + 0.4,
                z: g.player.z,
                vx: 0,
                vy: 0,
                vz: 0,
                age: 0,
                delay: 10,
              });
          }
          awardXP(g, 100);
        }
        if (r.portal) {
          r.used.push(r.portal.cell);
          r.portal = null;
        }
        r.cooldownUntil = g.tickCount + Math.round(r.config.cooldown * 20);
        r.session = null;
        await g.save();
      } catch (e) {
        g.player = old.player;
        g.inventory = old.inventory;
        g.drops = old.drops;
        this.record = old.record;
        g.cameraMode = old.cameraMode;
        throw e;
      }
      this.active = false;
      this.view?.dispose();
      this.view = null;
      this.hud.hidden = true;
      if (this.portalMesh) disposeTitanObject(this.portalMesh);
      this.portalMesh = null;
      this.audio.silence();
      document.querySelector("#app").classList.remove("titan-active");
      g.renderer.loadAround(g.player.x, g.player.z, 2, 9);
      g.ui.play();
      g.resume();
      g.ui.toast(
        s.won ? "Titan Sigil earned." : "Returned to your world.",
        7000,
      );
      return true;
    } catch (e) {
      g.ui.toast(
        "Return save failed; your checkpoint is retained. Retry Return: " +
          e.message,
        8000,
      );
      return false;
    } finally {
      this.closing = false;
    }
  }
}
