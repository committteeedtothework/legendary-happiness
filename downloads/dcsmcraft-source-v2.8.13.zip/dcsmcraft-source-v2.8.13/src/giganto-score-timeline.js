// Cue seconds refer to the user-supplied 264.96-second recording, not a remote
// stream. The 200 BPM grid was checked against decoded onset peaks (10 ms hop).
export const TITAN_SCORE_CUES = Object.freeze({
  bpm: 200,
  phaseOne: { start: 0, loopStart: 26.44, loopEnd: 103.24 },
  phaseTwo: { start: 179.14, loopStart: 160.54, loopEnd: 198.94 },
  transition: { start: 175.14, duration: 4 },
  finale: { start: 221.14, duration: 7 },
});
export function titanScorePlan(s) {
  const time = Number.isFinite(s?.stageTime) ? Math.max(0, s.stageTime) : 0;
  let section;
  if (s?.stage === "combat") section = s.phase === 2 ? "phaseTwo" : "phaseOne";
  else if (s?.stage === "phase") section = "transition";
  else if (s?.stage === "finale") section = "finale";
  else return null;
  const cue = TITAN_SCORE_CUES[section];
  let offset = cue.start + Math.min(time, cue.duration ?? Infinity);
  if (cue.loopEnd && offset >= cue.loopEnd)
    offset =
      cue.loopStart + ((offset - cue.loopEnd) % (cue.loopEnd - cue.loopStart));
  return { section, offset, loopStart: cue.loopStart, loopEnd: cue.loopEnd };
}
export function scorePosition(voice, now) {
  let position = voice.offset + Math.max(0, now - voice.when);
  if (voice.loopEnd && position >= voice.loopEnd)
    position =
      voice.loopStart +
      ((position - voice.loopEnd) % (voice.loopEnd - voice.loopStart));
  return position;
}
