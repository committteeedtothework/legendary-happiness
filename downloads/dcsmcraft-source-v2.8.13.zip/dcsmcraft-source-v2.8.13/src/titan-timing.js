import { TITAN_SCORE_CUES, scorePosition } from "./giganto-score-timeline.js";
// Protected cinematic poses share the music transport, including frame hitches
// and resumed cursor offsets. Gameplay remains fixed-step and event-driven.
export function alignTitanCinematic(s, score) {
  const section = { phase: "transition", finale: "finale" }[s.stage],
    voice = score?.current;
  if (
    !section ||
    !voice ||
    voice.section !== section ||
    score.context.state !== "running"
  )
    return;
  const cue = TITAN_SCORE_CUES[section],
    clock = scorePosition(voice, score.context.currentTime) - cue.start;
  if (Number.isFinite(clock))
    s.stageTime = Math.max(s.stageTime, Math.min(cue.duration, clock));
}
