import { OverworldMusic } from "./overworld-music.js";
import { TITAN_PRELUDE } from "./titan-prelude-data.js";
export class TitanPrelude {
  constructor(context, output, options = {}) {
    this.player = new OverworldMusic(context, output, {
      ...options,
      mode: "titan",
      tracks: [TITAN_PRELUDE],
    });
  }
  update(s, playing, settings) {
    const pre = ["intro", "traversal", "transform"].includes(s.stage);
    this.player.update(
      {
        active: pre,
        id: s.id,
        mode: "titan",
        dimension: "overworld",
        running: playing,
      },
      {
        ...settings,
        musicEnabled:
          settings.musicEnabled !== false && s.config.music && s.config.audio,
      },
    );
    if (this.player.media) this.player.media.loop = true;
  }
  allowPlayback() {
    this.player.allowPlayback();
  }
  dispose() {
    this.player.reset();
    this.player.output.disconnect();
  }
}
