# Can Giganto and Wyvern look better in Unity?

**Yes.** Unity 6 with URP can improve shadow stability, physically based materials, exposure/tonemapping, animation transitions, camera control, particles, and profiling. It does not automatically improve source geometry, create missing animation, or make an encounter match Sonic Frontiers.

## Already prepared in source

- URP 17.0.4, linear color, ACES tonemapping, restrained bloom and directional soft shadows.
- Three scalable levels: render scale 0.75/1/1.15, shadow distance 60/140/260, 1/2/4 cascades; world chunk radius 3/5/7.
- Actual source models converted to native-importable GLB 2.0 with embedded PNG textures, decoded vertex buffers and named animation clips. No external WebP/Meshopt decoder is required for the exported native art.
- Sonic: 10,414 triangles, 30 unique joints, 53 clips. Giganto: 42,145 triangles, 152 unique joints, 36 clips. Wyvern: 67,205 triangles, 403 unique joints, 11 clips.
- glTFast runtime loading shares imported model resources. Animation crossfades, shadow-casting meshes and bone-attached collision capsules are implemented in the prototype.
- Chunk rendering uses worker-generated meshes rather than one object per voxel; asset atlases retain point sampling.

These are configured/converted features. The Unity shader, imports, animation playback, lighting and visual quality have **not been verified in a running Unity build**. Model/clip counts are validated GLB contents, not a claim that every clip is wired to a finished native move.

## Highest-value next passes

1. Open/import and compile in the actual Editor, compare the converted model orientation/materials against the shipped browser build, verify color space and skinning.
2. Port complete existing encounter choreography and action events before retuning. The present native fights are deliberately identified as prototypes, with many source actions not connected yet.
3. Author Unity animation state machines/rig constraints, cinematic timelines/cameras, intentional contact poses and event-synchronized hitboxes/audio. Do not stretch Sonic to simulate speed.
4. Add detailed arena terrain layers, vegetation instancing/LODs, authored rocks/ruins, atmosphere, contact shadows and restrained GPU particles. No detailed arena art has been newly generated in this migration.
5. Profile CPU, GPU, draw calls, memory and worst-case particles/skin deformation on a Windows PC. Wyvern's 403-joint rig and 67K triangles deserve special attention; use reduction/LODs only after visual comparisons.

HDRP could provide higher-cost volumetrics and richer high-end effects in a separate Windows-focused branch. It is not configured here and would reduce portability to mobile/WebGL. URP is a practical starting renderer for the requested desktop port. No UE5-quality or 1:1 fidelity claim is made; there are no Unity in-game screenshots or measured FPS results yet.

## Verified reference sources

- [Unity 6000.0.62f1 release](https://unity.com/releases/editor/whats-new/6000.0.62f1)
- [Unity 6 command-line arguments](https://docs.unity3d.com/6000.0/Documentation/Manual/EditorCommandLineArguments.html)
- [Unity URP source package/version](https://github.com/Unity-Technologies/Graphics/blob/6000.0/staging/Packages/com.unity.render-pipelines.universal/package.json)
- [Unity glTFast](https://docs.unity3d.com/Packages/com.unity.cloud.gltfast@6.20/manual/index.html)

Research confirms package/API availability; it cannot substitute for running and profiling the Editor.
