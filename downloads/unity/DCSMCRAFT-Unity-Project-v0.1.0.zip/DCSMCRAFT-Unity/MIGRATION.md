# Migration boundaries and provenance

The task is a native engine rewrite, not a JavaScript-to-C# file conversion. The original JavaScript renderer, browser storage, simulation, input, UI, network protocol and animation evaluation require native replacements. This delivery begins that work and preserves every original file needed to continue it.

`Reference/source-manifest.json` records the SHA-256, size, original path and retained destination of 893 source/assets files. Public assets live in `Assets/StreamingAssets/Migrated/Original`; all remaining original code lives in `Reference/BrowserCode`, outside Unity's Assets folder. All were hash checked against the unchanged browser checkout.

`Reference/full-game-data.json` preserves complete original data, including extended item/block/mob fields. `catalog.json` is a normalized Unity JsonUtility-compatible subset with stable block IDs, static shape parts, three exact face-UV maps, inventory icons and recipe alternatives. Metadata preservation is not behavioral parity.

`Reference/art-manifest.json` hashes native GLBs/PNGs and records animation names/durations. Existing browser-authored rig clips were baked/exported with the existing models; the two skin locomotion clips were added specifically for this native foundation. Source art is retained separately so conversions can be corrected without losing the original.

To recover the unchanged browser project into an empty folder:

```text
python tools/reconstruct-browser.py /path/to/new-empty-browser-folder
```

Restore both asset archives first. The command verifies provenance hashes and refuses to overwrite a populated destination. It does not install dependencies or publish/modify existing builds.

## Saves

Native saves use their own Unity company/product path and format marker, SHA-256 integrity, `.new` staging and `.bak` recovery. They do not read or mutate browser IndexedDB/localStorage. Native terrain generation is currently **generation 1**, which differs from the browser's generation 16. Browser edit/container/entity saves must not be blindly imported onto different terrain. A compatible generator plus an explicit old-save migration is still required.

## Distribution and rights

The source/assets ZIPs form one project but are split to fit the hosting provider's per-file limit. `tools/asset-bundles.json` pins HTTPS URLs, archive hashes and individual asset hashes. The Windows restore script accepts local archives or downloads pinned archives, checks path safety and SHA-256 before installing. Cached asset downloads are excluded from source control.

Existing license/notices remain under the Original assets and BrowserCode. Sonic/Giganto/Wyvern models and MP3s were supplied in the existing project; they have not been newly licensed, replaced or synthesized here. Check the original permissions before commercial redistribution. No API keys, Unity credentials, .NET SDK binaries, dependency caches or build caches are included.
