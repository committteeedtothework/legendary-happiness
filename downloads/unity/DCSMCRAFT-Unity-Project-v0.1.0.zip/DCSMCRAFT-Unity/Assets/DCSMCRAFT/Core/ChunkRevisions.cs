using System.Collections.Generic;
namespace DCSMCRAFT.Core {
 public sealed class ChunkRevisions {
  readonly Dictionary<Cell,long> revisions=new Dictionary<Cell,long>();
  public Cell[] Changed(Cell position,long revision){int cx=SeedNoise.FloorDiv(position.x,16),cz=SeedNoise.FloorDiv(position.z,16);var cells=new List<Cell>();for(int z=cz-1;z<=cz+1;z++)for(int x=cx-1;x<=cx+1;x++){var k=new Cell(x,0,z);revisions[k]=revision;cells.Add(k);}return cells.ToArray();}
  public bool Current(Cell chunk,long snapshotRevision)=>!revisions.TryGetValue(chunk,out var changed)||changed<=snapshotRevision;
 }
}
