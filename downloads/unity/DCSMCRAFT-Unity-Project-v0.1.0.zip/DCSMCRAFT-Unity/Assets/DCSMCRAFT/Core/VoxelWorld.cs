using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
namespace DCSMCRAFT.Core {
 public sealed class VoxelWorld {
  public const int Size=16,MinY=-64,MaxY=319,Sea=62;
  public readonly string Seed,Dimension;public readonly uint SeedInt;public readonly Catalog Catalog;
  public readonly ConcurrentDictionary<Cell,ushort> Edits=new ConcurrentDictionary<Cell,ushort>();
  readonly ConcurrentDictionary<Cell,byte> light=new ConcurrentDictionary<Cell,byte>();
  public long Revision{get;private set;}public event Action<Cell> Changed;
  public VoxelWorld(Catalog catalog,string seed,string dimension="overworld"){Catalog=catalog;Seed=seed;Dimension=dimension;SeedInt=SeedNoise.Seed(dimension=="overworld"?seed:seed+":cinderwild");}
  public int Height(int x,int z){double land=SeedNoise.Fractal(x/380.0,z/380.0,SeedInt),ridge=SeedNoise.Fractal(x/110.0,z/110.0,SeedInt+61);return Dimension=="cinderworld"?38+(int)(ridge*62):Math.Max(24,Math.Min(180,44+(int)(land*44+Math.Max(0,ridge-.59)*145)));}
  public string Biome(int x,int z){if(Height(x,z)<Sea-3)return "ocean";double t=SeedNoise.Noise2(x/520.0,z/520.0,SeedInt+97),wet=SeedNoise.Noise2(x/470.0,z/470.0,SeedInt+171);return t<.25?"alpine":t>.72?wet<.5?"desert":"jungle":wet>.58?"woodland":"meadow";}
  public ushort Get(int x,int y,int z){if(y<MinY)return Catalog.Id("bedrock");if(y>MaxY)return 0;return Edits.TryGetValue(new Cell(x,y,z),out var id)?id:Natural(x,y,z);}
  public ushort Natural(int x,int y,int z)=>Sample(x,y,z,Height(x,z),Biome(x,z));
  public ushort Sample(int x,int y,int z,int h,string biome){bool cinder=Dimension=="cinderworld";
   if(y==MinY)return Catalog.Id("bedrock");if(y>h){if(!cinder&&y<=h+8&&(biome=="woodland"||biome=="jungle")){int gx=SeedNoise.FloorDiv(x,8),gz=SeedNoise.FloorDiv(z,8);for(int oz=-1;oz<=1;oz++)for(int ox=-1;ox<=1;ox++){int rx=gx+ox,rz=gz+oz;if(SeedNoise.Hash(rx,0,rz,SeedInt+710)<.58)continue;int tx=rx*8+2+(int)(SeedNoise.Hash(rx,1,rz,SeedInt+710)*4),tz=rz*8+2+(int)(SeedNoise.Hash(rx,2,rz,SeedInt+710)*4);if(Math.Abs(x-tx)>2||Math.Abs(z-tz)>2)continue;int th=Height(tx,tz);if(th<Sea+2)continue;if(x==tx&&z==tz&&y>th&&y<=th+5)return Catalog.Id("log");if(y>=th+3&&y<=th+6&&Math.Abs(x-tx)+Math.Abs(z-tz)<5)return Catalog.Id("leaves");}}if(y<=Sea&&!cinder)return Catalog.Id("water");return 0;}
   if(y<h-5&&y>MinY+4){double n=SeedNoise.Noise3(x/30.0,y/23.0,z/30.0,SeedInt+190);if(n>.69||n<.14)return Catalog.Id(y<-48?"lava":"air");}
   if(cinder){if(y<h-6&&SeedNoise.Hash(x/3,y/3,z/3,SeedInt+220)>.982)return Catalog.Id("hellfire_ore");return Catalog.Id("cinderstone");}
   if(y==h)return Catalog.Id(h<Sea+2||biome=="desert"?"sand":biome=="alpine"?"snow":"grass");if(y>h-4)return Catalog.Id("dirt");
   double ore=SeedNoise.Hash(SeedNoise.FloorDiv(x,3),SeedNoise.FloorDiv(y,3),SeedNoise.FloorDiv(z,3),SeedInt+23);if(y<-20&&ore>.994)return Catalog.Id("diamond_ore");if(y<55&&ore>.977)return Catalog.Id("iron_ore");if(ore>.952)return Catalog.Id("coal_ore");return Catalog.Id("stone");
  }
  public bool Set(int x,int y,int z,ushort id){if(y<=MinY||y>MaxY||id>=Catalog.Data.blocks.Length)return false;var p=new Cell(x,y,z);ushort before=Get(x,y,z);if(before==id)return false;bool relight=Emission(Catalog.Block(before))>0||Emission(Catalog.Block(id))>0||Light(x,y,z)>0||Light(x+1,y,z)>1||Light(x-1,y,z)>1||Light(x,y+1,z)>1||Light(x,y-1,z)>1||Light(x,y,z+1)>1||Light(x,y,z-1)>1;Edits[p]=id;Revision++;if(relight)RebuildLights();Changed?.Invoke(p);return true;}
  public bool Solid(int x,int y,int z)=>Catalog.Block(Get(x,y,z)).solid;
  public byte Light(int x,int y,int z)=>light.TryGetValue(new Cell(x,y,z),out var v)?v:(byte)0;
  static int Emission(BlockDef b)=>b.key=="torch"?14:b.key.Contains("lantern")||b.key=="lava"?15:b.light;
  public void RebuildLights(){light.Clear();var queue=new Queue<Cell>();foreach(var e in Edits){var b=Catalog.Block(e.Value);int emission=Emission(b);if(emission>0){light[e.Key]=(byte)Math.Min(15,emission);queue.Enqueue(e.Key);}}
   var d=new[]{new Cell(1,0,0),new Cell(-1,0,0),new Cell(0,1,0),new Cell(0,-1,0),new Cell(0,0,1),new Cell(0,0,-1)};
   while(queue.Count>0){var p=queue.Dequeue();var value=light[p];if(value<=1)continue;foreach(var n in d){var q=new Cell(p.x+n.x,p.y+n.y,p.z+n.z);if(q.y<MinY||q.y>MaxY||Catalog.Block(Get(q.x,q.y,q.z)).solid)continue;if(!light.TryGetValue(q,out var old)||old<value-1){light[q]=(byte)(value-1);queue.Enqueue(q);}}}
  }
  internal Dictionary<Cell,byte> LightCopy()=>new Dictionary<Cell,byte>(light);
  public WorldSnapshot Snapshot()=>new WorldSnapshot(this);
 }
 public sealed class WorldSnapshot {
  readonly VoxelWorld basis;readonly Dictionary<Cell,ushort> edits;readonly Dictionary<Cell,byte> lights;readonly Dictionary<Cell,(int h,string biome)> columns=new Dictionary<Cell,(int,string)>();
  public readonly long revision;public WorldSnapshot(VoxelWorld world){basis=world;lights=world.LightCopy();edits=new Dictionary<Cell,ushort>(world.Edits);revision=world.Revision;}
  public ushort Get(int x,int y,int z){if(y<VoxelWorld.MinY)return basis.Catalog.Id("bedrock");if(y>VoxelWorld.MaxY)return 0;if(edits.TryGetValue(new Cell(x,y,z),out var id))return id;var k=new Cell(x,0,z);if(!columns.TryGetValue(k,out var c)){c=(basis.Height(x,z),basis.Biome(x,z));columns[k]=c;}return basis.Sample(x,y,z,c.h,c.biome);}
  public byte Light(int x,int y,int z)=>lights.TryGetValue(new Cell(x,y,z),out var l)?l:(byte)0;
 }
}
