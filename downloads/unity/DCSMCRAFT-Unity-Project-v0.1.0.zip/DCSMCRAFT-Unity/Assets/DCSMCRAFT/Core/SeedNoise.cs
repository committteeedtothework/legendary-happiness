using System;
namespace DCSMCRAFT.Core {
 public static class SeedNoise {
  public static uint Seed(string value){unchecked{uint h=2166136261;for(int i=0;i<value.Length;i++){h^=value[i];h*=16777619;if(char.IsHighSurrogate(value[i])&&i+1<value.Length&&char.IsLowSurrogate(value[i+1]))i++;}return h;}}
  public static double Hash(int x,int y,int z,uint seed){unchecked{uint h=(uint)(x*374761393)^(uint)(y*668265263)^(uint)(z*2147483647)^seed;h=(h^(h>>13))*1274126177;return (h^(h>>16))/4294967296.0;}}
  static double Fade(double t)=>t*t*(3-2*t);static double Mix(double a,double b,double t)=>a+(b-a)*t;
  public static double Noise2(double x,double z,uint seed){int ix=(int)Math.Floor(x),iz=(int)Math.Floor(z);double u=Fade(x-ix),v=Fade(z-iz);return Mix(Mix(Hash(ix,0,iz,seed),Hash(ix+1,0,iz,seed),u),Mix(Hash(ix,0,iz+1,seed),Hash(ix+1,0,iz+1,seed),u),v);}
  public static double Noise3(double x,double y,double z,uint seed){int iy=(int)Math.Floor(y);return Mix(Noise2(x,z,seed^unchecked((uint)(iy*73471))),Noise2(x,z,seed^unchecked((uint)((iy+1)*73471))),Fade(y-iy));}
  public static double Fractal(double x,double z,uint seed)=>Noise2(x,z,seed)*.57+Noise2(x*2,z*2,seed+1)*.28+Noise2(x*4,z*4,seed+2)*.15;
  public static int FloorDiv(int x,int size){int q=x/size;return x<0&&x%size!=0?q-1:q;}
  public static int Mod(int x,int size)=>(x%size+size)%size;
 }
 [Serializable] public struct Cell : IEquatable<Cell> {public int x,y,z;public Cell(int x,int y,int z){this.x=x;this.y=y;this.z=z;}public bool Equals(Cell b)=>x==b.x&&y==b.y&&z==b.z;public override bool Equals(object o)=>o is Cell b&&Equals(b);public override int GetHashCode()=>unchecked((x*73856093)^(y*19349663)^(z*83492791));public override string ToString()=>$"{x},{y},{z}";}
 [Serializable] public struct Vec {public double x,y,z;public Vec(double x,double y,double z){this.x=x;this.y=y;this.z=z;} public static Vec operator +(Vec a,Vec b)=>new Vec(a.x+b.x,a.y+b.y,a.z+b.z);public static Vec operator -(Vec a,Vec b)=>new Vec(a.x-b.x,a.y-b.y,a.z-b.z);public static Vec operator *(Vec a,double s)=>new Vec(a.x*s,a.y*s,a.z*s);public double Length=>Math.Sqrt(x*x+y*y+z*z);public Vec Unit=>this*(1/Math.Max(1e-9,Length));}
}
