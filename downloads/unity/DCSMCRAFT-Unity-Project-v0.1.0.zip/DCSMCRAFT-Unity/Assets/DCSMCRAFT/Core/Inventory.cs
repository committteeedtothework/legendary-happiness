using System;
using System.Collections.Generic;
using System.Linq;
namespace DCSMCRAFT.Core {
 [Serializable] public sealed class Stack {public string id;public int count,durability;public Stack Clone()=>new Stack{id=id,count=count,durability=durability};}
 public sealed class Inventory {
  public Stack[] Slots;public readonly Catalog Catalog;public int Selected;public long Revision{get;private set;}
  public Inventory(Catalog catalog,int size=36){Catalog=catalog;Slots=new Stack[size];}
  public Stack Held=>Slots[Math.Max(0,Math.Min(Slots.Length-1,Selected))];
  public int Count(string id)=>Slots.Where(s=>s!=null&&s.id==id).Sum(s=>s.count);
  public int Add(string id,int amount,int durability=0){if(!Catalog.Items.TryGetValue(id,out var item)||amount<=0)return amount;int left=amount;
   for(int pass=0;pass<2;pass++)for(int i=0;i<Slots.Length&&left>0;i++){var s=Slots[i];if(pass==0&&(s==null||s.id!=id||s.durability!=durability))continue;if(pass==1&&s!=null)continue;int n=Math.Min(left,item.stack-(s?.count??0));if(n<=0)continue;if(s==null)Slots[i]=s=new Stack{id=id,count=0,durability=durability};s.count+=n;left-=n;}
   if(left!=amount)Revision++;return left;
  }
  public bool Consume(string id,int count){if(count<=0||Count(id)<count)return false;for(int i=0;i<Slots.Length&&count>0;i++)if(Slots[i]?.id==id){int n=Math.Min(Slots[i].count,count);Slots[i].count-=n;count-=n;if(Slots[i].count==0)Slots[i]=null;}Revision++;return true;}
  public Stack TakeAt(int slot,int amount){if(slot<0||slot>=Slots.Length||Slots[slot]==null||amount<=0)return null;var result=Slots[slot].Clone();result.count=Math.Min(amount,result.count);Slots[slot].count-=result.count;if(Slots[slot].count==0)Slots[slot]=null;Revision++;return result;}
  public int Transfer(int slot,Inventory target){if(slot<0||slot>=Slots.Length||target==this||Slots[slot]==null)return 0;var s=Slots[slot];int left=target.Add(s.id,s.count,s.durability),moved=s.count-left;if(moved>0){s.count=left;if(left==0)Slots[slot]=null;Revision++;}return moved;}
  public void Swap(int a,int b){if(a<0||b<0||a>=Slots.Length||b>=Slots.Length)return;var s=Slots[a];Slots[a]=Slots[b];Slots[b]=s;Revision++;}
  public bool CanCraft(RecipeDef r,string station=""){if(r.station!=""&&r.station!=station)return false;return Allocate(r.Needs())!=null;}
  public bool Craft(RecipeDef r,string station=""){
   if(r.station!=""&&r.station!=station)return false;var used=Allocate(r.Needs());if(used==null)return false;var old=Slots.Select(s=>s?.Clone()).ToArray();long rev=Revision;
   foreach(var id in used)if(!Consume(id,1)){Slots=old;Revision=rev;return false;}
   int durability=Catalog.Items.TryGetValue(r.result,out var item)?item.durability:0;if(Add(r.result,r.count,durability)>0){Slots=old;Revision=rev;return false;}return true;
  }
  string[] Allocate(Ingredient[] needs){if(needs==null)return null;var counts=Slots.Where(s=>s!=null).GroupBy(s=>s.id).ToDictionary(g=>g.Key,g=>g.Sum(s=>s.count));var order=needs.Select((n,i)=>(need:n,index:i,options:counts.Keys.Where(n.Matches).ToArray())).OrderBy(x=>x.options.Length).ToArray();var used=new string[needs.Length];
   bool Solve(int at){if(at==order.Length)return true;var n=order[at];foreach(var id in n.options){if(counts[id]<=0)continue;counts[id]--;used[n.index]=id;if(Solve(at+1))return true;counts[id]++;}return false;}return Solve(0)?used:null;
  }
  public RecipeDef MatchGrid(string[] grid,int width){if(grid.Length!=width*width)return null;foreach(var r in Catalog.Data.recipes){if(r.station!="")continue;
   if(!r.shaped){var ids=grid.Where(x=>!string.IsNullOrEmpty(x)).ToArray();if(ids.Length!=r.ingredients.Length)continue;var scratch=new Inventory(Catalog,ids.Length);for(int i=0;i<ids.Length;i++)scratch.Slots[i]=new Stack{id=ids[i],count=1};if(scratch.Allocate(r.ingredients)!=null)return r;continue;}
   int h=r.pattern.Length,w=r.pattern.Max(s=>s.Length);if(h>width||w>width)continue;for(int flip=0;flip<2;flip++)for(int oy=0;oy<=width-h;oy++)for(int ox=0;ox<=width-w;ox++){bool ok=true;for(int y=0;y<width;y++)for(int x=0;x<width;x++){int rx=x-ox,ry=y-oy;char symbol=rx>=0&&rx<w&&ry>=0&&ry<h&&rx<r.pattern[ry].Length?r.pattern[ry][flip==0?rx:w-1-rx]:' ';string id=grid[y*width+x];if(symbol==' '){if(!string.IsNullOrEmpty(id))ok=false;}else{var key=r.keys.FirstOrDefault(k=>k.symbol==symbol.ToString());if(key==null||!key.Matches(id))ok=false;}}if(ok)return r;}
  }return null;}
 }
 [Serializable] public sealed class FurnaceState {public Stack input,fuel,output;public double heat,progress;}
 public static class Furnace {
  public static void Step(FurnaceState s,Catalog c,double dt){if(dt<=0||double.IsNaN(dt))return;double left=Math.Min(60,dt);while(left>1e-9){var recipe=c.Data.smelts.FirstOrDefault(x=>x.input==s.input?.id);bool can=recipe!=null&&s.input.count>0&&(s.output==null||s.output.id==recipe.output&&s.output.count<c.Items[recipe.output].stack);
   if(!can){s.heat=Math.Max(0,s.heat-left);return;}if(s.heat<=0){var f=c.Data.fuels.FirstOrDefault(x=>x.id==s.fuel?.id);if(f==null||s.fuel.count<=0)return;s.heat=f.ticks/20.0;if(--s.fuel.count==0)s.fuel=null;}
   double amount=Math.Min(left,Math.Min(s.heat,10-s.progress));s.heat-=amount;s.progress+=amount;left-=amount;if(s.progress>=10-1e-8){if(--s.input.count==0)s.input=null;if(s.output==null)s.output=new Stack{id=recipe.output,count=0};s.output.count++;s.progress=0;}
  }}
 }
}
