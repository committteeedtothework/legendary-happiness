using System;
using System.Collections.Generic;
using System.Linq;
namespace DCSMCRAFT.Core {
 [Serializable] public sealed class PartDef {public float[] v;}
 [Serializable] public sealed class BlockDef { public int id; public string key,name,color,tool,drop,shape; public double hardness; public bool solid,transparent, @internal; public int tier,light; public float[] bounds; public PartDef[] parts,uvs;public int[] faceTiles,classicTiles,suppliedTiles; }
 [Serializable] public sealed class ItemDef { public string id,name,tool,color,spawnType; public int icon,block,stack,tier,durability,food; public double speed,attack,saturation; public bool unbreakable,creativeOnly; }
 [Serializable] public sealed class Ingredient { public string symbol; public string[] choices; public bool Matches(string id)=>choices!=null&&Array.IndexOf(choices,id)>=0; }
 [Serializable] public sealed class RecipeDef { public string id,result,station; public int count; public bool shaped; public string[] pattern; public Ingredient[] keys,ingredients; public Ingredient[] Needs()=>shaped?pattern.SelectMany(row=>row.Where(c=>c!=' ').Select(c=>keys.First(k=>k.symbol==c.ToString()))).ToArray():ingredients; }
 [Serializable] public sealed class FuelDef { public string id; public float ticks; }
 [Serializable] public sealed class SmeltDef { public string input,output; }
 [Serializable] public sealed class TitanDef { public string id,model,prelude; public double health,phaseOneStart,phaseOneEnd,phaseTwoStart,phaseTwoEnd,victoryStart; }
 [Serializable] public sealed class SkinDef {public string id,name,style;}
 [Serializable] public sealed class MobDef {public string id,name;public float height,width,speed;public int health,damage;public bool hostile,cinder;}
 [Serializable] public sealed class CatalogData { public int schema,generationVersion,minY,maxY,chunkSize,sea,atlasColumns,atlasRows; public string sourceVersion,reference; public BlockDef[] blocks; public ItemDef[] items; public RecipeDef[] recipes; public FuelDef[] fuels; public SmeltDef[] smelts; public TitanDef[] titans;public SkinDef[] skins;public MobDef[] mobs; }
 public sealed class Catalog {
  public readonly CatalogData Data; public readonly Dictionary<string,ItemDef> Items; public readonly Dictionary<string,ushort> Blocks; public readonly Dictionary<string,RecipeDef> Recipes;
  public Catalog(CatalogData data){Data=data??throw new ArgumentNullException(nameof(data)); if(data.schema!=1||data.blocks==null||data.items==null)throw new ArgumentException("Unsupported catalog"); Items=data.items.ToDictionary(x=>x.id);Blocks=data.blocks.ToDictionary(x=>x.key,x=>checked((ushort)x.id));Recipes=data.recipes.ToDictionary(x=>x.id);for(int i=0;i<data.blocks.Length;i++)if(data.blocks[i].id!=i)throw new ArgumentException("Block IDs are not stable");}
  public ushort Id(string key)=>Blocks.TryGetValue(key,out var id)?id:(ushort)0;
  public BlockDef Block(ushort id)=>Data.blocks[id<Data.blocks.Length?id:0];
 }
}
