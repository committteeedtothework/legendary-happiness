using System;
using System.Collections.Generic;
namespace DCSMCRAFT.Core {
 public struct MeshVertex {public float x,y,z,u,v,light,sky;public MeshVertex(float x,float y,float z,float u,float v,float light,float sky=1){this.x=x;this.y=y;this.z=z;this.u=u;this.v=v;this.light=light;this.sky=sky;}}
 public sealed class ChunkMesh {public readonly List<MeshVertex> vertices=new List<MeshVertex>();public readonly List<int> opaque=new List<int>(),water=new List<int>(),collision=new List<int>();public long revision;}
 public static class ChunkMesher {
  static readonly Cell[] Directions={new Cell(1,0,0),new Cell(-1,0,0),new Cell(0,1,0),new Cell(0,-1,0),new Cell(0,0,1),new Cell(0,0,-1)};
  static readonly int[][] Corners={new[]{1,0,1,1,0,0,1,1,0,1,1,1},new[]{0,0,0,0,0,1,0,1,1,0,1,0},new[]{0,1,1,1,1,1,1,1,0,0,1,0},new[]{0,0,0,1,0,0,1,0,1,0,0,1},new[]{0,0,1,1,0,1,1,1,1,0,1,1},new[]{1,0,0,0,0,0,0,1,0,1,1,0}};
  public static ChunkMesh Build(Catalog catalog,WorldSnapshot world,int cx,int cz,int pack=0){
   var result=new ChunkMesh{revision=world.revision};int height=VoxelWorld.MaxY-VoxelWorld.MinY+3;var cells=new ushort[18*18*height];var ceilings=new int[324];for(int i=0;i<ceilings.Length;i++)ceilings[i]=VoxelWorld.MinY;
   int Index(int x,int y,int z)=>(y-VoxelWorld.MinY+1)*324+(z+1)*18+x+1;
   for(int z=-1;z<=16;z++)for(int x=-1;x<=16;x++)for(int y=VoxelWorld.MinY-1;y<=VoxelWorld.MaxY+1;y++){ushort value=world.Get(cx*16+x,y,cz*16+z);cells[Index(x,y,z)]=value;var block=catalog.Block(value);if(block.solid&&!block.transparent)ceilings[(z+1)*18+x+1]=y;}
   for(int y=VoxelWorld.MinY;y<=VoxelWorld.MaxY;y++)for(int z=0;z<16;z++)for(int x=0;x<16;x++){
    ushort id=cells[Index(x,y,z)];if(id==0)continue;var b=catalog.Block(id);bool fluid=b.key=="water"||b.key=="lava";
    var parts=b.parts!=null&&b.parts.Length>0?b.parts:new[]{new PartDef{v=b.bounds??new float[]{0,0,0,1,1,1}}};
    foreach(var part in parts){var bounds=part.v;if(bounds==null||bounds.Length!=6)continue;
     for(int face=0;face<6;face++){var d=Directions[face];ushort n=cells[Index(x+d.x,y+d.y,z+d.z)];var neighbor=catalog.Block(n);bool full=parts.Length==1&&bounds[0]==0&&bounds[1]==0&&bounds[2]==0&&bounds[3]==1&&bounds[4]==1&&bounds[5]==1;
      if(full&&((fluid&&n==id)||(!neighbor.transparent&&neighbor.solid)))continue;
      int tile=(pack==1?b.classicTiles:pack==2?b.suppliedTiles:b.faceTiles)?[face]??id*3+(face==2?0:face==3?2:1);float u0=(tile%catalog.Data.atlasColumns+.015f)/catalog.Data.atlasColumns,v0=1-(tile/catalog.Data.atlasColumns+1-.015f)/catalog.Data.atlasRows;float du=.97f/catalog.Data.atlasColumns,dv=.97f/catalog.Data.atlasRows;
      float light=Math.Max(b.key=="torch"?.94f:b.key=="lava"?1:0,world.Light(cx*16+x+d.x,y+d.y,cz*16+z+d.z)/15f);
      int start=result.vertices.Count;var c=Corners[face];for(int i=0;i<4;i++){float px=bounds[0]+c[i*3]*(bounds[3]-bounds[0]),py=bounds[1]+c[i*3+1]*(bounds[4]-bounds[1]),pz=bounds[2]+c[i*3+2]*(bounds[5]-bounds[2]);if(b.key=="water"&&c[i*3+1]==1)py*=.92f;float tu=face==0?1-pz:face==1?pz:face==5?1-px:px,tv=face==2?1-pz:face==3?pz:py;var map=b.uvs!=null&&b.uvs.Length>pack*6+face?b.uvs[pack*6+face].v:null;float u=map==null?u0+(i==1||i==2?du:0):map[0]+tu*(map[2]-map[0])+tv*(map[4]-map[0]),v=map==null?v0+(i>=2?dv:0):map[1]+tu*(map[3]-map[1])+tv*(map[5]-map[1]);result.vertices.Add(new MeshVertex(x+px,y+py,z+pz,u,v,light,y+d.y>=ceilings[(z+d.z+1)*18+x+d.x+1]?1:0));}
      var target=fluid?result.water:result.opaque;foreach(int i in new[]{0,1,2,0,2,3}){target.Add(start+i);if(b.solid)result.collision.Add(start+i);}
     }
    }
   }
   return result;
  }
 }
}
