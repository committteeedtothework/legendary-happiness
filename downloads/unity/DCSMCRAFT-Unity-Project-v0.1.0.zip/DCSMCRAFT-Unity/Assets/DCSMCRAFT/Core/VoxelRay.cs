using System;
namespace DCSMCRAFT.Core {
 public struct VoxelHit {public bool hit;public Cell cell,normal;public double distance;}
 public static class VoxelRay {
  public static VoxelHit Cast(VoxelWorld world,Vec origin,Vec direction,double reach){var dir=direction.Unit;if(direction.Length<1e-8)return default;var p=new Cell((int)Math.Floor(origin.x),(int)Math.Floor(origin.y),(int)Math.Floor(origin.z));int sx=Math.Sign(dir.x),sy=Math.Sign(dir.y),sz=Math.Sign(dir.z);double dx=Math.Abs(dir.x)<1e-12?double.PositiveInfinity:Math.Abs(1/dir.x),dy=Math.Abs(dir.y)<1e-12?double.PositiveInfinity:Math.Abs(1/dir.y),dz=Math.Abs(dir.z)<1e-12?double.PositiveInfinity:Math.Abs(1/dir.z);
   double tx=sx==0?double.PositiveInfinity:((sx>0?p.x+1:p.x)-origin.x)/dir.x,ty=sy==0?double.PositiveInfinity:((sy>0?p.y+1:p.y)-origin.y)/dir.y,tz=sz==0?double.PositiveInfinity:((sz>0?p.z+1:p.z)-origin.z)/dir.z;
   for(int i=0;i<256;i++){var b=world.Catalog.Block(world.Get(p.x,p.y,p.z));if(b.id!=0&&b.key!="water"&&b.key!="lava"){foreach(var part in b.parts??new[]{new PartDef{v=b.bounds}}){var a=part.v;if(a==null)continue;double enter=0,exit=reach;Cell normal=default;bool valid=true;for(int axis=0;axis<3;axis++){double o=axis==0?origin.x:axis==1?origin.y:origin.z,d=axis==0?dir.x:axis==1?dir.y:dir.z,offset=axis==0?p.x:axis==1?p.y:p.z,min=offset+a[axis],max=offset+a[axis+3];if(Math.Abs(d)<1e-12){if(o<min||o>max)valid=false;continue;}double n=(min-o)/d,f=(max-o)/d;int sign=-Math.Sign(d);if(n>f){double tmp=n;n=f;f=tmp;}if(n>enter){enter=n;normal=axis==0?new Cell(sign,0,0):axis==1?new Cell(0,sign,0):new Cell(0,0,sign);}exit=Math.Min(exit,f);if(enter>exit)valid=false;}if(valid&&enter<=reach&&exit>=0)return new VoxelHit{hit=true,cell=p,normal=normal,distance=enter};}}
    double t=Math.Min(tx,Math.Min(ty,tz));if(t>reach)return default;if(tx<=ty&&tx<=tz){p.x+=sx;tx+=dx;}else if(ty<=tz){p.y+=sy;ty+=dy;}else{p.z+=sz;tz+=dz;}
   }return default;
  }
 }
 public static class Mining {
  public static double Seconds(BlockDef b,ItemDef item){if(b.hardness<0)return double.PositiveInfinity;if(b.hardness==0)return 0;bool correct=string.IsNullOrEmpty(b.tool)||item?.tool==b.tool;bool harvest=string.IsNullOrEmpty(b.tool)||correct&&(item?.tier??0)>=b.tier;double speed=correct?(item?.speed??1):1;return Math.Max(.05,b.hardness*(harvest?1.5:5)/speed);}
  public static bool CanHarvest(BlockDef b,ItemDef item)=>string.IsNullOrEmpty(b.tool)||item?.tool==b.tool&&(item?.tier??0)>=b.tier;
 }
}
