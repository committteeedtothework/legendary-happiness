using System;
using System.Collections.Generic;
namespace DCSMCRAFT.Core {
 // Native encounter foundation, intentionally distinct from the complete JS
 // choreography. Stages/rewards/resources are real; imported animations drive
 // presentation without being authoritative for hit or save state.
 public enum TitanStage { Approach,Transform,Combat,PhaseTransition,Defeat,Victory }
 public sealed class TitanEncounter {
  public readonly TitanDef Definition;public TitanStage Stage=TitanStage.Approach;public double Health,Rings=150,Time,StageTime,ComboTimer;public int Phase=1,Combo;public bool Emerald,Paused,RewardClaimed;public string Move="idle",BossAttack="idle";
  public readonly List<string> Events=new List<string>();public double Windup,Contact,Recovery,AttackAge;public int Sequence;public double ParryAge=100,DodgeAge=100,Opening;public Vec HomingTarget,AttackTarget;public bool Homing;public double HomingAge;public long StrikeSerial;double attackTime;bool didHit;
  public TitanEncounter(TitanDef definition){Definition=definition;Health=definition.health;}
  public void CollectRing(int amount=1){if(Stage==TitanStage.Approach||Stage==TitanStage.Combat)Rings=Math.Min(400,Rings+Math.Max(0,amount));}
  public bool CollectEmerald(){if(Stage!=TitanStage.Approach)return false;Emerald=true;Change(TitanStage.Transform);return true;}
  public bool Parry(){if(Stage!=TitanStage.Combat)return false;ParryAge=0;Move="parry";return true;}
  public bool Dodge(){if(Stage!=TitanStage.Combat)return false;DodgeAge=0;Homing=false;Move="dodge";return true;}
  public bool BeginHoming(Vec target){if(Stage!=TitanStage.Combat||Homing)return false;Homing=true;HomingAge=0;HomingTarget=target;StrikeSerial++;Move="homing_attack";return true;}
  public Vec HomingVelocity(Vec position,double dt){if(!Homing||dt<=0)return default;if(HomingAge<.15)return default;var delta=HomingTarget-position;return delta.Unit*Math.Min(180,delta.Length/dt);}
  public bool Hit(string move,double distance,bool pressed=true){if(Stage!=TitanStage.Combat||Homing||attackTime>0||Definition.id=="wyvern"&&Opening<=0)return false;double reach=move=="sonic_boom"?50:8;if(distance>reach)return false;Move=move;attackTime=.34;didHit=false;StrikeSerial++;return true;}
  public void Tick(double dt,Vec player,Vec contact,bool homingContact=false){Events.Clear();if(Paused||dt<=0||Stage==TitanStage.Victory||Stage==TitanStage.Defeat)return;dt=Math.Min(.05,dt);Time+=dt;StageTime+=dt;ParryAge+=dt;DodgeAge+=dt;Opening=Math.Max(0,Opening-dt);ComboTimer=Math.Max(0,ComboTimer-dt);if(ComboTimer==0)Combo=0;
   if(Stage==TitanStage.Transform){if(StageTime>=4)Change(TitanStage.Combat);return;}if(Stage==TitanStage.PhaseTransition){if(StageTime>=3)Change(TitanStage.Combat);return;}if(Stage!=TitanStage.Combat)return;
   Rings=Math.Max(0,Rings-dt);if(Rings<=0){Homing=false;Change(TitanStage.Defeat);return;}
   if(Homing){HomingAge+=dt;if(HomingAge>.15&&homingContact){Damage(500);Homing=false;Move="fly";Events.Add("homing-impact");}else if(HomingAge>2.5){Homing=false;Move="fly";}}
   if(attackTime>0){double old=attackTime;attackTime=Math.Max(0,attackTime-dt);if(!didHit&&old>.18&&attackTime<=.18){didHit=true;if((contact-player).Length<=8||Move=="sonic_boom")Damage(Move=="sonic_boom"?300:180);}if(attackTime==0)Move="fly";}
   if(Stage!=TitanStage.Combat)return;
   if(BossAttack=="idle"){BossAttack=Definition.id=="wyvern"?"missile":new[]{"swing","slap","stomp","beam"}[Sequence++%Math.Min(Phase==1?3:4,4)];Windup=Phase==1?1.6:1.25;Contact=Windup;Recovery=2.2;AttackAge=0;AttackTarget=player;Events.Add("telegraph");}
   else{double old=AttackAge;AttackAge+=dt;if(old<Contact&&AttackAge>=Contact){bool reaches=BossAttack=="missile"||BossAttack=="beam"?(player-AttackTarget).Length<4:(player-contact).Length<(BossAttack=="stomp"?24:15);if(reaches&&ParryAge<=.45){Opening=12;BeginHoming(contact);Events.Add("parry");}else if(reaches&&DodgeAge>.4){Rings=Math.Max(0,Rings-20);Events.Add("hurt");}}if(AttackAge>=Contact+Recovery)BossAttack="idle";}
  }
  public void Damage(double amount){if(Stage!=TitanStage.Combat||Definition.id=="wyvern"&&Opening<=0)return;Health=Math.Max(0,Health-Math.Max(0,amount));Combo++;ComboTimer=2;Events.Add("hit");if(Health==0){Homing=false;Change(TitanStage.Victory);return;}if(Phase==1&&Health<=Definition.health*.5){Health=Definition.health*.5;Phase=2;Homing=false;Change(TitanStage.PhaseTransition);}}
  public (double start,double end) MusicRegion()=>Stage==TitanStage.Victory?(Definition.victoryStart,double.PositiveInfinity):Phase==1?(Definition.phaseOneStart,Definition.phaseOneEnd):(Definition.phaseTwoStart,Definition.phaseTwoEnd);
  public bool ClaimReward(){if(Stage!=TitanStage.Victory||RewardClaimed)return false;RewardClaimed=true;return true;}
  public void Retry(){if(Stage!=TitanStage.Defeat)return;Rings=200;Health=Phase==2?Definition.health*.5:Definition.health;Homing=false;Change(TitanStage.Combat);}
  void Change(TitanStage stage){Stage=stage;StageTime=0;BossAttack="idle";attackTime=0;Events.Add("stage");}
 }
}
