using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
namespace DCSMCRAFT.Core {
 // Separate format/path from browser saves. A validated previous generation is
 // retained even when the current generation is damaged or a write is interrupted.
 public sealed class AtomicSaveStore {
  readonly string path;readonly object gate=new object();
  public AtomicSaveStore(string path){this.path=path;}
  static string Hash(string payload){using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(payload))).Replace("-","").ToLowerInvariant();}
  public static string Pack(string payload)=>"DCSMCRAFT-UNITY-1\n"+Hash(payload)+"\n"+payload;
  public static bool TryUnpack(string text,out string payload){payload=null;if(text==null||!text.StartsWith("DCSMCRAFT-UNITY-1\n",StringComparison.Ordinal))return false;int split=text.IndexOf('\n',18);if(split<0)return false;string hash=text.Substring(18,split-18);payload=text.Substring(split+1);if(hash!=Hash(payload)){payload=null;return false;}return true;}
  bool Read(string file,out string payload){payload=null;try{return File.Exists(file)&&TryUnpack(File.ReadAllText(file,Encoding.UTF8),out payload);}catch(IOException){return false;}catch(UnauthorizedAccessException){return false;}}
  public string Load(){lock(gate){foreach(var file in new[]{path,path+".bak",path+".new"})if(Read(file,out var payload))return payload;return null;}}
  public void Save(string payload){if(payload==null)throw new ArgumentNullException(nameof(payload));lock(gate){Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));string temp=path+".new";byte[] bytes=Encoding.UTF8.GetBytes(Pack(payload));using(var stream=new FileStream(temp,FileMode.Create,FileAccess.Write,FileShare.None)){stream.Write(bytes,0,bytes.Length);stream.Flush(true);}if(!Read(temp,out _))throw new IOException("Save verification failed");
   if(File.Exists(path)){if(Read(path,out _))File.Copy(path,path+".bak",true);File.Delete(path);}File.Move(temp,path);
  }}
 }
 [Serializable] public sealed class SavedMob {public string type;public double x,y,z;public int health;}
 [Serializable] public sealed class SavedDrop {public double x,y,z,age;public Stack stack;}
 [Serializable] public sealed class SavedEdit {public int x,y,z,id;}
 [Serializable] public sealed class SavedContainer {public int x,y,z;public Stack[] slots;}
 [Serializable] public sealed class SavedFurnace {public int x,y,z;public FurnaceState state;}
 [Serializable] public sealed class SaveData {public int schema=1,generation=1,selected;public string seed,dimension="overworld",mode="creative",skin="explorer";public double x,y,z,yaw,pitch,health=20,hunger=20,time=0;public Stack[] slots;public SavedEdit[] edits;public SavedFurnace[] furnaces;public SavedContainer[] containers;public SavedDrop[] drops;public SavedMob[] mobs;public string[] titanRewards=new string[0];}
}
