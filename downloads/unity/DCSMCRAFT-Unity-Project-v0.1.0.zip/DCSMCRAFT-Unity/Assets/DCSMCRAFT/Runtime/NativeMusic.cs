using System;
using System.Threading.Tasks;
using UnityEngine;
namespace DCSMCRAFT.Unity {
 public sealed class NativeMusic : MonoBehaviour {
  public float Volume=.45f;AudioSource[] voices;int epoch,index;AudioClip clip;double start,end,next;bool loop,scheduled;
  void Awake(){voices=new[]{gameObject.AddComponent<AudioSource>(),gameObject.AddComponent<AudioSource>()};foreach(var v in voices){v.playOnAwake=false;v.spatialBlend=0;v.volume=Volume;}}
  public async Task Play(MigratedAssets assets,string file,double from,double until,bool repeat){int request=++epoch;StopVoices();var loaded=await assets.Audio(file);if(!this||request!=epoch||!loaded)return;clip=loaded;start=Math.Max(0,Math.Min(from,clip.length-.02));end=until>start?Math.Min(until,clip.length):clip.length;loop=repeat;index=0;next=AudioSettings.dspTime+.08;Schedule(index,next);next+=end-start;scheduled=false;}
  void Schedule(int i,double at){var v=voices[i];v.Stop();v.clip=clip;v.timeSamples=Mathf.Clamp((int)(start*clip.frequency),0,clip.samples-1);v.volume=Volume;v.PlayScheduled(at);v.SetScheduledEndTime(at+end-start);}
  void Update(){if(!clip||AudioListener.pause)return;foreach(var v in voices)v.volume=Volume;if(!loop)return;double now=AudioSettings.dspTime;if(!scheduled&&next-now<1){Schedule(1-index,next);scheduled=true;}if(scheduled&&now>=next){index=1-index;next+=end-start;scheduled=false;}}
  public void Stop(){epoch++;clip=null;StopVoices();}void StopVoices(){if(voices!=null)foreach(var v in voices)v.Stop();}void OnDestroy(){Stop();}
 }
}
