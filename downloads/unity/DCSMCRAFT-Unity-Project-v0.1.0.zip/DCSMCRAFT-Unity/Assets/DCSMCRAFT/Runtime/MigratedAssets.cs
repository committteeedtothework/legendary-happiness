using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using DCSMCRAFT.Core;
using GLTFast;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.Rendering;
namespace DCSMCRAFT.Unity {
 public sealed class MigratedAssets : IDisposable {
  public Catalog Catalog{get;private set;}public string Root=>Path.Combine(Application.streamingAssetsPath,"Migrated");
  readonly Dictionary<string,Texture2D> textures=new Dictionary<string,Texture2D>();readonly Dictionary<string,Task<GltfImport>> imports=new Dictionary<string,Task<GltfImport>>();readonly List<AudioClip> clips=new List<AudioClip>();readonly Dictionary<string,Task<AudioClip>> audioJobs=new Dictionary<string,Task<AudioClip>>();
  public void LoadCatalog(){var path=Path.Combine(Root,"catalog.json");if(!File.Exists(path))throw new IOException("Game data is missing. Run tools/Restore-Assets.ps1 first.");Catalog=new Catalog(JsonUtility.FromJson<CatalogData>(File.ReadAllText(path)));}
  public Texture2D Texture(string name){if(textures.TryGetValue(name,out var t))return t;var path=Path.Combine(Root,name);if(!File.Exists(path))throw new IOException("Missing artwork: "+name);t=new Texture2D(2,2,TextureFormat.RGBA32,true){name=name,filterMode=FilterMode.Point,wrapMode=TextureWrapMode.Clamp};if(!ImageConversion.LoadImage(t,File.ReadAllBytes(path)))throw new IOException("Invalid artwork: "+name);textures[name]=t;return t;}
  async Task<GltfImport> Import(string path){var gltf=new GltfImport();try{if(!await gltf.Load(new Uri(path).AbsoluteUri,new ImportSettings{AnimationMethod=AnimationMethod.Legacy,NodeNameMethod=NameImportMethod.Original}))throw new IOException("Model import failed: "+path);return gltf;}catch{gltf.Dispose();throw;}}
  public async Task<GameObject> Model(string name,Transform parent){var path=Path.Combine(Root,name);if(!File.Exists(path))throw new IOException("Missing model: "+name);if(!imports.TryGetValue(name,out var job))imports[name]=job=Import(path);var gltf=await job;if(!parent)throw new OperationCanceledException();var root=new GameObject(Path.GetFileNameWithoutExtension(name));root.transform.SetParent(parent,false);if(!await gltf.InstantiateMainSceneAsync(root.transform)){UnityEngine.Object.Destroy(root);throw new IOException("Model scene could not be instantiated: "+name);}foreach(var r in root.GetComponentsInChildren<Renderer>()){r.shadowCastingMode=ShadowCastingMode.On;r.receiveShadows=true;}return root;}
  public Task<AudioClip> Audio(string relative){if(!audioJobs.TryGetValue(relative,out var job))audioJobs[relative]=job=LoadAudio(relative);return job;}
  async Task<AudioClip> LoadAudio(string relative){string path=Path.Combine(Root,relative);if(!File.Exists(path))return null;using(var req=UnityWebRequestMultimedia.GetAudioClip(new Uri(path).AbsoluteUri,AudioType.MPEG)){var handler=(DownloadHandlerAudioClip)req.downloadHandler;handler.streamAudio=true;var operation=req.SendWebRequest();while(!operation.isDone)await Task.Yield();if(req.result!=UnityWebRequest.Result.Success)throw new IOException("Audio could not be loaded: "+relative);var clip=DownloadHandlerAudioClip.GetContent(req);clips.Add(clip);return clip;}}
  public static Bounds Normalize(GameObject model,float height){var renderers=model.GetComponentsInChildren<Renderer>();if(renderers.Length==0)throw new InvalidDataException("Model has no renderers");var bounds=renderers[0].bounds;foreach(var r in renderers)bounds.Encapsulate(r.bounds);if(bounds.size.y<.001f)throw new InvalidDataException("Invalid model bounds");model.transform.localScale*=height/bounds.size.y;bounds=renderers[0].bounds;foreach(var r in renderers)bounds.Encapsulate(r.bounds);model.transform.position-=Vector3.up*(bounds.min.y-model.transform.parent.position.y);return bounds;}
  public static void Play(GameObject model,string clip,float blend=.12f){if(!model)return;var animation=model.GetComponentInChildren<Animation>();if(!animation)return;if(animation[clip]!=null&&!animation.IsPlaying(clip)){animation[clip].wrapMode=new[]{"idle","move","run","boost","fly","flight","boost_run","boost_flight","walk","jump_spin"}.Contains(clip)?WrapMode.Loop:WrapMode.ClampForever;animation.CrossFade(clip,blend);}}
  public void Dispose(){foreach(var i in imports.Values)if(i.Status==TaskStatus.RanToCompletion)i.Result.Dispose();foreach(var t in textures.Values)UnityEngine.Object.Destroy(t);foreach(var c in clips)UnityEngine.Object.Destroy(c);imports.Clear();textures.Clear();clips.Clear();}
 }
}
