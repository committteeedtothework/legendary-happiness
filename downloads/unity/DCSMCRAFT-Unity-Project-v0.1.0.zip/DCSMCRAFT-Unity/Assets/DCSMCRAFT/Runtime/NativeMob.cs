using System;
using System.Linq;
using DCSMCRAFT.Core;
using UnityEngine;
namespace DCSMCRAFT.Unity {
 public sealed class NativeMob : MonoBehaviour {
  public NativeGame Game;public string Type;public int Health;MobDef data;CharacterController body;GameObject model;Vector3 goal;float timer,attackTimer,vertical,flee;
  public async void Initialize(NativeGame game,MobDef definition,int health){Game=game;data=definition;Type=data.id;Health=health>0?health:Math.Max(1,data.health);gameObject.layer=10;body=gameObject.AddComponent<CharacterController>();body.height=Mathf.Max(.5f,data.height);body.radius=Mathf.Clamp(data.width*.5f,.2f,1.2f);body.center=Vector3.up*body.height*.5f;body.stepOffset=Mathf.Min(.5f,body.height*.45f);body.skinWidth=.03f;goal=transform.position;try{model=await game.Assets.Model("Mobs/"+data.id+".glb",transform);if(this)MigratedAssets.Normalize(model,body.height);}catch(OperationCanceledException){}catch(Exception e){if(this)game.Error=e.Message;}}
  void Update(){if(!Game||Game.Paused||Game.InArena||!Game.IsChunkLoaded(transform.position)||body==null)return;timer-=Time.deltaTime;attackTimer-=Time.deltaTime;flee=Mathf.Max(0,flee-Time.deltaTime);var p=Game.Player.transform.position;bool chase=data.hostile&&Vector3.Distance(p,transform.position)<22;if(chase)goal=p;else if(flee>0)goal=transform.position+(transform.position-p).normalized*8;else if(timer<=0){timer=2+UnityEngine.Random.value*4;goal=transform.position+new Vector3(UnityEngine.Random.Range(-8f,8f),0,UnityEngine.Random.Range(-8f,8f));}var delta=goal-transform.position;delta.y=0;bool moving=delta.sqrMagnitude>.5f;var movement=moving?delta.normalized*Mathf.Max(.4f,data.speed)*(chase?1.8f:1):Vector3.zero;if(body.isGrounded)vertical=-2;else vertical-=25*Time.deltaTime;movement.y=vertical;body.Move(movement*Time.deltaTime);if(moving)transform.rotation=Quaternion.Slerp(transform.rotation,Quaternion.LookRotation(delta),1-Mathf.Exp(-Time.deltaTime*6));if(chase&&attackTimer<=0&&Vector3.Distance(p,transform.position)<2){Game.TakeDamage(Math.Max(1,data.damage));attackTimer=1.3f;}}
  public void Hit(int damage){if(Type=="watcher")return;Health-=Math.Max(1,damage);flee=4;if(Health>0)return;string drop=Type=="skeleton"?"bone":data.hostile?"rotten_flesh":"raw_meat";Game.SpawnDrop(new Stack{id=drop,count=1},transform.position+Vector3.up*.5f);Destroy(gameObject);}
 }
 public sealed partial class NativeGame {
  public bool IsChunkLoaded(Vector3 at)=>streamer&&streamer.IsLoaded(at);
  public void SpawnMob(string id,Vector3 at,int health=0){var def=Catalog.Data.mobs.FirstOrDefault(m=>m.id==id);if(def==null)return;var mob=new GameObject(def.name);mob.transform.SetParent(worldRoot.transform);mob.transform.position=at;mob.AddComponent<NativeMob>().Initialize(this,def,health);}
  void SpawnWildlife(){var types=dimension=="cinderworld"?Catalog.Data.mobs.Where(m=>m.cinder&&m.height<3).Select(m=>m.id).ToArray():new[]{"cow","chicken","rabbit","grazer"};if(types.Length==0)return;for(int i=0;i<10;i++){int x=UnityEngine.Random.Range(-28,29),z=UnityEngine.Random.Range(-28,29);if(World.Height(x,z)<VoxelWorld.Sea)continue;SpawnMob(types[i%types.Length],new Vector3(x,World.Height(x,z)+2,z));}}
  public void TakeDamage(float amount){if(Creative||InArena)return;Health-=amount;if(Health<=0)Respawn();}
  float nextMelee;
  public bool AttackMob(Ray ray,double blockDistance){if(Time.time<nextMelee)return false;if(Physics.Raycast(ray,out var hit,4.5f,1<<10,QueryTriggerInteraction.Ignore)&&hit.distance<blockDistance+.001){var mob=hit.collider.GetComponentInParent<NativeMob>();if(mob){Catalog.Items.TryGetValue(Inventory.Held?.id??"",out var item);mob.Hit(Mathf.RoundToInt((float)(item?.attack??1)));nextMelee=Time.time+.4f;return true;}}return false;}
 }
}
