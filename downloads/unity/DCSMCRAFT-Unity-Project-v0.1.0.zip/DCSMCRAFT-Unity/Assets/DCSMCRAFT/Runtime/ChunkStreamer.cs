using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DCSMCRAFT.Core;
using UnityEngine;
using UnityEngine.Rendering;
namespace DCSMCRAFT.Unity {
 public sealed class ChunkStreamer : MonoBehaviour {
  public VoxelWorld World{get;private set;}public Transform Observer;public int Distance=4,Pack;public Material SolidMaterial,WaterMaterial;public bool Ready{get;private set;}
  readonly Dictionary<Cell,GameObject> chunks=new Dictionary<Cell,GameObject>();readonly Dictionary<Cell,Task<ChunkMesh>> jobs=new Dictionary<Cell,Task<ChunkMesh>>();readonly HashSet<Cell> dirty=new HashSet<Cell>();readonly Dictionary<Cell,Mesh[]> owned=new Dictionary<Cell,Mesh[]>();bool disposed;readonly ChunkRevisions revisions=new ChunkRevisions();
  public void Initialize(VoxelWorld world,Transform observer,Material solid,Material water){World=world;Observer=observer;SolidMaterial=solid;WaterMaterial=water;world.Changed+=OnEdit;}
  void OnEdit(Cell cell){foreach(var chunk in revisions.Changed(cell,World.Revision))dirty.Add(chunk);}
  public bool IsLoaded(Vector3 at)=>chunks.ContainsKey(new Cell(Mathf.FloorToInt(at.x/16),0,Mathf.FloorToInt(at.z/16)));
  public void RebuildAll(){foreach(var k in chunks.Keys)dirty.Add(k);}
  void Update(){if(World==null||!Observer||disposed)return;var center=new Cell(Mathf.FloorToInt(Observer.position.x/16),0,Mathf.FloorToInt(Observer.position.z/16));
   foreach(var key in chunks.Keys.Where(k=>Math.Abs(k.x-center.x)>Distance+1||Math.Abs(k.z-center.z)>Distance+1).ToArray())Remove(key);
   var watch=System.Diagnostics.Stopwatch.StartNew();foreach(var pair in jobs.ToArray()){if(!pair.Value.IsCompleted)continue;jobs.Remove(pair.Key);if(pair.Value.IsFaulted){Debug.LogException(pair.Value.Exception);continue;}var mesh=pair.Value.Result;if(disposed)continue;if(!revisions.Current(pair.Key,mesh.revision)){dirty.Add(pair.Key);continue;}if(Math.Abs(pair.Key.x-center.x)<=Distance+1&&Math.Abs(pair.Key.z-center.z)<=Distance+1)Apply(pair.Key,mesh);if(watch.Elapsed.TotalMilliseconds>4)break;}
   var candidates=new List<Cell>();for(int z=center.z-Distance;z<=center.z+Distance;z++)for(int x=center.x-Distance;x<=center.x+Distance;x++){var k=new Cell(x,0,z);if(!jobs.ContainsKey(k)&&(!chunks.ContainsKey(k)||dirty.Contains(k)))candidates.Add(k);}foreach(var key in candidates.OrderBy(k=>(k.x-center.x)*(k.x-center.x)+(k.z-center.z)*(k.z-center.z))){if(jobs.Count>=2)break;var snapshot=World.Snapshot();int pack=Pack;dirty.Remove(key);jobs[key]=Task.Run(()=>ChunkMesher.Build(World.Catalog,snapshot,key.x,key.z,pack));}
   Ready=chunks.ContainsKey(center)&&chunks.ContainsKey(new Cell(center.x+1,0,center.z))&&chunks.ContainsKey(new Cell(center.x-1,0,center.z))&&chunks.ContainsKey(new Cell(center.x,0,center.z+1))&&chunks.ContainsKey(new Cell(center.x,0,center.z-1));
  }
  void Apply(Cell key,ChunkMesh data){if(!chunks.TryGetValue(key,out var go)){go=new GameObject($"Chunk {key.x},{key.z}");go.transform.SetParent(transform,false);go.transform.localPosition=new Vector3(key.x*16,0,key.z*16);go.AddComponent<MeshFilter>();go.AddComponent<MeshRenderer>().sharedMaterials=new[]{SolidMaterial,WaterMaterial};go.AddComponent<MeshCollider>();chunks[key]=go;}go.GetComponent<MeshRenderer>().sharedMaterials=new[]{SolidMaterial,WaterMaterial};var v=data.vertices;var positions=new Vector3[v.Count];var uv=new Vector2[v.Count];var colors=new Color[v.Count];for(int i=0;i<v.Count;i++){positions[i]=new Vector3(v[i].x,v[i].y,v[i].z);uv[i]=new Vector2(v[i].u,v[i].v);colors[i]=new Color(v[i].light,v[i].sky,0,1);}var mesh=new Mesh{name="Chunk visual",indexFormat=IndexFormat.UInt32,vertices=positions,uv=uv,colors=colors,subMeshCount=2};mesh.SetTriangles(data.opaque,0);mesh.SetTriangles(data.water,1);mesh.RecalculateNormals();mesh.RecalculateBounds();var collision=new Mesh{name="Chunk collision",indexFormat=IndexFormat.UInt32,vertices=positions};collision.SetTriangles(data.collision,0);collision.RecalculateBounds();go.GetComponent<MeshFilter>().sharedMesh=mesh;go.GetComponent<MeshCollider>().sharedMesh=collision;if(owned.TryGetValue(key,out var old))foreach(var m in old)Destroy(m);owned[key]=new[]{mesh,collision};}
  void Remove(Cell k){if(chunks.TryGetValue(k,out var go)){Destroy(go);chunks.Remove(k);}if(owned.TryGetValue(k,out var meshes)){foreach(var m in meshes)Destroy(m);owned.Remove(k);}dirty.Remove(k);}
  void OnDestroy(){disposed=true;if(World!=null)World.Changed-=OnEdit;foreach(var k in chunks.Keys.ToArray())Remove(k);jobs.Clear();}
 }
}
