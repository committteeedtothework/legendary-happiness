Shader "DCSMCRAFT/VoxelLit" {
 Properties { _BaseMap("Atlas",2D)="white"{} _BaseColor("Tint",Color)=(1,1,1,1) _Cutoff("Cutout",Range(0,1))=.2 _Alpha("Alpha",Range(0,1))=1 _SrcBlend("Source blend",Float)=1 _DstBlend("Destination blend",Float)=0 _ZWrite("Depth write",Float)=1 }
 SubShader { Tags{"RenderPipeline"="UniversalPipeline" "RenderType"="Opaque"} Pass { Name "ForwardLit" Tags{"LightMode"="UniversalForward"} Blend [_SrcBlend] [_DstBlend] ZWrite [_ZWrite]
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
 #pragma multi_compile _ _ADDITIONAL_LIGHTS
 #pragma multi_compile_fragment _ _SHADOWS_SOFT
 #pragma multi_compile_fog
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
 TEXTURE2D(_BaseMap);SAMPLER(sampler_BaseMap);
 CBUFFER_START(UnityPerMaterial)
 float4 _BaseMap_ST;half4 _BaseColor;half _Cutoff,_Alpha;
 CBUFFER_END
 struct Attributes{float4 positionOS:POSITION;float3 normalOS:NORMAL;float2 uv:TEXCOORD0;half4 color:COLOR;};
 struct Varyings{float4 positionCS:SV_POSITION;float3 positionWS:TEXCOORD0;half3 normalWS:TEXCOORD1;float2 uv:TEXCOORD2;half emission:TEXCOORD3;half fog:TEXCOORD4;half sky:TEXCOORD5;};
 Varyings vert(Attributes i){Varyings o;VertexPositionInputs p=GetVertexPositionInputs(i.positionOS.xyz);o.positionCS=p.positionCS;o.positionWS=p.positionWS;o.normalWS=TransformObjectToWorldNormal(i.normalOS);o.uv=TRANSFORM_TEX(i.uv,_BaseMap);o.emission=i.color.r;o.sky=i.color.g;o.fog=ComputeFogFactor(p.positionCS.z);return o;}
 half4 frag(Varyings i):SV_Target{half4 albedo=SAMPLE_TEXTURE2D(_BaseMap,sampler_BaseMap,i.uv)*_BaseColor;clip(albedo.a-_Cutoff);half3 n=normalize(i.normalWS);Light sun=GetMainLight(TransformWorldToShadowCoord(i.positionWS));half3 lit=SampleSH(n)*i.sky+sun.color*saturate(dot(n,sun.direction))*sun.shadowAttenuation*i.sky;
 #ifdef _ADDITIONAL_LIGHTS
 uint count=GetAdditionalLightsCount();for(uint index=0;index<count;index++){Light l=GetAdditionalLight(index,i.positionWS);lit+=l.color*saturate(dot(n,l.direction))*l.distanceAttenuation*l.shadowAttenuation;}
 #endif
 half3 color=albedo.rgb*(max(lit,half3(.015,.015,.02))+i.emission*1.2);return half4(MixFog(color,i.fog),albedo.a*_Alpha);}
 ENDHLSL
 } UsePass "Universal Render Pipeline/Lit/ShadowCaster"
 }
}
