using System;
using DCSMCRAFT.Core;
using UnityEngine;
namespace DCSMCRAFT.Unity {
 public sealed class NativeDrop : MonoBehaviour {
  public NativeGame Game;public Stack Stack;public float Age;Material material;GameObject art;
  public async void Initialize(NativeGame game,Stack stack,float age=0){Game=game;Stack=stack;Age=age;var rigid=gameObject.AddComponent<Rigidbody>();rigid.mass=.1f;var collision=gameObject.AddComponent<SphereCollider>();collision.radius=.14f;try{string file="Weapons/"+stack.id+".glb";if(System.IO.File.Exists(System.IO.Path.Combine(game.Assets.Root,file))){art=await game.Assets.Model(file,transform);if(!this)return;art.transform.localScale=Vector3.one*.35f;}else{art=GameObject.CreatePrimitive(PrimitiveType.Quad);Destroy(art.GetComponent<Collider>());art.transform.SetParent(transform,false);art.transform.localScale=Vector3.one*.35f;var item=game.Catalog.Items[stack.id];material=new Material(Shader.Find("Universal Render Pipeline/Unlit"));material.EnableKeyword("_ALPHATEST_ON");material.SetFloat("_Cull",0);material.SetFloat("_AlphaClip",1);material.SetFloat("_Cutoff",.2f);material.mainTexture=game.Assets.Texture("Art/icons-"+game.PackName+".png");float rows=(float)Math.Ceiling(game.Catalog.Data.items.Length/32.0);material.mainTextureScale=new Vector2(1/32f,1/rows);material.mainTextureOffset=new Vector2(item.icon%32/32f,1-(item.icon/32+1)/rows);art.GetComponent<Renderer>().sharedMaterial=material;}}catch(OperationCanceledException){}catch(Exception e){if(this)game.Error=e.Message;}}
  void Update(){if(!Game||Game.InArena||Game.Paused)return;Age+=Time.deltaTime;if(Age>300){Destroy(gameObject);return;}if(art&&material&&Game.Player)art.transform.LookAt(Game.Player.View.transform);if(Age>.65f&&Game.Player&&Vector3.Distance(Game.Player.transform.position+Vector3.up*.7f,transform.position)<1.5f){Stack.count=Game.Inventory.Add(Stack.id,Stack.count,Stack.durability);if(Stack.count<=0)Destroy(gameObject);}}
  void OnDestroy(){if(material)Destroy(material);}
 }
 public sealed partial class NativeGame {
  public void SpawnDrop(Stack stack,Vector3 position,float age=0){if(stack==null||stack.count<=0)return;var drop=new GameObject("Dropped "+stack.id);drop.transform.SetParent(worldRoot.transform);drop.transform.position=position;drop.AddComponent<NativeDrop>().Initialize(this,stack,age);}
 }
}
