using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
namespace DCSMCRAFT.Unity {
 public sealed class NativeBoneCollision : MonoBehaviour {
  readonly List<Collider> shapes=new List<Collider>();
  public void Build(GameObject model,float height){var bones=model.GetComponentsInChildren<SkinnedMeshRenderer>().SelectMany(r=>r.bones).Distinct().ToArray();foreach(var bone in bones){string name=bone.name.ToLowerInvariant();if(!new[]{"arm","leg","knee","elbow","spine","neck","tail","head","wing","shoulder","hip"}.Any(name.Contains)||new[]{"finger","needle","jaw","eye"}.Any(name.Contains))continue;foreach(Transform child in bone){if(!bones.Contains(child))continue;float length=Vector3.Distance(bone.position,child.position);if(length<height*.008f||length>height*3)continue;float radius=height*(name.Contains("spine")||name.Contains("hip")?.07f:name.Contains("head")?.07f:name.Contains("tail")?.012f:.022f);var go=new GameObject("Native limb collision");go.layer=9;go.transform.SetParent(bone,false);var local=child.localPosition;go.transform.localPosition=local*.5f;go.transform.localRotation=Quaternion.FromToRotation(Vector3.up,local.normalized);float scale=Mathf.Max(.00001f,Mathf.Abs(bone.lossyScale.x));var capsule=go.AddComponent<CapsuleCollider>();capsule.radius=radius/scale;capsule.height=Mathf.Max(capsule.radius*2,length/scale+capsule.radius*2);capsule.direction=1;capsule.contactOffset=.015f;shapes.Add(capsule);}}}
  public Vector3 Closest(Vector3 point,Vector3 fallback){float distance=float.PositiveInfinity;var best=fallback;foreach(var shape in shapes){if(!shape)continue;var q=shape.ClosestPoint(point);float d=(q-point).sqrMagnitude;if(d<distance){distance=d;best=q;}}return best;}
 }
}
