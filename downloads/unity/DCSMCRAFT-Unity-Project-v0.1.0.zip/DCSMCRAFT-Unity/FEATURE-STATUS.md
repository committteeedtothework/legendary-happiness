# Native Unity feature status

Status describes C# implementation, not successful Unity runtime verification. **No system has been playtested in Unity yet.** The source archive preserves the full browser game, independently of the native port.

| System | Native implementation | Remaining work |
|---|---|---|
| Data/content | All 2,625 block definitions, 1,125 items, 1,292 recipes, 39 mob definitions and 11 skins migrated; full original metadata retained | Port special behavior for most advanced blocks/items |
| World | Deterministic generation 1, height −64…319, six biomes, oceans, caves, ores, basic trees, Cinder terrain | Exact generation-16 parity, diverse caves, rivers/lakes, structures, villages, temples, mineshafts, full Cinder generation |
| Rendering | Chunk meshes, hidden-face removal, Unity frustum culling, two CPU mesh workers, nearby-first streaming, bounded uploads, collision meshes, three pixel-art packs | Unity profiling, distant LODs/occlusion, smooth streaming under fast travel, animated block/fluid materials |
| Lighting | Native block-light flood propagation, occlusion, neighbor chunk invalidation, separate skylight/emission shader inputs; core tested | Full skylight propagation, natural lava emission discovery, large-world lighting scalability, Unity shadow/shader verification |
| Movement | First/third person, walk/run/double-W sprint, Shift crouch, jump, gravity, collisions, basic swimming, Creative flight | Reference camera/physics parity, boats, precise shaped collision/movement behavior, complete controller menus/settings/presets, touch/mobile |
| Block interaction | DDA targeting, progressive hardness/tool-tier mining, drops, solid placement exclusion, static shape meshes | Orientation/state interactions, doors, stairs refinement, block updates, gravity blocks, flowing fluids, fire, explosions, redstone-like behavior |
| Inventory | Nine-slot hotbar, 36 slots, stack limits, consumption, pickups/drops, chest transfer, persistence | Armor/offhand/cursor drag/split/swap UI, durability use/equipment, full reference layout and recipes UI |
| Crafting/smelting | Atomic shaped/shapeless recipe engine with alternatives, grid matching, recipe-click crafting, native furnace/fuel/cooking | Actual 2×2/3×3 cursor crafting interface, advanced workstations, experience/enchantments/anvils/brewing/farming |
| Survival | Health/hunger, basic regeneration/starvation, oxygen/suffocation/fall damage, death drops and respawn | Saturation parity, armor/shield/projectiles/status effects, exact combat cooldowns/criticals, beds/spawn rules, difficulty |
| Creatures | 39 converted models available; basic wandering/chasing/fleeing/melee; initial wildlife, Creative eggs, saved entities | Full spawn/despawn rules, nighttime ecology, pathfinding, breeding, trading, villages/guardians/Golem/Watcher behaviors, bosses outside Titans |
| Environment | Day/night lighting, Cinder terrain generator exists | Weather, snow/tornadoes, fishing, renewable ecology, full dimension portals and survival progression |
| Audio | Original files retained; native streamed music, explicit phase cue regions, dual DSP-scheduled sources, pause and stale-request cancellation | Positional SFX/events, full soundscape, playlist sequencing/fades, Unity device/pause/latency tests |
| Character art | 11 skin GLBs with two simple native locomotion clips each, 39 mob GLBs, 61 tool/weapon GLBs, all icons and packs | Complete held/third-person animations, skin preview, armor fit, bow draw/projectiles, custom weapons/stands and their mechanics |
| Giganto | Actual model/36 clips migrated; native arena prototype with objective/transform/two phases, basic swing/slap/stomp/beam, parry/dodge/homing/melee/Boom, victory/retry/return/reward ledger | Complete current choreography, ascent, cinematic QTEs/finishers, advanced moves/combos, polished camera/UI, precise hitboxes, VFX and audio synchronization |
| Wyvern | Actual model/11 clips migrated; native flight arena prototype with missiles/parry/homing, two phases, victory/retry/return | Tower/traversal rails, varied canyon chase, full missile/finger-flick/counters/QTE choreography, natural rig constraints and full boss moveset |
| Sonic/Super Sonic | Actual rig and 53 source clips migrated; native run/jump/flight/basic attack playback, simple gold material/morph transformation; no energy meter | Accurate full Super rig/quills/materials, all relevant moves/counters/cinematics, blending/contact/collision polish |
| Automation | Original source/data preserved | Native circuits, pistons, observers, hoppers, comparators, dispensers, tick-accurate transfers |
| Saves | Separate checksummed format with backup/interrupted-save recovery; edits, inventory, containers, furnaces, mobs/drops and Titan reward ledger | Browser save import, full simulation state, multiple-world selection/migration |
| UI/controls | Native title/new/load/options/pause, inventory/chest/furnace/recipe/Creative prototype, three quality levels | Full menu parity, arena-only settings/HUD polish, controller glyphs/presets, mobile UI/accessibility |
| Networking | Original relay/server/client source preserved | Native networking, authoritative world simulation, public relay, chat/commands, anti-duplication/concurrency testing |
| Distribution | Separate source/assets archives, pinned dependencies, Windows CLI scripts | Unity compilation and import verification, actual native Windows EXE, installers/signing, Android/iOS/WebGL builds |

The browser version remains the complete playable baseline. “Preserved” means recoverable source/assets, not an embedded browser renderer or a completed native system. The new C# runtime does not launch Electron, Chromium, Three.js, or the browser game.
