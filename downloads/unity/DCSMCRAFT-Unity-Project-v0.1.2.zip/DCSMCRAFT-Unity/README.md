# DCSMCRAFT Unity — migration foundation (build repair package 0.1.2)

This is a **separate, unfinished native Unity port** of browser build 2.16.0. It does not replace the browser, Windows wrapper, or mobile versions. All 893 original source/asset files are preserved byte-for-byte. Native C# systems and a Unity runtime have been written, but Unity Editor compilation, playtesting, and a Windows executable are **not yet verified**.

The full game has not been ported. Converted catalogs, models, and clips do not imply that their behaviors are implemented. See [FEATURE-STATUS.md](FEATURE-STATUS.md) before using this as a replacement game.

Existing project? Use the automatic repair in [LAUNCHER-FIX.md](LAUNCHER-FIX.md) instead of downloading unchanged assets again.

## Open or build on Windows 10/11

1. Install Unity Hub and **Unity Editor 6000.0.62f1**, with Windows Build Support. Activate an eligible Unity license through Hub.
2. Extract `DCSMCRAFT-Unity-Project-v0.1.2.zip`. Keep the matching Media and Models-Art ZIPs beside the resulting `DCSMCRAFT-Unity` folder, or let the restore script download them using its pinned HTTPS links.
3. Double-click **Build-Windows.cmd**. The script verifies/restores asset checksums and invokes the Editor in batch mode. A successful build produces `Builds/Windows/DCSMCRAFT-Unity.exe`; its adjacent data folder is required.
4. To inspect first: run `tools/Build-Windows.ps1 -Target EditorCheck`, add the project in Unity Hub, then choose **DCSMCRAFT → Open game scene** and enter Play mode.

If compilation or package resolution fails, inspect `BuildLogs/Unity.log`. This package has not passed a Unity Editor build here. The build script reports success only when the Editor actually produces the requested output. No precompiled executable is included.

[BUILDING.md](BUILDING.md) · [FEATURE-STATUS.md](FEATURE-STATUS.md) · [GRAPHICS-STATUS.md](GRAPHICS-STATUS.md) · [VALIDATION.md](VALIDATION.md) · [MIGRATION.md](MIGRATION.md)

## Native prototype controls

WASD move; mouse look; Space jump; Shift crouch/descend; Ctrl sprint/boost; double W sprint; left/right mouse mine/place; 1–9/scroll hotbar; E inventory/interact with nearby Titan portal; Q drop; F Creative flight; F5 third person; Escape pause. Right-click food to eat. Click recipes to craft with held materials; shift-click inventory slots to transfer to an open chest. Native crafting UI is simplified.

Arena: collect rings and the final Emerald, then fly with Space/Shift. Left mouse attack, right mouse parry, Q dodge, X physical Homing Attack, R Sonic Boom. These are prototype moves, not the complete current browser fights. Return through the victory portal or use Return in pause/defeat. Xbox-style movement/button input is present; complete controller menus, presets/glyphs and mobile touch are not ported.

Unity saves are separate: `Application.persistentDataPath/UnityWorlds/world.dcu`. Native generation 1 differs from browser generation 16. Existing browser saves cannot be imported yet; they remain untouched.

Assets retain their original notices. Imported Sonic/Titan assets and user-supplied music are not newly licensed by this migration. Review their original permissions before broader redistribution or commercial use. No paid generation service was used.
