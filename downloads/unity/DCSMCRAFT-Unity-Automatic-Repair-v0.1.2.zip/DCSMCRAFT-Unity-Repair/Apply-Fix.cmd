@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Apply-Fix.ps1" %*
set "DCSMCRAFT_REPAIR_EXIT=%ERRORLEVEL%"
if not "%DCSMCRAFT_REPAIR_EXIT%"=="0" echo Repair failed. Read the message above.
pause
exit /b %DCSMCRAFT_REPAIR_EXIT%
