param([string]$UnityEditor,[ValidateSet('Windows','EditorCheck')][string]$Target='Windows')
$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
if (-not $UnityEditor) { $UnityEditor=$env:UNITY_EDITOR }
if (-not $UnityEditor -and ${env:ProgramFiles}) { $UnityEditor=Join-Path ${env:ProgramFiles} 'Unity\Hub\Editor\6000.0.62f1\Editor\Unity.exe' }
if (-not $UnityEditor -or -not (Test-Path -LiteralPath $UnityEditor -PathType Leaf)) { throw 'Unity 6000.0.62f1 was not found. Install/activate it in Unity Hub, or pass -UnityEditor C:\path\Unity.exe.' }
$UnityEditor=(Resolve-Path -LiteralPath $UnityEditor).Path
$manifestPath=Join-Path $project 'Packages\manifest.json'
$editorScript=Join-Path $project 'Assets\DCSMCRAFT\Editor\BuildCli.cs'
$projectManifest=Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($projectManifest.dependencies.PSObject.Properties.Name -contains 'com.unity.modules.inputlegacy') { throw 'The build repair is incomplete: Packages/manifest.json still requests the invalid inputlegacy package. Run Apply-Fix.cmd from the repair download.' }
if ((Get-Content -LiteralPath $editorScript -Raw) -match 'public\s+uint\s+errors\s*;') { throw 'The build repair is incomplete: BuildCli.cs still contains the unsigned build-error field. Run Apply-Fix.cmd from the repair download.' }
& (Join-Path $PSScriptRoot 'Restore-Assets.ps1')
$logs=Join-Path $project 'BuildLogs';New-Item -ItemType Directory -Force $logs | Out-Null
$method=if ($Target -eq 'EditorCheck') {'DCSMCRAFT.Editor.BuildCli.CheckProject'} else {'DCSMCRAFT.Editor.BuildCli.BuildWindows'}
$log=Join-Path $logs 'Unity.log'
$failureLog=Join-Path $logs 'BuildFailure.txt'
if(Test-Path -LiteralPath $failureLog){Remove-Item -LiteralPath $failureLog}
$output=if ($Target -eq 'EditorCheck') {Join-Path $project 'Verification\unity-editor-check.json'} else {Join-Path $project 'Builds\Windows\DCSMCRAFT-Unity.exe'}
$receipt=if ($Target -eq 'EditorCheck') {$output} else {Join-Path $project 'Verification\unity-build.json'}
# A previous executable/receipt must never make this invocation look successful.
foreach($previous in @($log,$receipt)) {
 if(Test-Path -LiteralPath $previous) { Move-Item -LiteralPath $previous -Destination ($previous+'.previous') -Force }
}
function Show-UnityFailure {
 if (Test-Path -LiteralPath $log) {
  Write-Host "Unity log: $log"
  $logErrors=Select-String -LiteralPath $log -Pattern 'error CS[0-9]+|error [A-Z]+[0-9]+|Project has invalid dependencies|cannot be found|error occurred while resolving packages|Aborting batchmode|Another Unity instance|Failed to (activate|load|resolve)|No valid Unity Editor license' | Select-Object -First 12
  foreach($match in $logErrors) {Write-Host $match.Line}
  $tail=Get-Content -LiteralPath $log -Tail 100
  $report=@("Project: $project","Editor: $UnityEditor","Target: $Target","Log: $log",'')+@($logErrors | ForEach-Object {$_.Line})+@('','--- latest log tail ---')+@($tail)
  $report | Set-Content -LiteralPath $failureLog -Encoding UTF8
  $tail | ForEach-Object {Write-Host $_}
  Write-Host "Build details saved to $failureLog"
 } else { $message="Unity did not create a log at $log.";Write-Host $message;@("Project: $project","Editor: $UnityEditor","Target: $Target",$message) | Set-Content -LiteralPath $failureLog -Encoding UTF8 }
}
# Explicit quotes are necessary: Start-Process joins ArgumentList with spaces.
# Windows GUI applications do not reliably populate PowerShell's LASTEXITCODE.
$arguments=@('-batchmode','-nographics','-quit','-projectPath',('"{0}"' -f $project),'-executeMethod',$method,'-logFile',('"{0}"' -f $log))
Write-Host 'Starting Unity. Keep this window open until the build finishes.'
try { $process=Start-Process -FilePath $UnityEditor -ArgumentList $arguments -WorkingDirectory $project -Wait -PassThru }
catch { Show-UnityFailure;throw "Could not start Unity: $($_.Exception.Message). Editor: $UnityEditor" }
if ($null -eq $process -or $null -eq $process.ExitCode) { Show-UnityFailure;throw "Unity finished without a readable process exit code. See $log" }
$unityExitCode=[int]$process.ExitCode
if ($unityExitCode -ne 0) { Show-UnityFailure;throw "Unity exited with code $unityExitCode. See $log" }
if (-not (Test-Path -LiteralPath $receipt -PathType Leaf) -or -not (Test-Path -LiteralPath $output -PathType Leaf)) { Show-UnityFailure;throw "Unity exited with code 0 but did not complete the requested $Target build. See $log" }
try { $result=Get-Content -LiteralPath $receipt -Raw | ConvertFrom-Json }
catch { Show-UnityFailure;throw "Unity produced an unreadable build receipt. See $log" }
$valid=if ($Target -eq 'EditorCheck') {$result.editorCompilation -eq $true -and $result.dataValidation -eq $true} else {$result.result -eq 'Succeeded' -and $null -ne $result.errors -and $result.errors -eq 0}
if (-not $valid) { Show-UnityFailure;throw "Unity did not report a successful $Target build. See $log" }
Write-Host "Completed: $output"
