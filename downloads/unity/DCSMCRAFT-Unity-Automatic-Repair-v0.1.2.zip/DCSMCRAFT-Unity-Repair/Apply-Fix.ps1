param([string]$ProjectPath)
$ErrorActionPreference='Stop'
function Test-GameProject([string]$Path) {
 if(-not $Path){return $false}
 return ((Test-Path -LiteralPath (Join-Path $Path 'ProjectSettings\ProjectVersion.txt') -PathType Leaf) -and (Test-Path -LiteralPath (Join-Path $Path 'Assets\DCSMCRAFT\Runtime\NativeGame.cs') -PathType Leaf) -and (Test-Path -LiteralPath (Join-Path $Path 'Packages\manifest.json') -PathType Leaf))
}
if(-not $ProjectPath) {
 $downloads=Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Downloads'
 $candidates=@()
 foreach($relative in @('DCSMCRAFT-Unity-Project-v0.1.0\DCSMCRAFT-Unity','DCSMCRAFT-Unity-Project-v0.1.1\DCSMCRAFT-Unity','DCSMCRAFT-Unity-Project-v0.1.2\DCSMCRAFT-Unity','DCSMCRAFT-Unity')) {
  $candidate=Join-Path $downloads $relative;if(Test-GameProject $candidate){$candidates+=@($candidate)}
 }
 if($candidates.Count -eq 1){$ProjectPath=$candidates[0]}
 else {
  Add-Type -AssemblyName System.Windows.Forms
  $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
  $dialog.Description='Select your existing DCSMCRAFT-Unity project (contains Assets, Packages and ProjectSettings).'
  $dialog.ShowNewFolderButton=$false
  if($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){throw 'Repair cancelled; no files were changed.'}
  $ProjectPath=$dialog.SelectedPath
 }
}
if(-not (Test-GameProject $ProjectPath)){throw 'Select the existing DCSMCRAFT-Unity project folder, containing Assets, Packages and ProjectSettings. No files were changed.'}
$ProjectPath=(Resolve-Path -LiteralPath $ProjectPath).Path
$lock=Join-Path $ProjectPath 'Temp\UnityLockfile'
if(Test-Path -LiteralPath $lock) {
 try {$handle=[IO.File]::Open($lock,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$handle.Dispose()}
 catch {throw 'Close Unity Editor for this project before applying the repair. No files were changed.'}
}
$manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'repair-files.json') -Raw | ConvertFrom-Json
$allowed=@('Build-Windows.cmd','tools/Build-Windows.ps1','Packages/manifest.json','Assets/DCSMCRAFT/Editor/BuildCli.cs')
if($manifest.files.Count -ne $allowed.Count -or @($manifest.files.path | Select-Object -Unique).Count -ne $allowed.Count){throw 'Invalid repair package.'}
# Verify the complete payload before changing any project file.
foreach($file in $manifest.files) {
 if($allowed -cnotcontains $file.path){throw "Unexpected repair path: $($file.path)"}
 $source=Join-Path (Join-Path $PSScriptRoot 'payload') $file.path
 if(-not (Test-Path -LiteralPath $source -PathType Leaf) -or (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file.sha256){throw "Repair payload is missing or corrupt: $($file.path). No files were changed."}
}
$backup=Join-Path $ProjectPath ('.buildfix-backups\v0.1.2\'+[Guid]::NewGuid().ToString('N'))
foreach($file in $manifest.files) {
 $target=Join-Path $ProjectPath $file.path
 if(Test-Path -LiteralPath $target){$saved=Join-Path $backup $file.path;New-Item -ItemType Directory -Force (Split-Path $saved -Parent) | Out-Null;Copy-Item -LiteralPath $target -Destination $saved}
}
try {
 foreach($file in $manifest.files) {
  $target=Join-Path $ProjectPath $file.path
  New-Item -ItemType Directory -Force (Split-Path $target -Parent) | Out-Null
  Copy-Item -LiteralPath (Join-Path (Join-Path $PSScriptRoot 'payload') $file.path) -Destination $target -Force
  if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file.sha256){throw "Installed file did not verify: $($file.path)"}
 }
}catch{
 foreach($file in $manifest.files){$saved=Join-Path $backup $file.path;if(Test-Path -LiteralPath $saved){Copy-Item -LiteralPath $saved -Destination (Join-Path $ProjectPath $file.path) -Force}}
 throw
}
$verification=Join-Path $ProjectPath 'Verification';New-Item -ItemType Directory -Force $verification | Out-Null
@{version='0.1.2';project=$ProjectPath;backup=$backup;files=$manifest.files} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $verification 'build-repair-v0.1.2.json') -Encoding UTF8
Write-Host "Repair applied and verified: $ProjectPath"
Write-Host "Previous files saved in: $backup"
Write-Host 'Now double-click Build-Windows.cmd in that project folder, with Unity Editor closed.'
