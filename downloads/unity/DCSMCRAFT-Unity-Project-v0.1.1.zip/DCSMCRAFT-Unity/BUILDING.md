# Build and dependencies

Target: Windows 10/11 x86-64. Project version: 0.1.0 native migration foundation. Browser source baseline: 2.16.0. Exact reference metadata is preserved in `catalog.json`: Java Edition 26.3 content with custom survival mechanics.

Install/activate Unity Editor **6000.0.62f1 (f99f05b3e950)** and Windows Build Support in Unity Hub. Unity licenses must meet your eligibility; this project does not activate, bypass or supply a license. Internet is required for first-time package and optional asset downloads. Once restored, this desktop project does not need a local web server.

Pinned Package Manager dependencies:

| Package | Version |
|---|---|
| Universal Render Pipeline | 17.0.4 |
| Input System | 1.11.2 |
| Unity glTFast | 6.20.0 |

Their transitive dependencies are resolved by Unity Package Manager; no Unity-generated `packages-lock.json` is fabricated before a real Editor import. The glTFast 6.20.0 package's actual API and Unity 6000.0 compatibility metadata were inspected. All converted native GLBs use embedded PNG images and plain buffers.

From PowerShell in the project:

```powershell
.\tools\Restore-Assets.ps1
.\tools\Build-Windows.ps1 -Target EditorCheck
.\tools\Build-Windows.ps1 -Target Windows
# Optional custom installation:
.\tools\Build-Windows.ps1 -UnityEditor 'D:\Unity\6000.0.62f1\Editor\Unity.exe'
```

`Build-Windows.cmd` runs the Windows target. Unity writes `BuildLogs/Unity.log`, `Verification/unity-editor-check.json` only after a successful Editor check, and `Verification/unity-build.json` with the real build result. Successful native output is `Builds/Windows/DCSMCRAFT-Unity.exe` plus its adjacent files. None of those Editor success records or executables are included in this delivery.

The batch methods prepare the URP asset/renderer and Main scene, enable both input backends, include runtime glTF shaders, validate data and invoke BuildPipeline. A platform module/license/package/compiler error must be resolved before a game binary exists. The Editor menus also expose Prepare project and Open game scene.

On Linux with an appropriately installed/licensed Editor and Windows support, restore both asset archives and run `UNITY_EDITOR=/path/to/Unity ./tools/build-unity.sh`. PowerShell Core can run Restore-Assets.ps1; alternatively extract the two archives into the project parent folder (they share the `DCSMCRAFT-Unity/` root).

## Independent core checks

Python 3 and .NET SDK 8 are needed only for these optional tests, not for normal Unity builds:

```text
python tools/test-core.py --dotnet /path/to/dotnet
python tools/check-csharp-syntax.py --dotnet /path/to/dotnet
python tools/validate-project.py
```

The first script compiles only the engine-independent C# core through Roslyn and runs it. The syntax check parses all C# files but does not resolve Unity APIs or compile shaders. These tests cannot replace Editor compilation/PlayMode tests.

To regenerate exports from the preserved browser source, restore its npm dependencies, use Node 24 and Playwright/Chromium, then run `tools/migrate-data.mjs /path/to/browser-source` and `tools/export-art.mjs /path/to/browser-source`. These developer scripts read the browser source without editing it. Use an external writable cache (`DCSMCRAFT_UNITY_CACHE`) for export bundles.

## Launcher package 0.1.1

See [LAUNCHER-FIX.md](LAUNCHER-FIX.md). The Windows launcher now waits for the Unity process and reads its exit code directly, prints actual Unity diagnostics, and requires fresh successful build receipts. Native gameplay and asset bundles remain version 0.1.0.
