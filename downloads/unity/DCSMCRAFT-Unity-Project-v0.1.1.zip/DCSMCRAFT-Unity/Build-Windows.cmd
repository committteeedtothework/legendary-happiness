@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Build-Windows.ps1" %*
set "DCSMCRAFT_BUILD_EXIT=%ERRORLEVEL%"
if not "%DCSMCRAFT_BUILD_EXIT%"=="0" (
  echo Build failed. The Unity errors are shown above and in BuildLogs\Unity.log.
  pause
  exit /b %DCSMCRAFT_BUILD_EXIT%
)
echo Build completed. You can close this window.
pause
exit /b 0
