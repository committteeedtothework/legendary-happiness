#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using DCSMCRAFT.Core;
using DCSMCRAFT.Unity;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;
namespace DCSMCRAFT.Editor {
 public static class BuildCli {
  const string ScenePath="Assets/DCSMCRAFT/Scenes/Main.unity";const string PipelinePath="Assets/DCSMCRAFT/Settings/Universal.asset";
  [MenuItem("DCSMCRAFT/Prepare project")] public static void PrepareProject(){Directory.CreateDirectory("Assets/DCSMCRAFT/Scenes");Directory.CreateDirectory("Assets/DCSMCRAFT/Settings");
   AssetDatabase.Refresh();var pipeline=AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath);if(!pipeline){var renderer=ScriptableObject.CreateInstance<UniversalRendererData>();AssetDatabase.CreateAsset(renderer,"Assets/DCSMCRAFT/Settings/UniversalRenderer.asset");pipeline=UniversalRenderPipelineAsset.Create(renderer);pipeline.renderScale=1;pipeline.shadowDistance=140;pipeline.shadowCascadeCount=2;AssetDatabase.CreateAsset(pipeline,PipelinePath);}GraphicsSettings.defaultRenderPipeline=pipeline;QualitySettings.renderPipeline=pipeline;
   PlayerSettings.companyName="DCSMCRAFT";PlayerSettings.productName="DCSMCRAFT Unity";PlayerSettings.bundleVersion="0.1.0";PlayerSettings.defaultScreenWidth=1280;PlayerSettings.defaultScreenHeight=720;PlayerSettings.resizableWindow=true;PlayerSettings.runInBackground=false;PlayerSettings.colorSpace=ColorSpace.Linear;
   var settings=new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset")[0]);var input=settings.FindProperty("activeInputHandler");if(input!=null){input.intValue=2;settings.ApplyModifiedPropertiesWithoutUndo();}
   if(!File.Exists(ScenePath)){var previous=SceneManager.GetActiveScene();var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);SceneManager.SetActiveScene(scene);new GameObject("DCSMCRAFT").AddComponent<NativeGame>();EditorSceneManager.SaveScene(scene,ScenePath);EditorSceneManager.CloseScene(scene,true);if(previous.IsValid())SceneManager.SetActiveScene(previous);}
   EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(ScenePath,true)};IncludeShaders();AssetDatabase.SaveAssets();AssetDatabase.Refresh();Debug.Log("DCSMCRAFT Unity project prepared.");
  }
  static void IncludeShaders(){var graphics=AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset");if(graphics.Length==0)return;var data=new SerializedObject(graphics[0]);var shaders=data.FindProperty("m_AlwaysIncludedShaders");if(shaders==null)return;var candidates=AssetDatabase.FindAssets("t:Shader").Select(AssetDatabase.GUIDToAssetPath).Where(p=>p.Contains("com.unity.cloud.gltfast")||p.Contains("DCSMCRAFT")).Select(p=>AssetDatabase.LoadAssetAtPath<Shader>(p)).Where(s=>s!=null).Concat(new[]{Shader.Find("Universal Render Pipeline/Lit"),Shader.Find("Universal Render Pipeline/Unlit")}).Where(s=>s!=null).Distinct();foreach(var shader in candidates){bool present=false;for(int i=0;i<shaders.arraySize;i++)if(shaders.GetArrayElementAtIndex(i).objectReferenceValue==shader)present=true;if(!present){int n=shaders.arraySize;shaders.InsertArrayElementAtIndex(n);shaders.GetArrayElementAtIndex(n).objectReferenceValue=shader;}}data.ApplyModifiedPropertiesWithoutUndo();}
  [MenuItem("DCSMCRAFT/Open game scene")] public static void OpenScene(){PrepareProject();if(EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())EditorSceneManager.OpenScene(ScenePath);}
  public static void CheckProject(){try{PrepareProject();ValidateData();Directory.CreateDirectory("Verification");File.WriteAllText("Verification/unity-editor-check.json","{\"editorCompilation\":true,\"dataValidation\":true,\"playModeTested\":false}");EditorApplication.Exit(0);}catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
  static void ValidateData(){var catalogPath="Assets/StreamingAssets/Migrated/catalog.json";if(!File.Exists(catalogPath))throw new FileNotFoundException("Run tools/Restore-Assets.ps1 before building.");var catalog=new Catalog(JsonUtility.FromJson<CatalogData>(File.ReadAllText(catalogPath)));foreach(string name in new[]{"Art/atlas-renewed.png","Art/icons-renewed.png","Authored/sonic.glb","Authored/giganto.glb","Authored/wyvern.glb"})if(!File.Exists("Assets/StreamingAssets/Migrated/"+name))throw new FileNotFoundException("Missing migrated asset: "+name);if(catalog.Items.Count!=1125||catalog.Data.blocks.Length!=2625)throw new InvalidDataException("The catalog is incomplete.");}
  public static void BuildWindows(){try{PrepareProject();ValidateData();if(!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Standalone,BuildTarget.StandaloneWindows64))throw new InvalidOperationException("Install Windows Build Support for this Unity Editor.");Directory.CreateDirectory("Builds/Windows");var report=BuildPipeline.BuildPlayer(new[]{ScenePath},"Builds/Windows/DCSMCRAFT-Unity.exe",BuildTarget.StandaloneWindows64,BuildOptions.Development);Directory.CreateDirectory("Verification");File.WriteAllText("Verification/unity-build.json",JsonUtility.ToJson(new BuildRecord{editor=Application.unityVersion,result=report.summary.result.ToString(),errors=report.summary.totalErrors,bytes=report.summary.totalSize},true));if(report.summary.result!=BuildResult.Succeeded)throw new Exception("Unity build failed; inspect BuildLogs/Unity.log.");Debug.Log("Windows build completed: Builds/Windows/DCSMCRAFT-Unity.exe");EditorApplication.Exit(0);}catch(Exception e){Debug.LogException(e);EditorApplication.Exit(1);}}
  [Serializable] class BuildRecord {public string editor,result;public int errors;public ulong bytes;}
 }
}
#endif
