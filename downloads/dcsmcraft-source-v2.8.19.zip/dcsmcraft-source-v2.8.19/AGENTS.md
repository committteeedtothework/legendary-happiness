# Current user scope

Only change the Giganto boss encounter unless the user explicitly authorizes
another area. The current authorized exception is restoring the earlier wool
and water textures. The latest user also explicitly authorizes correcting torch
lighting propagation, occlusion, chunk/mesh invalidation and stale illumination.
Keep other sandbox visuals, mechanics, saves, content and multiplayer behavior
unchanged. Arena graphics/audio/settings must stay isolated from the overworld.

Do not resume the unfinished AUDIT.md stages without a new user instruction
authorizing that work. Necessary builds, verification and documentation may
accompany an authorized change. Do not push, deploy or publish without approval.

The user also authorizes player-facing wording cleanup across the arena and
overworld. Keep text concise and use consistent game terminology. Avoid filler,
marketing slogans, implementation/debug details and redundant labels in menus.
Keep actionable controls, storage/connection failures, accessibility labels and
user-authored messages. Apply this wording preference to future additions.
