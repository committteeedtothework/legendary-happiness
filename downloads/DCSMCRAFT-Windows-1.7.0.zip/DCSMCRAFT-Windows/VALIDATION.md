# Validation record — DCSMCRAFT 1.7.0 Cave Update

Reference remains Minecraft Java Edition 1.20.4 with partial/missing mechanics listed in FEATURES.md. New Overworld terrain uses generator 12; saved generators 2–11 retain their original terrain. New caves/mineshafts/ore layout require a new world.

## Core checks

**350 core tests pass**, including 18 Cave Update cases. Coverage includes four seeded underground regions, deterministic negative chunk borders/generation order, bedrock preservation, natural mineshaft supports/rails/webs/clearance, chest loot remaining empty or broken after regeneration/reload, diamond rarity and height bounds, immediate placed/removed torch response, all four daytime cave hostiles, complete creature body clearance, exclusion distance/caps/modes/difficulty, and daylight spider aggression underground.

Watcher checks cover all damage kinds, no knockback/drops/XP/attacks, gaze and wall line of sight, a single laugh per sighting with cooldown, unseen stalking, rare natural appearance, saved rarity state, light retreat and Creative exclusions. Every one of the 24 eggs creates its real creature without consumption; Survival use, crafting, dropping, blocked placement and occupied placement are rejected. Sound samples remain finite, continuous across buffer boundaries and non-repeating. Cobweb slowing, thin rail geometry, roof/depth atmosphere detection, open-shaft/surface preservation and Cinderworld exclusion are verified. Existing movement, recipes, inventory, saving/recovery, fluids, Guardians, Cinderworld, pistols and Mad Titan cases remain passing.

Visual inspection also found blue sky at distant underground chunk boundaries. Caves now smoothly blend into dark fog and dimmer ambient light, with hidden sky objects. Surface/open-shaft and Cinderworld skies retain their existing behavior.

Fixes found during development include light near the player suppressing distant dark-passage spawning, a hardcoded multiplayer generation ceiling excluding new worlds, and a multiplayer laugh-state merge assuming an existing entity array. Torch suppression now applies at the candidate spawn point, guests accept the current supported generation, and new state merges tolerate an empty fixture. Rail targeting/outline bounds now match the thin rendered rail; egg-spawned villagers receive a working default farmer profession.

## Browser checks

**Six distinct selected browser scenarios pass** on the frozen build:

1. Exact standalone HTML with outside requests blocked: Creative egg search/catalog, real cow/zombie/Watcher/villager spawning without consumption, and Survival refusal.
2. A naturally generated Wildflower mineshaft: real chest inventory transfer followed by browser/world reload, preserving the empty chest and collected bread without duplication.
3. Daylight underground hostile spawning and a naturally selected Watcher; gaze-triggered laugh, no player harm, actual melee and pistol immunity, and real WebAudio cave/night target mixes. Only the saved rarity timer is accelerated; the production chance and valid-position checks select the encounter.
4. Four naturally generated cave regions rendered from clear positions, with screenshots and no checked WebGL/page errors.
5. Retained Guardian acquisition: Creative/Peaceful refusal, two real defeats and reload, the final defeat, Sigil approach and an actual uninterrupted 30-second sword extraction with unique persistence.
6. Actual HTTPS/WSS Survival relay: connection test, address persistence, invitation, guest generation adoption and existing synchronized chat/inventory/world interactions.

A separate direct file:// attempt is blocked by managed Chromium policy (`ERR_BLOCKED_BY_ADMINISTRATOR`) before the game loads; the test is marked skipped here and remains runnable on unrestricted desktops. The identical standalone HTML is verified over local HTTP with external requests blocked. This does not prove file-origin persistence on Windows.

The first new browser run exposed test-fixture API mistakes (calling nonexistent UI/inventory helpers and mixing ambience while paused); those fixtures were corrected. The final Watcher check was strengthened to require a real pistol trace intersecting its body, then rerun. Controlled positions, equipment and timers keep combat and encounters reproducible. This is not an unaided complete Survival playthrough, an audio listening review, exhaustive seed coverage, or a guarantee of no bugs. Creature/cave screenshots are visually inspected; audio is checked through PCM continuity/finite values and WebAudio wiring rather than a subjective listening claim.

## Build, compatibility and delivery

Production web assets, standalone HTML and Windows x64 launcher build successfully. The companion executable extractor's HTML matches the standalone byte-for-byte. Native Windows execution remains unverified on this Linux host; the shipped launcher uses installed Edge/Chrome.

Sixty sampled chunks in both dimensions across generators 2–11 are byte-identical to published 1.6.1. Three further generator-12 Cinderworld samples match the previous generator-11 terrain. These are representative compatibility checks, not an exhaustive comparison across seeds/chunks.

Runtime/build source hashes are frozen before browser checks and verified during packaging. ZIP CRCs, executable-embedded HTML, and SHA-256 checksums are checked before publication; public download bytes are verified again after uploading. Reports and checksums accompany the release. Historical PERFORMANCE.json measurements are labeled by their original versions; no new hardware FPS gain is claimed.

Lighting uses a conservative local bright-source approximation, including through walls; AI uses local steering rather than full dungeon pathfinding. Decorative rails have no carts, and cubic dripstone has no falling-spike mechanics. Natural cave spawning is centered around the host. Existing multiplayer dimension/hosting limits remain in MULTIPLAYER.md. Live Cloudflare tunneling, real YouTube playback, native Windows launch and every historical browser scenario were not repeated here.
