import {sonicJump} from './sonic-movement.js';
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
const state=s=>s.traversalKit ||= {dash:[],roll:0,slide:0,stomp:false,drop:false,dodge:0,combo:0,lastHit:-10};
export function sonicTraversalInput(s,action,targets=[],emit=()=>{}){
 if(s.stage!=='traversal'||s.emerald||s.climb?.attached)return false;
 const p=s.avatar,q=state(s),say=(name,duration)=>{s.action=name;s.actionTime=duration;q.actionDuration=duration;};
 if(action==='jump')return sonicJump(s,s.titan==='wyvern'?18:24);
 if(action==='target'){s.lock=!s.lock;return true;}
 if(action==='dodge'&&q.dodge<=0){q.dash=[];q.dodge=0.22;s.dodge=0.22;s.iframes=Math.max(s.iframes,0.22);say('dodge',0.3);return true;}
 if(action==='stomp'&&!p.onGround){q.stomp=true;q.dash=[];p.vy=-55;say('stomp',0.8);return true;}
 if(action==='spin'){q.dropKey=true;q.drop=!p.onGround;q.roll=p.onGround?0.9:0;say('spin',0.9);return true;}
 if(action==='shot'&&p.onGround){q.slide=0.7;say('slide',0.7);return true;}
 if(action==='hit'&&s.time-q.lastHit>0.18){q.combo=(q.combo+1)%3;q.lastHit=s.time;say('hit',0.32);return true;}
 if(action==='homing'||action==='boom'){
  if(q.dash.length)return false;
  const list=targets.map((t,i)=>({t,i,d:distance(t,p),dot:-(t.x-p.x)*Math.sin(p.yaw)-(t.z-p.z)*Math.cos(p.yaw)})).filter(v=>v.d>2&&v.d<65&&v.dot>-4).sort((a,b)=>a.d-b.d);
  if(!list.length){if(action==='boom')return false;q.dash=[{x:p.x-Math.sin(p.yaw)*14,y:p.y+1,z:p.z-Math.cos(p.yaw)*14}];}
  else {const first=list[0];q.dash=action==='boom'?targets.slice(first.i,first.i+14).map(v=>({...v})).filter(t=>distance(p,t)<85):[{...first.t}];}
  q.age=0;q.totalAge=0;q.stomp=false;p.onGround=false;say('homing',1);s.jumpAge=0;emit('homing');return true;
 }
 return false;
}
export function applySonicTraversal(s,input,dt,emit=()=>{}){
 if(s.stage!=='traversal'||s.emerald)return 1;
 const p=s.avatar,q=state(s);
 if(!q.dropKey&&!p.onGround)q.drop=s.airJumps===1&&input.up&&s.jumpAge>0.18;
 q.dodge=Math.max(0,q.dodge-dt);
 if(q.dash.length){q.totalAge=(q.totalAge||0)+dt;if(q.totalAge>1.1)q.dash=[];}
 if(q.dash.length){q.age=(q.age||0)+dt;const target=q.dash[0],d=distance(p,target);
  if(d<2.5||q.age>0.45){q.dash.shift();q.age=0;}
  else {const speed=Math.min(95,d/dt);p.vx=(target.x-p.x)/d*speed;p.vy=(target.y-p.y)/d*speed;p.vz=(target.z-p.z)/d*speed;s.action='homing';s.actionTime=0.15;p.onGround=false;return 0;}
 }
 if(input.boost&&q.stomp){q.stomp=false;p.vy=Math.max(0,p.vy);}
 if(q.stomp){p.vy=-55;s.action='stomp';s.actionTime=0.2;}
 if(q.drop&&p.onGround){q.drop=false;q.dropKey=false;q.roll=0.9;emit('impact',{point:{...p},strength:0.25});}
 if(q.stomp&&p.onGround){q.stomp=false;emit('impact',{point:{...p},strength:0.65});}
 for(const k of ['roll','slide']){q[k]=Math.max(0,q[k]-dt);if(q[k]>0){const heading=Number.isFinite(p.facingYaw)?p.facingYaw:p.yaw+Math.PI,speed=k==='roll'?52:34;p.vx=Math.sin(heading)*speed;p.vz=Math.cos(heading)*speed;s.action=k==='roll'?'spin':'slide';s.actionTime=0.15;}}
 if(q.dodge>0){const side=(input.moveX ?? +!!input.right-+!!input.left)||1;p.vx+=Math.cos(p.yaw)*side*28;p.vz-=Math.sin(p.yaw)*side*28;}
 if(input.parry){s.action='parry';s.actionTime=0.15;}
 if(input.hit)sonicTraversalInput(s,'hit',[],emit);
 return q.stomp?0:1;
}
export function restoreSonicTraversal(s,raw){
 const q=state(s),old=raw.traversalKit;
 if(!old)return;
 for(const k of ['roll','slide','dodge'])q[k]=Number.isFinite(old[k])?Math.max(0,Math.min(1,old[k])):0;
 q.drop=old.drop===true;q.stomp=old.stomp===true;
 q.dash=(Array.isArray(old.dash)?old.dash:[]).filter(p=>p&&['x','y','z'].every(k=>Number.isFinite(p[k])&&Math.abs(p[k])<4000)).slice(0,14).map(p=>({x:p.x,y:p.y,z:p.z}));
 q.age=Number.isFinite(old.age)?Math.max(0,Math.min(1.3,old.age)):0;
}
