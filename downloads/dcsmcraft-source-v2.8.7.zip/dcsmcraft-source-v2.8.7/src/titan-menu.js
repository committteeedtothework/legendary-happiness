import { TITAN_DAMAGE } from "./titan-combat.js";
const names = {
  basic: "Jab",
  combo: "Combo",
  heavy: "Heavy strike",
  finisher: "Combo finisher",
  boom: "Sonic Boom",
  rush: "Wild Rush",
  loop: "Cyloop",
  homing: "Homing attack",
  cross: "Cross Slash",
  counter: "Counter",
  perfectCounter: "Perfect counter",
  struggle: "Cinematic counter",
};
export function titanSettingsPanel(c, active, info) {
  const check = (k, name) =>
    `<label class="titan-check"><span>${name}</span><input type="checkbox" data-titan-config="${k}" ${c[k] ? "checked" : ""}></label>`;
  const select = (k, name, options) =>
    `<label><span>${name}</span><select data-titan-config="${k}">${options.map(([v, label]) => `<option value="${v}" ${c[k] === v ? "selected" : ""}>${label}</option>`).join("")}</select></label>`;
  const range = (k, name, min, max, step) =>
    `<label><span>${name} <output>${c[k]}</output></span><input type="${k === "drain" ? "number" : "range"}" min="${min}" max="${max}" step="${step}" value="${c[k]}" data-titan-config="${k}"></label>`;
  const group = (name, content) =>
    `<fieldset><legend>${name}</legend>${content}</fieldset>`;
  const combat = group(
    "Combat",
    select(
      "difficulty",
      "Difficulty",
      ["easy", "normal", "hard"].map((x) => [
        x,
        x[0].toUpperCase() + x.slice(1),
      ]),
    ) +
      range("drain", "Ring drain", 0, 3, 0.1) +
      range("rings", "Ring capacity", 100, 999, 1) +
      range("healthMultiplier", "Boss health", 0.5, 2, 0.1) +
      check("strictParry", "Timed parry") +
      check("checkpoints", "Checkpoints") +
      check("cinematics", "Cinematics"),
  );
  const visual = group(
    "Graphics",
    select("graphicsQuality", "Quality", [
      ["auto", "Match world"],
      ["low", "Low"],
      ["balanced", "Balanced"],
      ["high", "High"],
    ]) +
      select("shadowQuality", "Shadows", [
        ["auto", "Match world"],
        ["off", "Off"],
        ["low", "Soft · 1024"],
        ["high", "Soft · 2048"],
      ]) +
      check("postProcessing", "Bloom & tone mapping") +
      check("motionBlur", "Speed blur") +
      check("speedTrails", "Speed trails") +
      check("particles", "Particles") +
      check("lighting", "Dynamic lighting"),
  );
  const sound = group(
    "Audio",
    check("audio", "Sound") +
      check("music", "Music") +
      range("masterVolume", "Master volume", 0, 1, 0.01) +
      range("musicVolume", "Music volume", 0, 1, 0.01) +
      range("effectsVolume", "Effects volume", 0, 1, 0.01),
  );
  const camera = group(
    "Camera",
    range("cameraFov", "Field of view", 45, 95, 1) +
      range("cameraSensitivity", "Sensitivity", 0.0005, 0.01, 0.0001) +
      range("cameraShake", "Camera shake", 0, 1, 0.05),
  );
  const tuning = `<details class="titan-tuning"><summary>Damage tuning</summary>${Object.entries(
    c.damage,
  )
    .map(
      ([k, v]) =>
        `<label><span>${names[k] || k}</span><input type="number" min="1" max="${TITAN_DAMAGE[k] * 3}" value="${v}" data-titan-damage="${k}"></label>`,
    )
    .join("")}</details>`;
  const portal = info.portal
    ? `Portal · X ${info.portal.x} / Y ${info.portal.y} / Z ${info.portal.z}`
    : `No signal${info.cooldown ? ` · ${info.cooldown}s` : ""}`;
  return `<main class="dialog titan-result titan-settings"><h2>${active ? "Battle settings" : "Titan Signals"}</h2>${active ? "" : `<p class="titan-signal">${portal}</p><p>Titan Sigils · ${info.sigils}</p>`}<div class="titan-config">${active ? visual + sound + camera + combat + tuning : group("Portals", check("enabled", "Natural portals") + range("spawnChance", "Spawn chance", 0, 1, 0.05) + range("cooldown", "Cooldown", 10, 7200, 10)) + combat}</div>${active ? `<details class="titan-control-guide"><summary>Controls</summary><p>WASD · Move | Mouse · Camera | Shift · Boost | Space / Ctrl · Rise / Fall</p><p>LMB · Combo / Counter | RMB · Parry | Q · Dodge | Tab · Target</p><p>X · Homing attack | R · Sonic Boom | F · Wild Rush | E · Cyloop | C · Cross Slash</p><p>Enter · Skip cinematic | Escape · Pause</p></details>` : ""}${!active && info.creative ? '<button class="secondary wide" data-titan="summon">Find nearby portal</button>' : ""}<button class="primary wide" data-titan="back">Done</button></main>`;
}
