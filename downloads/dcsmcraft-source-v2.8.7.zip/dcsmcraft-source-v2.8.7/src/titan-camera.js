import {
  point,
  closestSegment,
  distance,
  titanBodyRegions,
} from "./titan-contact.js";
function blocked(regions, focus, camera) {
  for (let i = 1; i <= 16; i++) {
    const u = i / 16,
      p = point(
        focus.x + (camera.x - focus.x) * u,
        focus.y + (camera.y - focus.y) * u,
        focus.z + (camera.z - focus.z) * u,
      );
    for (const r of regions) {
      if (r.axes) {
        const q =
          ((p.x - r.center.x) / (r.axes.x + 0.6)) ** 2 +
          ((p.y - r.center.y) / (r.axes.y + 0.6)) ** 2 +
          ((p.z - r.center.z) / (r.axes.z + 0.6)) ** 2;
        if (q < 1) return true;
      } else if (distance(p, closestSegment(p, r.a, r.b)) < r.r + 0.6)
        return true;
    }
  }
  return false;
}
export function titanCameraBlocked(s, camera) {
  return blocked(
    titanBodyRegions(s),
    point(s.avatar.x, s.avatar.y + 2.2, s.avatar.z),
    camera,
  );
}
export function clearTitanCamera(s, camera, clearance) {
  const p = s.avatar,
    focus = point(p.x, p.y + 2.2, p.z),
    regions = titanBodyRegions(s);
  if (!blocked(regions, focus, camera)) return { ...camera };
  const angle = Math.atan2(p.x, p.z + 7.5),
    target = Math.atan2(camera.x, camera.z + 7.5),
    delta = Math.atan2(Math.sin(target - angle), Math.cos(target - angle)),
    radius = Math.max(clearance + 8, Math.hypot(p.x, p.z + 7.5) + 14),
    preferred = Math.max(-0.95, Math.min(0.95, delta));
  for (const offset of [preferred, -preferred, 0, 0.55, -0.55]) {
    const candidate = point(
      Math.sin(angle + offset) * radius,
      Math.max(2.5, camera.y, p.y + 4),
      Math.cos(angle + offset) * radius - 7.5,
    );
    if (!blocked(regions, focus, candidate)) return candidate;
  }
  // Last resort: shorten the boom from Sonic's side of the obstruction.
  let last = point(focus.x, focus.y + 1.5, focus.z);
  for (let i = 1; i <= 16; i++) {
    const u = i / 16,
      candidate = point(
        focus.x + (camera.x - focus.x) * u,
        focus.y + (camera.y - focus.y) * u,
        focus.z + (camera.z - focus.z) * u,
      );
    if (blocked(regions, focus, candidate)) break;
    last = candidate;
  }
  if (Math.hypot(last.x, last.z) >= clearance) return last;
  // A transient attacking limb may cover the focus itself. Keep the camera
  // outside the giant rather than pulling it inside the mantle with Sonic.
  return point(
    Math.sin(angle + preferred) * radius,
    Math.max(2.5, camera.y, p.y + 4),
    Math.cos(angle + preferred) * radius - 7.5,
  );
}
