# Validation record — DCSMCRAFT 1.8.0 Forge & Motion

Reference remains Minecraft Java Edition 1.20.4 with partial/missing mechanics in FEATURES.md. This release changes original models and cosmetic animation. Generator 12, item/block IDs, recipes, stats and authoritative movement/combat/progression code are retained. Existing worlds receive the update without regeneration.

## Core checks

**361 core tests pass**, including 11 new model/animation cases. New checks cover all 42 weapon/tool silhouettes, finite vertex colours and transforms, thin geometry, bounded merged batches, dropped-size normalization, actual gold-grip metadata/pixels, raised Devin ridges, three stationary blade glints and Minimal-particle suppression. Distinct staged action curves settle to rest and remain visual only.

Each weapon keeps its grip in the articulated palm through attack/mining/use poses with armor. Swimming checks cover prone strokes, continuous stationary treading, full submersion near the floor, wading/Creative-flight exclusions, smooth land exit, hip-centered rotation, pause, held-item phase continuity and first-person phase consistency across 30/60/144 Hz. Validated co-op appearance flags/visual velocity are tested separately from authoritative physics.

All eight Cinderworld designs have distinct geometry, finite animated special poses, preserved collision heights, glowing rest materials and bounded batches. Added jaw/claw/cloak subassemblies initially exceeded the old Titan draw budget; batching each rigid joint group corrected this without raising the existing budget. A water playtest found swimming stopping near the bottom: the visual pose now also accepts full submersion, without changing water physics. Hip-centered rotation and accumulated stroke phase prevent position drift and phase jumps.

Published v1.7 pistol geometry, first-person fire poses and F5 player poses have matching fingerprints. The pistol model, audio, abilities and effects source files are byte-identical. Working block/door models have matching fingerprints. World, physics, simulation, inventory, equipment, relic, cave and hostile-combat source files are byte-identical. The planted Devin display shares the new held model, stays inside its existing target cell, respects Minimal particles, hides after claim/removal and leaves the extraction blocks intact.

## Browser playtests

**Eight selected browser scenarios pass** on the frozen build:

1. Exact standalone: generate all 42 held models, render representative weapon/tool families, inspect flint/steel's actual transparent hole and flat geometry, ignite ordinary ground with durability loss, drop it using Q, preserve ordinary blocks/pistols, then save/reload an edited world.
2. Actual sword-click damage; F5 staged weapon poses, attached elbow/palm grips, Minimal-particle suppression, and a naturally generated temple's matching planted Devin model. Deterministic animation phase is frozen for action screenshots.
3. Actual W movement through real water with existing fluid/body physics, first-person paddling, F5 prone swimming, continuous stationary treading and smooth land recovery.
4. Eight redesigned Cinderworld foe/neutral rigs in the actual dimension, special-pose rendering and glowing material restoration after a damage flash.
5. Retained pistol palm sockets, independent recoil, F5, particle controls and item swaps.
6. Flint ignition and actual portal entry, linked Cinderworld return, realm saves and persistent reload.
7. All-Guardians sword requirement: Creative/Peaceful refusal, real defeats across reload, Sigil attunement, the actual 30-second held-mouse extraction and a unique persistent sword.
8. Actual HTTPS/WSS Survival relay, invitation, synchronized chat/inventory/world interactions and rendered co-op player appearances.

New model/cinder/swim screenshots are visually inspected. Creature positions, gear, target health, animation phases and portal/Guardian fixtures are controlled for reproducibility; this is not an unaided complete Survival playthrough or a guarantee of no bugs. The first visual pass exposed the bottom-of-pool pose gap and the new joint batching budget issue; both are fixed. One final test initially expected durability loss in Creative; its fixture was corrected to verify Creative keeps 64 uses and Survival ignition consumes one, without changing gameplay. The corrected scenario was rerun against the identical frozen build. Tests exercise production input, rendering, physics and inventory/save paths. Every historical browser scenario was not repeated.

## Compatibility and builds

Sixty-six sampled chunks across generators 2–12 and both dimensions are byte-identical to published v1.7.0, as are 22 accumulated container snapshots. Block/item definitions, recipes, mob stats, Creative catalogs and generation version compare equal. Thirteen relevant gameplay/pistol source files have identical SHA-256 values. These are representative terrain samples, not exhaustive proof across all seeds/chunks. The versioned compatibility report includes comparisons and fingerprints.

The production web build, self-contained HTML and Windows x64 executable build successfully. The companion extractor yields HTML identical to the standalone; the PE embeds the same bytes. Runtime/build inputs are frozen before browser tests and rechecked before packaging. ZIP CRCs and artifact SHA-256 values are verified; public download bytes are fetched and compared again before release publication.

Native Windows execution is unverified on this Linux host. Managed Chromium blocks direct file:// navigation before the game loads, so the identical standalone HTML is tested over local HTTP with outside requests blocked. The flint/portal and HTTPS cases rebuild the same frozen source into a temporary standalone copy; it is compared with the shipped HTML. Live Cloudflare tunneling and actual YouTube streaming remain unverified. Historical PERFORMANCE.json data is labelled by its original versions; no new hardware FPS claim is made.

## Intentional limits

These are original assets and cosmetic animations, not exact Minecraft skin UV/animation parity. The swimming model retains the authoritative upright collision body, so a horizontal visual limb can intersect nearby terrain. Animation wind-up does not delay existing click damage. Pistol models/recoil/F5 player rig/poses remain excluded; that retained stance is an intentional exception to the new non-pistol swimming rig. Co-op player movement/swimming appearances update, while complete remote attack animation synchronization remains partial. Enemy navigation/combat limits remain as previously documented.
