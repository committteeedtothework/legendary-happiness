import test from "node:test";
import assert from "node:assert/strict";
import { B, BLOCKS, ITEMS, CREATIVE_ITEMS, makeStack } from "../src/data.js";
import { Inventory } from "../src/inventory.js";
import {
  parseYouTubeLink,
  cleanTrack,
  watchURL,
  jukeboxRecord,
  Jukebox,
} from "../src/jukebox.js";
import { youtubeError } from "../src/youtube-player.js";
import { pack, unpack } from "../src/storage.js";
import { exportRealm, restoreRealm } from "../src/realms.js";
import { World } from "../src/world.js";
const id = "M7lc1UVf-VE";
test("YouTube links accept official video formats and canonicalize tracking away", () => {
  for (const url of [
    id,
    `youtube.com/watch?v=${id}&si=tracking&list=ignored`,
    `https://youtu.be/${id}`,
    `https://m.youtube.com/shorts/${id}`,
    `https://www.youtube.com/live/${id}`,
    `https://www.youtube-nocookie.com/embed/${id}`,
    `https://music.youtube.com/watch?v=${id}`,
  ])
    assert.deepEqual(parseYouTubeLink(url), { videoId: id, start: 0 });
  assert.equal(
    watchURL(parseYouTubeLink(`https://youtu.be/${id}?si=not-saved&t=30s`)),
    `https://www.youtube.com/watch?v=${id}&t=30s`,
  );
});
test("YouTube timestamps are parsed, bounded, and reject malformed values", () => {
  for (const [time, start] of [
    ["90", 90],
    ["1h2m3s", 3723],
    ["2m", 120],
    ["999999", 86400],
  ])
    assert.equal(
      parseYouTubeLink(`https://youtu.be/${id}?t=${time}`).start,
      start,
    );
  assert.equal(
    parseYouTubeLink(`https://youtube.com/watch?v=${id}#t=12s`).start,
    12,
  );
  assert.throws(() => parseYouTubeLink(`https://youtu.be/${id}?start=-2`));
});
test("Only YouTube video links are accepted, without credentials, scripts, or arbitrary embeds", () => {
  for (const value of [
    "",
    null,
    {},
    "javascript:alert(1)",
    "data:text/html,test",
    `https://youtube.com.evil.example/watch?v=${id}`,
    `https://youtube.com@evil.example/watch?v=${id}`,
    `https://user:password@youtube.com/watch?v=${id}`,
    `https://youtube.com:444/watch?v=${id}`,
    "https://youtube.com/playlist?list=abc",
    "https://youtube.com/@channel",
    `https://vimeo.com/${id}`,
    "x".repeat(2049),
    "<iframe src=x>",
  ])
    assert.throws(() => parseYouTubeLink(value));
});
test("Saved tracks validate strings and clamp numeric offsets without retaining unknown data", () => {
  assert.equal(cleanTrack({ videoId: [id] }), null);
  assert.equal(cleanTrack({ videoId: "<script>" }), null);
  assert.deepEqual(cleanTrack({ videoId: id, start: Infinity }), {
    videoId: id,
    start: 0,
  });
  assert.deepEqual(
    cleanTrack({ videoId: id, start: 2.9, tracking: "secret" }),
    { videoId: id, start: 2 },
  );
  assert.equal(watchURL({ videoId: "invalid" }), "");
});
test("Jukebox appends its block ID and consumes eight planks and a diamond exactly once", () => {
  assert.equal(B.jukebox, 122);
  assert.equal(B.matthew_altar, 121);
  assert.equal(BLOCKS[B.jukebox].solid, true);
  assert.equal(ITEMS.jukebox.stack, 64);
  assert.ok(CREATIVE_ITEMS.some((i) => (i.id || i) === "jukebox"));
  const inv = new Inventory();
  inv.craft = Array.from({ length: 9 }, (_, i) =>
    makeStack(i === 4 ? "diamond" : "planks"),
  );
  assert.notEqual(inv.recipe(2)?.result, "jukebox");
  assert.equal(inv.recipe(3).result, "jukebox");
  assert.equal(inv.craftOne(3), true);
  assert.deepEqual(inv.cursor, makeStack("jukebox"));
  assert.ok(inv.craft.every((x) => x === null));
  assert.equal(inv.craftOne(3), false);
});
test("Jukebox metadata persists through checksummed realm saves without player objects", () => {
  const world = new World("jukebox-save"),
    target = { x: 0, y: 200, z: 0 };
  assert.equal(jukeboxRecord(world, target), null);
  world.set(0, 200, 0, B.jukebox);
  const record = jukeboxRecord(world, target);
  record.youtube = { videoId: id, start: 45 };
  record.volume = 0.35;
  assert.equal(jukeboxRecord(world, target), record);
  assert.deepEqual(record.slots, []);
  const saved = unpack(pack(exportRealm({ world, entities: [], drops: [] })));
  const restored = restoreRealm("jukebox-save", "overworld", saved);
  assert.equal(restored.world.get(0, 200, 0), B.jukebox);
  assert.deepEqual(jukeboxRecord(restored.world, target), record);
});
test("Jukebox cannot overwrite saved links as a co-op guest", () => {
  const game = {
    id: "world",
    dimension: "overworld",
    multiplayer: { isGuest: true },
    world: { containers: { key: { type: "jukebox", youtube: null } } },
    save: () => assert.fail("guest saved"),
  };
  const box = new Jukebox(game);
  box.selection = { worldId: "world", dimension: "overworld", key: "key" };
  box.track = { videoId: id, start: 0 };
  box.saveSelection();
  assert.equal(game.world.containers.key.youtube, null);
});
test("Master volume and mute apply without repeated per-frame API commands", () => {
  const calls = [],
    box = new Jukebox({ settings: { volume: 0.8 } });
  box.ready = true;
  box.volume = 0.5;
  box.player = {
    setVolume: (v) => calls.push(v),
    mute: () => calls.push("mute"),
    unMute: () => calls.push("unmute"),
  };
  box.syncVolume();
  box.syncVolume();
  assert.deepEqual(calls, [40, "unmute"]);
  box.game.settings.volume = 0;
  box.syncVolume();
  assert.deepEqual(calls, [40, "unmute", 0, "mute"]);
});
test("Embedding restrictions have useful explanations and normal YouTube fallback", () => {
  assert.match(youtubeError(153), /origin.*Local HTML/);
  assert.match(youtubeError(101), /owner/);
  assert.match(youtubeError(100), /private/);
  assert.match(youtubeError(999), /Open on YouTube/);
});
