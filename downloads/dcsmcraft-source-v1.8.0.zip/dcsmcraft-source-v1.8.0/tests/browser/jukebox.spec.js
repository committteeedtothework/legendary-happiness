import { test, expect } from "@playwright/test";
import { readFileSync } from "node:fs";
import { B } from "../../src/data.js";
const html = readFileSync("dist/DCSMCRAFT-Standalone.html", "utf8");
const link = "https://youtu.be/M7lc1UVf-VE?t=30s&si=discard";
async function boot(page, fixture = true) {
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.addInitScript(() =>
    localStorage.setItem(
      "dcsmcraft-settings",
      JSON.stringify({
        graphics: 1,
        renderDistance: 2,
        volume: 0.8,
        ambientSounds: false,
        musicEnabled: false,
      }),
    ),
  );
  if (fixture)
    await page.addInitScript(() => {
      window.youtubeFixture = { instances: [], calls: [] };
      window.YT = {
        Player: class {
          constructor(host, options) {
            this.options = options;
            this.state = 5;
            this.frame = document.createElement("iframe");
            this.frame.src = "about:blank";
            this.frame.title = "SDK fixture";
            host.replaceWith(this.frame);
            youtubeFixture.instances.push(this);
            queueMicrotask(() => options.events.onReady({ target: this }));
          }
          getIframe() {
            return this.frame;
          }
          getPlayerState() {
            return this.state;
          }
          playVideo() {
            this.state = 1;
            youtubeFixture.calls.push("play");
            this.options.events.onStateChange({ target: this, data: 1 });
          }
          pauseVideo() {
            this.state = 2;
            youtubeFixture.calls.push("pause");
            this.options.events.onStateChange({ target: this, data: 2 });
          }
          setVolume(v) {
            this.volume = v;
          }
          mute() {
            this.muted = true;
          }
          unMute() {
            this.muted = false;
          }
          destroy() {
            this.destroyed = true;
            this.frame.remove();
          }
        },
      };
    });
  await page.route("**/*", (r) =>
    r.request().url().endsWith("/jukebox.html")
      ? r.fulfill({ contentType: "text/html", body: html })
      : r.abort(),
  );
  await page.goto("/jukebox.html");
  await page.waitForFunction(() => window.dcsmcraft?.initialized);
  await page.locator("[data-action=create]").first().click();
  await page.locator("[name=seed]").fill("Wildflower");
  await page.locator("[name=mode][value=creative]").check();
  await page.locator("[data-action=start-world]").click();
  await page.waitForFunction(() => dcsmcraft.running);
  await page.evaluate((B) => {
    const g = dcsmcraft;
    g.pause();
    g.entities = [];
    g.drops = [];
    for (let x = -3; x <= 3; x++)
      for (let z = -3; z <= 3; z++) g.world.set(x, 199, z, B.stone);
    Object.assign(g.player, {
      x: 0.5,
      y: 200,
      z: 2.5,
      yaw: 0,
      pitch: 0,
      onGround: true,
      flying: false,
      vx: 0,
      vy: 0,
      vz: 0,
      health: 20,
      fallStart: 200,
    });
  }, B);
  return errors;
}
async function openPhysical(page) {
  await page.evaluate((B) => {
    const g = dcsmcraft;
    g.player.crouching = false;
    if (g.world.get(0, 200, 0) !== B.jukebox) {
      g.inventory.selected = 0;
      g.inventory.slots[0] = { id: "jukebox", count: 1 };
      g.target = {
        id: B.stone,
        x: 0,
        y: 199,
        z: 0,
        normal: { x: 0, y: 1, z: 0 },
      };
      g.lastPlace = -10;
      g.use();
      if (g.world.get(0, 200, 0) !== B.jukebox)
        throw Error("Jukebox placement failed");
    }
    g.inventory.slots[0] = { id: "matthew_dual_pistols", count: 1 };
    g.inventory.selected = 0;
    g.target = { id: B.jukebox, x: 0, y: 200, z: 0 };
    g.player.crouching = false;
    g.ui.play();
    g.running = true;
    g.pointerLockFallback = true;
    g.use();
  }, B);
  await expect(page.locator("#jukebox-form")).toBeVisible();
}
test("standalone jukebox link, visible player, controls, persistent reload and block removal", async ({
  page,
}) => {
  const errors = await boot(page);
  await openPhysical(page);
  expect(
    await page.evaluate(() => dcsmcraft.player.tricksterRecharges?.length || 0),
  ).toBe(0);
  await page.locator("#jukebox-link").fill(link);
  await page.locator("#jukebox-form button").click();
  await expect(page.locator("#jukebox-dock iframe")).toBeVisible();
  await expect(page.locator("#jukebox-status")).toContainText("Playing");
  const info = await page.evaluate(() => {
    const g = dcsmcraft,
      p = youtubeFixture.instances.at(-1);
    return {
      record: g.world.containers["0,200,0"],
      video: p.options.videoId,
      start: p.options.playerVars.start,
      host: p.options.host,
      volume: p.volume,
    };
  });
  expect(info.video).toBe("M7lc1UVf-VE");
  expect(info.start).toBe(30);
  expect(info.host).toBe("https://www.youtube-nocookie.com");
  expect(info.record.youtube).toEqual({ videoId: "M7lc1UVf-VE", start: 30 });
  expect(info.volume).toBe(52);
  const frame = await page.locator("#jukebox-dock iframe").boundingBox();
  expect(frame.width).toBeGreaterThanOrEqual(200);
  expect(frame.height).toBeGreaterThanOrEqual(200);
  await page.locator("[data-jukebox-toggle]").click();
  await expect(page.locator("#jukebox-status")).toContainText("paused");
  await page.locator("[data-jukebox-toggle]").click();
  await page.locator("#jukebox-volume").fill("0.4");
  await expect
    .poll(() => page.evaluate(() => youtubeFixture.instances.at(-1).volume))
    .toBe(32);
  await page.evaluate(() => {
    dcsmcraft.settings.volume = 0;
  });
  await expect
    .poll(() => page.evaluate(() => youtubeFixture.instances.at(-1).muted))
    .toBe(true);
  await page.locator("[data-action=resume]").click();
  await expect(page.locator("#jukebox-dock")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.locator("#jukebox-dock")).toBeHidden();
  expect(await page.evaluate(() => youtubeFixture.instances.at(-1).state)).toBe(
    2,
  );
  await page.locator("[data-action=jukebox]").click();
  await expect(page.locator("#jukebox-dock")).toBeVisible();
  await page.screenshot({
    path: "/workspace/artifacts/DCSMCRAFT-v1.3.4-jukebox.png",
  });
  const id = await page.evaluate(async () => {
    await dcsmcraft.save();
    return dcsmcraft.id;
  });
  await page.reload();
  await page.waitForFunction(() => window.dcsmcraft?.initialized);
  await page.evaluate(async (id) => dcsmcraft.loadWorld(id), id);
  await page.waitForFunction(() => dcsmcraft.active);
  await expect(page.locator("#jukebox-dock")).toHaveCount(0);
  expect(
    await page.evaluate(() => dcsmcraft.world.containers["0,200,0"].youtube),
  ).toEqual({ videoId: "M7lc1UVf-VE", start: 30 });
  await openPhysical(page);
  await expect(page.locator("#jukebox-link")).toHaveValue(
    "https://www.youtube.com/watch?v=M7lc1UVf-VE&t=30s",
  );
  await page.locator("#jukebox-form button").click();
  await page.evaluate((B) => {
    const g = dcsmcraft;
    g.mode = "survival";
    g.inventory.slots[0] = null;
    g.breakBlock({ id: B.jukebox, x: 0, y: 200, z: 0 });
    g.jukebox.update();
  }, B);
  await expect(page.locator("#jukebox-dock")).toHaveCount(0);
  expect(
    await page.evaluate(
      () => dcsmcraft.drops.filter((x) => x.id === "jukebox").length,
    ),
  ).toBe(1);
  expect(
    await page.evaluate(() => dcsmcraft.world.containers["0,200,0"]),
  ).toBeUndefined();
  expect(errors).toEqual([]);
});
test("temporary menu player rejects unsafe links, explains provider errors and fits narrow screens", async ({
  page,
}) => {
  const errors = await boot(page);
  await page.locator("[data-action=jukebox]").click();
  await page.locator("#jukebox-link").fill("https://example.com/video");
  await page.locator("#jukebox-form button").click();
  await expect(page.locator("#jukebox-status")).toContainText("Only YouTube");
  expect(await page.evaluate(() => youtubeFixture.instances.length)).toBe(0);
  await page.locator("#jukebox-link").fill(link);
  await page.locator("#jukebox-form button").click();
  await expect(page.locator("#jukebox-dock iframe")).toBeVisible();
  await page.evaluate(() => {
    const p = youtubeFixture.instances.at(-1);
    p.options.events.onError({ data: 153 });
  });
  await expect(page.locator("#jukebox-status")).toContainText("origin");
  await expect(page.locator("#jukebox-open-youtube")).toHaveAttribute(
    "href",
    "https://www.youtube.com/watch?v=M7lc1UVf-VE&t=30s",
  );
  await page.setViewportSize({ width: 390, height: 844 });
  await expect
    .poll(() =>
      page.evaluate(
        () =>
          document.querySelector(".jukebox-dialog").getBoundingClientRect()
            .top >=
          document.querySelector("#jukebox-dock").getBoundingClientRect()
            .bottom,
      ),
    )
    .toBe(true);
  await page.screenshot({
    path: "/workspace/artifacts/DCSMCRAFT-v1.3.4-jukebox-narrow.png",
  });
  const boxes = await page.evaluate(() => {
    const d = document.querySelector("#jukebox-dock").getBoundingClientRect(),
      f = document.querySelector(".jukebox-dialog").getBoundingClientRect();
    return {
      left: d.left,
      right: d.right,
      bottom: d.bottom,
      formTop: f.top,
      scroll: document.documentElement.scrollWidth,
    };
  });
  expect(boxes.left).toBeGreaterThanOrEqual(0);
  expect(boxes.right).toBeLessThanOrEqual(390);
  expect(boxes.formTop).toBeGreaterThanOrEqual(boxes.bottom);
  expect(boxes.scroll).toBeLessThanOrEqual(390);
  await page.locator("#jukebox-stop").click();
  await expect(page.locator("#jukebox-dock")).toHaveCount(0);
  expect(
    await page.evaluate(() => youtubeFixture.instances.at(-1).destroyed),
  ).toBe(true);
  expect(errors).toEqual([]);
});
test("offline standalone stays playable and offers normal YouTube fallback when SDK cannot load", async ({
  page,
}) => {
  const errors = await boot(page, false);
  expect(await page.locator('script[src*="youtube"]').count()).toBe(0);
  await page.locator("[data-action=jukebox]").click();
  await page.locator("#jukebox-link").fill(link);
  await page.locator("#jukebox-form button").click();
  await expect(page.locator("#jukebox-status")).toContainText(
    "could not connect",
  );
  await expect(page.locator("#jukebox-open-youtube")).toBeVisible();
  await page.locator("#jukebox-form button").click();
  await expect(page.locator("#jukebox-status")).toContainText(
    "could not connect",
  );
  await page.locator("#jukebox-stop").click();
  await page.locator("[data-action=resume]").click();
  await page.waitForFunction(() => dcsmcraft.running);
  expect(errors).toEqual([]);
});
