import { B } from "./data.js";
import { loadYouTubeAPI, youtubeError } from "./youtube-player.js";
const VIDEO = /^[A-Za-z0-9_-]{11}$/;
const HOSTS = new Set([
  "youtube.com",
  "www.youtube.com",
  "m.youtube.com",
  "music.youtube.com",
  "youtu.be",
  "www.youtu.be",
  "youtube-nocookie.com",
  "www.youtube-nocookie.com",
]);
function seconds(value) {
  if (!value) return 0;
  if (/^\d+$/.test(value)) return Math.min(86400, Number(value));
  const m = /^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?$/.exec(value);
  if (!m || !m[0]) throw Error("The YouTube start time is invalid.");
  return Math.min(
    86400,
    Number(m[1] || 0) * 3600 + Number(m[2] || 0) * 60 + Number(m[3] || 0),
  );
}
export function parseYouTubeLink(text) {
  if (typeof text !== "string" || text.length > 2048)
    throw Error("Paste a single YouTube video link.");
  text = text.trim();
  if (VIDEO.test(text)) return { videoId: text, start: 0 };
  let url;
  try {
    url = new URL(/^https?:\/\//i.test(text) ? text : `https://${text}`);
  } catch {
    throw Error("Paste a valid YouTube video link.");
  }
  if (
    !["http:", "https:"].includes(url.protocol) ||
    !HOSTS.has(url.hostname.toLowerCase()) ||
    url.username ||
    url.password ||
    url.port
  )
    throw Error("Only YouTube video links are supported.");
  const parts = url.pathname.split("/").filter(Boolean);
  const videoId = url.hostname.endsWith("youtu.be")
    ? parts[0]
    : parts[0] === "watch"
      ? url.searchParams.get("v")
      : ["embed", "shorts", "live"].includes(parts[0])
        ? parts[1]
        : null;
  if (!VIDEO.test(videoId || ""))
    throw Error("Use a video link, not a channel or playlist-only link.");
  const hash = new URLSearchParams(url.hash.slice(1));
  return {
    videoId,
    start: seconds(
      url.searchParams.get("t") ||
        url.searchParams.get("start") ||
        hash.get("t"),
    ),
  };
}
export function cleanTrack(track) {
  if (!track || typeof track.videoId !== "string" || !VIDEO.test(track.videoId))
    return null;
  return {
    videoId: track.videoId,
    start: Number.isFinite(track.start)
      ? Math.max(0, Math.min(86400, Math.floor(track.start)))
      : 0,
  };
}
export function watchURL(track) {
  const t = cleanTrack(track);
  return t
    ? `https://www.youtube.com/watch?v=${t.videoId}${t.start ? `&t=${t.start}s` : ""}`
    : "";
}
export const jukeboxKey = (t) => `${t.x},${t.y},${t.z}`;
export function jukeboxRecord(world, target) {
  if (!target || world.get(target.x, target.y, target.z) !== B.jukebox)
    return null;
  const key = jukeboxKey(target),
    existing = world.containers[key];
  if (existing?.type === "jukebox") return existing;
  return (world.containers[key] = {
    type: "jukebox",
    slots: [],
    youtube: null,
    volume: 0.65,
  });
}
export class Jukebox {
  constructor(game) {
    this.game = game;
    this.token = 0;
    this.volume = 0.65;
    this.state = "stopped";
    this.ready = false;
    this.menuPaused = false;
  }
  interact() {
    const g = this.game,
      t = g.target;
    if (g.player.crouching || t?.id !== B.jukebox) return false;
    this.open(t);
    return true;
  }
  open(target) {
    const g = this.game;
    if (!g.active) return;
    g.pause();
    if (target) {
      if (
        this.bound?.key !== jukeboxKey(target) ||
        this.bound?.worldId !== g.id ||
        this.bound?.dimension !== g.dimension
      )
        this.stop();
      this.selection = {
        worldId: g.id,
        dimension: g.dimension,
        key: jukeboxKey(target),
        x: target.x,
        y: target.y,
        z: target.z,
      };
      const record = jukeboxRecord(g.world, target);
      this.track = cleanTrack(record?.youtube);
      this.volume = Number.isFinite(record?.volume)
        ? Math.max(0, Math.min(1, record.volume))
        : 0.65;
    } else if (
      !this.selection ||
      this.selection.worldId !== g.id ||
      this.selection.dimension !== g.dimension ||
      (this.selection.key &&
        g.world.containers[this.selection.key]?.type !== "jukebox")
    ) {
      this.selection = { worldId: g.id, dimension: g.dimension, key: null };
      this.track = null;
    }
    g.ui.setScreen(
      "jukebox",
      `<main class="dialog jukebox-dialog"><div class="dialog-top"><span class="eyebrow">JUKEBOX</span><button class="close" data-action="back" aria-label="Close jukebox">×</button></div><h2>A soundtrack of your own</h2><p>Paste a YouTube video link. Its official video player stays visible while you build.</p><form id="jukebox-form"><label>YouTube video link<input id="jukebox-link" type="text" maxlength="2048" autocomplete="off" placeholder="https://www.youtube.com/watch?v=…" required></label><button class="primary wide" type="submit">Play link</button></form><p id="jukebox-status" role="status"></p><div class="jukebox-actions"><button id="jukebox-stop" class="secondary">Stop playback</button><a id="jukebox-open-youtube" class="secondary" target="_blank" rel="noopener noreferrer" hidden>Open on YouTube</a></div><label class="jukebox-volume-label">Jukebox volume<input id="jukebox-volume" type="range" min="0" max="1" step="0.05"></label><p class="fine">Master volume also applies. Original game music keeps its own Options toggle.</p><p class="fine">Internet required. Some videos disable embedding. Local HTML/desktop files may get YouTube error 153; Open on YouTube always opens the normal video page. An HTTP/HTTPS-hosted game has a proper web origin.</p><p id="jukebox-save-note" class="fine"></p><button class="primary wide" data-action="resume">Back to Game</button></main>`,
    );
    const ui = g.ui.overlay;
    ui.querySelector("#jukebox-link").value = watchURL(this.track);
    ui.querySelector("#jukebox-volume").value = String(this.volume);
    if (this.dock)
      this.dock.querySelector("[data-jukebox-volume]").value = String(
        this.volume,
      );
    ui.querySelector("#jukebox-save-note").textContent = g.multiplayer?.isGuest
      ? "Co-op listening is personal. The host controls saved block links."
      : this.selection.key
        ? "This link and volume are saved with this jukebox. Playback never starts automatically after reload."
        : "Temporary player: place and right-click a crafted Jukebox to save a link with that block.";
    ui.querySelector("#jukebox-form").addEventListener("submit", (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.playLink(ui.querySelector("#jukebox-link").value);
    });
    ui.querySelector("#jukebox-stop").addEventListener("click", () =>
      this.stop("Playback stopped."),
    );
    ui.querySelector("#jukebox-volume").addEventListener("input", (e) => {
      this.volume = Number(e.target.value);
      this.saveSelection();
      this.syncVolume();
      if (this.dock)
        this.dock.querySelector("[data-jukebox-volume]").value = String(
          this.volume,
        );
    });
    this.status(this.message || "Choose a video and press Play link.");
    this.updateLinks();
  }
  status(text) {
    this.message = text;
    this.game.ui?.root
      .querySelectorAll("#jukebox-status,[data-jukebox-status]")
      .forEach((el) => (el.textContent = text));
  }
  updateLinks() {
    const url = watchURL(this.track);
    this.game.ui.root
      .querySelectorAll("#jukebox-open-youtube,[data-jukebox-external]")
      .forEach((a) => {
        a.hidden = !url;
        if (url) a.href = url;
        else a.removeAttribute("href");
      });
  }
  saveSelection() {
    const g = this.game,
      s = this.selection;
    if (
      !s?.key ||
      s.worldId !== g.id ||
      s.dimension !== g.dimension ||
      g.multiplayer?.isGuest
    )
      return;
    const record = g.world.containers[s.key];
    if (record?.type !== "jukebox") return;
    record.youtube = cleanTrack(this.track);
    record.volume = this.volume;
    g.save().catch(() =>
      this.status(
        "The link is usable now, but could not be saved. Export a world backup.",
      ),
    );
  }
  makeDock() {
    if (this.dock) return;
    this.dock = document.createElement("aside");
    this.dock.id = "jukebox-dock";
    this.dock.setAttribute("aria-label", "YouTube jukebox player");
    this.dock.innerHTML =
      '<div class="jukebox-dock-heading"><strong>JUKEBOX · YOUTUBE</strong><button type="button" data-jukebox-stop aria-label="Stop YouTube playback">■ Stop</button></div><div id="jukebox-video-host"></div><p data-jukebox-status role="status"></p><div class="jukebox-dock-controls"><button type="button" data-jukebox-toggle>Pause / Play</button><button type="button" data-jukebox-edit>Edit link</button><a data-jukebox-external target="_blank" rel="noopener noreferrer">YouTube ↗</a></div><label>Volume<input data-jukebox-volume type="range" min="0" max="1" step="0.05"></label><small>Esc → Jukebox for controls · other menus pause playback</small>';
    this.game.ui.root.append(this.dock);
    if (typeof ResizeObserver !== "undefined") {
      this.dockObserver = new ResizeObserver(() => {
        if (this.dock && !this.dock.hidden)
          this.game.ui.root.style.setProperty(
            "--jukebox-clearance",
            `${this.dock.offsetHeight + 24}px`,
          );
      });
      this.dockObserver.observe(this.dock);
    }
    this.dock
      .querySelector("[data-jukebox-stop]")
      .addEventListener("click", () => this.stop("Playback stopped."));
    this.dock
      .querySelector("[data-jukebox-edit]")
      .addEventListener("click", () => this.open());
    this.dock
      .querySelector("[data-jukebox-toggle]")
      .addEventListener("click", () => {
        if (!this.ready) return;
        try {
          this.player.getPlayerState() === 1
            ? this.player.pauseVideo()
            : this.player.playVideo();
        } catch {
          this.status("Use the controls inside the YouTube player.");
        }
      });
    this.dock
      .querySelector("[data-jukebox-volume]")
      .addEventListener("input", (e) => {
        this.volume = Number(e.target.value);
        this.saveSelection();
        this.syncVolume();
        const input = this.game.ui.overlay.querySelector("#jukebox-volume");
        if (input) input.value = String(this.volume);
      });
  }
  async playLink(text) {
    let track;
    try {
      track = parseYouTubeLink(text);
    } catch (e) {
      this.status(e.message);
      return false;
    }
    this.stop();
    this.track = track;
    this.bound = { ...this.selection };
    this.saveSelection();
    this.makeDock();
    const token = ++this.token;
    this.dock.hidden = false;
    this.dock.querySelector("[data-jukebox-volume]").value = String(
      this.volume,
    );
    this.updateLinks();
    this.status("Connecting to YouTube…");
    this.dock.querySelector("#jukebox-video-host")?.remove();
    const host = document.createElement("div");
    host.id = "jukebox-video-host";
    this.dock.querySelector(".jukebox-dock-heading").after(host);
    try {
      const YT = await loadYouTubeAPI();
      if (token !== this.token) return false;
      const playerVars = {
        playsinline: 1,
        controls: 1,
        autoplay: 0,
        rel: 0,
        start: track.start,
      };
      if (["http:", "https:"].includes(location.protocol))
        playerVars.origin = location.origin;
      this.player = new YT.Player(host, {
        host: "https://www.youtube-nocookie.com",
        width: "100%",
        height: "200",
        videoId: track.videoId,
        playerVars,
        events: {
          onReady: (e) => {
            if (token !== this.token) {
              e.target.destroy();
              return;
            }
            this.player = e.target;
            this.ready = true;
            this.lastVolume = null;
            const frame = e.target.getIframe?.();
            if (frame) {
              frame.title = "YouTube jukebox video player";
              frame.referrerPolicy = "strict-origin-when-cross-origin";
            }
            this.syncVolume();
            this.status(
              "Ready — click Play in the video if your browser asks.",
            );
            if (this.canShowPlayer()) e.target.playVideo();
            else {
              this.menuPaused = true;
              this.resumeAfterMenu = true;
            }
          },
          onStateChange: (e) => {
            if (token !== this.token) return;
            if (e.data === 1 && !this.canShowPlayer()) {
              this.resumeAfterMenu = true;
              e.target.pauseVideo();
              return;
            }
            this.state =
              {
                1: "playing",
                2: "paused",
                0: "ended",
                3: "buffering",
                5: "ready",
              }[e.data] || "ready";
            this.status(
              {
                playing: "Playing from YouTube.",
                paused: "YouTube playback paused.",
                ended:
                  "Video ended. Choose another link or replay in the player.",
                buffering: "YouTube is buffering…",
                ready: "Ready — use the YouTube player controls.",
              }[this.state],
            );
          },
          onError: (e) => {
            if (token !== this.token) return;
            this.state = "error";
            this.status(
              youtubeError(e.data) + " Use Open on YouTube if needed.",
            );
          },
          onAutoplayBlocked: () => {
            if (token === this.token)
              this.status(
                "Your browser blocked automatic playback. Click Play inside the visible YouTube player.",
              );
          },
        },
      });
      return true;
    } catch (e) {
      if (token === this.token) {
        this.state = "error";
        this.status(e.message);
      }
      return false;
    }
  }
  syncVolume() {
    if (!this.ready || !this.player) return;
    const volume = Math.round(
      Math.max(0, Math.min(1, this.game.settings.volume ?? 0.65)) *
        this.volume *
        100,
    );
    if (volume === this.lastVolume) return;
    this.lastVolume = volume;
    try {
      this.player.setVolume(volume);
      volume === 0 ? this.player.mute() : this.player.unMute();
    } catch {}
  }
  stop(message) {
    this.token++;
    this.ready = false;
    this.state = "stopped";
    this.bound = null;
    this.lastVolume = null;
    this.menuPaused = false;
    this.resumeAfterMenu = false;
    try {
      this.player?.destroy();
    } catch {}
    this.player = null;
    this.dockObserver?.disconnect();
    this.dockObserver = null;
    this.game.ui.root.style.removeProperty("--jukebox-clearance");
    if (this.dock) {
      this.dock.remove();
      this.dock = null;
    }
    if (message) this.status(message);
  }
  canShowPlayer() {
    return (
      this.game.active && ["play", "jukebox"].includes(this.game.ui.screen)
    );
  }
  update() {
    const g = this.game,
      b = this.bound;
    if (
      b &&
      (!g.active ||
        b.worldId !== g.id ||
        b.dimension !== g.dimension ||
        (b.key && !g.world.containers[b.key]))
    ) {
      this.stop("Jukebox stopped: its block or world is no longer active.");
      return;
    }
    if (this.dock) {
      const show = this.canShowPlayer();
      this.dock.hidden = !show;
      if (!show && !this.menuPaused) {
        this.menuPaused = true;
        this.resumeAfterMenu = ["playing", "buffering"].includes(this.state);
        try {
          this.player?.pauseVideo();
        } catch {}
      } else if (show && this.menuPaused) {
        this.menuPaused = false;
        if (this.resumeAfterMenu && this.ready) {
          this.resumeAfterMenu = false;
          try {
            this.player.playVideo();
          } catch {}
        }
      }
    }
    this.syncVolume();
  }
}
