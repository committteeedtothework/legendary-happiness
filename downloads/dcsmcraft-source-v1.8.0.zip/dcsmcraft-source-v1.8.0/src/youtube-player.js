// Official visible YouTube IFrame Player API; no stream extraction or proxying.
let loading;
export function loadYouTubeAPI() {
  if (window.YT?.Player) return Promise.resolve(window.YT);
  if (loading) return loading;
  loading = new Promise((resolve, reject) => {
    const previous = window.onYouTubeIframeAPIReady;
    const script = document.createElement("script");
    let done = false;
    const finish = (error) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      if (error) {
        script.remove();
        loading = null;
        reject(error);
      } else resolve(window.YT);
    };
    const timer = setTimeout(
      () =>
        finish(
          new Error(
            "YouTube did not load. Check your internet connection, or use Open on YouTube.",
          ),
        ),
      15000,
    );
    window.onYouTubeIframeAPIReady = () => {
      try {
        previous?.();
      } catch {}
      if (window.YT?.Player) finish();
      else
        finish(
          new Error("YouTube player is unavailable. Use Open on YouTube."),
        );
    };
    script.src = "https://www.youtube.com/iframe_api";
    script.async = true;
    script.onerror = () =>
      finish(
        new Error(
          "YouTube could not connect. Check your connection or use Open on YouTube.",
        ),
      );
    document.head.append(script);
  });
  return loading;
}
export function youtubeError(code) {
  return (
    {
      2: "YouTube rejected this video link.",
      5: "YouTube could not play this video in this browser.",
      100: "This video is unavailable or private.",
      101: "The video owner has disabled embedded playback.",
      150: "The video owner has disabled embedded playback.",
      153: "YouTube could not verify this page’s origin. Local HTML files can be blocked; use Open on YouTube or an HTTP/HTTPS-hosted game.",
    }[code] ||
    "YouTube could not play this video. Try its player controls or Open on YouTube."
  );
}
