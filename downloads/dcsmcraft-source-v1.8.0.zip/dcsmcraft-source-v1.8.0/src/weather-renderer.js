import * as THREE from "three";
import { hash } from "./random.js";
import { weatherAt } from "./weather.js";
export class WeatherRenderer {
  constructor(scene, settings) {
    this.scene = scene;
    this.settings = settings;
    this.clock = 0;
    this.count = 640;
    this.rainPositions = new Float32Array(this.count * 6);
    this.snowPositions = new Float32Array(this.count * 3);
    const rainGeo = new THREE.BufferGeometry(),
      snowGeo = new THREE.BufferGeometry();
    rainGeo.setAttribute(
      "position",
      new THREE.BufferAttribute(this.rainPositions, 3).setUsage(
        THREE.DynamicDrawUsage,
      ),
    );
    snowGeo.setAttribute(
      "position",
      new THREE.BufferAttribute(this.snowPositions, 3).setUsage(
        THREE.DynamicDrawUsage,
      ),
    );
    this.rain = new THREE.LineSegments(
      rainGeo,
      new THREE.LineBasicMaterial({
        color: "#91b3ce",
        transparent: true,
        opacity: 0.5,
        depthWrite: false,
      }),
    );
    this.snow = new THREE.Points(
      snowGeo,
      new THREE.PointsMaterial({
        color: "#eff6f6",
        size: 0.12,
        transparent: true,
        opacity: 0.85,
        depthWrite: false,
      }),
    );
    this.hail = new THREE.Points(
      snowGeo,
      new THREE.PointsMaterial({
        color: "#c6e3eb",
        size: 0.2,
        depthWrite: false,
      }),
    );
    this.funnelCount = 1728;
    this.funnelPositions = new Float32Array(this.funnelCount * 3);
    const funnelGeo = new THREE.BufferGeometry();
    funnelGeo.setAttribute(
      "position",
      new THREE.BufferAttribute(this.funnelPositions, 3).setUsage(
        THREE.DynamicDrawUsage,
      ),
    );
    this.funnel = new THREE.Points(
      funnelGeo,
      new THREE.PointsMaterial({
        color: "#5d6269",
        fog: false,
        size: 1.5,
        transparent: true,
        opacity: 0.6,
        depthWrite: false,
      }),
    );
    this.hail.frustumCulled = this.funnel.frustumCulled = false;
    this.hail.visible = this.funnel.visible = false;
    this.rain.frustumCulled = this.snow.frustumCulled = false;
    this.rain.visible = this.snow.visible = false;
    scene.add(this.rain, this.snow, this.hail, this.funnel);
    this.roofs = new Map();
    this.bolt = new THREE.LineSegments(
      new THREE.BufferGeometry(),
      new THREE.LineBasicMaterial({
        color: "#d6e6ff",
        transparent: true,
        opacity: 0.85,
        depthWrite: false,
      }),
    );
    this.bolt.frustumCulled = false;
    this.bolt.visible = false;
    scene.add(this.bolt);
  }
  sample(world, p, elapsed) {
    if (
      this.world !== world ||
      elapsed >= (this.nextSample || 0) ||
      Math.hypot(p.x - (this.lastX || 0), p.z - (this.lastZ || 0)) > 4
    ) {
      this.world = world;
      this.view = weatherAt(world, p);
      this.nextSample = elapsed + 0.4;
      this.lastX = p.x;
      this.lastZ = p.z;
      this.roofs.clear();
    }
    const w = world.weather;
    return {
      ...this.view,
      intensity: world.dimension === "cinderwild" ? 0 : w?.intensity || 0,
      kind: world.dimension === "cinderwild" ? "clear" : w?.kind || "clear",
      flash:
        world.dimension !== "cinderwild" && w?.strike
          ? Math.max(0, 1 - (world.tick - w.strike.tick) / 5)
          : 0,
      strike: world.dimension === "cinderwild" ? null : w?.strike,
      funnel: world.dimension === "cinderwild" ? null : w?.funnel,
    };
  }
  update(world, p, dt, elapsed, playing) {
    const view = this.sample(world, p, elapsed);
    this.clock += dt;
    const budget =
      this.settings.particles === "minimal"
        ? 180
        : this.settings.particles === "decreased"
          ? 360
          : this.count;
    const total = Math.floor(budget * view.intensity),
      active = playing && this.settings.weatherEffects !== false && total > 1;
    this.rain.visible = active && view.type === "rain";
    this.snow.visible = active && view.type === "snow";
    this.hail.visible = active && view.kind === "hail" && view.type !== "none";
    if (this.hail.visible) this.snow.visible = false;
    if (this.rain.visible || this.snow.visible || this.hail.visible) {
      for (let i = 0; i < total; i++) {
        const x = p.x + (hash(i, 1, 99) - 0.5) * 36,
          z = p.z + (hash(i, 2, 99) - 0.5) * 36,
          cell = `${Math.floor(x)},${Math.floor(z)}`;
        let roof = this.roofs.get(cell);
        if (roof === undefined) {
          roof = world.skyHeight(x, z);
          this.roofs.set(cell, roof);
        }
        const speed = this.hail.visible
          ? 18
          : view.type === "rain"
            ? 15 + hash(i, 3, 99) * 6
            : 0.65 + hash(i, 3, 99) * 0.8;
        let y = p.y + 15 - ((hash(i, 4, 99) * 24 + this.clock * speed) % 24);
        if (y < roof + 1) y = -10000;
        if (this.rain.visible && !this.hail.visible) {
          const j = i * 6;
          this.rainPositions.set([x, y, z, x + 0.08, y + 0.65, z + 0.02], j);
        } else {
          const j = i * 3;
          this.snowPositions.set(
            [x + Math.sin(this.clock * 0.6 + i) * 0.4, y, z],
            j,
          );
        }
      }
      const object = this.hail.visible
        ? this.hail
        : this.rain.visible
          ? this.rain
          : this.snow;
      if (this.hail.visible) this.rain.visible = false;
      object.geometry.setDrawRange(0, total * (this.rain.visible ? 2 : 1));
      object.geometry.attributes.position.needsUpdate = true;
    }
    this.funnel.visible = playing && !!view.funnel && view.intensity > 0.1;
    if (this.funnel.visible) {
      const f = view.funnel,
        ground = Math.max(62, world.terrain(f.x, f.z).h) + 1;
      for (let i = 0; i < this.funnelCount; i++) {
        const level = i / this.funnelCount,
          angle = i * 2.399 + this.clock * (3 - level * 1.5),
          radius = 2 + level * level * 18;
        this.funnelPositions.set(
          [
            f.x + Math.cos(angle) * radius,
            ground + level * 58,
            f.z + Math.sin(angle) * radius,
          ],
          i * 3,
        );
      }
      this.funnel.geometry.attributes.position.needsUpdate = true;
      this.funnel.material.opacity = Math.min(0.8, view.intensity * 0.8);
    }
    const strike = view.strike;
    if (strike && strike.tick !== this.strikeTick) {
      this.strikeTick = strike.tick;
      const vertices = [];
      let last = [strike.x, strike.y + 72, strike.z];
      for (let i = 1; i <= 12; i++) {
        const point = [
          strike.x + (hash(i, strike.seed || 0, 7) - 0.5) * 6 * (1 - i / 12),
          strike.y + 72 * (1 - i / 12),
          strike.z + (hash(i, 3, strike.seed || 0) - 0.5) * 5 * (1 - i / 12),
        ];
        vertices.push(...last, ...point);
        last = point;
      }
      this.bolt.geometry.dispose();
      this.bolt.geometry = new THREE.BufferGeometry();
      this.bolt.geometry.setAttribute(
        "position",
        new THREE.Float32BufferAttribute(vertices, 3),
      );
    }
    this.bolt.visible = playing && !!strike && world.tick - strike.tick < 4;
    return view;
  }
}
