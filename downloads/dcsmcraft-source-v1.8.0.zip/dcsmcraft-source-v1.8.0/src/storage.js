const DB = "dcsmcraft-worlds",
  STORE = "worlds";
const FALLBACK_KEY = "dcsmcraft-worlds-fallback-v1";
export function checksum(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}
export function pack(data) {
  const payload = JSON.stringify(data);
  return { payload, checksum: checksum(payload) };
}
export function unpack(record) {
  if (!record || checksum(record.payload) !== record.checksum)
    throw new Error("Save integrity check failed");
  return JSON.parse(record.payload);
}
export class SaveStore {
  async open() {
    if (this.db) return this.db;
    if (this.fallback) return null;
    if (!this.opening) {
      this.opening = new Promise((resolve, reject) => {
        const r = indexedDB.open(DB, 1);
        r.onupgradeneeded = () =>
          r.result.createObjectStore(STORE, { keyPath: "id" });
        r.onsuccess = () => resolve(r.result);
        r.onerror = () => reject(r.error);
      })
        .then((db) => (this.db = db))
        .catch(() => {
          // Local-file viewers can deny IndexedDB. Keep their worlds in local
          // storage when permitted, without altering any existing IndexedDB data.
          this.fallback = true;
          this.records = {};
          try {
            const records = JSON.parse(
              localStorage.getItem(FALLBACK_KEY) || "{}",
            );
            if (
              !records ||
              typeof records !== "object" ||
              Array.isArray(records)
            )
              throw new Error("Invalid fallback saves");
            const probe = `${FALLBACK_KEY}-probe`;
            localStorage.setItem(probe, "1");
            localStorage.removeItem(probe);
            this.records = records;
          } catch {
            // Still allow a playable world in a storage-blocked viewer. The UI
            // labels session-only saves and tells the player to export a backup.
            this.temporary = true;
          }
          return null;
        });
    }
    return this.opening;
  }
  writeFallback(record, id = record?.id) {
    const records = { ...this.records };
    if (record) records[id] = record;
    else delete records[id];
    if (!this.temporary) {
      try {
        localStorage.setItem(FALLBACK_KEY, JSON.stringify(records));
      } catch {
        this.temporary = true;
      }
    }
    this.records = records;
  }
  async list() {
    const db = await this.open();
    if (!db)
      return Object.values(this.records)
        .map(({ id, name, seed, mode, updated, day }) => ({
          id,
          name,
          seed,
          mode,
          updated,
          day,
        }))
        .sort((a, b) => b.updated - a.updated);
    return new Promise((resolve, reject) => {
      const r = db.transaction(STORE).objectStore(STORE).getAll();
      r.onsuccess = () =>
        resolve(
          r.result
            .map(({ id, name, seed, mode, updated, day }) => ({
              id,
              name,
              seed,
              mode,
              updated,
              day,
            }))
            .sort((a, b) => b.updated - a.updated),
        );
      r.onerror = () => reject(r.error);
    });
  }
  async load(id) {
    const db = await this.open();
    const record = !db
      ? this.records[id]
      : await new Promise((resolve, reject) => {
          const r = db.transaction(STORE).objectStore(STORE).get(id);
          r.onsuccess = () => resolve(r.result);
          r.onerror = () => reject(r.error);
        });
    if (!record) throw new Error("World does not exist");
    try {
      return { data: unpack(record.current), recovered: false };
    } catch {
      if (record.backup)
        return { data: unpack(record.backup), recovered: true };
      throw new Error(
        "Both save generations failed validation. Export your browser data before clearing storage.",
      );
    }
  }
  async save(data) {
    const db = await this.open(),
      current = pack(data);
    if (!db) {
      const old = this.records[data.id];
      let backup = old?.backup || null;
      try {
        if (old?.current) {
          unpack(old.current);
          backup = old.current;
        }
      } catch {
        /* Retain the valid backup. */
      }
      this.writeFallback({
        id: data.id,
        name: data.name,
        seed: data.seed,
        mode: data.mode,
        day: Math.floor(data.time / 24000) + 1,
        updated: Date.now(),
        current,
        backup,
      });
      return;
    }
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite"),
        store = tx.objectStore(STORE),
        r = store.get(data.id);
      r.onsuccess = () => {
        const old = r.result;
        let backup = old?.backup || null;
        try {
          if (old?.current) {
            unpack(old.current);
            backup = old.current;
          }
        } catch {
          /* Keep the last known valid generation. */
        }
        store.put({
          id: data.id,
          name: data.name,
          seed: data.seed,
          mode: data.mode,
          day: Math.floor(data.time / 24000) + 1,
          updated: Date.now(),
          current,
          backup,
        });
      };
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error("Save interrupted"));
    });
  }
  async remove(id) {
    const db = await this.open();
    if (!db) {
      this.writeFallback(null, id);
      return;
    }
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).delete(id);
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
  }
}
