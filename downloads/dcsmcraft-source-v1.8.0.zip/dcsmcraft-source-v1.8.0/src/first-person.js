import { createWeaponModel } from "./weapon-models.js";
import { createPistolModel } from "./pistol-model.js";
import * as THREE from "three";
import { BLOCKS, ITEMS } from "./data.js";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { COLS, ROWS, iconURL, itemIconCanvas } from "./textures.js";

function box(parent, size, position, material) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  mesh.position.set(...position);
  parent.add(mesh);
  return mesh;
}
export function createHandRig() {
  const root = new THREE.Group(),
    wrist = new THREE.Group(),
    grip = new THREE.Group();
  root.add(wrist);
  root.position.set(0.37, -0.27, -0.72);
  wrist.rotation.set(-0.12, -0.12, -0.13);
  const skin = new THREE.MeshLambertMaterial({ color: "#bb8b64" });
  const sleeve = new THREE.MeshLambertMaterial({ color: "#355b6b" });
  box(wrist, [0.115, 0.24, 0.11], [0, -0.245, 0.07], sleeve).rotation.x = -0.3;
  box(wrist, [0.1, 0.16, 0.095], [0, -0.105, 0.025], skin);
  box(wrist, [0.108, 0.12, 0.08], [0, 0, 0.02], skin);
  // The handle fits between the palm and fingers; the head is above the fist.
  for (let i = 0; i < 3; i++)
    box(wrist, [0.1, 0.028, 0.028], [0, -0.03 + i * 0.032, -0.065], skin);
  box(wrist, [0.033, 0.065, 0.065], [-0.065, 0.015, -0.025], skin).rotation.z =
    -0.3;
  grip.position.set(0, 0, -0.042);
  wrist.add(grip);
  const glove = new THREE.Group();
  const leather = new THREE.MeshLambertMaterial({ color: "#292833" });
  box(glove, [0.111, 0.075, 0.085], [0, 0.02, 0.023], leather);
  box(glove, [0.104, 0.047, 0.1], [0, -0.075, 0.025], leather);
  glove.visible = false;
  wrist.add(glove);
  return { root, wrist, grip, sleeve, skin, glove };
}
export function createHeldModel(id, atlas) {
  const item = ITEMS[id];
  if (!item) return null;
  if (id === "matthew_dual_pistols") return createPistolModel();
  const weapon = createWeaponModel(id);
  if (weapon) return weapon;
  if (id === "flint_and_steel") return createFlatTool(id);
  const g = new THREE.Group();
  g.userData.kind = item.block !== undefined ? "block" : item.tool || "item";
  if (item.block !== undefined) {
    const door = BLOCKS[item.block].door;
    const geometry = new THREE.BoxGeometry(
      door ? 0.15 : 0.235,
      door ? 0.32 : 0.235,
      door ? 0.035 : 0.235,
    );
    const uv = geometry.attributes.uv;
    for (let face = 0; face < 6; face++) {
      const tile = item.block * 3 + [1, 1, 0, 2, 1, 1][face];
      for (let i = face * 4; i < face * 4 + 4; i++)
        uv.setXY(
          i,
          ((tile % COLS) + 0.015 + uv.getX(i) * 0.97) / COLS,
          1 - (Math.floor(tile / COLS) + 0.985 - uv.getY(i) * 0.97) / ROWS,
        );
    }
    const cube = new THREE.Mesh(
      geometry,
      new THREE.MeshLambertMaterial({ map: atlas.texture, alphaTest: 0.5 }),
    );
    cube.material.userData.sharedMap = true;
    cube.position.set(-0.025, 0.11, door ? -0.055 : -0.18);
    cube.rotation.y = -0.35;
    g.add(cube);
  } else {
    const map = new THREE.TextureLoader().load(iconURL(id));
    map.magFilter = map.minFilter = THREE.NearestFilter;
    map.colorSpace = THREE.SRGBColorSpace;
    const sprite = new THREE.Mesh(
      new THREE.BoxGeometry(0.2, 0.23, 0.025),
      new THREE.MeshLambertMaterial({ map, alphaTest: 0.5, transparent: true }),
    );
    sprite.position.set(0, 0.08, -0.025);
    g.add(sprite);
  }
  return g;
}

function createFlatTool(id) {
  const root = new THREE.Group();
  const map = new THREE.CanvasTexture(itemIconCanvas(id));
  map.magFilter = map.minFilter = THREE.NearestFilter;
  map.colorSpace = THREE.SRGBColorSpace;
  const mesh = new THREE.Mesh(
    new THREE.PlaneGeometry(0.23, 0.25),
    new THREE.MeshLambertMaterial({
      map,
      alphaTest: 0.5,
      side: THREE.DoubleSide,
    }),
  );
  mesh.position.set(0, 0.075, -0.025);
  root.add(mesh);
  root.userData = { kind: "item", flatCutout: true, item: id };
  return root;
}
export function createDroppedModel(id, atlas) {
  const item = ITEMS[id];
  if (!item) return new THREE.Group();
  let model;
  if (item.tool || item.block !== undefined || id === "flint_and_steel")
    model = createHeldModel(id, atlas);
  else {
    // Solid pixel silhouettes have lit front/back faces and coloured side walls.
    // Merge horizontal runs into one vertex-coloured mesh per dropped item.
    const canvas = itemIconCanvas(id),
      data = canvas.getContext("2d").getImageData(0, 0, 32, 32).data,
      parts = [];
    for (let y = 0; y < 32; y++)
      for (let x = 0; x < 32; ) {
        const i = (y * 32 + x) * 4;
        if (data[i + 3] < 100) {
          x++;
          continue;
        }
        let end = x + 1;
        while (
          end < 32 &&
          [0, 1, 2, 3].every(
            (ch) => data[(y * 32 + end) * 4 + ch] === data[i + ch],
          )
        )
          end++;
        const geo = new THREE.BoxGeometry((end - x) / 32, 1 / 32, 0.12);
        geo.translate((x + end) / 64 - 0.5, 0.5 - (y + 0.5) / 32, 0);
        const color = new THREE.Color().setRGB(
          data[i] / 255,
          data[i + 1] / 255,
          data[i + 2] / 255,
          THREE.SRGBColorSpace,
        );
        const colors = new Float32Array(geo.attributes.position.count * 3);
        for (let j = 0; j < colors.length; j += 3)
          colors.set([color.r, color.g, color.b], j);
        geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
        parts.push(geo);
        x = end;
      }
    model = new THREE.Group();
    if (parts.length) {
      const geometry = mergeGeometries(parts);
      parts.forEach((g) => g.dispose());
      model.add(
        new THREE.Mesh(
          geometry,
          new THREE.MeshLambertMaterial({ vertexColors: true }),
        ),
      );
    }
  }
  const bounds = new THREE.Box3().setFromObject(model),
    size = bounds.getSize(new THREE.Vector3()),
    center = bounds.getCenter(new THREE.Vector3());
  // Root offset preserves rigid tool grips while normalising dropped silhouettes.
  const root = new THREE.Group(),
    scale = 0.38 / Math.max(size.x, size.y, size.z, 0.01);
  model.position.sub(center);
  root.add(model);
  root.scale.setScalar(scale);
  root.userData.droppedItem = id;
  return root;
}
