import { ITEMS } from "./data.js";
export const enchantLevel = (stack, id) =>
  Math.max(0, Math.min(5, Math.floor(stack?.enchantments?.[id] || 0)));
export function wear(stack, amount = 1, random = Math.random) {
  if (!stack || stack.durability === undefined || ITEMS[stack.id]?.unbreakable)
    return false;
  const chance = 1 / (enchantLevel(stack, "unbreaking") + 1);
  for (let i = 0; i < amount; i++) if (random() < chance) stack.durability--;
  return stack.durability <= 0;
}
export function equipHeld(inventory) {
  const held = inventory.held,
    slot = ITEMS[held?.id]?.armorSlot;
  if (slot === undefined) return false;
  [inventory.slots[inventory.selected], inventory.equipment[slot]] = [
    inventory.equipment[slot],
    held,
  ];
  return true;
}
export function armorStats(inventory) {
  return (inventory.equipment || []).reduce(
    (s, stack) => {
      const item = ITEMS[stack?.id];
      if (item) {
        s.armor += item.armor || 0;
        s.toughness += item.toughness || 0;
        s.protection += enchantLevel(stack, "protection");
      }
      return s;
    },
    { armor: 0, toughness: 0, protection: 0 },
  );
}
export function reduceDamage(inventory, incoming, cause) {
  const s = armorStats(inventory),
    fall = /fall/i.test(cause),
    bypass = /void|starvation/.test(cause);
  if (bypass) return incoming;
  let amount = incoming;
  if (!fall && !/drowning|suffocation/.test(cause)) {
    const effective = Math.min(
      20,
      Math.max(s.armor / 5, s.armor - incoming / (2 + s.toughness / 4)),
    );
    amount *= 1 - effective / 25;
    (inventory.equipment || []).forEach((stack, i) => {
      if (wear(stack, Math.max(1, Math.floor(incoming / 4))))
        inventory.equipment[i] = null;
    });
  }
  const protection =
    s.protection +
    (fall ? enchantLevel(inventory.equipment?.[3], "feather_falling") * 3 : 0);
  const firePieces = /lava|fire|ember|cinder/i.test(cause)
    ? (inventory.equipment || []).filter((s) => s?.id.startsWith("hellfire_"))
        .length
    : 0;
  return (
    amount * (1 - Math.min(20, protection) * 0.04) * (1 - firePieces * 0.1)
  );
}
export const ENCHANTMENTS = {
  sharpness: {
    name: "Sharpness",
    max: 5,
    fits: (i) => ["sword", "axe", "spear"].includes(i?.tool),
  },
  efficiency: {
    name: "Efficiency",
    max: 5,
    fits: (i) => ["pickaxe", "axe", "shovel", "hoe"].includes(i?.tool),
  },
  unbreaking: { name: "Unbreaking", max: 3, fits: (i) => !!i?.durability },
  protection: {
    name: "Protection",
    max: 4,
    fits: (i) => i?.armorSlot !== undefined,
  },
  feather_falling: {
    name: "Feather Falling",
    max: 4,
    fits: (i) => i?.armorSlot === 3,
  },
  knockback: {
    name: "Knockback",
    max: 2,
    fits: (i) => ["sword", "spear"].includes(i?.tool),
  },
};
export const enchantCost = (level) => ({ xp: 5 * level, lapis: level });
export function enchantItem(game, index, id) {
  const stack = game.inventory.slots[index],
    e = ENCHANTMENTS[id],
    item = ITEMS[stack?.id];
  if (!stack || !e || !e.fits(item))
    return { ok: false, message: "Choose compatible equipment." };
  const level = enchantLevel(stack, id) + 1,
    cost = enchantCost(level);
  if (level > e.max)
    return { ok: false, message: "Maximum enchantment level reached." };
  const lapis = game.inventory.slots.reduce(
    (n, s) => n + (s?.id === "lapis_lazuli" ? s.count : 0),
    0,
  );
  if (
    game.mode !== "creative" &&
    (game.player.xp < cost.xp || lapis < cost.lapis)
  )
    return {
      ok: false,
      message: `Requires ${cost.xp} XP points and ${cost.lapis} lapis.`,
    };
  if (game.mode !== "creative") {
    let left = cost.lapis;
    for (let i = 0; i < 36 && left; i++)
      if (game.inventory.slots[i]?.id === "lapis_lazuli") {
        const n = Math.min(left, game.inventory.slots[i].count);
        game.inventory.consume(i, n);
        left -= n;
      }
    game.player.xp -= cost.xp;
  }
  stack.enchantments = { ...stack.enchantments, [id]: level };
  game.audio?.tone("enchant");
  game.ui?.updateHotbar();
  return { ok: true, message: `${e.name} ${level} applied.` };
}
export function enchantText(stack) {
  return Object.entries(stack?.enchantments || {})
    .map(([id, level]) => `${ENCHANTMENTS[id]?.name || id} ${level}`)
    .join(" · ");
}
