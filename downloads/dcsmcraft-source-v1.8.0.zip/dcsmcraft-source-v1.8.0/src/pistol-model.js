import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";

// Original long-slide sidearms: palm socket at the origin, barrel along -Z.
export function createPistolModel(dark = false) {
  const root = new THREE.Group(),
    slide = new THREE.Group(),
    hammer = new THREE.Group();
  root.add(slide, hammer);
  const colors = {
    steel: dark ? "#343942" : "#bac4cb",
    edge: dark ? "#68717a" : "#e1e6e8",
    black: "#171b21",
    wood: dark ? "#633b29" : "#875237",
    grain: dark ? "#89573b" : "#ad7750",
    brass: "#b6a36b",
  };
  const materials = Object.fromEntries(
    Object.entries(colors).map(([key, color]) => [
      key,
      new THREE.MeshLambertMaterial({ color }),
    ]),
  );
  const batches = new Map();
  function part(parent, geometry, position, material, rotation = [0, 0, 0]) {
    geometry.applyMatrix4(
      new THREE.Matrix4().compose(
        new THREE.Vector3(...position),
        new THREE.Quaternion().setFromEuler(new THREE.Euler(...rotation)),
        new THREE.Vector3(1, 1, 1),
      ),
    );
    // Batch each rigid subassembly by material: details add no per-part draws.
    let bucket = batches.get(parent);
    if (!bucket) batches.set(parent, (bucket = new Map()));
    if (!bucket.has(material)) bucket.set(material, []);
    bucket
      .get(material)
      .push(geometry.index ? geometry.toNonIndexed() : geometry);
    if (geometry.index) geometry.dispose();
  }
  const box = (parent, size, pos, mat, rotation) =>
    part(parent, new THREE.BoxGeometry(...size), pos, mat, rotation);
  function profile(points, depth) {
    const shape = new THREE.Shape(
      points.map(([z, y]) => new THREE.Vector2(z, y)),
    );
    const g = new THREE.ExtrudeGeometry(shape, {
      depth,
      bevelEnabled: false,
      steps: 1,
    });
    // Shape XY -> gun ZY, extrusion -> gun X.
    g.applyMatrix4(
      new THREE.Matrix4().set(
        0,
        0,
        1,
        -depth / 2,
        0,
        1,
        0,
        0,
        -1,
        0,
        0,
        0,
        0,
        0,
        0,
        1,
      ),
    );
    return g;
  }
  // Slanted grip, flared magazine heel, under-barrel weight and beavertail.
  part(
    root,
    profile(
      [
        [-0.067, -0.105],
        [0.035, -0.105],
        [0.065, -0.073],
        [0.032, 0.09],
        [-0.035, 0.09],
      ],
      0.077,
    ),
    [0, 0, 0],
    "steel",
  );
  box(root, [0.087, 0.021, 0.105], [0, -0.109, 0.014], "black", [-0.12, 0, 0]);
  box(root, [0.104, 0.04, 0.21], [0, 0.077, -0.055], "steel");
  box(root, [0.082, 0.035, 0.21], [0, 0.074, -0.249], "edge");
  box(root, [0.094, 0.017, 0.25], [0, 0.053, -0.23], "steel");
  box(root, [0.1, 0.02, 0.085], [0, 0.085, 0.075], "steel", [-0.22, 0, 0]);
  // A hollow trigger guard, rather than a filled block.
  const guard = new THREE.Shape();
  guard.moveTo(-0.024, 0.065);
  guard.lineTo(-0.17, 0.065);
  guard.quadraticCurveTo(-0.187, 0.06, -0.187, 0.035);
  guard.lineTo(-0.187, -0.016);
  guard.quadraticCurveTo(-0.187, -0.035, -0.163, -0.035);
  guard.lineTo(-0.039, -0.035);
  guard.closePath();
  const hole = new THREE.Path();
  hole.moveTo(-0.046, 0.05);
  hole.lineTo(-0.052, -0.021);
  hole.lineTo(-0.158, -0.021);
  hole.quadraticCurveTo(-0.174, -0.021, -0.174, -0.009);
  hole.lineTo(-0.174, 0.029);
  hole.quadraticCurveTo(-0.174, 0.05, -0.16, 0.05);
  hole.closePath();
  guard.holes.push(hole);
  const gg = new THREE.ExtrudeGeometry(guard, {
    depth: 0.06,
    bevelEnabled: false,
    curveSegments: 4,
  });
  gg.applyMatrix4(
    new THREE.Matrix4().set(0, 0, -1, 0.03, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1),
  );
  part(root, gg, [0, 0, 0], "steel");
  box(root, [0.018, 0.045, 0.012], [0, 0.027, -0.071], "brass", [-0.32, 0, 0]);
  for (const side of [-1, 1]) {
    part(
      root,
      profile(
        [
          [-0.053, -0.088],
          [0.024, -0.088],
          [0.046, -0.062],
          [0.023, 0.062],
          [-0.025, 0.062],
        ],
        0.009,
      ),
      [side * 0.043, 0, 0],
      "wood",
    );
    for (const y of [-0.073, 0.049]) {
      part(
        root,
        new THREE.CylinderGeometry(0.009, 0.009, 0.006, 8),
        [side * 0.051, y, 0.012 + y * 0.2],
        "edge",
        [0, 0, Math.PI / 2],
      );
      box(
        root,
        [0.007, 0.002, 0.011],
        [side * 0.055, y, 0.012 + y * 0.2],
        "black",
      );
    }
    part(
      root,
      new THREE.SphereGeometry(1, 8, 6).scale(0.004, 0.037, 0.023),
      [side * 0.05, -0.009, 0.007],
      "brass",
    );
    part(
      root,
      new THREE.SphereGeometry(1, 8, 6).scale(0.004, 0.031, 0.018),
      [side * 0.054, -0.009, 0.007],
      "black",
    );
    // Hand-built cameo motif, no embedded photographic/third-party texture.
    box(root, [0.004, 0.019, 0.011], [side * 0.059, -0.005, 0.009], "grain");
    box(root, [0.004, 0.012, 0.022], [side * 0.059, -0.022, 0.007], "wood");
    for (let i = 0; i < 3; i++)
      box(
        root,
        [0.002, 0.072, 0.002],
        [side * 0.049, -0.006, -0.025 + i * 0.007],
        "grain",
        [-0.16, 0, 0],
      );
    box(root, [0.009, 0.017, 0.075], [side * 0.057, 0.073, -0.05], "brass");
    box(root, [0.007, 0.015, 0.035], [side * 0.054, 0.045, 0.016], "steel");
  }
  // The articulated slide runs over a fixed receiver and muzzle.
  box(slide, [0.1, 0.075, 0.425], [0, 0.123, -0.1375], "steel");
  box(slide, [0.073, 0.012, 0.39], [0, 0.165, -0.145], "edge");
  box(slide, [0.104, 0.016, 0.4], [0, 0.09, -0.14], "black");
  for (const side of [-1, 1]) {
    box(slide, [0.003, 0.029, 0.18], [side * 0.051, 0.125, -0.235], "edge");
    for (let i = 0; i < 9; i++)
      box(
        slide,
        [0.004, 0.057, 0.004],
        [side * 0.052, 0.127, 0.058 - i * 0.009],
        "black",
        [-0.2, 0, 0],
      );
    for (let i = 0; i < 5; i++)
      box(
        slide,
        [0.003, 0.007, 0.012],
        [side * 0.053, 0.125, -0.075 - i * 0.017],
        "brass",
        [i % 2 ? 0.2 : -0.2, 0, 0],
      );
  }
  box(slide, [0.004, 0.028, 0.058], [0.053, 0.131, -0.046], "black");
  box(slide, [0.005, 0.018, 0.046], [0.055, 0.129, -0.046], "edge");
  box(slide, [0.025, 0.026, 0.024], [0, 0.181, -0.317], "black");
  box(slide, [0.015, 0.006, 0.007], [0, 0.195, -0.315], "brass");
  for (const side of [-1, 1])
    box(slide, [0.015, 0.024, 0.025], [side * 0.033, 0.18, 0.035], "black");
  part(
    root,
    new THREE.CylinderGeometry(0.031, 0.031, 0.024, 12),
    [0, 0.124, -0.355],
    "edge",
    [Math.PI / 2, 0, 0],
  );
  part(
    root,
    new THREE.CylinderGeometry(0.021, 0.021, 0.002, 12),
    [0, 0.124, -0.368],
    "black",
    [Math.PI / 2, 0, 0],
  );
  hammer.position.set(0, 0.104, 0.088);
  box(hammer, [0.027, 0.035, 0.026], [0, 0.018, 0.012], "steel", [0.4, 0, 0]);
  box(hammer, [0.034, 0.012, 0.033], [0, 0.038, 0.019], "brass");
  for (const [parent, bucket] of batches)
    for (const [material, geometries] of bucket) {
      const merged = mergeGeometries(geometries, false);
      geometries.forEach((g) => g.dispose());
      const mesh = new THREE.Mesh(merged, materials[material]);
      mesh.castShadow = mesh.receiveShadow = true;
      parent.add(mesh);
    }
  const flash = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.065, 0),
    new THREE.MeshBasicMaterial({
      color: dark ? "#ffc580" : "#cdeaff",
      transparent: true,
      depthWrite: false,
    }),
  );
  flash.position.set(0, 0.124, -0.415);
  flash.visible = false;
  root.add(flash);
  const casing = new THREE.Mesh(
    new THREE.CylinderGeometry(0.008, 0.008, 0.025, 6),
    materials.brass,
  );
  casing.visible = false;
  root.add(casing);
  root.userData = {
    kind: "pistols",
    finish: dark ? "black" : "silver",
    slide,
    hammer,
    flash,
    casing,
  };
  return root;
}

export const PISTOL_RECOIL_SECONDS = 0.18;
export function pistolRecoil(remaining) {
  const age = Math.max(0, PISTOL_RECOIL_SECONDS - Math.max(0, remaining));
  if (!(remaining > 0)) return { kick: 0, slide: 0, flash: false, age };
  const kick =
    age < 0.018
      ? age / 0.018
      : Math.exp(-(age - 0.018) * 23) * Math.max(0, 1 - age / 0.18);
  const slide =
    age < 0.018 ? age / 0.018 : Math.max(0, 1 - (age - 0.018) / 0.065);
  return { kick, slide, flash: age < 0.04, age };
}
export function animatePistolModel(model, remaining, effects = true) {
  const u = model?.userData;
  if (!u?.slide) return;
  const p = pistolRecoil(remaining);
  u.slide.position.z = p.slide * 0.048;
  u.hammer.rotation.x = -p.slide * 0.65;
  u.flash.visible = p.flash && effects;
  u.flash.scale.set(0.65 + p.kick * 0.35, 0.65 + p.kick * 0.35, 1.6 + p.kick);
  u.flash.rotation.z = p.age * 65;
  u.casing.visible = effects && remaining > 0 && p.age > 0.018 && p.age < 0.17;
  const t = Math.max(0, p.age - 0.018);
  u.casing.position.set(
    0.065 + t * 1.25,
    0.14 + t * 1.2 - t * t * 9,
    -0.025 + t * 0.35,
  );
  u.casing.rotation.set(t * 22, 0, t * 35);
}
