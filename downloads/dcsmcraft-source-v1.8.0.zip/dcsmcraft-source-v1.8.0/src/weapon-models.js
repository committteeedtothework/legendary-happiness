import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { ITEMS } from "./data.js";

// Original pixel silhouettes. A single coloured mesh carries each rigid weapon;
// the handle's grip point is always the origin in held, dropped and F5 views.
export const WEAPON_FAMILIES = new Set([
  "sword",
  "spear",
  "axe",
  "pickaxe",
  "shovel",
  "hoe",
]);
export function weaponBlueprint(id) {
  const item = ITEMS[id];
  if (!item || !WEAPON_FAMILIES.has(item.tool) || item.block !== undefined)
    return null;
  const legendary = !!item.legendary,
    spear = item.tool === "spear";
  const width = 21,
    height = spear ? 40 : legendary ? 34 : 29;
  const grid = Array.from({ length: height }, () => Array(width).fill("."));
  const fill = (x, y, w, h, c) => {
    for (let j = y; j < y + h; j++)
      for (let i = x; i < x + w; i++)
        if (grid[j]?.[i] !== undefined) grid[j][i] = c;
  };
  const blade = (x, y, w, h) => {
    fill(x, y, w, h, "b");
    fill(x, y, 1, h, "l");
    if (w > 3) fill(x + w - 1, y, 1, h, "d");
  };
  const handle = (x, y, h) => {
    fill(x, y, 2, h, "h");
    fill(x, y, 1, h, "H");
  };
  let anchor = [10, 23],
    unit = 0.024;
  if (legendary) {
    anchor = [10, 28];
    unit = 0.023;
    handle(9, 23, 9);
    fill(8, 31, 4, 2, "g");
    fill(10, 1, 1, 2, "l");
    blade(9, 3, 3, 3);
    blade(8, 6, 5, 4);
    blade(7, 10, 7, 10);
    fill(10, 5, 1, 16, "r");
    fill(9, 9, 1, 11, "l");
    fill(11, 10, 1, 10, "d");
    fill(3, 21, 15, 2, "g");
    fill(2, 20, 2, 2, "g");
    fill(17, 20, 2, 2, "g");
    fill(8, 20, 5, 4, "g");
    fill(9, 21, 3, 2, "r");
    for (let y = 24; y < 31; y += 2) fill(9, y, 2, 1, "G");
  } else if (spear) {
    anchor = [10, 28];
    unit = 0.022;
    handle(9, 13, 25);
    fill(9, 1, 2, 2, "l");
    blade(8, 3, 4, 3);
    blade(7, 6, 6, 5);
    blade(8, 11, 4, 3);
    fill(8, 14, 4, 2, "g");
    fill(9, 16, 2, 2, "G");
    fill(8, 36, 4, 2, "d");
  } else if (item.tool === "sword") {
    handle(9, 18, 8);
    fill(8, 26, 4, 1, "g");
    blade(10, 1, 1, 1);
    blade(9, 2, 3, 2);
    blade(8, 4, 5, 12);
    fill(5, 16, 11, 2, "g");
    fill(8, 18, 4, 1, "d");
  } else if (item.tool === "pickaxe") {
    handle(9, 8, 19);
    blade(5, 2, 10, 2);
    blade(3, 4, 14, 2);
    blade(2, 6, 3, 4);
    blade(15, 6, 3, 4);
    fill(9, 6, 3, 4, "d");
    fill(9, 7, 2, 3, "g");
  } else if (item.tool === "axe") {
    handle(11, 7, 20);
    anchor = [12, 23];
    blade(5, 2, 7, 2);
    blade(3, 4, 10, 5);
    blade(4, 9, 7, 2);
    blade(6, 11, 4, 2);
    fill(11, 5, 3, 5, "g");
  } else if (item.tool === "hoe") {
    handle(11, 7, 20);
    anchor = [12, 23];
    blade(4, 3, 11, 3);
    blade(3, 6, 3, 6);
    fill(11, 6, 3, 3, "g");
  } else {
    handle(9, 12, 15);
    blade(7, 2, 6, 2);
    blade(6, 4, 8, 7);
    blade(7, 11, 6, 2);
    blade(8, 13, 4, 1);
  }
  // Outline only real silhouettes; never a rectangular sprite backing plate.
  const original = grid.map((row) => [...row]);
  for (let y = 0; y < height; y++)
    for (let x = 0; x < width; x++)
      if (
        original[y][x] === "." &&
        [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ].some(
          ([dx, dy]) =>
            original[y + dy]?.[x + dx] && original[y + dy][x + dx] !== ".",
        )
      )
        grid[y][x] = "o";
  return {
    id,
    kind: item.tool,
    width,
    height,
    grid,
    anchor,
    unit,
    depth: legendary ? 0.045 : 0.03,
    legendary,
  };
}
function paletteFor(id) {
  const item = ITEMS[id],
    legendary = !!item.legendary,
    hell = id.startsWith("hellfire_");
  const base = new THREE.Color(legendary ? "#43d5df" : item.color);
  const lighter = base.clone().lerp(new THREE.Color("#f2f4df"), 0.4);
  const darker = base.clone().multiplyScalar(0.63);
  return {
    b: base,
    l: lighter,
    d: darker,
    o: new THREE.Color(hell ? "#392b34" : legendary ? "#155a70" : "#35413d"),
    h: new THREE.Color(legendary ? "#d8a632" : hell ? "#563441" : "#855933"),
    H: new THREE.Color(legendary ? "#ffe69a" : hell ? "#8b5a4c" : "#be9358"),
    g: new THREE.Color(legendary ? "#ecc259" : hell ? "#b95d37" : item.color),
    G: new THREE.Color(legendary ? "#ad7824" : "#c3a579"),
    r: new THREE.Color("#d7ffff"),
  };
}
function colouredBox(parts, size, pos, color) {
  const geometry = new THREE.BoxGeometry(...size);
  geometry.translate(...pos);
  const colors = new Float32Array(geometry.attributes.position.count * 3);
  for (let i = 0; i < colors.length; i += 3)
    colors.set([color.r, color.g, color.b], i);
  geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
  parts.push(geometry);
}
export function createWeaponModel(id) {
  const p = weaponBlueprint(id);
  if (!p) return null;
  const root = new THREE.Group(),
    parts = [],
    colors = paletteFor(id);
  for (let y = 0; y < p.height; y++)
    for (let x = 0; x < p.width; ) {
      const c = p.grid[y][x];
      if (c === ".") {
        x++;
        continue;
      }
      let end = x + 1;
      while (end < p.width && p.grid[y][end] === c) end++;
      colouredBox(
        parts,
        [(end - x) * p.unit, p.unit, p.depth],
        [
          (x + (end - x) / 2 - p.anchor[0]) * p.unit,
          (p.anchor[1] - y - 0.5) * p.unit,
          0,
        ],
        colors[c],
      );
      x = end;
    }
  if (p.legendary) {
    // Raised central fuller and stepped chevrons follow the broad cyan icon.
    for (const side of [-1, 1]) {
      colouredBox(
        parts,
        [0.015, 0.3, 0.009],
        [0, 0.33, side * 0.027],
        colors.l,
      );
      for (let i = 0; i < 4; i++) {
        const y = 0.2 + i * 0.069;
        colouredBox(
          parts,
          [0.043, 0.012, 0.009],
          [-0.021, y, side * 0.028],
          colors.r,
        );
        colouredBox(
          parts,
          [0.043, 0.012, 0.009],
          [0.021, y + 0.012, side * 0.028],
          colors.d,
        );
      }
      colouredBox(
        parts,
        [0.045, 0.036, 0.014],
        [0, 0.128, side * 0.031],
        colors.r,
      );
    }
  }
  const geometry = mergeGeometries(parts);
  parts.forEach((g) => g.dispose());
  geometry.computeBoundingBox();
  const material = new THREE.MeshLambertMaterial({
    vertexColors: true,
    emissive: p.legendary
      ? "#083942"
      : id.startsWith("hellfire_")
        ? "#40160b"
        : "#000000",
    emissiveIntensity: p.legendary ? 0.16 : 1,
  });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.name = p.legendary
    ? "Devin ridged blade and gold hilt"
    : p.kind + " pixel silhouette";
  root.add(mesh);
  root.userData = {
    kind: p.kind,
    weaponModel: id,
    pixelProfile: true,
    gripOrigin: [0, 0, 0],
    bladeRidges: p.legendary ? 8 : 0,
    goldenGrip: p.legendary,
  };
  if (p.legendary) {
    const sheen = new THREE.Mesh(
      new THREE.BoxGeometry(0.009, 0.38, 0.048),
      new THREE.MeshBasicMaterial({
        color: "#a9f6f4",
        transparent: true,
        opacity: 0.17,
        depthWrite: false,
      }),
    );
    sheen.position.set(-0.017, 0.34, 0);
    sheen.userData.bladeSheen = true;
    root.add(sheen);
    for (let i = 0; i < 3; i++) {
      const glint = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.009, 0),
        new THREE.MeshBasicMaterial({
          color: i === 1 ? "#ffe3a0" : "#b4ffff",
          transparent: true,
          opacity: 0.5,
          depthWrite: false,
        }),
      );
      glint.position.set(
        (i % 2 ? 1 : -1) * (0.07 - i * 0.014),
        0.23 + i * 0.12,
        -0.035,
      );
      glint.userData.magicGlint = i;
      root.add(glint);
    }
  }
  return root;
}
