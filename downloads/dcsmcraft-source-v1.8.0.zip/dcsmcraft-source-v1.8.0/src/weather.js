import { hash } from "./random.js";
import { moveBody } from "./physics.js";
export const WEATHER_KINDS = ["clear", "rain", "thunder", "hail", "tornado"];
export function createWeather(seed = 0) {
  return {
    kind: "clear",
    override: null,
    remaining: 6000 + Math.floor(hash(seed, 2, 71) * 12000),
    serial: 0,
    intensity: 0,
    nextStrike: 0,
    strike: null,
    funnel: null,
  };
}
export function restoreWeather(value, seed = 0) {
  const base = createWeather(seed);
  if (!value || typeof value !== "object") return base;
  return {
    ...base,
    kind: WEATHER_KINDS.includes(value.kind) ? value.kind : "clear",
    override: WEATHER_KINDS.includes(value.override) ? value.override : null,
    remaining: Number.isFinite(value.remaining)
      ? Math.max(1, Math.min(72000, Math.floor(value.remaining)))
      : base.remaining,
    serial: Math.max(0, Math.floor(value.serial || 0)),
    intensity: Math.max(0, Math.min(1, Number(value.intensity) || 0)),
    nextStrike: Math.max(0, Number(value.nextStrike) || 0),
    strike:
      value.strike &&
      ["x", "y", "z", "tick"].every((k) => Number.isFinite(value.strike[k]))
        ? { ...value.strike }
        : null,
    funnel:
      value.funnel &&
      ["x", "z", "age", "seed"].every((k) => Number.isFinite(value.funnel[k]))
        ? { ...value.funnel }
        : null,
  };
}
export function setWeather(world, kind) {
  const w = (world.weather ||= createWeather(world.seedInt));
  w.override = WEATHER_KINDS.includes(kind) ? kind : null;
  if (w.override) w.kind = w.override;
  w.remaining = 6000;
  w.nextStrike = 0;
  w.funnel = null;
  if (kind === "clear") w.strike = null;
  return w;
}
export function tickWeather(game) {
  const world = game.world;
  if (world.dimension === "cinderwild") return;
  const w = (world.weather ||= createWeather(world.seedInt));
  if (w.override) w.kind = w.override;
  else if (--w.remaining <= 0) {
    w.serial++;
    const r = hash(world.seedInt, w.serial, 819);
    w.kind =
      w.kind === "clear"
        ? r < 0.06
          ? "tornado"
          : r < 0.17
            ? "hail"
            : r < 0.38
              ? "thunder"
              : "rain"
        : "clear";
    w.remaining =
      w.kind === "clear"
        ? 6000 + Math.floor(r * 18000)
        : 4000 + Math.floor(r * 8000);
  }
  w.intensity += ((w.kind === "clear" ? 0 : 1) - w.intensity) * 0.0035;
  if (
    ["thunder", "tornado"].includes(w.kind) &&
    w.intensity > 0.5 &&
    world.tick >= w.nextStrike
  ) {
    const n = w.serial++ + world.tick,
      angle = hash(n, 2, world.seedInt) * Math.PI * 2,
      r = 18 + hash(n, 3, world.seedInt) * 45;
    const x = Math.floor(game.player.x + Math.sin(angle) * r),
      z = Math.floor(game.player.z + Math.cos(angle) * r),
      t = world.terrain(x, z);
    if (precipitation(t.biome, t.h) !== "none")
      w.strike = { x, y: Math.max(t.h, 62) + 1, z, tick: world.tick, seed: n };
    w.nextStrike =
      world.tick + 100 + Math.floor(hash(n, 4, world.seedInt) * 240);
  }
  if (w.kind === "tornado") {
    if (!w.funnel) {
      const angle = hash(world.tick, 11, world.seedInt) * Math.PI * 2;
      w.funnel = {
        x: game.player.x + Math.cos(angle) * 70,
        z: game.player.z + Math.sin(angle) * 70,
        age: 0,
        seed: world.tick + world.seedInt,
      };
      game.ui?.announce?.(
        "TORNADO WARNING",
        "A funnel is approaching. Get beneath a solid roof.",
      );
    }
    w.funnel.age++;
    w.funnel.x += 0.035;
    w.funnel.z += 0.018 + Math.sin(w.funnel.age / 800) * 0.012;
  } else w.funnel = null;
  tickWeatherDamage(game);
}
export function tickWeatherDamage(game) {
  const world = game.world,
    w = world.weather;
  if (!w || world.dimension === "cinderwild") return;
  if (
    w.intensity < 0.55 ||
    game.mode === "creative" ||
    game.difficulty === "peaceful"
  )
    return;
  const p = game.player,
    view = weatherAt(world, p);
  if (!view.exposed || p.health <= 0) return;
  if (w.kind === "hail" && view.type !== "none" && world.tick % 60 === 0)
    game.damage?.(1, "hailstones");
  if (w.kind === "tornado" && w.funnel) {
    const dx = w.funnel.x - p.x,
      dz = w.funnel.z - p.z,
      d = Math.hypot(dx, dz);
    if (
      d < 28 &&
      d > 0.1 &&
      p.y < Math.max(62, world.terrain(w.funnel.x, w.funnel.z).h) + 62
    ) {
      const force = (1 - d / 28) * w.intensity;
      moveBody(
        world,
        p,
        (dx / d - (dz / d) * 1.8) * force * 0.18,
        0,
        (dz / d + (dx / d) * 1.8) * force * 0.18,
        p.crouching ? 1.5 : 1.8,
        0.6,
      );
      if (d < 13) p.vy = Math.max(p.vy, 4 + force * 2);
      if (world.tick % 40 === 0) game.damage?.(1, "tornado debris");
    }
  }
}
export function precipitation(biome, height = 70) {
  if (["desert", "badlands", "cinderwild"].includes(biome)) return "none";
  return ["alpine", "snowy_taiga"].includes(biome) || height > 140
    ? "snow"
    : "rain";
}
export function weatherAt(world, p) {
  const w = world.weather || createWeather(world.seedInt),
    t = world.terrain(p.x, p.z);
  const cinder = world.dimension === "cinderwild",
    kind = cinder ? "clear" : w.kind;
  const intensity = cinder ? 0 : w.intensity,
    type = precipitation(t.biome, Math.max(t.h, p.y));
  const roof = world.skyHeight?.(Math.floor(p.x), Math.floor(p.z)) ?? t.h;
  return {
    kind,
    intensity,
    type,
    rain: type === "rain" ? intensity : 0,
    snow: type === "snow" ? intensity : 0,
    exposed: p.y + 1.6 > roof + 0.1,
    roof,
    biome: t.biome,
    storm: ["thunder", "hail", "tornado"].includes(kind) && intensity > 0.5,
    hail: kind === "hail" && type !== "none" ? intensity : 0,
    funnel: cinder ? null : w.funnel,
    flash:
      !cinder && w.strike
        ? Math.max(0, 1 - (world.tick - w.strike.tick) / 5)
        : 0,
    strike: cinder ? null : w.strike,
  };
}
