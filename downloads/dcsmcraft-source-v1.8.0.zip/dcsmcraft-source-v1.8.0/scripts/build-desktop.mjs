import { readFile, writeFile, mkdir, copyFile, cp } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { resolve } from "node:path";
const zig =
  process.env.DCSMCRAFT_ZIG ||
  "/workspace/.cache/dcsmcraft-toolchain/node_modules/@oven/zig-linux-x64/zig";
if (!existsSync(zig))
  throw new Error(
    "Set DCSMCRAFT_ZIG to a Zig 0.12-compatible compiler. See desktop/README.md.",
  );
const html = await readFile("dist/DCSMCRAFT-Standalone.html", "utf8");
const bytes = Buffer.from(html, "utf8");
const rows = [];
for (let i = 0; i < bytes.length; i += 64)
  rows.push(
    [...bytes.subarray(i, i + 64)]
      .map((b) => "0x" + b.toString(16).padStart(2, "0"))
      .join(","),
  );
await writeFile(
  "desktop/payload.hpp",
  "// Generated embedded offline payload.\nstatic const unsigned char embedded_html[]={\n" +
    rows.join(",\n") +
    ",0};\n",
);
await mkdir("dist/desktop", { recursive: true });
const env = {
  ...process.env,
  ZIG_GLOBAL_CACHE_DIR: resolve(".desktop-cache/global"),
  ZIG_LOCAL_CACHE_DIR: resolve(".desktop-cache/local"),
};
const args = [
  "cc",
  "desktop/launcher.c",
  "-std=c11",
  "-O2",
  "-target",
  "x86_64-windows-gnu",
  "-Wl,--subsystem,windows",
  "-luser32",
  "-lshell32",
  "-lole32",
  "-o",
  "dist/desktop/DCSMCRAFT.exe",
];
const result = spawnSync(zig, args, { stdio: "inherit", env });
if (result.status !== 0) process.exit(result.status || 1);
const local = spawnSync(
  "gcc",
  ["desktop/launcher.c", "-std=c11", "-O2", "-o", "dist/desktop/payload-check"],
  { stdio: "inherit" },
);
if (local.status !== 0) process.exit(local.status || 1);
await mkdir("/tmp/dcsmcraft desktop verification", { recursive: true });
const check = spawnSync(
  "dist/desktop/payload-check",
  ["--extract-only", "/tmp/dcsmcraft desktop verification/index.html"],
  { stdio: "inherit" },
);
if (check.status !== 0) process.exit(check.status || 1);
if (
  (await readFile("/tmp/dcsmcraft desktop verification/index.html", "utf8")) !==
  html
)
  throw new Error("Executable payload differs from standalone build");
await copyFile("desktop/README.md", "dist/desktop/START-HERE.txt");
await cp("desktop/licenses", "dist/desktop/licenses", { recursive: true });
console.log(
  "Windows x64 executable built; companion extraction verified byte-for-byte. Windows launch is not tested on this Linux host.",
);
