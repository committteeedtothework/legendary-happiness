# Current user scope

Only change the Giganto boss encounter unless the user explicitly authorizes
another area. The current authorized exception is restoring the earlier wool
and water textures. Keep other sandbox visuals, mechanics, saves, content and
multiplayer behavior unchanged.

Do not resume the unfinished AUDIT.md stages without a new user instruction
authorizing that work. Necessary builds, verification and documentation may
accompany an authorized change. Do not push, deploy or publish without approval.
