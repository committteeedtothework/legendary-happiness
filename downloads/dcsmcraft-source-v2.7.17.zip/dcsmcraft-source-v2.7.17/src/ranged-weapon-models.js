import * as THREE from "three";
import { weaponPixels } from "./weapon-art.js";
import { pixelWeaponMesh, pixelRootData } from "./pixel-weapon-mesh.js";
export function createRangedWeapon(id) {
  if (!["bow", "crossbow", "shield"].includes(id)) return null;
  const root = new THREE.Group(),
    p = weaponPixels(id);
  root.userData = { ...pixelRootData(p), editionWeapon: true, drawMeshes: [] };
  for (let i = 0; i < (id === "shield" ? 1 : 4); i++) {
    const mesh = pixelWeaponMesh(weaponPixels(id, i));
    mesh.visible = i === 0;
    root.add(mesh);
    root.userData.drawMeshes.push(mesh);
  }
  return root;
}
export function animateRangedWeapon(model, player, time, stack) {
  if (!model?.userData.editionWeapon) return;
  const u = model.userData,
    draw =
      player.editionDraw?.id === u.item
        ? Math.max(
            0,
            Math.min(
              1,
              (time - player.editionDraw.start) /
                (u.item === "crossbow" ? 1.25 : 1),
            ),
          )
        : 0;
  const stage =
    u.item === "crossbow" && stack?.charged
      ? 3
      : draw <= 0
        ? 0
        : draw < 0.65
          ? 1
          : draw < 0.9
            ? 2
            : 3;
  u.drawStage = stage;
  u.drawMeshes.forEach(
    (m, i) => (m.visible = i === Math.min(stage, u.drawMeshes.length - 1)),
  );
}
