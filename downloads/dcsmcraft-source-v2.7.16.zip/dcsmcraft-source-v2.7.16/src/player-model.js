import {
  poseThirdPersonWeapon,
  configureWeaponDisplay,
} from "./weapon-poses.js";
import { isWeapon } from "./weapon-art.js";
import { animateRangedWeapon } from "./ranged-weapon-models.js";
import { animateArticulatedPlayer } from "./player-motion.js";
import {
  createPistolModel,
  animatePistolModel,
  pistolRecoil,
} from "./pistol-model.js";
import * as THREE from "three";
import { isFlatItem } from "./item-shapes.js";
import { ITEMS } from "./data.js";
import { skinFor, armAppearanceFor } from "./skins.js";
import { skinMaterial, skinBoxGeometry } from "./skin-art.js";
import { createHeldModel } from "./first-person.js";
// Every outfit shares the classic 8px head, 8x12 torso and 4x12 limbs.
// The authoritative collision body, camera height and weapon models are unchanged.
export const PLAYER_PROPORTIONS = Object.freeze({
  pixel: 1.8 / 32,
  head: [0.45, 0.45, 0.45],
  body: [0.45, 0.675, 0.225],
  leg: [0.225, 0.675, 0.225],
  arm: [0.225, 0.675, 0.225],
});
export function createPlayerModel(skinId, equipment = [], held, atlas) {
  const s = skinFor(skinId),
    armAppearance = armAppearanceFor(skinId),
    root = new THREE.Group(),
    rig = new THREE.Group();
  root.add(rig);
  const materials = {};
  const mat = (color) =>
    (materials[color] ||= new THREE.MeshLambertMaterial({ color }));
  function box(parent, size, pos, color) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), mat(color));
    mesh.position.set(...pos);
    mesh.castShadow = mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  }
  const textured = (parent, size, pos, part) => {
    const material = skinMaterial(skinId, part);
    const mesh = new THREE.Mesh(skinBoxGeometry(size, material.map), material);
    mesh.position.set(...pos);
    mesh.castShadow = mesh.receiveShadow = true;
    mesh.name = `skin-${part}`;
    parent.add(mesh);
    return mesh;
  };
  const joint = (x, y) => {
    const g = new THREE.Group();
    g.position.set(x, y, 0);
    rig.add(g);
    return g;
  };
  const legs = [-1, 1].map((side) => {
    const leg = joint(side * 0.1125, 0.675);
    textured(leg, PLAYER_PROPORTIONS.leg, [0, -0.3375, 0], "leg");
    return leg;
  });
  const body = textured(rig, PLAYER_PROPORTIONS.body, [0, 1.0125, 0], "body");
  const forearms = [];
  const arms = [-1, 1].map((side) => {
    const arm = joint(side * 0.3375, 1.35);
    textured(arm, [0.225, 0.3, 0.225], [0, -0.15, 0], "sleeve");
    const elbow = new THREE.Group();
    elbow.position.y = -0.3;
    arm.add(elbow);
    textured(elbow, [0.225, 0.195, 0.225], [0, -0.0975, 0], "sleeve");
    textured(elbow, [0.225, 0.18, 0.225], [0, -0.285, 0], "hand");
    if (armAppearance.glove) {
      const glove = armAppearance.glove;
      box(
        elbow,
        [0.226, glove.end - glove.start, 0.226],
        [0, -0.375 + (glove.end + glove.start) / 2, 0],
        glove.color,
      );
    }
    forearms.push(elbow);
    return arm;
  });
  const head = new THREE.Group();
  head.position.y = 1.35;
  rig.add(head);
  textured(head, PLAYER_PROPORTIONS.head, [0, 0.225, 0], "head");
  const coat = [];
  if (s.style === "dante" || s.style === "vergil") {
    for (const side of [-1, 1]) {
      const tail = new THREE.Group();
      tail.position.set(side * 0.1125, 0.7, 0.12);
      rig.add(tail);
      box(tail, [0.222, 0.54, 0.016], [0, -0.27, 0], s.shirt);
      box(
        tail,
        [0.018, 0.54, 0.018],
        [side * 0.1, -0.27, -0.002],
        s.style === "vergil" ? s.accent : "#6f1e30",
      );
      coat.push(tail);
    }
    if (s.style === "vergil") {
      const sheath = box(
        rig,
        [0.045, 0.75, 0.045],
        [-0.28, 0.54, 0.15],
        "#252b38",
      );
      sheath.rotation.z = -0.2;
      const hilt = box(
        rig,
        [0.045, 0.17, 0.045],
        [-0.19, 0.99, 0.15],
        s.accent,
      );
      hilt.rotation.z = -0.2;
      box(rig, [0.11, 0.025, 0.09], [-0.21, 0.91, 0.15], s.accent);
    }
  }
  if (s.style === "astronaut")
    box(rig, [0.3, 0.43, 0.1], [0, 1.03, 0.165], s.shirt);
  // Armor follows each articulated body part rather than floating beside it.
  equipment.forEach((stack, slot) => {
    const i = ITEMS[stack?.id];
    if (i?.armorSlot !== slot) return;
    if (stack.id.startsWith("hellfire_")) {
      if (slot === 0)
        box(head, [0.08, 0.28, 0.03], [0, 0.3, -0.235], "#ffd093");
      if (slot === 1) {
        box(rig, [0.14, 0.31, 0.025], [0, 1, -0.155], "#533442");
        box(rig, [0.06, 0.18, 0.025], [0, 1, -0.17], "#ffd093");
      }
    }
    if (slot === 0) {
      box(head, [0.48, 0.15, 0.48], [0, 0.39, 0], i.color);
      box(head, [0.07, 0.28, 0.47], [-0.205, 0.245, 0.015], i.color);
      box(head, [0.07, 0.28, 0.47], [0.205, 0.245, 0.015], i.color);
    }
    if (slot === 1) {
      box(rig, [0.48, 0.69, 0.26], [0, 1.0125, 0], i.color);
      arms.forEach((g) => box(g, [0.24, 0.2, 0.25], [0, -0.1, 0], i.color));
    }
    if (slot === 2)
      legs.forEach((g) => box(g, [0.24, 0.45, 0.25], [0, -0.2, 0], i.color));
    if (slot === 3)
      legs.forEach((g) =>
        box(g, [0.245, 0.2, 0.26], [0, -0.575, -0.01], i.color),
      );
  });
  const grip = new THREE.Group();
  const blockHeld = ITEMS[held]?.block !== undefined;
  grip.position.set(0, -0.6, blockHeld ? -0.02 : -0.07);
  grip.rotation.x = blockHeld ? -0.1 : -0.85;
  if (forearms.length) {
    grip.position.y = -0.3;
    forearms[1].add(grip);
  } else arms[1].add(grip);
  const heldModel = createHeldModel(held, atlas);
  if (heldModel) {
    if (isFlatItem(held)) heldModel.position.z -= 0.11;
    heldModel.scale.setScalar(1.1);
    if (isWeapon(held) && held !== "matthew_dual_pistols")
      configureWeaponDisplay(heldModel, held, "third");
    grip.add(heldModel);
  }
  const leftGrip = new THREE.Group();
  if (held === "matthew_dual_pistols") {
    leftGrip.position.copy(grip.position);
    leftGrip.rotation.copy(grip.rotation);
    const left = createPistolModel(true);
    left.scale.setScalar(1.1);
    leftGrip.add(left);
    forearms[0].add(leftGrip);
  }
  root.userData = {
    coat,
    leftGrip,
    rig,
    head,
    arms,
    forearms,
    legs,
    body,
    grip,
    skin: skinId,
    heldId: held,
    heldKind:
      ITEMS[held]?.tool ||
      (ITEMS[held]?.block !== undefined ? "block" : "item"),
  };
  return root;
}
export function animatePlayerModel(
  model,
  p,
  dt,
  moving,
  action = 0,
  actionKind = "attack",
  pistolRemaining = 0,
  pistolEffects = true,
  visualAction = null,
  visualContext = {},
) {
  if (model.userData.heldKind !== "pistols") {
    animateArticulatedPlayer(
      model,
      p,
      dt,
      moving,
      action,
      actionKind,
      visualAction,
    );
    if (dt > 0) {
      poseThirdPersonWeapon(
        model,
        p,
        visualAction,
        action,
        actionKind,
        visualContext,
      );
      animateRangedWeapon(
        model.userData.grip.children[0],
        p,
        visualContext.time ?? 0,
        visualContext.held,
      );
    }
    return;
  }
  const u = model.userData;
  u.stride = (u.stride || 0) + (moving ? dt * (p.sprinting ? 14 : 9) : 0);
  const alpha = 1 - Math.exp(-14 * dt),
    gait = moving ? (p.sprinting ? 0.65 : 0.4) : 0;
  u.gait = (u.gait || 0) + (gait - (u.gait || 0)) * alpha;
  u.legs.forEach(
    (g, i) => (g.rotation.x = Math.sin(u.stride + i * Math.PI) * u.gait),
  );
  u.arms.forEach((g, i) => {
    g.rotation.x =
      -Math.sin(u.stride + i * Math.PI) * u.gait * 0.8 +
      (i === 1 ? -action * 1.6 : 0);
  });
  const use = actionKind === "eat" || actionKind === "use";
  const thrust = u.heldKind === "spear";
  const swimming = p.inWater && !p.onGround;
  u.arms.forEach((arm, i) => {
    u.forearms?.[i]?.rotation.set(0, 0, 0);
    arm.rotation.z = 0;
    arm.rotation.y = 0;
    if (swimming) arm.rotation.x = Math.sin(u.stride + i * Math.PI) * 0.6 + 1.5;
    else if (!p.onGround && !p.flying) arm.rotation.z = (i ? 1 : -1) * 0.12;
    if (i === 1 && action > 0) {
      arm.rotation.x = use
        ? action * 2.0
        : thrust
          ? action * 1.45
          : action * (actionKind === "place" ? 1.25 : 1.8);
      arm.rotation.y = use ? 0 : thrust ? -action * 0.15 : -action * 0.5;
      arm.rotation.z = use ? -action * 0.2 : thrust ? 0 : action * 0.5;
    }
  });
  u.body.rotation.z =
    actionKind === "attack" ? Math.sin(action * Math.PI) * 0.035 : 0;
  u.grip.rotation.x =
    u.heldKind === "block"
      ? -0.1
      : thrust
        ? -1.4 - u.arms[1].rotation.x
        : (use ? -1.05 : -0.85) - u.arms[1].rotation.x * 0.65;
  if (u.heldKind === "pistols") {
    const kick = pistolRecoil(pistolRemaining).kick;
    u.carry =
      (u.carry || 0) +
      ((p.sprinting && moving && pistolRemaining <= 0 ? 1 : 0) -
        (u.carry || 0)) *
        alpha;
    u.arms.forEach((arm, i) => {
      const firing = i === (p.matthewHand || 0) ? kick : 0;
      arm.rotation.x = 1.3 + p.pitch * 0.6 + firing * 0.24 - u.carry * 0.65;
      arm.rotation.y = (i ? -1 : 1) * (0.07 + u.carry * 0.18);
      arm.rotation.z = (i ? 1 : -1) * (firing * 0.035 + u.carry * 0.12);
    });
    u.grip.rotation.x = u.leftGrip.rotation.x = -1.3 + p.pitch * 0.4;
    animatePistolModel(
      u.grip.children[0],
      p.matthewHand === 1 ? pistolRemaining : 0,
      pistolEffects,
    );
    animatePistolModel(
      u.leftGrip.children[0],
      p.matthewHand === 1 ? 0 : pistolRemaining,
      pistolEffects,
    );
  }
  u.coat?.forEach((tail, i) => {
    const target =
      (moving ? 0.12 : 0) +
      Math.abs(Math.sin(u.stride + i * 0.5)) * u.gait * 0.2 +
      Math.min(0.2, Math.abs(p.vy || 0) * 0.012);
    tail.rotation.x += (-target - tail.rotation.x) * alpha;
    tail.rotation.z = (i ? 1 : -1) * (0.035 + u.gait * 0.08);
  });
  u.head.rotation.x = p.pitch;
  u.rig.rotation.x = p.crouching ? 0.18 : 0;
  u.rig.position.y = p.crouching ? -0.25 : 0;
}
