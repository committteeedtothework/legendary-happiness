import { test, expect } from "@playwright/test";
import { readFileSync, mkdirSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { createServer } from "node:http";
import { resolve, extname } from "node:path";
const html = readFileSync("dist/DCSMCRAFT-Standalone.html"),
  out = process.env.DCSMCRAFT_WYVERN_ARTIFACTS || "/workspace/artifacts/wyvern";
mkdirSync(out, { recursive: true });
let server, origin;
test.use({ trace: "off" });
test.beforeAll(async () => {
  server = createServer((q, r) => {
    if (q.url.startsWith("/mobile/")) {
      try {
        const base = resolve("dist/mobile"),
          file = resolve(
            base,
            decodeURIComponent(q.url.slice(8)) || "index.html",
          );
        if (!file.startsWith(base + "/")) throw Error("path");
        const types = {
          ".html": "text/html",
          ".js": "application/javascript",
          ".json": "application/json",
          ".webmanifest": "application/manifest+json",
          ".glb": "model/gltf-binary",
          ".mp3": "audio/mpeg",
          ".css": "text/css",
        };
        r.setHeader(
          "Content-Type",
          types[extname(file)] || "application/octet-stream",
        );
        r.end(readFileSync(file));
      } catch {
        r.writeHead(404);
        r.end();
      }
      return;
    }
    r.setHeader("Content-Type", "text/html");
    r.end(html);
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  origin = `http://127.0.0.1:${server.address().port}`;
});
test.afterAll(async () => {
  server?.closeAllConnections();
  if (server) await new Promise((r) => server.close(r));
});
async function boot(page, path = "/wyvern.html") {
  const errors = [],
    external = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (m) => {
    if (/Shader Error|GL_INVALID|WebGLProgram/.test(m.text()))
      errors.push(m.text());
  });
  await page.route("**/*", (r) =>
    r
      .request()
      .url()
      .startsWith(origin + "/")
      ? r.continue()
      : (external.push(r.request().url()), r.abort()),
  );
  await page.addInitScript(() =>
    localStorage.setItem(
      "dcsmcraft-settings",
      JSON.stringify({
        graphics: 1,
        renderDistance: 2,
        distantTerrain: false,
        volume: 0,
        musicEnabled: false,
        ambientSounds: false,
        frameLimit: 30,
        skin: "hero",
      }),
    ),
  );
  await page.goto(origin + path);
  await page.waitForFunction(() => window.dcsmcraft?.initialized);
  await page.locator("[data-action=create]").click();
  await page.locator("[name=seed]").fill("WyvernRelease");
  await page.locator("[name=mode][value=creative]").check();
  await page.locator("[data-action=start-world]").click();
  await page.waitForFunction(() => dcsmcraft.running);
  await page.evaluate(() => {
    const g = dcsmcraft;
    g.pause();
    for (let x = 0; x < 10; x++)
      for (let z = 0; z < 10; z++) {
        g.world.set(x, 199, z, 3);
        for (let y = 200; y < 206; y++) g.world.set(x, y, z, 0);
      }
    Object.assign(g.player, {
      x: 4.5,
      y: 200,
      z: 7,
      yaw: 0,
      pitch: 0,
      onGround: true,
      health: 17,
      hunger: 12,
    });
    g.inventory.slots.fill(null);
    g.inventory.slots[0] = { id: "diamond_sword", count: 1, durability: 500 };
    g.giganto.record.portal = {
      id: "giganto:retained",
      x: 60,
      y: 200,
      z: 60,
      cell: "g:retained",
    };
    g.giganto.record.ledger = ["prior-giganto-win"];
    g.giganto.wyvern.record.portal = {
      id: "wyvern:browser",
      x: 4,
      y: 200,
      z: 4,
      cell: "w:browser",
    };
    g.giganto.overworld(0.01);
    if (g.touch?.mobile) g.touch.activate();
    g.resume();
  });
  if (path.startsWith("/mobile"))
    await page.locator('[data-touch="use"]').tap({ timeout: 15000 });
  else await page.keyboard.press("KeyE");
  await page.waitForFunction(
    () =>
      dcsmcraft.giganto.active &&
      !dcsmcraft.giganto.pending &&
      dcsmcraft.giganto.view?.assetsReady,
    null,
    { timeout: 90000 },
  );
  await freeze(page);
  return { errors, external };
}
async function freeze(page) {
  await page.evaluate(() => {
    dcsmcraft.running = false;
    document.exitPointerLock?.();
  });
  await page.waitForTimeout(150);
  await page.evaluate(() => {
    dcsmcraft.ui.play();
    dcsmcraft.pointerLockFallback = true;
    dcsmcraft.running = false;
  });
}
async function capture(page, name) {
  await page.evaluate(() => {
    const e = dcsmcraft.giganto;
    e.controls.clear();
    for (let i = 0; i < 8; i++) e.view.draw(e.session, 0.2);
    e.updateHUD();
    e.hud.hidden = false;
  });
  await page.screenshot({ path: `${out}/${name}.png` });
}
async function advance(page, kind) {
  return page.evaluate((kind) => {
    const g = dcsmcraft,
      e = g.giganto,
      s = e.session,
      draw = e.view.draw,
      hud = e.updateHUD;
    e.view.draw = () => {};
    e.updateHUD = () => {};
    g.ui.play();
    g.pointerLockFallback = true;
    g.running = false;
    let ticks = 0;
    const step = () => {
      g.running = true;
      g.elapsed += 1 / 60;
      e.frame(1 / 60);
      g.running = false;
      ticks++;
    };
    const walk = (target) => {
      for (let i = 0; i < 900; i++) {
        const p = s.avatar,
          dx = target.x - p.x,
          dz = target.z - p.z;
        if (Math.hypot(dx, dz) < 0.7) return;
        p.yaw = Math.atan2(-dx, -dz);
        e.controls = new Set(["KeyW"]);
        step();
      }
      throw Error("Tower walk failed " + JSON.stringify(s.avatar));
    };
    try {
      if (kind === "traverse") {
        while (s.stage === "intro" && ticks < 500) step();
        walk({ x: -51, z: 42 });
        for (let i = 3; i <= 192; i += 3) {
          const u = i / 192,
            a = -u * Math.PI * 6;
          walk({ x: -68 + Math.cos(a) * 17, z: 42 + Math.sin(a) * 17 });
        }
        e.controls.clear();
        if (!e.input("homing")) throw Error("Tower launch rejected");
        while (s.wyvern.section === "boarding" && ticks < 5000) step();
        while (s.wyvern.section === "runway" && ticks < 8000) {
          for (let i = 0; i < 3; i++)
            if (s.wyvern.gate <= i && [112, 255, 398][i] - s.wyvern.rail < 15)
              e.input("homing");
          e.controls = new Set(["ShiftLeft"]);
          step();
        }
        e.controls = new Set(["KeyW"]);
        while (s.stage === "traversal" && ticks < 8500) step();
        e.controls.clear();
        while (s.stage === "transform" && ticks < 9000) step();
      } else if (kind === "fight") {
        const stages = new Set(),
          phases = new Set();
        while (!["victory", "defeat"].includes(s.stage) && ticks < 60 * 420) {
          stages.add(s.stage);
          phases.add(s.phase);
          if (s.qte) {
            const u = (s.qte.age % 3) / 3;
            if (
              (s.qte.kind === "mash" && ticks % 6 === 0) ||
              (s.qte.kind === "timing" && u > 0.56 && u < 0.64)
            )
              e.input("hit");
          }
          if (s.stage === "combat" && s.wyvern.open > 0)
            for (const a of ["cyclone", "rush", "spin", "boom", "cross"])
              if (!s.strike && s.cooldowns[a] <= 0) e.input(a);
          const p = s.avatar,
            dx = -p.x,
            dz = p.z - 26,
            dy = 65 - p.y;
          p.yaw = 0;
          e.controls = new Set(["Mouse2"]);
          if (s.wyvern.open > 0) e.controls.add("Mouse0");
          if (Math.abs(dx) > 0.7) e.controls.add(dx > 0 ? "KeyD" : "KeyA");
          if (Math.abs(dz) > 0.7) e.controls.add(dz > 0 ? "KeyW" : "KeyS");
          if (Math.abs(dy) > 1)
            e.controls.add(dy > 0 ? "Space" : "ControlLeft");
          if (Math.hypot(dx, dz) > 32) e.controls.add("ShiftLeft");
          step();
        }
        window.wyvernJourney = {
          stages: [...stages],
          phases: [...phases],
          ticks,
        };
      } else if (kind === "return") {
        e.controls = new Set(["KeyW"]);
        for (let i = 0; i < 150 && !e.closing; i++) step();
      }
      return {
        stage: s.stage,
        section: s.wyvern.section,
        rings: s.rings,
        hp: s.hp,
        maxHp: s.maxHp,
        ticks,
        journey: window.wyvernJourney,
        position: { ...s.avatar },
        portal: s.returnPortal,
      };
    } finally {
      e.controls.clear();
      e.view.draw = draw;
      e.updateHUD = hud;
      g.running = false;
    }
  }, kind);
}
test("Wyvern portal, physical tower/runway, saved fight, every phase and return preserve the original world and Giganto progress", async ({
  page,
}) => {
  test.setTimeout(240000);
  const ev = await boot(page);
  await capture(page, "wyvern-entrance");
  const route = await advance(page, "traverse");
  console.log("Wyvern traversal", route.stage, route.ticks);
  expect(route.stage).toBe("combat");
  expect(route.rings).toBeGreaterThan(80);
  await capture(page, "wyvern-combat");
  const saved = await page.evaluate(async () => {
    const g = dcsmcraft;
    g.running = false;
    await g.save();
    return {
      id: g.id,
      rings: g.giganto.session.rings,
      hp: g.giganto.session.hp,
      original: g.giganto.session.original,
    };
  });
  await page.evaluate(async (id) => {
    await dcsmcraft.loadWorld(id);
    dcsmcraft.running = false;
  }, saved.id);
  await page.waitForFunction(() => dcsmcraft.giganto.view?.assetsReady);
  await freeze(page);
  expect(
    await page.evaluate(() => ({
      rings: dcsmcraft.giganto.session.rings,
      hp: dcsmcraft.giganto.session.hp,
      titan: dcsmcraft.giganto.session.titan,
    })),
  ).toEqual({ rings: saved.rings, hp: saved.hp, titan: "wyvern" });
  const win = await advance(page, "fight");
  console.log("Wyvern fight", win.stage, win.ticks);
  expect(win.stage).toBe("victory");
  expect(win.journey.phases).toEqual([1, 2]);
  for (const st of [
    "phase",
    "wyvern-volley",
    "wyvern-slam",
    "wyvern-dive",
    "wyvern-mouth",
    "finale",
  ])
    expect(win.journey.stages).toContain(st);
  expect(win.portal.crossed).toBe(false);
  await capture(page, "wyvern-victory");
  await advance(page, "return");
  await page.waitForFunction(() => !dcsmcraft.giganto.active);
  await freeze(page);
  const returned = await page.evaluate(async () => {
    const g = dcsmcraft;
    await g.save();
    return {
      player: {
        x: g.player.x,
        y: g.player.y,
        z: g.player.z,
        health: g.player.health,
        hunger: g.player.hunger,
      },
      sword: g.inventory.slots[0],
      diamonds: g.inventory.slots
        .filter((s) => s?.id === "diamond")
        .reduce((a, s) => a + s.count, 0),
      ledger: g.giganto.record.ledger,
      portal: g.giganto.record.portal,
      wyvern: g.giganto.wyvern.record,
      shadows: g.renderer.gl.shadowMap.enabled,
    };
  });
  expect(returned.player).toEqual({
    x: 4.5,
    y: 200,
    z: 7,
    health: 17,
    hunger: 12,
  });
  expect(returned.sword).toEqual({
    id: "diamond_sword",
    count: 1,
    durability: 500,
  });
  expect(returned.diamonds).toBe(6);
  expect(returned.ledger).toEqual(["prior-giganto-win"]);
  expect(returned.portal.id).toBe("giganto:retained");
  expect(returned.wyvern.ledger).toHaveLength(1);
  expect(returned.wyvern.portal).toBeNull();
  expect(returned.wyvern.cooldownUntil).toBeGreaterThan(0);
  await page.evaluate(async (id) => {
    await dcsmcraft.loadWorld(id);
    dcsmcraft.running = false;
  }, saved.id);
  await freeze(page);
  expect(
    await page.evaluate(() => dcsmcraft.giganto.wyvern.record.ledger.length),
  ).toBe(1);
  expect(
    await page.evaluate(() =>
      dcsmcraft.inventory.slots
        .filter((s) => s?.id === "diamond")
        .reduce((a, s) => a + s.count, 0),
    ),
  ).toBe(6);
  expect(ev.errors).toEqual([]);
  expect(ev.external).toEqual([]);
  writeFileSync(
    out + "/journey-report.json",
    JSON.stringify(
      {
        htmlSHA256: createHash("sha256").update(html).digest("hex"),
        route,
        win,
        returned,
        errors: ev.errors,
      },
      null,
      2,
    ),
  );
});

test("Wyvern reload, pause, defeat/retry, interrupted return and repeated entry keep audio and rewards isolated", async ({
  page,
}) => {
  test.setTimeout(240000);
  const ev = await boot(page);
  await page.evaluate(() => {
    const g = dcsmcraft,
      e = g.giganto,
      s = e.session;
    Object.assign(s, {
      stage: "combat",
      checkpoint: "phase2",
      emerald: true,
      phase: 2,
      hp: s.maxHp * 0.42,
      rings: 180,
    });
    Object.assign(s.avatar, { x: 0, y: 65, z: 26, onGround: false });
    s.wyvern.open = 8;
    s.cooldowns.boom = 3.5;
    s.wyvern.ringIds = ["field:1", "rail:3"];
    e.menu();
  });
  await expect(page.locator(".titan-settings")).toBeVisible();
  expect(await page.locator('[data-titan-config="climbMode"]').count()).toBe(0);
  expect(
    await page.locator('[data-titan-config="shadowQuality"]').count(),
  ).toBe(1);
  const paused = await page.evaluate(async () => {
    const g = dcsmcraft,
      e = g.giganto,
      t = e.session.time;
    g.running = false;
    e.frame(0.1);
    await g.save();
    return { id: g.id, time: e.session.time, t, hp: e.session.hp };
  });
  expect(paused.time).toBe(paused.t);
  await page.evaluate(async (id) => {
    await dcsmcraft.loadWorld(id);
    dcsmcraft.running = false;
  }, paused.id);
  await page.waitForFunction(() => dcsmcraft.giganto.view?.assetsReady);
  await freeze(page);
  expect(
    await page.evaluate(() => ({
      phase: dcsmcraft.giganto.session.phase,
      hp: dcsmcraft.giganto.session.hp,
      cd: dcsmcraft.giganto.session.cooldowns.boom,
      ids: dcsmcraft.giganto.session.wyvern.ringIds,
    })),
  ).toEqual({ phase: 2, hp: paused.hp, cd: 3.5, ids: ["field:1", "rail:3"] });
  await page.evaluate(() => {
    const g = dcsmcraft,
      e = g.giganto,
      s = e.session;
    s.rings = 0.001;
    s.config.drain = 3;
    g.running = true;
    e.frame(1 / 30);
    g.running = false;
  });
  expect(await page.evaluate(() => dcsmcraft.giganto.session.stage)).toBe(
    "defeat",
  );
  await page.evaluate(async () => {
    await dcsmcraft.giganto.button("retry");
    dcsmcraft.running = false;
  });
  await freeze(page);
  expect(
    await page.evaluate(() => ({
      stage: dcsmcraft.giganto.session.stage,
      phase: dcsmcraft.giganto.session.phase,
      rings: dcsmcraft.giganto.session.rings,
    })),
  ).toEqual({ stage: "combat", phase: 2, rings: 220 });
  const rollback = await page.evaluate(async () => {
    const g = dcsmcraft,
      e = g.giganto,
      save = g.save,
      inv = JSON.stringify(g.inventory.export());
    g.save = async () => {
      throw Error("test interrupted write");
    };
    const result = await e.exit();
    g.save = save;
    return {
      result,
      active: e.active,
      titan: e.session.titan,
      inventorySame: inv === JSON.stringify(g.inventory.export()),
      gLedger: e.wyvern.savedGigantoRecord.ledger,
      wLedger: e.record.ledger,
    };
  });
  expect(rollback).toEqual({
    result: false,
    active: true,
    titan: "wyvern",
    inventorySame: true,
    gLedger: ["prior-giganto-win"],
    wLedger: [],
  });
  await page.evaluate(async () => {
    await dcsmcraft.giganto.exit();
    dcsmcraft.running = false;
  });
  await freeze(page);
  expect(await page.evaluate(() => dcsmcraft.giganto.active)).toBe(false);
  expect(
    await page.evaluate(() => dcsmcraft.giganto.wyvern.record.ledger.length),
  ).toBe(0);
  // A second, independent portal entry exercises resource cleanup after a failed return.
  await page.evaluate(() => {
    const g = dcsmcraft,
      e = g.giganto;
    e.wyvern.record.cooldownUntil = 0;
    e.wyvern.record.portal = {
      id: "wyvern:second",
      x: 4,
      y: 200,
      z: 4,
      cell: "w:second",
    };
    e.overworld(0.01);
    g.resume();
  });
  await page.keyboard.press("KeyE");
  await page.waitForFunction(
    () =>
      dcsmcraft.giganto.active &&
      !dcsmcraft.giganto.pending &&
      dcsmcraft.giganto.view?.assetsReady,
  );
  await freeze(page);
  const rendered = await page.evaluate(() => {
    const e = dcsmcraft.giganto,
      s = e.session,
      gl = dcsmcraft.renderer.gl,
      old = {
        tone: gl.toneMapping,
        exposure: gl.toneMappingExposure,
        shadow: gl.shadowMap.enabled,
        target: gl.getRenderTarget(),
      };
    s.stage = "combat";
    s.emerald = true;
    Object.assign(s.avatar, { x: 0, y: 65, z: 26 });
    const frames = [];
    for (const dt of [1 / 30, 1 / 60, 1 / 144]) {
      for (let i = 0; i < 12; i++) e.view.draw(s, dt);
      frames.push(e.view.sonic.scale.toArray());
    }
    return {
      frames,
      stable:
        old.tone === gl.toneMapping &&
        old.exposure === gl.toneMappingExposure &&
        old.shadow === gl.shadowMap.enabled &&
        old.target === gl.getRenderTarget(),
      bones: e.view.boss.userData.mixer?.getRoot()?.name || e.view.boss.name,
    };
  });
  expect(rendered.stable).toBe(true);
  for (const scale of rendered.frames)
    expect(scale.every(Number.isFinite)).toBe(true);
  await page.evaluate(async () => {
    await dcsmcraft.giganto.exit();
    dcsmcraft.running = false;
  });
  await freeze(page);
  // Enter the pre-existing Giganto portal after two Wyvern sessions.
  await page.evaluate(() => {
    const g = dcsmcraft,
      e = g.giganto;
    for (let x = 56; x < 66; x++)
      for (let z = 56; z < 66; z++) {
        g.world.set(x, 199, z, 3);
        for (let y = 200; y < 206; y++) g.world.set(x, y, z, 0);
      }
    Object.assign(g.player, { x: 60.5, y: 200, z: 63, yaw: 0, onGround: true });
    e.overworld(0.01);
    g.resume();
  });
  await page.keyboard.press("KeyE");
  await page.waitForFunction(
    () =>
      dcsmcraft.giganto.active &&
      !dcsmcraft.giganto.pending &&
      dcsmcraft.giganto.view?.assetsReady,
  );
  await freeze(page);
  expect(
    await page.evaluate(() => dcsmcraft.giganto.session.titan || "giganto"),
  ).toBe("giganto");
  await expect(page.locator(".titan-title")).toHaveText("GIGANTO");
  await page.evaluate(async () => {
    await dcsmcraft.giganto.exit();
    dcsmcraft.running = false;
  });
  expect(ev.errors).toEqual([]);
  expect(ev.external).toEqual([]);
  writeFileSync(
    out + "/reliability-report.json",
    JSON.stringify({ rollback, rendered, errors: ev.errors }, null, 2),
  );
});

test.describe("Wyvern mobile", () => {
  test.use({
    viewport: { width: 844, height: 390 },
    hasTouch: true,
    isMobile: true,
    deviceScaleFactor: 1,
    userAgent:
      "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Version/17.0 Mobile Safari/604.1",
  });
  test("the mobile asset build enters Wyvern and touch controls dispatch flight, combat, parry and pause", async ({
    page,
  }) => {
    test.setTimeout(180000);
    const ev = await boot(page, "/mobile/");
    await page.evaluate(() => {
      const g = dcsmcraft,
        e = g.giganto,
        s = e.session;
      Object.assign(s, { stage: "combat", emerald: true, stageTime: 10 });
      Object.assign(s.avatar, { x: 0, y: 65, z: 26, onGround: false });
      s.wyvern.open = 10;
      s.config.graphicsQuality = "low";
      s.config.shadowQuality = "off";
      s.config.postProcessing = false;
      s.config.drain = 0;
      window.wyvernTouchActions = [];
      const input = e.input.bind(e);
      e.input = (a) => {
        wyvernTouchActions.push(a);
        return input(a);
      };
      g.resume();
    });
    await expect(page.locator('[data-touch="boost"]')).toBeVisible();
    await page.locator('[data-touch="attack"]').tap();
    await page.locator('[data-touch="dodge"]').tap();
    await page.locator('[data-touch="actions"]').tap();
    await page.locator('[data-touch="boom"]').tap();
    expect(await page.evaluate(() => wyvernTouchActions)).toEqual(
      expect.arrayContaining(["hit", "dodge", "boom"]),
    );
    await page.locator('[data-touch="pause"]').tap();
    await expect(page.locator('[data-titan="resume"]')).toBeVisible();
    expect(await page.evaluate(() => dcsmcraft.running)).toBe(false);
    await page.screenshot({ path: out + "/wyvern-touch.png" });
    await page.evaluate(async () => {
      await dcsmcraft.giganto.exit();
      dcsmcraft.running = false;
    });
    expect(ev.errors).toEqual([]);
    expect(ev.external).toEqual([]);
  });
});
