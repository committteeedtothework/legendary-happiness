import * as T from "three";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
import { SMAAPass } from "three/addons/postprocessing/SMAAPass.js";
import {
  prepareWyvernModels,
  makeWyvernRig,
  animateWyvern,
} from "./wyvern-model.js";
import {
  importedRig,
  updateImportedSonic,
  disposeImportedRig,
} from "./titan-imports.js";
import {
  TitanTransformationView,
  makeChaosEmerald,
  sonicSuper,
} from "./titan-transformation.js";
import { TitanImpactFX } from "./titan-impact-fx.js";
import { GrassCyloopView } from "./titan-grass-cyloop-view.js";
import { TitanCombatFlare } from "./titan-combat-flare.js";
import { titanPortal, animateTitanPortal } from "./giganto-view.js";
import { arenaQuality } from "./titan-settings.js";
import {
  clamp,
  ease,
  WYVERN_TOWER,
  TOWER,
  runwayPoint,
  wyvernGround,
  wyvernBattleRing,
  W_HEAD,
} from "./wyvern-space.js";
import { WYVERN_GAPS, WYVERN_HAZARDS } from "./wyvern-simulation.js";
const v = (p) => new T.Vector3(p.x, p.y, p.z),
  up = new T.Vector3(0, 0, 1);
function joinRibbon(points, width, gaps = []) {
  const positions = [],
    uvs = [];
  for (let i = 0; i < points.length - 1; i++) {
    const a = points[i],
      b = points[i + 1];
    if (gaps.some(([lo, hi]) => a.t >= lo && a.t < hi)) continue;
    const n = new T.Vector3(b.z - a.z, 0, a.x - b.x)
        .normalize()
        .multiplyScalar(width / 2),
      corners = [
        [a.x + n.x, a.y, a.z + n.z],
        [a.x - n.x, a.y, a.z - n.z],
        [b.x + n.x, b.y, b.z + n.z],
        [b.x - n.x, b.y, b.z - n.z],
      ];
    for (const k of [0, 1, 2, 2, 1, 3]) {
      positions.push(...corners[k]);
      uvs.push(k % 2, i / 10);
    }
  }
  const g = new T.BufferGeometry();
  g.setAttribute("position", new T.Float32BufferAttribute(positions, 3));
  g.setAttribute("uv", new T.Float32BufferAttribute(uvs, 2));
  g.computeVertexNormals();
  return g;
}
function sandTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 256;
  const ctx = c.getContext("2d"),
    image = ctx.createImageData(256, 256);
  for (let i = 0; i < 256 * 256; i++) {
    const x = i % 256,
      y = Math.floor(i / 256),
      n = (((Math.sin(x * 127.1 + y * 311.7) * 43758.5453) % 1) + 1) % 1,
      r = Math.sin(y * 0.25 + Math.sin(x * 0.03) * 3) * 4 + n * 12;
    image.data.set([174 + r, 139 + r * 0.8, 91 + r * 0.6, 255], i * 4);
  }
  ctx.putImageData(image, 0, 0);
  const t = new T.CanvasTexture(c);
  t.wrapS = t.wrapT = T.RepeatWrapping;
  t.repeat.set(70, 70);
  t.colorSpace = T.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}
function cloudTexture() {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 128;
  const ctx = c.getContext("2d");
  for (let i = 0; i < 14; i++) {
    const x = 30 + ((i * 43) % 190),
      y = 40 + Math.sin(i * 2.4) * 20,
      g = ctx.createRadialGradient(x, y, 2, x, y, 30 + (i % 3) * 8);
    g.addColorStop(0, "rgba(255,246,231,.48)");
    g.addColorStop(1, "rgba(255,250,245,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 256, 128);
  }
  const t = new T.CanvasTexture(c);
  t.colorSpace = T.SRGBColorSpace;
  return t;
}
export class WyvernView {
  constructor(game) {
    this.game = game;
    this.scene = new T.Scene();
    this.scene.background = new T.Color("#9ec7de");
    this.scene.fog = new T.FogExp2("#d9bf95", 0.0009);
    this.camera = new T.PerspectiveCamera(67, 1, 0.12, 2400);
    this.camera.position.set(115, 105, 220);
    this.look = new T.Vector3(0, 55, 0);
    this.scene.add(new T.HemisphereLight("#d3edff", "#815c3c", 1.7));
    this.light = new T.DirectionalLight("#fff1d0", 3.5);
    this.light.position.set(-140, 230, 100);
    this.light.target.position.set(0, 40, 0);
    this.scene.add(this.light, this.light.target);
    Object.assign(this.light.shadow.camera, {
      left: -140,
      right: 140,
      top: 140,
      bottom: -140,
      near: 1,
      far: 600,
    });
    this.light.shadow.camera.updateProjectionMatrix();
    this.light.shadow.bias = -0.00012;
    this.light.shadow.normalBias = 0.055;
    this.rim = new T.DirectionalLight("#88c8fa", 1.1);
    this.rim.position.set(100, 50, -150);
    this.scene.add(this.rim);
    this.pmrem = new T.PMREMGenerator(game.renderer.gl);
    const room = new RoomEnvironment();
    this.env = this.pmrem.fromScene(room, 0.05);
    room.dispose();
    this.scene.environment = this.env.texture;
    this.land = new T.Group();
    this.scene.add(this.land);
    this.makeLandscape();
    this.tower = new T.Group();
    this.scene.add(this.tower);
    const mat = new T.MeshStandardMaterial({
      color: "#484b50",
      roughness: 0.72,
      metalness: 0.28,
    });
    const core = new T.Mesh(new T.CylinderGeometry(9, 13, 80, 8), mat);
    core.position.set(TOWER.x, 40, TOWER.z);
    core.castShadow = core.receiveShadow = true;
    this.tower.add(core);
    const ramp = new T.Mesh(
      joinRibbon(WYVERN_TOWER, 7.2),
      new T.MeshStandardMaterial({
        color: "#59616a",
        roughness: 0.68,
        side: T.DoubleSide,
      }),
    );
    ramp.receiveShadow = ramp.castShadow = true;
    this.tower.add(ramp);
    const cap = new T.Mesh(new T.CylinderGeometry(21, 18, 3, 12), mat);
    cap.position.set(TOWER.x, 78.5, TOWER.z);
    cap.castShadow = cap.receiveShadow = true;
    this.tower.add(cap);
    for (let i = 0; i < 5; i++) {
      const ring = new T.Mesh(
        new T.TorusGeometry(12 + i * 0.7, 0.15, 5, 48),
        new T.MeshBasicMaterial({
          color: i % 2 ? "#c94462" : "#65d4e8",
          toneMapped: false,
        }),
      );
      ring.rotation.x = Math.PI / 2;
      ring.position.set(TOWER.x, 12 + i * 15, TOWER.z);
      this.tower.add(ring);
    }
    const railPoints = Array.from({ length: 241 }, (_, i) => ({
      ...runwayPoint(i * 2),
      t: i * 2,
    }));
    this.runway = new T.Mesh(
      joinRibbon(
        railPoints,
        18,
        WYVERN_GAPS.map((t) => [t, t + 15]),
      ),
      new T.MeshStandardMaterial({
        color: "#902c4d",
        emissive: "#e62058",
        emissiveIntensity: 0.65,
        roughness: 0.4,
        metalness: 0.2,
        side: T.DoubleSide,
      }),
    );
    this.scene.add(this.runway);
    this.bars = [];
    for (const t of WYVERN_GAPS) {
      const q = runwayPoint(t - 7),
        bar = new T.Group();
      const b = new T.Mesh(
        new T.CylinderGeometry(0.28, 0.28, 14, 8),
        new T.MeshBasicMaterial({ color: "#ff5977", toneMapped: false }),
      );
      b.rotation.z = Math.PI / 2;
      bar.add(b);
      const ring = new T.Mesh(new T.TorusGeometry(4, 0.11, 5, 32), b.material);
      bar.add(ring);
      bar.position.copy(v(q)).add(new T.Vector3(0, 5, 0));
      this.scene.add(bar);
      this.bars.push(bar);
    }
    this.hazards = WYVERN_HAZARDS.map((h) => {
      const m = new T.Mesh(
        new T.IcosahedronGeometry(1.1, 1),
        new T.MeshStandardMaterial({
          color: "#ff6694",
          emissive: "#ef225b",
          emissiveIntensity: 2,
        }),
      );
      m.position
        .copy(v(runwayPoint(h.t, h.lane)))
        .add(new T.Vector3(0, 1.5, 0));
      this.scene.add(m);
      return m;
    });
    this.rings = [];
    const ringGeo = new T.TorusGeometry(0.65, 0.16, 6, 20),
      ringMat = new T.MeshStandardMaterial({
        color: "#ffce3b",
        emissive: "#875100",
        emissiveIntensity: 0.25,
        metalness: 0.68,
        roughness: 0.25,
      });
    const addRing = (id, p) => {
      const m = new T.Mesh(ringGeo, ringMat);
      m.position.copy(v(p)).add(new T.Vector3(0, 1.4, 0));
      m.userData.id = id;
      this.scene.add(m);
      this.rings.push(m);
    };
    for (let i = 0; i < WYVERN_TOWER.length; i += 8)
      addRing("tower:" + i, WYVERN_TOWER[i]);
    for (let i = 1; i <= 13; i++)
      addRing("rail:" + i, runwayPoint(i * 34, (i % 3) - 1));
    for (let i = 0; i < 12; i++) {
      const a = (i * Math.PI) / 6,
        x = -20 + Math.sin(a) * 22,
        z = 65 + Math.cos(a) * 22;
      addRing("field:" + i, { x, y: wyvernGround(x, z), z });
    }
    this.battleRings = Array.from({ length: 3 }, () => {
      const m = new T.Mesh(ringGeo, ringMat);
      this.scene.add(m);
      return m;
    });
    this.emerald = makeChaosEmerald("#24d79b");
    this.emerald.position.set(0, 75, 0);
    this.scene.add(this.emerald);
    this.returnGate = titanPortal();
    this.returnGate.visible = false;
    this.scene.add(this.returnGate);
    this.impacts = new TitanImpactFX(this.scene);
    this.flare = new TitanCombatFlare(this.scene);
    this.grass = new GrassCyloopView(this.scene);
    this.transformation = new TitanTransformationView(this.scene);
    this.projectilePool = new T.InstancedMesh(
      new T.ConeGeometry(0.45, 2.5, 6).rotateX(Math.PI / 2),
      new T.MeshStandardMaterial({
        color: "#d8c8bc",
        emissive: "#e83152",
        emissiveIntensity: 1.4,
        metalness: 0.7,
        roughness: 0.4,
      }),
      32,
    );
    this.projectilePool.frustumCulled = false;
    this.scene.add(this.projectilePool);
    this.energyPool = new T.InstancedMesh(
      new T.TorusGeometry(1, 0.12, 5, 24),
      new T.MeshBasicMaterial({
        color: "#7fddff",
        transparent: true,
        opacity: 0.85,
        blending: T.AdditiveBlending,
        depthWrite: false,
        toneMapped: false,
      }),
      12,
    );
    this.energyPool.frustumCulled = false;
    this.scene.add(this.energyPool);
    this.lasers = Array.from({ length: 4 }, () => {
      const g = new T.Group(),
        m = new T.MeshBasicMaterial({
          color: "#f73d66",
          transparent: true,
          opacity: 0.7,
          blending: T.AdditiveBlending,
          depthWrite: false,
          toneMapped: false,
        });
      g.add(new T.Mesh(new T.TorusGeometry(12, 0.25, 6, 64), m));
      const face = new T.Mesh(new T.CircleGeometry(12, 48), m.clone());
      face.material.opacity = 0.055;
      g.add(face);
      this.scene.add(g);
      return g;
    });
    this.aura = new T.Mesh(
      new T.SphereGeometry(2.5, 20, 12),
      new T.MeshBasicMaterial({
        color: "#ffe579",
        transparent: true,
        opacity: 0.06,
        blending: T.AdditiveBlending,
        depthWrite: false,
        toneMapped: false,
      }),
    );
    this.scene.add(this.aura);
    this.particles = [];
    this.particlePool = new T.InstancedMesh(
      new T.IcosahedronGeometry(1, 0),
      new T.MeshBasicMaterial({
        color: "#ffe8a6",
        transparent: true,
        opacity: 0.8,
        blending: T.AdditiveBlending,
        depthWrite: false,
        toneMapped: false,
      }),
      192,
    );
    this.particlePool.frustumCulled = false;
    this.scene.add(this.particlePool);
    this.dummy = new T.Object3D();
    this.assetsReady = false;
    this.ready = prepareWyvernModels()
      .then(({ sonic, gltf }) => {
        if (this.disposed) return;
        this.sonic = importedRig(sonic);
        this.boss = makeWyvernRig(gltf);
        this.scene.add(this.sonic, this.boss);
        this.assetsReady = true;
      })
      .catch((e) => {
        this.assetError = e.message;
        console.error("Wyvern assets", e);
      });
  }
  makeLandscape() {
    const sand = sandTexture();
    this.sandTexture = sand;
    const material = new T.MeshStandardMaterial({
      map: sand,
      color: "#d5b487",
      roughness: 0.96,
    });
    this.ground = [];
    for (const segments of [64, 128]) {
      const g = new T.PlaneGeometry(2200, 2200, segments, segments);
      g.rotateX(-Math.PI / 2);
      const p = g.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const x = p.getX(i),
          z = p.getZ(i),
          edge = clamp((Math.hypot(x, z) - 150) / 180, 0, 1);
        p.setY(
          i,
          wyvernGround(x, z) +
            edge *
              (Math.sin(x * 0.013 + Math.cos(z * 0.008)) * 9 +
                Math.cos(z * 0.018) * 7),
        );
      }
      g.computeVertexNormals();
      const m = new T.Mesh(g, material);
      m.receiveShadow = true;
      this.land.add(m);
      this.ground.push(m);
    }
    const strataCanvas = document.createElement("canvas");
    strataCanvas.width = strataCanvas.height = 256;
    const ctx = strataCanvas.getContext("2d"),
      pixels = ctx.createImageData(256, 256);
    for (let i = 0; i < 65536; i++) {
      const x = i % 256,
        y = i >> 8,
        n =
          Math.sin(y * 0.25 + Math.sin(x * 0.02)) * 0.1 +
          Math.sin(y * 1.3) * 0.035 +
          Math.sin(x * 9.71 + y * 19.3) * 0.02;
      pixels.data.set([126 + n * 100, 111 + n * 88, 93 + n * 75, 255], i * 4);
    }
    ctx.putImageData(pixels, 0, 0);
    this.rockTexture = new T.CanvasTexture(strataCanvas);
    this.rockTexture.colorSpace = T.SRGBColorSpace;
    this.rockTexture.wrapS = this.rockTexture.wrapT = T.RepeatWrapping;
    const rockMat = new T.MeshStandardMaterial({
        map: this.rockTexture,
        bumpMap: this.rockTexture,
        bumpScale: 0.22,
        roughness: 0.91,
      }),
      rockGeo = new T.CylinderGeometry(0.8, 1.1, 1, 16, 10);
    const positions = rockGeo.attributes.position;
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i),
        y = positions.getY(i),
        z = positions.getZ(i),
        r =
          1 +
          Math.sin(y * 31) * 0.035 +
          Math.sin(Math.atan2(z, x) * 7 + y * 4) * 0.055;
      positions.setX(i, x * r);
      positions.setZ(i, z * r);
    }
    rockGeo.computeVertexNormals();
    this.rocks = new T.InstancedMesh(rockGeo, rockMat, 110);
    const d = new T.Object3D();
    for (let i = 0; i < 110; i++) {
      const a = i * 2.399963,
        r = 250 + (i % 9) * 68;
      d.position.set(Math.sin(a) * r, 12 + (i % 6) * 4, Math.cos(a) * r);
      d.rotation.set(i * 0.13, a, i * 0.07);
      d.scale.set(25 + (i % 6) * 7, 40 + (i % 7) * 12, 32 + (i % 5) * 8);
      d.updateMatrix();
      this.rocks.setMatrixAt(i, d.matrix);
    }
    this.rocks.castShadow = this.rocks.receiveShadow = true;
    this.land.add(this.rocks);
    const pillarMat = new T.MeshStandardMaterial({
      color: "#535b60",
      roughness: 0.72,
      metalness: 0.3,
    });
    this.ruins = new T.InstancedMesh(new T.BoxGeometry(1, 1, 1), pillarMat, 36);
    for (let i = 0; i < 36; i++) {
      const a = i * 2.7,
        r = 160 + (i % 5) * 55;
      d.position.set(Math.sin(a) * r, 7 + (i % 4) * 4, Math.cos(a) * r);
      d.rotation.set(0, a, 0.05 * (i % 3));
      d.scale.set(5, 15 + (i % 4) * 8, 5);
      d.updateMatrix();
      this.ruins.setMatrixAt(i, d.matrix);
    }
    this.ruins.castShadow = this.ruins.receiveShadow = true;
    this.land.add(this.ruins);
    this.cloudTexture = cloudTexture();
    this.clouds = [];
    for (let i = 0; i < 18; i++) {
      const m = new T.Mesh(
        new T.PlaneGeometry(190 + (i % 3) * 90, 80 + (i % 4) * 25),
        new T.MeshBasicMaterial({
          map: this.cloudTexture,
          transparent: true,
          opacity: 0.65,
          depthWrite: false,
          side: T.DoubleSide,
          toneMapped: false,
        }),
      );
      const a = i * 2.4;
      m.position.set(
        Math.sin(a) * (450 + i * 15),
        220 + (i % 5) * 38,
        Math.cos(a) * (450 + i * 15),
      );
      m.userData.origin = m.position.clone();
      this.scene.add(m);
      this.clouds.push(m);
    }
  }
  event(e, s) {
    this.impacts.event(e, s);
    this.flare.event?.(e, s);
    if (
      [
        "hit",
        "parry",
        "counter",
        "qte-win",
        "wyvern-explosion",
        "impact",
      ].includes(e.type)
    ) {
      const p = e.point || s.avatar,
        count =
          e.type === "wyvern-explosion" ? 150 : e.type === "parry" ? 22 : 12;
      for (let i = 0; i < count; i++) {
        const a = i * 2.399963,
          fast = e.type === "wyvern-explosion" ? 30 : 8;
        this.particles.push({
          x: p.x,
          y: p.y,
          z: p.z,
          vx: Math.sin(a) * fast,
          vy: Math.cos(i * 1.7) * fast + 3,
          vz: Math.cos(a) * fast,
          life: e.type === "wyvern-explosion" ? 2.5 : 0.55,
          initial: e.type === "wyvern-explosion" ? 2.5 : 0.55,
          size: e.type === "wyvern-explosion" ? 2 : 0.16,
        });
      }
      this.particles = this.particles.slice(-192);
      this.shake = Math.max(
        this.shake || 0,
        e.type === "wyvern-explosion" ? 1 : e.type === "impact" ? 0.6 : 0.15,
      );
    }
  }
  draw(s, dt) {
    if (!this.assetsReady || this.disposed) return;
    const gl = this.game.renderer.gl,
      p = s.avatar,
      w = s.wyvern,
      quality = arenaQuality(s.config, this.game.settings);
    this.heading = ((((p.yaw * 180) / Math.PI) % 360) + 360) % 360;
    const pose =
      s.stage.startsWith("wyvern-") || s.stage === "finale"
        ? {
            ...s,
            stage: "combat",
            action: s.qte
              ? "idle"
              : s.stage === "wyvern-slam"
                ? "counter"
                : "homing",
            actionTime: 0.5,
          }
        : s;
    updateImportedSonic(this.sonic, pose, dt);
    animateWyvern(this.boss, s, dt);
    this.transformation.update(s, this.sonic);
    this.grass.update(s);
    this.impacts.update(s);
    this.flare.update(s, quality);
    this.aura.visible = sonicSuper(s) && s.config.particles;
    this.aura.position.copy(this.sonic.position).add(new T.Vector3(0, 1.7, 0));
    this.aura.scale.setScalar(1 + Math.sin(s.time * 8) * 0.03);
    this.emerald.visible = !s.emerald && w.section === "emerald";
    this.emerald.rotation.y = s.time;
    this.emerald.position.y = 75 + Math.sin(s.time * 2) * 0.18;
    this.runway.visible = !s.emerald;
    this.tower.visible = s.stage === "intro" || s.stage === "traversal";
    this.bars.forEach((b, i) => {
      b.visible = !s.emerald;
      b.rotation.z = s.time * 2 + i;
    });
    this.hazards.forEach((h, i) => {
      h.visible = !s.emerald && !w.hitHazards.includes(i);
      h.rotation.y = s.time * 2;
    });
    for (const m of this.rings) {
      m.visible = !s.emerald && !w.ringIds.includes(m.userData.id);
      m.rotation.y = s.time * 1.8;
    }
    this.battleRings.forEach((m, i) => {
      const q = wyvernBattleRing(s, i);
      m.visible = s.stage === "combat" && !w.ringIds.includes(q.id);
      m.position.set(q.x, q.y, q.z);
      m.rotation.y = s.time * 2;
    });
    this.ground[0].visible = quality < 2;
    this.ground[1].visible = quality >= 2;
    this.rocks.count = quality < 2 ? 45 : quality === 2 ? 80 : 110;
    this.ruins.count = quality < 2 ? 16 : 36;
    const skyTime = w.skyFreeze ?? s.time,
      phase = s.config.dynamicSky
        ? (skyTime / (s.config.arenaDayLength || 240)) * Math.PI * 2
        : 0;
    this.light.intensity = 3.2 + Math.cos(phase) * 0.4;
    this.light.color.setHSL(0.1, 0.24, 0.88);
    this.scene.background.setHSL(0.56, 0.38, 0.7 + Math.cos(phase) * 0.035);
    this.clouds.forEach((m, i) => {
      m.visible = s.config.atmosphere !== false && i < (quality < 2 ? 8 : 18);
      m.position.copy(m.userData.origin);
      m.position.x += Math.sin(skyTime * 0.015 + i) * 30;
      m.quaternion.copy(this.camera.quaternion);
    });
    this.land.rotation.y = s.emerald ? -(w.skyFreeze ?? s.time) * 0.08 : 0;
    this.rocks.rotation.y =
      s.emerald && !s.won
        ? Math.sin(s.time * 0.018) * 0.025
        : this.rocks.rotation.y;
    let desired, focus;
    if (s.stage === "intro") {
      const a = ease(s.stageTime / 5);
      desired = new T.Vector3(135 - a * 65, 105 - a * 22, 200 - a * 70);
      focus = new T.Vector3(-18, 58, 0);
    } else if (s.stage === "traversal" && w.section === "runway") {
      const q = runwayPoint(w.rail + 18, w.lane);
      const behind = v(p).sub(v(q)).setY(0).normalize().multiplyScalar(17);
      desired = v(p)
        .add(behind)
        .add(new T.Vector3(-3, 6, 0));
      focus = v(q).add(new T.Vector3(0, 2, 0));
    } else if (s.stage === "transform") {
      const a = ease(s.stageTime / 6),
        r = 8 + Math.sin(a * Math.PI) * 4;
      desired = v(p).add(
        new T.Vector3(Math.sin(a * 3) * r, 3 + a * 2, Math.cos(a * 3) * r),
      );
      focus = v(p).add(new T.Vector3(0, 1.8, 0));
    } else if (s.stage === "phase") {
      const a = ease(s.stageTime / 5);
      desired = new T.Vector3(110, 100, 150 - a * 130);
      focus = new T.Vector3(0, 65, -25);
    } else if (s.stage === "wyvern-slam") {
      const a = ease(s.stageTime / 5.5);
      desired = new T.Vector3(130 - a * 30, 95, 155 - a * 65);
      focus = new T.Vector3(0, 60, -35);
    } else if (s.qte) {
      desired = v(p).add(new T.Vector3(12, 8, 22));
      focus = v(p).lerp(new T.Vector3(0, 66, 0), 0.3);
    } else if (s.stage === "finale") {
      const a = ease(s.stageTime / 7);
      desired = new T.Vector3(30 + a * 45, 78 + a * 12, 60 + a * 50);
      focus = new T.Vector3(0, 66, -10);
    } else {
      const distance = s.emerald
        ? s.strike && s.config.moveCamera
          ? 12
          : 20
        : 9;
      desired = v(p).add(
        new T.Vector3(
          Math.sin(p.yaw) * distance + 4,
          4.5 + p.pitch * 9,
          Math.cos(p.yaw) * distance,
        ),
      );
      focus = v(p).add(new T.Vector3(0, 1.7, 0));
      if (s.emerald && s.lock && !s.won)
        focus.lerp(new T.Vector3(0, 66, 0), 0.3);
    }
    const rad = Math.hypot(desired.x - TOWER.x, desired.z - TOWER.z);
    if (this.tower.visible && rad < 13 && desired.y < 82) {
      desired.x =
        TOWER.x + ((desired.x - TOWER.x) / Math.max(0.01, rad)) * 13.5;
      desired.z =
        TOWER.z + ((desired.z - TOWER.z) / Math.max(0.01, rad)) * 13.5;
    }
    desired.y = Math.max(desired.y, wyvernGround(desired.x, desired.z) + 2);
    const a = dt > 0 ? 1 - Math.exp(-dt * 5) : this.lastDrawn ? 0 : 1;
    this.camera.position.lerp(desired, a);
    this.look.lerp(focus, a);
    this.shake = Math.max(0, (this.shake || 0) - dt * 3);
    if (this.shake && s.config.cameraShake) {
      this.camera.position.x +=
        Math.sin(s.time * 90) * this.shake * s.config.cameraShake * 0.1;
    }
    this.camera.lookAt(this.look);
    this.camera.aspect =
      Math.max(1, gl.domElement.clientWidth) /
      Math.max(1, gl.domElement.clientHeight);
    this.camera.fov = s.config.cameraFov || 67;
    this.camera.updateProjectionMatrix();
    this.camera.updateMatrixWorld();
    this.lastDrawn = true;
    const target = new T.Vector3(0, 66, 0).project(this.camera);
    this.targetScreen = {
      x: target.x * 0.5 + 0.5,
      y: -target.y * 0.5 + 0.5,
      visible:
        Math.abs(target.x) < 1 &&
        Math.abs(target.y) < 1 &&
        target.z > 0 &&
        target.z < 1,
    };
    this.damageScreen = this.targetScreen;
    const d = this.dummy,
      missiles = [];
    for (const m of w.missiles) {
      const u = clamp(m.age / m.eta, 0, 1),
        from = m.reflected ? m.target : m.from,
        to = m.reflected ? m.from : m.target;
      missiles.push({
        x:
          T.MathUtils.lerp(from.x, to.x, u) +
          Math.sin(u * Math.PI) * Math.sin(m.id) * 5,
        y: T.MathUtils.lerp(from.y, to.y, u) + Math.sin(u * Math.PI) * 4,
        z: T.MathUtils.lerp(from.z, to.z, u),
        dir: v(to).sub(v(from)).normalize(),
      });
    }
    if (s.stage === "wyvern-volley" || s.stage === "finale")
      for (let i = 0; i < 16; i++) {
        const angle = (i * Math.PI) / 8 + s.time * 0.3,
          r = s.stage === "finale" ? Math.max(0, 18 - s.stageTime * 5) : 18;
        missiles.push({
          x: p.x + Math.cos(angle) * r,
          y: p.y + 4 + Math.sin(angle) * r * 0.5,
          z: p.z + Math.sin(angle) * r,
          dir: new T.Vector3(-Math.cos(angle), 0, -Math.sin(angle)),
        });
      }
    this.projectilePool.count = Math.min(32, missiles.length);
    missiles.slice(0, 32).forEach((m, i) => {
      d.position.set(m.x, m.y, m.z);
      d.quaternion.setFromUnitVectors(up, m.dir);
      d.scale.setScalar(1);
      d.updateMatrix();
      this.projectilePool.setMatrixAt(i, d.matrix);
    });
    this.projectilePool.instanceMatrix.needsUpdate = true;
    this.energyPool.count = Math.min(12, s.projectiles.length);
    s.projectiles.slice(0, 12).forEach((q, i) => {
      d.position.set(q.x, q.y, q.z);
      d.quaternion.setFromUnitVectors(
        up,
        new T.Vector3(q.vx, q.vy, q.vz).normalize(),
      );
      d.scale.setScalar(q.kind === "shot" ? 1 : 2.3);
      d.updateMatrix();
      this.energyPool.setMatrixAt(i, d.matrix);
    });
    this.energyPool.instanceMatrix.needsUpdate = true;
    this.lasers.forEach((g, i) => {
      const l = w.lasers[i];
      g.visible = !!l;
      if (l) {
        g.position.set(l.x, l.y, 8 + (Math.max(0, l.age - 1.1) / 2.1) * 112);
        g.scale.setScalar(0.5 + ease(l.age / 0.7) * 0.5);
      }
    });
    this.particles = this.particles.filter((q) => {
      q.life -= dt;
      q.x += q.vx * dt;
      q.y += q.vy * dt;
      q.z += q.vz * dt;
      return q.life > 0;
    });
    this.particlePool.count = s.config.particles
      ? Math.min(quality < 2 ? 64 : 192, this.particles.length)
      : 0;
    this.particles.slice(-this.particlePool.count).forEach((q, i) => {
      d.position.set(q.x, q.y, q.z);
      d.quaternion.identity();
      d.scale.setScalar((q.size * q.life) / q.initial);
      d.updateMatrix();
      this.particlePool.setMatrixAt(i, d.matrix);
    });
    this.particlePool.instanceMatrix.needsUpdate = true;
    this.returnGate.visible = s.stage === "victory" && !!s.returnPortal;
    if (this.returnGate.visible) {
      const q = s.returnPortal;
      this.returnGate.position.set(q.x, q.y - 1.8, q.z);
      this.returnGate.rotation.y = Math.atan2(q.nx, q.nz);
      animateTitanPortal(
        this.returnGate,
        s.time,
        s.config.particles,
        s.config.lighting,
      );
    }
    if (this.returnGate.visible) {
      const projected = v(s.returnPortal).project(this.camera);
      this.returnScreen = {
        x: projected.x * 0.5 + 0.5,
        y: -projected.y * 0.5 + 0.5,
        visible:
          Math.abs(projected.x) < 1 &&
          Math.abs(projected.y) < 1 &&
          projected.z > 0 &&
          projected.z < 1,
      };
    } else this.returnScreen = null;
    const old = {
      target: gl.getRenderTarget(),
      tone: gl.toneMapping,
      exposure: gl.toneMappingExposure,
      shadow: gl.shadowMap.enabled,
      auto: gl.autoClear,
    };
    try {
      gl.setRenderTarget(null);
      gl.autoClear = true;
      gl.toneMapping = T.ACESFilmicToneMapping;
      gl.toneMappingExposure = s.config.exposure || 1.05;
      gl.shadowMap.enabled = s.config.shadowQuality !== "off" && quality > 1;
      this.light.castShadow = gl.shadowMap.enabled;
      const size =
        quality >= 3 && s.config.shadowQuality === "high" ? 2048 : 1024;
      if (this.shadowSize !== size) {
        this.light.shadow.map?.dispose();
        this.light.shadow.map = null;
        this.light.shadow.mapSize.set(size, size);
        this.shadowSize = size;
      }
      if (s.config.postProcessing && quality > 1) {
        const w = gl.domElement.width,
          h = gl.domElement.height,
          scale = s.config.renderScale || 1,
          key = [w, h, scale, s.config.antialiasing].join(":");
        if (!this.composer || key !== this.postKey) {
          this.composer?.dispose();
          this.bloom?.dispose();
          this.aa?.dispose();
          this.composer = new EffectComposer(
            gl,
            new T.WebGLRenderTarget(
              Math.max(1, (w * scale) | 0),
              Math.max(1, (h * scale) | 0),
              { type: T.HalfFloatType },
            ),
          );
          this.composer.setPixelRatio(1);
          this.composer.setSize(
            Math.max(1, (w * scale) | 0),
            Math.max(1, (h * scale) | 0),
          );
          this.composer.addPass(new RenderPass(this.scene, this.camera));
          this.bloom = new UnrealBloomPass(
            new T.Vector2(w * scale, h * scale),
            0.2,
            0.4,
            1,
          );
          this.composer.addPass(this.bloom);
          if (s.config.antialiasing) {
            this.aa = new SMAAPass();
            this.composer.addPass(this.aa);
          }
          this.composer.addPass(new OutputPass());
          this.postKey = key;
        }
        this.bloom.strength = s.config.bloomIntensity ?? 0.26;
        this.composer.render(dt);
      } else gl.render(this.scene, this.camera);
    } finally {
      gl.setRenderTarget(old.target);
      gl.toneMapping = old.tone;
      gl.toneMappingExposure = old.exposure;
      gl.shadowMap.enabled = old.shadow;
      gl.autoClear = old.auto;
    }
  }
  dispose() {
    this.disposed = true;
    this.sonic && disposeImportedRig(this.sonic);
    this.boss?.userData.mixer.stopAllAction();
    this.boss?.traverse((o) => o.skeleton?.boneTexture?.dispose());
    this.composer?.dispose();
    this.bloom?.dispose();
    this.aa?.dispose();
    this.env?.dispose();
    this.pmrem?.dispose();
    this.light.shadow.map?.dispose();
    this.sandTexture?.dispose();
    this.cloudTexture?.dispose();
    this.rockTexture?.dispose();
    const geometries = new Set(),
      materials = new Set();
    this.scene.traverse((o) => {
      if (o === this.sonic || this.sonic?.getObjectById(o.id)) return;
      if (o.geometry && !o.geometry.userData.wyvernShared)
        geometries.add(o.geometry);
      for (const m of Array.isArray(o.material)
        ? o.material
        : o.material
          ? [o.material]
          : [])
        materials.add(m);
    });
    for (const g of geometries) g.dispose();
    for (const m of materials) m.dispose();
    this.scene.clear();
  }
}
