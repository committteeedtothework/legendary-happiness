// Canonical boss-space contacts shared by the rendered head and combat engine.
export const W_HEAD = { x: 0, y: 66, z: 0 };
export const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
export const ease = (n) => {
  n = clamp(n, 0, 1);
  return n * n * (3 - 2 * n);
};
export function wyvernPoint(s, p) {
  const y = s.wyvern?.yaw || 0,
    c = Math.cos(y),
    a = Math.sin(y);
  return {
    x: (s.boss?.x || 0) + p.x * c + p.z * a,
    y: W_HEAD.y + p.y,
    z: (s.boss?.z || 0) + p.z * c - p.x * a,
  };
}
export function wyvernRegions(s) {
  return [
    {
      id: "head",
      center: wyvernPoint(s, { x: 0, y: 0, z: 0 }),
      axes: { x: 8, y: 7, z: 22 },
      yaw: s.wyvern?.yaw || 0,
    },
    {
      id: "neck",
      a: wyvernPoint(s, { x: 0, y: -1, z: -7 }),
      b: wyvernPoint(s, { x: 0, y: -2, z: -40 }),
      r: 5,
    },
    {
      id: "left claw",
      a: wyvernPoint(s, { x: 6, y: -2, z: -20 }),
      b: wyvernPoint(s, { x: 14, y: -7, z: -12 }),
      r: 3.5,
    },
    {
      id: "right claw",
      a: wyvernPoint(s, { x: -6, y: -2, z: -20 }),
      b: wyvernPoint(s, { x: -14, y: -7, z: -12 }),
      r: 3.5,
    },
  ];
}
export function wyvernDamageGate(s, emit) {
  if (s.wyvern.open <= 0 || s.qte) {
    emit(s, "block", { point: { ...s.avatar }, amount: 0 });
    return false;
  }
  return true;
}
export function wyvernDamageTransition(s, emit) {
  if (s.phase === 1 && s.hp <= s.maxHp * 0.5) {
    s.hp = s.maxHp * 0.5;
    s.phase = 2;
    s.checkpoint = "phase2";
    s.stage = "phase";
    s.stageTime = 0;
    s.strike = null;
    s.projectiles = [];
    s.wyvern.open = 0;
    s.queuedMove = null;
    emit(s, "stage", { stage: "phase" });
  } else if (
    s.phase === 2 &&
    s.hp <= s.maxHp * 0.12 &&
    !s.wyvern.finaleStarted
  ) {
    s.hp = s.maxHp * 0.12;
    s.wyvern.finaleStarted = true;
    s.stage = "wyvern-volley";
    s.stageTime = 0;
    s.strike = null;
    s.queuedMove = null;
    s.projectiles = [];
    s.wyvern.open = 0;
    s.qte = {
      kind: "timing",
      hits: 0,
      need: 1,
      left: 6,
      age: 0,
      lastTap: -10,
      success: false,
    };
    emit(s, "stage", { stage: s.stage });
  }
  if (s.wyvern.slamDone && s.hp <= s.maxHp * 0.04 && s.stage === "combat") {
    s.hp = s.maxHp * 0.04;
    s.stage = "wyvern-dive";
    s.stageTime = 0;
    s.strike = null;
    s.queuedMove = null;
    s.projectiles = [];
    s.qte = { kind: "timing", hits: 0, need: 1, left: 6, age: 0, lastTap: -10 };
    emit(s, "stage", { stage: s.stage });
  }
  return true;
}
export const TOWER = {
  x: -68,
  z: 42,
  radius: 17,
  height: 80,
  turns: 3,
  width: 3.6,
};
export const WYVERN_TOWER = Array.from({ length: 193 }, (_, i) => {
  const u = i / 192,
    a = -u * Math.PI * 2 * TOWER.turns;
  return {
    x: TOWER.x + Math.cos(a) * TOWER.radius,
    y: u * TOWER.height,
    z: TOWER.z + Math.sin(a) * TOWER.radius,
  };
});
export function runwayPoint(t, lane = 0) {
  const a = t * 0.008;
  const q = {
    x: Math.sin(a) * 48 + lane * 6 * Math.cos(a),
    y: 80 + Math.sin(t * 0.017) * 14 + t * 0.025,
    z: 42 - t * 0.22 + lane * 6 * Math.sin(a),
  };
  const u = Math.max(0, Math.min(1, (t - 420) / 60)),
    f = u * u * (3 - 2 * u);
  return {
    x: q.x * (1 - f),
    y: q.y * (1 - f) + 73 * f,
    z: q.z * (1 - f) + 9 * f,
  };
}
export function wyvernGround(x, z) {
  return Math.sin(x * 0.025) * Math.cos(z * 0.018) * 1.2;
}

export function wyvernBattleRing(s, index) {
  return {
    x: (index - 1) * 22,
    y: 62 + (index % 2) * 8,
    z: 36 + Math.sin(s.wyvern.cycle + index) * 4,
    id: "battle:" + (s.wyvern.cycle * 3 + index),
  };
}
