import { TitanAudio } from "./giganto-audio.js";
import { TitanBoostAudio } from "./titan-boost.js";
export class WyvernAudio extends TitanAudio {
  constructor(game) {
    super(game);
    this.musicVoices = new Set();
  }
  prepare(s) {
    if (!s?.config.battleTrack) {
      this.score?.dispose();
      this.score = null;
      return null;
    }
    return super.prepare(s);
  }
  stopMusic() {
    for (const n of this.musicVoices) {
      try {
        n.osc.stop();
      } catch {}
      n.osc.disconnect();
      n.gain.disconnect();
    }
    this.musicVoices.clear();
    this.origin = null;
  }
  pause(s) {
    super.pause(s);
    this.stopMusic();
  }
  frame(s, playing) {
    const a = this.game.audio,
      ctx = a.context,
      settings = this.settings(s);
    a.updateVolume();
    this.route(s);
    this.prepareMenu(s);
    if (this.lastSession !== s || this.lastAttempt !== (s.attempt || 0)) {
      this.stopEffects();
      this.stopMusic();
      this.seen.clear();
      this.lastSession = s;
      this.lastAttempt = s.attempt || 0;
      this.beat = 0;
    }
    if (!playing && this.playing !== false) {
      this.stopEffects();
      this.stopMusic();
    }
    this.playing = playing;
    if (ctx?.createBufferSource && this.bus) {
      this.boost ||= new TitanBoostAudio(ctx, this.bus);
      this.boost.update(s, playing, settings);
    }
    if (this.bus && ctx)
      this.bus.gain.setTargetAtTime(
        playing && s.config.audio ? (s.config.effectsVolume ?? 0.75) : 0,
        ctx.currentTime,
        0.03,
      );
    // User-supplied tracks use the existing decoded transport and editable cues.
    // Giganto's supplied recordings are deliberately never substituted for Wyvern.
    if (s.config.battleTrack) {
      const mapped = {
        ...s,
        stage: s.stage.startsWith("wyvern-") ? "combat" : s.stage,
      };
      super.prepare(mapped)?.update(mapped, playing, settings);
      s.battleMusic = mapped.battleMusic;
      this.stopMusic();
      return;
    }
    this.score?.dispose();
    this.score = null;
    if (
      !ctx ||
      !this.master ||
      !playing ||
      !s.config.audio ||
      !s.config.music ||
      settings.volume <= 0 ||
      settings.musicVolume <= 0
    ) {
      this.stopMusic();
      return;
    }
    if (!this.musicBus) {
      this.musicBus = ctx.createGain();
      this.musicBus.connect(this.master);
    }
    const fade = s.stage === "victory" ? Math.max(0, 1 - s.stageTime / 7) : 1;
    this.musicBus.gain.setTargetAtTime(
      (settings.musicVolume ?? 0.45) * fade,
      ctx.currentTime,
      0.1,
    );
    if (!fade || s.stage === "defeat") {
      this.stopMusic();
      return;
    }
    const phase = s.emerald ? s.phase : 0;
    const spacing = phase === 2 ? 0.205 : phase === 1 ? 0.235 : 0.48,
      now = ctx.currentTime;
    if (this.musicPhase !== phase) {
      this.musicPhase = phase;
      this.origin = null;
      this.beat = 0;
    }
    if (this.origin == null) {
      this.origin = ctx.currentTime - (s.wyvern.musicTime || 0);
      this.beat = Math.ceil((s.wyvern.musicTime || 0) / spacing);
    }

    if (this.origin + this.beat * spacing < now - 0.15) {
      this.origin = now;
      this.beat = 0;
    }
    while (this.origin + this.beat * spacing < now + 0.08) {
      const at = this.origin + this.beat * spacing,
        root = [73.416, 65.406, 87.307, 55][Math.floor(this.beat / 32) % 4],
        n = [0, 7, 12, 15, 12, 7, 10, 7][this.beat % 8];
      this.note(
        ctx,
        at,
        root * Math.pow(2, n / 12),
        phase ? "triangle" : "sine",
        0.045,
        spacing * 1.7,
      );
      if (phase && this.beat % 2 === 0)
        this.note(ctx, at, root / 2, "sine", 0.07, 0.15);
      this.beat++;
    }
  }
  note(ctx, at, hz, type, volume, duration) {
    if (this.musicVoices.size > 24) return;
    const osc = ctx.createOscillator(),
      gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(hz, at);
    gain.gain.setValueAtTime(0, at);
    gain.gain.linearRampToValueAtTime(volume, at + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, at + duration);
    osc.connect(gain);
    gain.connect(this.musicBus);
    const n = { osc, gain };
    this.musicVoices.add(n);
    osc.onended = () => {
      osc.disconnect();
      gain.disconnect();
      this.musicVoices.delete(n);
    };
    osc.start(at);
    osc.stop(at + duration + 0.02);
  }
  event(e) {
    if (e.type === "wyvern-explosion")
      return super.event({ ...e, type: "cinematic-cue", cue: "detonate" });
    if (e.type === "missile") return super.event({ ...e, type: "shot" });
    super.event(e);
  }
  silence() {
    this.stopMusic();
    this.musicBus?.disconnect();
    this.musicBus = null;
    super.silence();
  }
}
