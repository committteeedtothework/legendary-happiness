DCSMCRAFT 2.21.0 verification
989-test full unit suite passed; 62 affected checks rerun after final refinements. Five End/UI browser checks and eight Overworld/Titan regressions passed, with relevant UI reruns. Packaged Linux Electron offline save/relaunch/import/export, journals and both Titan entries passed. Windows payload verified; native Windows execution unverified.
Screenshots are actual staged in-game checkpoints. Practical content differences are in END-CITIES.md.
